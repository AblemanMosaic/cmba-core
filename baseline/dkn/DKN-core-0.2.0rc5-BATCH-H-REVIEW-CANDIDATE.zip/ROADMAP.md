# DKN work program — Batch F

A–E and RC2 self-review are retained predecessor evidence. Batch F implements the finite
LC-F1 lifecycle and optional cooperative transactional local vault, with models, schemas,
regression tests and executable workflow. Its exact measured results live in the current
release receipt, not in a promise of protocol-wide closure.

## F — bounded implementation delivered

Namespace policy precommitment; exact grants and revocations; possession-proved rotation;
separately endorsed guardian recovery; suspension; explicit epoch instances; visible forks;
reader pins/checkpoints/floors; verified SQLite snapshot storage and atomic local pin updates;
quiescent-index import; conformance corpus and model traceability. See docs/batch-f/.

## G — not started

Deterministic partition/equivocation/availability and shared-failure simulations for P2P,
corporate and federated assurance models. No simulation result becomes a live guarantee.
Keep the cryptographic kernel small and simulation optional. Treat LC-F1's 256-event bound
as an explicit test constraint, not an implicit infinite operational history.

## H — not started

Consolidated interoperability, target-platform/dependency replay, independent-review
handoff and a frozen release candidate. No silent expansion to a network service, universal
recovery engine or theorem prover. External review and operator acceptance remain gates.


## Batch G — finite distributed model delivered

DS-G1, 27 public scenarios, exact evidence joins, replay, fault domains and separate model binding are implemented. Batch H remains consolidated release/external-review readiness; live deployment and independent approval are not complete.

## Batch H — consolidation boundary (current distribution 0.2.0rc5)

A–H construction ends at a bounded frozen review candidate. No new operational protocol
profile is added. H preserves all G runtime and semantic contracts, repairs the conformance
test oracle, consolidates current documentation, and supplies context-bound replay tooling.
The next work is independent review and deployment/target-platform validation, not an
implicit Batch I feature expansion. See `docs/release/REVIEW-HANDOFF.md` for unclosed gates.
