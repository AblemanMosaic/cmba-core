"""Check semantic/realization binding references, never infer full semantic equivalence.

Input files are bounded local review artifacts. An optional executed test report must bind
this exact reviewed source tree; it remains unsigned engineering testimony.
"""
from __future__ import annotations
import argparse,ast,hashlib,json,sys
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT))
from dkn_v02.core import read_canonical,verify_dimension


def safe(root,name):
    p=PurePosixPath(name)
    if type(name) is not str or p.is_absolute() or '..' in p.parts or '\\' in name:
        raise ValueError('MODEL_REFERENCE_PATH')
    path=root/p
    if path.is_symlink() or root.resolve() not in path.resolve().parents:raise ValueError('MODEL_REFERENCE_CUSTODY')
    return path


def symbols(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return {n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}


def check(root=ROOT,report=None):
    findings=[]
    model=read_canonical((root/'model/v02/SEMANTIC-CONTRACT.json').read_bytes())
    commitment=read_canonical((root/'model/v02/SEMANTIC-COMMITMENT.json').read_bytes())
    binding=read_canonical((root/'model/v02/REALIZATION-BINDING.json').read_bytes())
    verify_dimension(commitment,model,supplied=True,supported_schemas={'dkn.semantic-contract.v1'})
    if binding['semantic_digest']!=commitment['digest_hex']:findings.append('SEMANTIC_BINDING_MISMATCH')
    for row in model['normative_references']+binding['source_files']:
        path=safe(root,row['path'])
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:findings.append('HASH_MISMATCH:'+row['path'])
    ids={row['id'] for row in model['obligations']}
    if len(ids)!=16 or {r['obligation'] for r in binding['traceability']}!=ids:findings.append('OBLIGATION_COVERAGE')
    if report is not None:
        from tools import verify_v02_candidate as runner
        old=runner.ROOT
        try:
            runner.ROOT=root
            if report.get('source_fingerprint')!=runner.source_fingerprint():findings.append('EXECUTED_SOURCE_MISMATCH')
        finally:runner.ROOT=old
    reference_count=0
    for row in binding['traceability']:
        if not row['implementation'] or not row['tests']:findings.append('EMPTY_TRACE:'+row['obligation'])
        for ref in row['implementation']+row['tests']:
            path,name=ref.split('::',1)
            if name not in symbols(safe(root,path)):findings.append('MISSING_SYMBOL:'+ref)
        for ref in row['tests']:
            reference_count+=1
            if report is not None:
                path,name=ref.split('::',1);base=path[:-3].replace('/','.')+'::'+name
                matches=[c for c in report.get('test_cases',[]) if c['id']==base or c['id'].startswith(base+'[')]
                if not matches or any(c['result']!='PASS' for c in matches):findings.append('TEST_NOT_ESTABLISHED:'+ref)
    return {'schema':'dkn.semantic-binding-check.v0.2-rc2','status':'PASS_REFERENCE_INTEGRITY' if not findings else 'FAIL',
            'semantic_digest':commitment['digest_hex'],'obligations':len(ids),'test_references':reference_count,
            'source_files':len(binding['source_files']),'normative_references':len(model['normative_references']),
            'executed_test_binding':'CHECKED' if report is not None else 'NOT_CHECKED',
            'findings':findings,'claim_ceiling':'HASH_SYMBOL_AND_RECORDED_TEST_TRACEABILITY_NOT_PROGRAM_EQUIVALENCE_PROOF',
            'authority_effect':'NONE'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
    r=check(report=json.loads(a.report.read_text()) if a.report else None)
    text=json.dumps(r,indent=2,sort_keys=True)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text);return 0 if not r['findings'] else 2
if __name__=='__main__':raise SystemExit(main())
