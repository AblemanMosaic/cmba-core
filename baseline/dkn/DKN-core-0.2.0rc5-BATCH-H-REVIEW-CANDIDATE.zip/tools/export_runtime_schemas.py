"""Export candidate input/report schemas; no schema downloads or network access."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02.runtime_schemas import SCHEMAS

def export():
    root=ROOT/'schemas/v02/runtime';root.mkdir(parents=True,exist_ok=True)
    for name,schema in SCHEMAS.items():
        (root/(name+'.schema.json')).write_text(json.dumps(schema,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    return len(SCHEMAS)

if __name__=='__main__':print(export())
