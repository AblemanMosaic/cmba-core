"""Read-only conformance TEST adapter, not an authorization service or new production ABI.

A replacement realization implements this small harness to replay the frozen corpus.
No code loading, filesystem paths, remote references or signing operations are accepted.
"""
from __future__ import annotations
import base64
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT/'src') not in sys.path:sys.path.insert(0,str(ROOT/'src'))
from dkn_v02 import core as c
from dkn_v02.navigation import inspect
from dkn_v02.lineage import analyze_lineage
from dkn_v02.sam_abi import dispatch


def raw(value):
    c.check(type(value) is str,'CONF_BASE64_INVALID')
    try:return base64.b64decode(value,validate=True)
    except (ValueError,TypeError) as exc:raise c.Refusal('CONF_BASE64_INVALID') from exc


def invoke(operation,a):
    c.check(type(operation) is str and type(a) is dict,'CONF_REQUEST_INVALID')
    if operation=='canonical':
        c.exact(a,{'raw_base64'});return {'canonical_base64':base64.b64encode(c.canonical(c.read_canonical(raw(a['raw_base64'])))).decode()}
    if operation=='dimension':
        c.exact(a,{'dimension_id','schema_id','value','critical'});return c.commit(**a)
    if operation=='verify-dimension':
        c.exact(a,{'item','value','supplied','supported_schemas'})
        allowed=a['supported_schemas'];c.check(allowed is None or (type(allowed) is list and all(type(x) is str for x in allowed)),'CONF_REQUEST_INVALID')
        return c.verify_dimension(a['item'],a['value'],supplied=a['supplied'],supported_schemas=None if allowed is None else set(allowed))
    if operation=='manifest':
        c.exact(a,{'files','dimensions'});c.check(type(a['files']) is dict,'CONF_REQUEST_INVALID')
        return c.build_manifest({p:raw(b) for p,b in a['files'].items()},a['dimensions'])
    if operation=='archive':
        c.exact(a,{'raw_base64'});return c.verify_archive(raw(a['raw_base64']))
    if operation=='certificate':
        c.exact(a,{'certificate','manifest'});return c.verify_certificate(**a)
    if operation=='genesis':
        c.exact(a,{'value'});return c.verify_genesis(a['value'])
    if operation=='lineage':
        c.exact(a,{'genesis','events'});return c.verify_transitions(**a)
    if operation=='forks':
        c.exact(a,{'genesis','chains'});return analyze_lineage(**a)
    if operation=='inspect':
        c.exact(a,{'raw_base64','certificate','relations','genesis','transitions'})
        return inspect(raw(a['raw_base64']),**{k:v for k,v in a.items() if k!='raw_base64'})
    if operation=='sam':
        c.exact(a,{'request'});return dispatch(a['request'])
    raise c.Refusal('CONF_OPERATION_UNSUPPORTED')


def execute(request):
    c.exact(request,{'schema','cases'})
    c.check(request['schema']=='dkn.conformance-request.v0.2-rc2','CONF_REQUEST_INVALID')
    c.check(type(request['cases']) is list and 1<=len(request['cases'])<=128,'CONF_LIMIT')
    seen=set();results=[]
    for item in request['cases']:
        c.exact(item,{'id','operation','arguments'});c.check(type(item['id']) is str and item['id'] not in seen,'CONF_REQUEST_INVALID');seen.add(item['id'])
        try:results.append({'id':item['id'],'outcome':'RETURNED','result':invoke(item['operation'],item['arguments'])})
        except c.Refusal as exc:results.append({'id':item['id'],'outcome':'REFUSED','code':exc.code})
    return {'schema':'dkn.conformance-response.v0.2-rc2','results':results,'authority_effect':'NONE'}


def main():
    try:result=execute(c.read_canonical(sys.stdin.buffer.read(c.MAX_META+1)));code=0
    except c.Refusal as exc:result={'outcome':'REFUSED','code':exc.code,'authority_effect':'NONE'};code=2
    sys.stdout.buffer.write(c.canonical(result));return code
if __name__=='__main__':raise SystemExit(main())
