"""Compare a selected local realization with a frozen, language-neutral behavior corpus.

--command is an explicit argv list, never evaluated through a shell. A candidate process
is trusted executable code: sandbox/approve it externally before choosing to run it.
"""
from __future__ import annotations
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dkn_v02.core import canonical,read_canonical

def run(command,corpus_path):
    material=corpus_path.read_bytes();corpus=read_canonical(material)
    requests={'schema':'dkn.conformance-request.v0.2-rc2','cases':[c['request'] for c in corpus['cases']]}
    expected={'schema':'dkn.conformance-response.v0.2-rc2','results':[c['expected'] for c in corpus['cases']],'authority_effect':'NONE'}
    failures=[]
    try:completed=subprocess.run(command,input=canonical(requests),capture_output=True,timeout=90,cwd=ROOT)
    except (OSError,subprocess.TimeoutExpired) as exc:
        completed=subprocess.CompletedProcess(command,124 if isinstance(exc,subprocess.TimeoutExpired) else 127,
            getattr(exc,'stdout',None) or b'',getattr(exc,'stderr',None) or str(exc).encode())
        failures.append({'error':'PROCESS_UNAVAILABLE_OR_TIMEOUT','type':type(exc).__name__})
    decoded=False
    try:
        actual=read_canonical(completed.stdout);decoded=True
    except Exception as exc:actual=None;failures.append({'error':'RESPONSE_NOT_CANONICAL','type':type(exc).__name__})
    if completed.returncode!=0:failures.append({'error':'PROCESS_EXIT','code':completed.returncode})
    # Python equality aliases True/1 and False/0; conformance requires exact typed bytes.
    if decoded and completed.stdout!=canonical(expected):
        rows=actual.get('results',[]) if type(actual) is dict else []
        returned={r['id']:r for r in rows if type(r) is dict and type(r.get('id')) is str} if type(rows) is list else {}
        for exp in expected['results']:
            if exp['id'] not in returned or canonical(returned[exp['id']])!=canonical(exp):failures.append({'error':'CASE_MISMATCH','id':exp['id']})
        if not failures:failures.append({'error':'ENVELOPE_MISMATCH'})
    return {'schema':'dkn.conformance-run.v0.2-rc2','status':'PASS' if not failures else 'FAIL',
            'corpus_sha256':hashlib.sha256(material).hexdigest(),'cases':len(corpus['cases']),
            'command':command,'exit_code':completed.returncode,'failures':failures,
            'comparison':'EXACT_CANONICAL_RESPONSE_BYTES',
            'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(),
            'stderr_sha256':hashlib.sha256(completed.stderr).hexdigest(),
            'claim_ceiling':'FROZEN_CORPUS_AGREEMENT_NOT_PROOF_OF_ALL_INPUT_EQUIVALENCE',
            'authority_effect':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--corpus',type=Path,default=ROOT/'interop/portable-conformance-rc2.json')
    p.add_argument('--out',type=Path);p.add_argument('--command',nargs=argparse.REMAINDER)
    a=p.parse_args();command=a.command or [sys.executable,str(ROOT/'tools/reference_conformance.py')]
    r=run(command,a.corpus)
    if a.out:a.out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(r,sort_keys=True));return 0 if r['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
