# Invoke explicitly in an existing reviewed environment. Does not install or publish.
param(
  [Parameter(Mandatory=$true)][string]$EvidenceDir,
  [string]$Python = "python",
  [switch]$RequireLegacy
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Push-Location $Root
try {
  foreach ($Phase in @("tests", "examples", "audit", "assemble")) {
    $Arguments = @("tools/verify_batch_h.py", "--out", $EvidenceDir, "--phase", $Phase)
    if ($RequireLegacy) { $Arguments += "--require-legacy" }
    & $Python @Arguments
    if ($LASTEXITCODE -ne 0) { throw "DKN H phase $Phase refused or failed: $LASTEXITCODE" }
  }
} finally { Pop-Location }
