"""Portable scoped candidate runner; never invents a Windows or independent PASS.

Runs v0.2 tests and examples, records actual environment, and separately reports
legacy dependency availability. --require-legacy makes that prerequisite gating.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import shutil
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ('v02_publish_verify.py','v02_navigate.py','v02_assurance.py','v02_end_to_end.py','v02_reader_policy.py','v02_lifecycle_vault.py','v02_distributed_simulation.py')


def source_fingerprint():
    rows=[]
    for folder in ('src','tests','tests_v02','tools','interop','schemas','examples','vectors','profiles','docs','design-v0.2','model','META','release'):
        for path in sorted((ROOT/folder).rglob('*')):
            if path.is_file() and not any(part in ('__pycache__','.pytest_cache') or part.endswith('.egg-info') for part in path.parts) and not path.name.endswith(('.pyc','.pyo')):
                rows.append((path.relative_to(ROOT).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest()))
    for name in ('pyproject.toml','README.md','SECURITY.md','NOTICE','LICENSE','ROADMAP.md','requirements-v02-dev.txt','requirements-v02-tested.txt'):
        if (ROOT/name).is_file():
            rows.append((name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()))
    return hashlib.sha256(json.dumps(sorted(rows),separators=(',',':')).encode()).hexdigest()


def bounded_run(command, env, timeout):
    try:
        return subprocess.run(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,
                              capture_output=True,text=True,timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        def text(value):return value.decode('utf-8','replace') if isinstance(value,bytes) else (value or '')
        return subprocess.CompletedProcess(command,124,text(exc.stdout),text(exc.stderr)+'\nRUNNER_TIMEOUT\n')
    except OSError as exc:
        return subprocess.CompletedProcess(command,127,'',type(exc).__name__+': '+str(exc))


def execute(out: Path, require_legacy=False, phase='all'):
    out.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, 'PYTHONPATH': os.pathsep.join((str(ROOT/'src'), str(ROOT))),
           'PYTHONDONTWRITEBYTECODE': '1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'}
    fingerprint=source_fingerprint()
    def stage_write(name, value):
        value['source_fingerprint']=fingerprint
        (out/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    def stage_read(name):
        value=json.loads((out/(name+'.json')).read_text(encoding='utf-8'))
        if value['source_fingerprint']!=fingerprint:raise ValueError('STAGE_SOURCE_CHANGED')
        return value
    xml=out/'v02-tests.xml'
    if phase in ('all','tests'):
        for stale in ('TEST-STAGE.json','LOCAL-RUN.json'):
            (out/stale).unlink(missing_ok=True)
        xml.unlink(missing_ok=True)
        cmd=[sys.executable,'-m','pytest','-q','tests_v02','-p','no:cacheprovider','--junitxml='+str(xml)]
        print('Running v0.2 test stage',file=sys.stderr,flush=True)
        p=bounded_run(cmd,env,180)
        (out/'v02-tests.stdout.txt').write_text(p.stdout,encoding='utf-8')
        (out/'v02-tests.stderr.txt').write_text(p.stderr,encoding='utf-8')
        stage_write('TEST-STAGE',{'exit_code':p.returncode,'xml_sha256':hashlib.sha256(xml.read_bytes()).hexdigest() if xml.exists() else None,
            'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(), 'stderr_sha256':hashlib.sha256(p.stderr.encode()).hexdigest()})
        if phase=='tests':return {'phase':'tests','exit_code':p.returncode,'source_fingerprint':fingerprint},p.returncode==0
    if phase in ('all','examples'):
        for stale in ('EXAMPLE-STAGE.json','LOCAL-RUN.json'):(out/stale).unlink(missing_ok=True)
        examples=[]
        for name in EXAMPLES:
            print('Running '+name,file=sys.stderr,flush=True)
            run=bounded_run([sys.executable,str(ROOT/'examples'/name)],env,30)
            (out/(name+'.stdout.txt')).write_text(run.stdout,encoding='utf-8')
            (out/(name+'.stderr.txt')).write_text(run.stderr,encoding='utf-8')
            examples.append({'path':'examples/'+name,'exit_code':run.returncode,'status':'PASS' if run.returncode==0 else 'FAIL',
                'stdout_sha256':hashlib.sha256(run.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr.encode()).hexdigest()})
        legacy={'status':'BLOCKED','reason':'BLAKE3_NOT_INSTALLED','tests_passed':None}
        if importlib.util.find_spec('blake3') is not None:
            run=bounded_run([sys.executable,'-m','unittest','discover','-s','tests','-v'],env,90)
            (out/'legacy-tests.stdout.txt').write_text(run.stdout,encoding='utf-8')
            (out/'legacy-tests.stderr.txt').write_text(run.stderr,encoding='utf-8')
            match=re.search(r'Ran ([0-9]+) tests?',run.stderr)
            count=int(match.group(1)) if match else 0
            legacy={'status':'PASS' if run.returncode==0 and count>0 else 'FAIL','exit_code':run.returncode,
                    'tests_run':count,'stdout_sha256':hashlib.sha256(run.stdout.encode()).hexdigest(),
                    'stderr_sha256':hashlib.sha256(run.stderr.encode()).hexdigest()}
        stage_write('EXAMPLE-STAGE',{'examples':examples,'legacy_runtime':legacy})
        if phase=='examples':return {'phase':'examples','examples':examples,'legacy_runtime':legacy},all(x['status']=='PASS' for x in examples) and legacy['status']!='FAIL' and (not require_legacy or legacy['status']=='PASS')
    test_stage=stage_read('TEST-STAGE');example_stage=stage_read('EXAMPLE-STAGE')
    if not xml.exists() or hashlib.sha256(xml.read_bytes()).hexdigest()!=test_stage['xml_sha256']:raise ValueError('TEST_XML_CHANGED')
    cases=[]
    for case in ET.parse(xml).iter('testcase'):
        result='FAIL' if case.find('failure') is not None else ('ERROR' if case.find('error') is not None else ('SKIP' if case.find('skipped') is not None else 'PASS'))
        cases.append({'id':case.attrib.get('classname','')+'::'+case.attrib.get('name',''),'result':result})
    examples=example_stage['examples'];legacy=example_stage['legacy_runtime']
    if [e['path'] for e in examples] != ['examples/'+n for n in EXAMPLES]:raise ValueError('EXAMPLE_STAGE_INCOMPLETE')
    for example in examples:
        for stream in ('stdout','stderr'):
            path=out/(Path(example['path']).name+'.'+stream+'.txt')
            if hashlib.sha256(path.read_bytes()).hexdigest()!=example[stream+'_sha256']:raise ValueError('EXAMPLE_LOG_CHANGED')
    for stream in ('stdout','stderr'):
        path=out/('v02-tests.'+stream+'.txt')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=test_stage[stream+'_sha256']:raise ValueError('TEST_LOG_CHANGED')
        if legacy['status']!='BLOCKED':
            path=out/('legacy-tests.'+stream+'.txt')
            if hashlib.sha256(path.read_bytes()).hexdigest()!=legacy[stream+'_sha256']:raise ValueError('LEGACY_LOG_CHANGED')
    p=subprocess.CompletedProcess([],test_stage['exit_code'])
    dependencies={}
    for name in ('cryptography','jsonschema','pytest','blake3'):
        try:dependencies[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:dependencies[name]='NOT_INSTALLED'
    okay=p.returncode==0 and bool(cases) and all(c['result']=='PASS' for c in cases) and all(e['status']=='PASS' for e in examples)
    if legacy['status']=='FAIL' or (require_legacy and legacy['status']!='PASS'):okay=False
    report={'schema':'dkn.batch-h-local-run.v0.2-rc5',
            'status':'PASS_SCOPED_LOCAL_ENGINEERING' if okay else 'INCOMPLETE_OR_FAILED',
            'source_fingerprint':fingerprint,'pytest_external_plugin_autoload':'DISABLED',
            'platform':{'system':platform.system(),'release':platform.release(),
                        'machine':platform.machine(),'python':platform.python_version()},
            'dependencies':dependencies,'v02_test_exit_code':p.returncode,
            'v02_tests':len(cases),'v02_passed':sum(c['result']=='PASS' for c in cases),
            'batch_h_tests':sum('test_batch_h_' in c['id'] for c in cases),
            'batch_g_tests':sum('test_batch_g_' in c['id'] for c in cases),
            'batch_f_tests':sum('test_batch_f_' in c['id'] for c in cases),
            'batch_d_tests':sum('test_batch_d_' in c['id'] for c in cases),
            'batch_e_tests':sum('test_batch_e_' in c['id'] for c in cases),
            'cross_language':{'implementation':'Node.js built-ins, separately written byte/signature checker',
                'node_version':bounded_run(['node','--version'],env,10).stdout.strip() if shutil.which('node') else 'NOT_AVAILABLE',
                'cases':sum('test_batch_e_interop' in c['id'] for c in cases),
                'passed':sum('test_batch_e_interop' in c['id'] and c['result']=='PASS' for c in cases),
                'scope':'CANONICAL_BYTES_HASHES_ED25519_NOT_FULL_PROTOCOL',
                'rust':'NOT_AVAILABLE' if shutil.which('rustc') is None else 'NOT_RUN',
                'independent_crypto_implementation':False},
            'test_cases':cases,'examples':examples,'legacy_runtime':legacy,
            'public_release_gate':'NOT_CLEARED',
            'cross_platform':'NOT_ESTABLISHED','independent_review':'NOT_PERFORMED',
            'publication':'NOT_PERFORMED','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}
    (out/'LOCAL-RUN.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    return report, okay


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,required=True,help='Write evidence to a new or controlled directory')
    p.add_argument('--require-legacy',action='store_true')
    p.add_argument('--phase',choices=('all','tests','examples','assemble'),default='all')
    a=p.parse_args()
    report,okay=execute(a.out.resolve(),a.require_legacy,a.phase)
    print(json.dumps({k:v for k,v in report.items() if k!='test_cases'},sort_keys=True))
    return 0 if okay else 2


if __name__=='__main__':raise SystemExit(main())
