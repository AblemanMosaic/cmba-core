"""Explicit authoring tool: updates model/source commitments. Verification NEVER calls it.

Changing a model and regenerating its commitment produces a different contract. It does
not grant acceptance of that contract. Only frozen reviewed files belong in a release.
"""
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02.core import canonical, commit

def build(root=ROOT):
    base=json.loads((root/'model/v02/SEMANTIC-COMMITMENT.json').read_bytes())
    obligations=[
    ('Precommitted policy','Policy digest is bound in signed genesis; no retroactive guardian takeover.',
     ['lifecycle::lifecycle_anchor'],['lifecycle::test_no_retroactive_policy_or_recovery','lifecycle::test_recovery_disabled_is_explicit']),
    ('Exact direct delegation','Controller grants exact artifact, subject, operations and half-open interval. No wildcard or subdelegation.',
     ['lifecycle::_payload','lifecycle::assess_delegation'],['lifecycle::test_scope_does_not_widen','lifecycle::test_no_subdelegation','lifecycle::test_expiry_boundaries']),
    ('Revocation and epoch invalidation','Revoked grants/keys and prior epoch grants cannot match the pinned supplied view; suspension invalidates grants.',
     ['lifecycle::_apply_payload'],['lifecycle::test_revoke_and_omission_require_pinned_head','lifecycle::test_suspend_resume_never_revives_grants','lifecycle::test_epoch_invalidation_survives_recovery_and_new_grant']),
    ('Possession and recovery','Rotation needs both keys; recovery needs precommitted unique guardian threshold and new-key possession. Separate signatures are supported.',
     ['lifecycle::_replay','lifecycle::assemble_event'],['lifecycle::test_bad_recovery_proofs','lifecycle::test_rotation_requires_possession_and_invalidates_grants','lifecycle::test_separate_custodian_endorsements_need_no_private_key_aggregation']),
    ('Stable root, scoped instances, visible forks','Root persists; epoch instances change on control transition; supplied competing branches are preserved without automatic choice.',
     ['lifecycle::verify_journal','lifecycle::analyze_journals'],['interfaces::test_epoch_instance_stable_within_epoch_changes_on_rotation','lifecycle::test_forks_are_preserved_not_selected']),
    ('Reader pins and freshness boundary','Exact root/head, valid checkpoint window and optional ancestor floor; no claim about unseen records or external trusted time.',
     ['lifecycle::assess_delegation'],['lifecycle::test_prefix_floor_blocks_longer_alternate_fork','lifecycle::test_missing_checkpoint_is_indeterminate','lifecycle::test_bad_checkpoints']),
    ('Certificate and payload joining','Certificate assessment binds actual signer, exact manifest and fixed operation; archive inspection checks the actual payload; authority remains external.',
     ['lifecycle::assess_certificate','lifecycle::inspect_with_lifecycle'],['lifecycle::test_exact_delegate_and_certificate_inspection','lifecycle::test_certificate_cannot_override_subject_or_operation','lifecycle::test_actor_identity_does_not_become_authority']),
    ('Atomic local writes and snapshots','Cooperative SQLite clients see one committed revision; failed writes do not leave partial rows/revision. Process-exit recovery is bounded local evidence.',
     ['vault::TransactionalVault'],['vault::test_transaction_rollback_no_partial_revision','vault::test_reader_sees_old_snapshot_until_commit','vault::test_competing_writers_serialize','vault::test_process_exit_before_commit_recovers']),
    ('Explicit pin continuity','Only explicit compare-and-swap with exact supplied ancestry advances a stored local pin. A concurrent branch loses rather than overwriting.',
     ['vault::advance_namespace','vault::read_namespace'],['vault::test_namespace_cas_and_ancestry','vault::test_two_namespace_writers_only_one_wins','vault::test_read_does_not_advance_namespace_pin']),
    ('Verified reads and import','Stored artifacts/journals reverify; quiescent source import is all-or-nothing and non-destructive. Damage is not empty successful discovery.',
     ['vault::_verified','vault::import_local_index'],['vault::test_corrupt_record_not_empty_or_verified','vault::test_namespace_storage_tampering_reverified','vault::test_directory_import_atomic_and_non_destructive','vault::test_import_rolls_back_all_entries']),
    ('Bounded and explicit interfaces','Finite journal, storage and report limits; closed ABI/schema; signature validity and schema shape never authorize effects.',
     ['lifecycle::verify_journal','lifecycle_abi::dispatch','vault::TransactionalVault'],['lifecycle::test_resource_bound','vault::test_bounded_snapshot_and_storage','interfaces::test_malformed_abi_inputs_typed','interfaces::test_assessment_cannot_promote_authority']),
    ('Replaceable realization evidence','Frozen schemas/vectors/corpus and model bind intended finite observables. Test traceability is not whole-program equivalence or independent approval.',
     ['lifecycle_schemas::validate_shape'],['interfaces::test_frozen_lifecycle_corpus','interfaces::test_node_checks_new_domain_hash_and_every_signature','binding::test_extension_model_and_realization_bindings'])]
    model={'schema':'dkn.lifecycle-contract.v1','profile':'dkn.lifecycle.v0.2-f1','base_semantic_digest':base['digest_hex'],
        'authority_effect':'NONE','obligations':[{'id':f'F-{i:02d}','title':o[0],'realized_guarantee':o[1]} for i,o in enumerate(obligations,1)],
        'explicit_exclusions':['global currentness or live revocation','network service or consensus','automatic capability grants or trust bootstrap','unbounded journals','guardian policy amendment','subdelegation','hostile operating-system custody','physical power failure validation','whole-database rollback protection without external floor','private-key persistence or secret scrubbing','full program equivalence or independent approval'],
        'normative_references':[]}
    paths=['docs/batch-f/LIFECYCLE-PROTOCOL.md','docs/batch-f/VAULT-CONTRACT.md',
           'vectors/v02/lifecycle-f1.json','interop/lifecycle-f1-conformance.json']
    paths += [p.relative_to(root).as_posix() for p in (root/'schemas/v02/lifecycle-f1').glob('*.json')]
    def records(paths):return [{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sorted(set(paths))]
    model['normative_references']=records(paths)
    commitment=commit('lifecycle-contract','dkn.lifecycle-contract.v1',model)
    sources=['src/dkn_v02/'+s+'.py' for s in ('lifecycle','vault','lifecycle_schemas','lifecycle_abi','lifecycle_cli')]
    sources += [p.relative_to(root).as_posix() for p in (root/'tests_v02').glob('test_batch_f*.py')]
    sources += ['tools/'+s+'.py' for s in ('build_lifecycle_contract','check_lifecycle_contract','build_lifecycle_vectors','export_lifecycle_schemas','reference_lifecycle_conformance','build_batch_f_candidate','verify_installed_f')]
    sources += ['pyproject.toml','tools/verify_v02_candidate.py','examples/v02_lifecycle_vault.py']
    trace=[]
    for i,o in enumerate(obligations,1):
        impl=['src/dkn_v02/'+m+'.py::'+n for m,n in (s.split('::') for s in o[2])]
        tests=['tests_v02/test_batch_f_'+m+'.py::'+n for m,n in (s.split('::') for s in o[3])]
        trace.append({'obligation':f'F-{i:02d}','implementation':impl,'tests':tests})
    binding={'schema':'dkn.lifecycle-realization-binding.v1','distribution_version':'0.2.0rc3','semantic_digest':commitment['digest_hex'],
             'authority_effect':'NONE','source_files':records(sources),'traceability':trace,
             'claim_ceiling':'TRACEABLE_REALIZATION_NOT_FORMAL_REFINEMENT_PROOF'}
    folder=root/'model/lifecycle-f1';folder.mkdir(exist_ok=True)
    for name,v in [('CONTRACT',model),('COMMITMENT',commitment),('REALIZATION-BINDING',binding)]:
        (folder/(name+'.json')).write_bytes(canonical(v))
    # Only the base realization binding changes; the base semantic model/commitment remain untouched.
    p=root/'model/v02/REALIZATION-BINDING.json';v=json.loads(p.read_bytes());v['distribution_version']='0.2.0rc3'
    v['source_files']=records([r['path'] for r in v['source_files']]);p.write_bytes(canonical(v))
    return {'semantic_digest':commitment['digest_hex'],'obligations':len(obligations),'source_files':len(sources)}
if __name__=='__main__':print(json.dumps(build(),sort_keys=True))
