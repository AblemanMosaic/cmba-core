"""Validate acceptance references against an actual test report, without promoting rows."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def audit(report):
    matrix=json.loads((ROOT/'design-v0.2/acceptance/MATRIX.json').read_text())
    cases=report['test_cases']; findings=[]; matched=0
    for row in matrix['cases']:
        for ref in row.get('test_refs',[]):
            module,name=ref.split('::',1)
            matches=[c for c in cases if c['id'].startswith('tests_v02.'+module+'::'+name)
                     and (c['id'].split('::',1)[1]==name or c['id'].split('::',1)[1].startswith(name+'['))]
            if not matches:findings.append({'id':row['id'],'ref':ref,'error':'NO_EXECUTED_CASE'})
            elif any(c['result']!='PASS' for c in matches):findings.append({'id':row['id'],'ref':ref,'error':'CASE_NOT_PASS'})
            matched+=len(matches)
    counts={}
    for r in matrix['cases']:counts[r['execution']]=counts.get(r['execution'],0)+1
    return {'schema':'dkn.acceptance-audit.v0.2-batch-e','status':'PASS' if not findings else 'FAIL',
            'rows':len(matrix['cases']),'referenced_executions_with_reuse':matched,'row_statuses':counts,
            'findings':findings,'claim_ceiling':'Reference integrity only; explicit row scopes remain binding.',
            'authority_effect':'NONE'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path,required=True);p.add_argument('--out',type=Path)
    a=p.parse_args();result=audit(json.loads(a.report.read_text()));encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if a.out:a.out.write_text(encoded,encoding='utf-8')
    print(encoded);raise SystemExit(0 if result['status']=='PASS' else 2)
