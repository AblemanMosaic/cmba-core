"""Local release verification; engineering evidence, never publication authority."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from dkn_core.archive import verify_portable_archive
from dkn_core.canonical import canonical_bytes
from tools.build_release import ARCHIVE_NAME, build_release_bytes, collect_payloads
from tools.build_vectors import build_vectors


def verify(source: Path, archive: Path | None = None) -> dict:
    payloads = collect_payloads(source)
    expected_vectors = canonical_bytes(build_vectors()) + b"\n"
    vector_path = source / "vectors" / "golden-vectors.json"
    if vector_path.read_bytes() != expected_vectors:
        raise ValueError("DKN_GOLDEN_VECTORS_STALE")
    env = dict(os.environ)
    env["PYTHONPATH"] = str(source / "src")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=source, env=env, capture_output=True, text=True,
    )
    if completed.returncode != 0:
        raise ValueError("DKN_TESTS_FAILED\n" + completed.stdout + completed.stderr)
    test_match = re.search(r"Ran (\d+) tests?", completed.stdout + completed.stderr)
    if test_match is None:
        raise ValueError("DKN_TEST_COUNT_UNAVAILABLE")
    unit_test_count = int(test_match.group(1))
    first = build_release_bytes(source)
    second = build_release_bytes(source)
    if first != second:
        raise ValueError("DKN_RELEASE_NONDETERMINISTIC")
    package = verify_portable_archive(first)
    archive_match = None
    if archive is not None:
        supplied = archive.read_bytes()
        verify_portable_archive(supplied)
        archive_match = supplied == first
        if not archive_match:
            raise ValueError("DKN_RELEASE_ARCHIVE_MISMATCH")
    return {
        "schema": "dkn.release-verification.v0.1",
        "status": "PASS_LOCAL_ENGINEERING_EVIDENCE",
        "public_version": "v0.1",
        "engineering_revision": "r002",
        "source_file_count": len(payloads),
        "unit_test_count": unit_test_count,
        "unit_tests_status": "PASS",
        "golden_vectors_sha256": hashlib.sha256(expected_vectors).hexdigest(),
        "two_builds_byte_identical": True,
        "archive_match": archive_match,
        "archive_verification": package,
        "execution_context": {
            "host_family": "WINDOWS",
            "filesystem_class": "WINDOWS_NATIVE",
            "python_version": sys.version.split()[0],
        },
        "portability": {
            "windows_native": "PASS",
            "wsl_native": "NOT_PERFORMED",
            "cross_platform_claim": "NOT_ESTABLISHED",
        },
        "independent_review": "NOT_PERFORMED",
        "publication": "NOT_PERFORMED",
        "standing": "INFORMATION_ONLY",
        "authority_effect": "NONE",
        "real_a5": False,
        "g0": "CLOSED",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=ROOT)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.source.resolve(), args.archive.resolve() if args.archive else None)
    except Exception as error:
        print(json.dumps({"status": "REFUSED", "code": str(error)}, sort_keys=True),
              file=sys.stderr)
        return 2
    raw = canonical_bytes(result) + b"\n"
    if args.out:
        if args.out.exists() and args.out.read_bytes() != raw:
            print("DKN_VERIFICATION_RECEIPT_EXISTS_DIFFERENT", file=sys.stderr)
            return 2
        if not args.out.exists():
            args.out.write_bytes(raw)
    sys.stdout.buffer.write(raw)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

