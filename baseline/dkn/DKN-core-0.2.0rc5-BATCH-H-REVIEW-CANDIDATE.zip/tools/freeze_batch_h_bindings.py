"""Explicit authoring step: renew implementation bindings, never redefine accepted models.

Verification does NOT call this tool. Run only after reviewing source changes. The
six baseline semantic files and all inherited runtime files must remain exact.
"""
import json
import hashlib
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02 import canonical
from tools.release_gate import audit_static

def freeze(root=ROOT):
    check=audit_static(root)
    if check['status']!='PASS':raise ValueError(check['findings'])
    for name in ('v02','lifecycle-f1','distributed-g1'):
        p=root/'model'/name/'REALIZATION-BINDING.json';value=json.loads(p.read_bytes())
        value['distribution_version']='0.2.0rc5'
        for row in value['source_files']:
            row['sha256']=hashlib.sha256((root/row['path']).read_bytes()).hexdigest()
        p.write_bytes(canonical(value))
    return {'status':'REALIZATION_BINDINGS_REFRESHED','semantic_files_changed':0,
            'authority_effect':'NONE','approval':'NOT_GRANTED'}
if __name__=='__main__':print(json.dumps(freeze(),sort_keys=True))
