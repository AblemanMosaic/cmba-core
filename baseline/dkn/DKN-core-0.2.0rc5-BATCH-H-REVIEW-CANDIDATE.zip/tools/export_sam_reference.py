"""Export reviewable schemas, profile templates, and deterministic fixture vectors.

Run from source root: PYTHONPATH=src:. python tools/export_sam_reference.py
No production secret material is used or written.
"""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'src'), str(ROOT)]
from dkn_v02.sam_schemas import SCHEMAS, PROFILES, V
from dkn_v02.reference_profiles import reference_profile
from dkn_v02.core import canonical
from dkn_v02.assurance import evaluate, compose
from dkn_v02.federation import assess_checkpoints, make_handoff
from examples.v02_assurance import fixture_bundle


def build_vectors():
    b = fixture_bundle()
    arguments = {k: b[k] for k in ('descriptor', 'contract', 'evidence', 'policy', 'context')}
    return {'schema': 'dkn.sam-fixture-vectors.'+V, 'fixture_only': True,
            'evaluation_request': {'schema': 'dkn.sam-request.'+V, 'operation': 'evaluate', 'arguments': arguments},
            'evaluation_result': evaluate(**arguments),
            'composition_result': compose([b['descriptor']], roots=[b['descriptor']['record_hash']], at_time=1000),
            'checkpoint_policy': b['checkpoint_policy'], 'checkpoints': b['checkpoints'],
            'checkpoint_result': assess_checkpoints(b['checkpoints'], b['checkpoint_policy'], at_time=1000),
            'handoff_result': make_handoff(b['checkpoints'], b['checkpoint_policy'], at_time=1000, consumer='CHC')}


def export():
    for name, schema in SCHEMAS.items():
        p = ROOT/'schemas/v02'/('sam-'+name+'.schema.json'); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(schema, sort_keys=True, indent=2)+'\n', encoding='utf-8')
    for name in PROFILES:
        p = ROOT/'profiles/v02'/(name.lower()+'.json'); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(canonical(reference_profile(name)))
    vectors = build_vectors()
    (ROOT/'vectors/v02-sam-vectors.json').write_bytes(canonical(vectors))
    (ROOT/'examples/v02-sam-request.json').write_bytes(canonical(vectors['evaluation_request']))


if __name__ == '__main__':
    export()
    print('Exported 9 schemas, 6 profiles, fixture vectors, and a CLI request.')
