"""Deterministic schema export from the installed runtime's local definitions."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dkn_v02.lifecycle_schemas import SCHEMAS

def export():
    target=ROOT/'schemas/v02/lifecycle-f1';target.mkdir(parents=True,exist_ok=True)
    for name,value in SCHEMAS.items():
        (target/(name+'.schema.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    return len(SCHEMAS)

if __name__=='__main__':print(export())
