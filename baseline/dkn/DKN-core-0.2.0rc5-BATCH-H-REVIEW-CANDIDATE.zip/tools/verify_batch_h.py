"""Explicit staged Batch H replay. All work is local; no external review is invoked.

Phases: tests, examples, audit, assemble. --require-legacy is an actual gate, never a mock.
Context/source and exact stage outputs are bound; the caller must still trust the runner.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from tools import verify_v02_candidate as runner
from tools import release_gate as gate


def context():
    deps={}
    for name in ('cryptography','jsonschema','pytest','blake3','setuptools'):
        try: deps[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError: deps[name]='NOT_INSTALLED'
    node='NOT_AVAILABLE'
    if shutil.which('node'):
        node=subprocess.run(['node','--version'],capture_output=True,text=True,timeout=10,check=True).stdout.strip()
    return {'python_executable':str(Path(sys.executable).resolve()),'python':platform.python_version(),
            'prefix':sys.prefix,'system':platform.system(),'release':platform.release(),
            'machine':platform.machine(),'sqlite':sqlite3.sqlite_version,'node':node,'dependencies':deps,
            'pytest_plugin_autoload':'DISABLED'}


def write(path,value):
    path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n',encoding='utf-8')


def seal_stage(out,phase,start,ctx,okay,paths):
    end=runner.source_fingerprint()
    if start!=end: raise ValueError('RELEASE_SOURCE_CHANGED_DURING_STAGE')
    if context()!=ctx: raise ValueError('RELEASE_CONTEXT_CHANGED_DURING_STAGE')
    rows=[{'path':p,'sha256':gate.digest(out/p)} for p in sorted(paths)]
    result={'schema':'dkn.release-stage.v0.2-h1','stage':phase,'source_fingerprint':start,
            'context':ctx,'status':'PASS' if okay else 'FAIL','outputs':rows,'authority_effect':'NONE'}
    write(out/('H-'+phase.upper()+'.json'),result)
    return result


def read_stage(out,phase,fp):
    stage=gate.read_json(out/('H-'+phase.upper()+'.json'))
    if stage['stage']!=phase or stage['source_fingerprint']!=fp:
        raise ValueError('RELEASE_STAGE_SOURCE_MISMATCH')
    for row in stage['outputs']:
        p=Path(row['path'])
        if p.is_absolute() or len(p.parts)!=1 or p.name!=row['path']:
            raise ValueError('RELEASE_STAGE_PATH')
        if gate.digest(out/p)!=row['sha256']:
            raise ValueError('RELEASE_STAGE_OUTPUT_CHANGED:'+row['path'])
    return stage


def execute(out:Path,phase:str,require_legacy=False):
    out=out.resolve();out.mkdir(parents=True,exist_ok=True)
    start=runner.source_fingerprint();ctx=context()
    if phase in ('tests','examples'):
        (out/'H-REVIEW.json').unlink(missing_ok=True)
        (out/('H-'+phase.upper()+'.json')).unlink(missing_ok=True)
        result,okay=runner.execute(out,require_legacy=require_legacy,phase=phase)
        if phase=='tests':
            paths=['TEST-STAGE.json','v02-tests.xml','v02-tests.stdout.txt','v02-tests.stderr.txt']
        else:
            paths=['EXAMPLE-STAGE.json']+[n+'.'+s+'.txt' for n in runner.EXAMPLES for s in ('stdout','stderr')]
            if (out/'legacy-tests.stdout.txt').exists(): paths+=['legacy-tests.stdout.txt','legacy-tests.stderr.txt']
        seal_stage(out,phase,start,ctx,okay,paths)
        return result,okay
    if phase=='audit':
        (out/'H-REVIEW.json').unlink(missing_ok=True)
        read_stage(out,'tests',start);read_stage(out,'examples',start)
        report,okay=runner.execute(out,require_legacy=require_legacy,phase='assemble')
        from tools import check_semantic_contract,check_lifecycle_contract,check_distributed_contract
        from tools import audit_acceptance,check_native_crypto,run_conformance
        results={'RUN-CHECK':gate.check_run(report,out/'v02-tests.xml',start,runner.EXAMPLES),
                 'STATIC':gate.audit_static(),
                 'BASE-MODEL':check_semantic_contract.check(report=report),
                 'LC-MODEL':check_lifecycle_contract.check(report=report),
                 'DS-MODEL':check_distributed_contract.check(report=report),
                 'ACCEPTANCE':audit_acceptance.audit(report),'NATIVE-CRYPTO':check_native_crypto.run()}
        for label,corpus,adapter in (
            ('BASE-CONFORMANCE','portable-conformance-rc2.json','reference_conformance.py'),
            ('LC-CONFORMANCE','lifecycle-f1-conformance.json','reference_lifecycle_conformance.py'),
            ('DS-CONFORMANCE','distributed-g1-conformance.json','reference_distributed_conformance.py')):
            results[label]=run_conformance.run([sys.executable,str(ROOT/'tools'/adapter)],ROOT/'interop'/corpus)
        for label,value in results.items(): write(out/(label+'.json'),value)
        okay=okay and all(v.get('status') in ('PASS','PASS_REFERENCE_INTEGRITY') for v in results.values())
        paths=['LOCAL-RUN.json']+[k+'.json' for k in results]
        seal_stage(out,phase,start,ctx,okay,paths)
        return {'phase':'audit','status':'PASS' if okay else 'FAIL','legs':{k:v['status'] for k,v in results.items()}},okay
    if phase!='assemble': raise ValueError('RELEASE_PHASE')
    stages=[read_stage(out,p,start) for p in ('tests','examples','audit')]
    if not gate.contexts_match([s['context'] for s in stages]) or ctx!=stages[0]['context']:
        raise ValueError('RELEASE_CONTEXT_MISMATCH')
    report=gate.read_json(out/'LOCAL-RUN.json')
    check=gate.check_run(report,out/'v02-tests.xml',start,runner.EXAMPLES)
    static=gate.audit_static()
    okay=all(s['status']=='PASS' for s in stages) and check['status']==static['status']=='PASS'
    legacy=report['legacy_runtime']['status']
    if require_legacy and legacy!='PASS':okay=False
    results={name:gate.read_json(out/(name+'.json')) for name in ('BASE-MODEL','LC-MODEL','DS-MODEL','ACCEPTANCE','BASE-CONFORMANCE','LC-CONFORMANCE','DS-CONFORMANCE','NATIVE-CRYPTO')}
    paths=sorted({row['path'] for s in stages for row in s['outputs']}|{'H-'+p.upper()+'.json' for p in ('tests','examples','audit')})
    result={'schema':'dkn.release-review.v0.2-h1','status':'PASS_SCOPED_ENGINEERING_EXTERNAL_GATES_OPEN' if okay else 'INCOMPLETE_OR_FAILED',
      'distribution_version':'0.2.0rc5','source_fingerprint':start,'context':ctx,'run_check':check,'static_check':static,
      'acceptance':results['ACCEPTANCE']['row_statuses'],'models':{k:results[k] for k in ('BASE-MODEL','LC-MODEL','DS-MODEL')},
      'conformance':{k:results[k] for k in ('BASE-CONFORMANCE','LC-CONFORMANCE','DS-CONFORMANCE')},
      'legacy_runtime':report['legacy_runtime'],'native_crypto_status':results['NATIVE-CRYPTO']['status'],
      'require_legacy':require_legacy,'tests':len(report['test_cases']),'new_h_tests':sum('test_batch_h_' in c['id'] for c in report['test_cases']),
      'workflows':len(report['examples']),'evidence':[{'path':p,'sha256':gate.digest(out/p)} for p in paths],
      'remaining_gates':['genuine BLAKE3 legacy replay' if legacy!='PASS' else 'additional legacy interoperability',
       'native Windows/WSL/macOS replay','fresh dependency resolution','full alternative-language realization',
       'independent security review','deployment-specific validation and approval'],
      'public_release_gate':'NOT_CLEARED','independent_review':'NOT_PERFORMED','publication':'NOT_PERFORMED',
      'authority_effect':'NONE','g0':'CLOSED','real_a5':False,
      'claim_ceiling':'SAME_AUTHOR_BOUNDED_ENGINEERING_NOT_INDEPENDENT_APPROVAL'}
    write(out/'H-REVIEW.json',result)
    return result,okay


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True)
    p.add_argument('--phase',choices=('tests','examples','audit','assemble'),required=True)
    p.add_argument('--require-legacy',action='store_true');a=p.parse_args()
    try:result,okay=execute(a.out,a.phase,a.require_legacy)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print(json.dumps({'status':'REFUSED','error':str(exc),'authority_effect':'NONE'},sort_keys=True));return 2
    print(json.dumps({k:v for k,v in result.items() if k not in ('test_cases','evidence','models','conformance')},sort_keys=True))
    return 0 if okay else 2
if __name__=='__main__':raise SystemExit(main())
