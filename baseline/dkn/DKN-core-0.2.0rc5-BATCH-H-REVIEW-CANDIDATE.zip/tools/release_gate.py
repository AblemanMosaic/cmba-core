"""Release evidence checks. Unsigned engineering evidence is not independent approval.

This module does not sign, publish, approve, run replacement executables, or mutate pins.
It checks a bounded, local review dossier against its separately recorded baseline.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tomllib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('RELEASE_DUPLICATE_JSON_KEY')
            out[key] = value
        return out
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError('RELEASE_EVIDENCE_LIMIT')
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def junit_cases(path: Path) -> list[dict]:
    """Require counted leaf suites and exact unique test identities; skips are not PASS."""
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError('RELEASE_XML_LIMIT')
    raw = path.read_bytes()
    if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw:
        raise ValueError('RELEASE_XML_DECLARATION')
    root = ET.fromstring(raw)
    suites = [s for s in root.iter('testsuite') if s.find('testsuite') is None]
    if not suites:
        raise ValueError('RELEASE_NO_TEST_SUITES')
    rows = []
    for suite in suites:
        cases = suite.findall('testcase')
        counts = {'tests': len(cases), 'failures': 0, 'errors': 0, 'skipped': 0}
        for case in cases:
            markers = [n for n in ('failure', 'error', 'skipped') if case.find(n) is not None]
            if len(markers) > 1:
                raise ValueError('RELEASE_AMBIGUOUS_TEST_RESULT')
            result = {'failure': 'FAIL', 'error': 'ERROR', 'skipped': 'SKIP'}.get(markers[0] if markers else '', 'PASS')
            if markers:
                counts[{'failure':'failures', 'error':'errors', 'skipped':'skipped'}[markers[0]]] += 1
            classname = case.get('classname'); name = case.get('name')
            if not classname or not name:
                raise ValueError('RELEASE_TEST_ID_MISSING')
            rows.append({'id': classname + '::' + name, 'result': result})
        for key, count in counts.items():
            declared = suite.get(key)
            if declared is None or not declared.isdecimal() or int(declared) != count:
                raise ValueError('RELEASE_JUNIT_COUNT_MISMATCH:' + key)
    if not rows:
        raise ValueError('RELEASE_EMPTY_TEST_RUN')
    if len({r['id'] for r in rows}) != len(rows):
        raise ValueError('RELEASE_DUPLICATE_TEST_ID')
    return rows


def check_run(report: dict, xml_path: Path, expected_fingerprint: str, examples: tuple[str, ...]):
    cases = junit_cases(xml_path)
    findings = []
    if report.get('source_fingerprint') != expected_fingerprint:
        findings.append('SOURCE_FINGERPRINT_MISMATCH')
    # Byte-level JSON comparison avoids bool/int aliasing in nested result fields.
    encode = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'))
    if encode(report.get('test_cases')) != encode(cases):
        findings.append('TEST_REPORT_XML_MISMATCH')
    if type(report.get('v02_tests')) is not int or report['v02_tests'] != len(cases):
        findings.append('TEST_COUNT_MISMATCH')
    if type(report.get('v02_passed')) is not int or report['v02_passed'] != len(cases):
        findings.append('PASS_COUNT_MISMATCH')
    if any(r['result'] != 'PASS' for r in cases):
        findings.append('TEST_NOT_PASS')
    if type(report.get('v02_test_exit_code')) is not int or report['v02_test_exit_code'] != 0:
        findings.append('TEST_PROCESS_NOT_PASS')
    ex = report.get('examples', [])
    if type(ex) is not list or [r.get('path') for r in ex] != ['examples/' + n for n in examples]:
        findings.append('WORKFLOW_SET_MISMATCH')
    elif any(r.get('status') != 'PASS' or type(r.get('exit_code')) is not int or r['exit_code'] != 0 for r in ex):
        findings.append('WORKFLOW_NOT_PASS')
    if report.get('authority_effect') != 'NONE' or report.get('public_release_gate') != 'NOT_CLEARED':
        findings.append('UNSUPPORTED_AUTHORITY_PROMOTION')
    if report.get('independent_review') != 'NOT_PERFORMED':
        findings.append('SAME_AUTHOR_RUN_IS_NOT_INDEPENDENT_REVIEW')
    return {'status': 'PASS' if not findings else 'FAIL', 'cases': len(cases),
            'workflows': len(ex), 'findings': findings, 'authority_effect': 'NONE'}


def audit_static(root: Path = ROOT):
    baseline = read_json(root/'release/REVIEW-BASELINE.json')
    findings = []
    for group in ('runtime_files', 'semantic_files', 'corpora'):
        for row in baseline[group]:
            path = root / row['path']
            if not path.is_file() or digest(path) != row['sha256']:
                findings.append('PRESERVATION_MISMATCH:' + row['path'])
    boundary = read_json(root/'META/V02-CANDIDATE-BOUNDARY.json')
    if boundary.get('current_inventory') != 'BATCH-H-FILE-MANIFEST.json':
        findings.append('CURRENT_INVENTORY_MISMATCH')
    version = tomllib.loads((root/'pyproject.toml').read_text())['project']['version']
    if version != '0.2.0rc5' or boundary.get('distribution_version') != version:
        findings.append('DISTRIBUTION_VERSION_MISMATCH')
    if boundary.get('predecessor_archive_sha256') != baseline['predecessor_archive_sha256']:
        findings.append('PREDECESSOR_MISMATCH')
    if boundary.get('public_release_gate') != 'NOT_CLEARED' or boundary.get('authority_effect') != 'NONE':
        findings.append('UNSUPPORTED_AUTHORITY_PROMOTION')
    return {'status': 'PASS' if not findings else 'FAIL', 'runtime_files': len(baseline['runtime_files']),
            'semantic_files': len(baseline['semantic_files']), 'corpora': len(baseline['corpora']),
            'findings': findings, 'authority_effect':'NONE'}


def contexts_match(contexts: list[dict]) -> bool:
    if len(contexts) != 3 or any(type(c) is not dict or not c for c in contexts):
        return False
    encode = lambda c: json.dumps(c, sort_keys=True, separators=(',', ':'))
    return len({encode(c) for c in contexts}) == 1
