"""Generate public deterministic LC-F1 TEST fixtures; never use these known keys in production.

Expected behavior is reference-assisted, not an independently authored specification proof.
Run explicitly when changing the protocol; frozen corpus changes require a new model commitment.
"""
from pathlib import Path
import copy,hashlib,sys
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dkn_v02 import canonical, declare_genesis, key_hex, pack, certify, Refusal
from dkn_v02 import lifecycle as lc
from dkn_v02.lifecycle_abi import dispatch


def build():
    key=lambda name:Ed25519PrivateKey.from_private_bytes(hashlib.sha256(('PUBLIC_DKN_F_FIXTURE:'+name).encode()).digest())
    owner,delegate,successor=[key(name) for name in ('owner','delegate','successor')]
    guardians=sorted([key('guardian-'+str(i)) for i in range(3)],key=key_hex)
    policy=lc.lifecycle_policy(recovery_keys=[key_hex(k) for k in guardians],recovery_threshold=2,
        allowed_operations=['certify_artifact','publish_artifact'],max_grant_seconds=1000)
    genesis=declare_genesis(semantic_name='fixture.lifecycle',purpose='publisher',nonce='fixture',key=owner,
        recovery_policy_ref=lc.policy_reference(policy))
    _,manifest=pack({'fixture.txt':b'public fixture'})
    def event(events,kind,payload,keys,at=100):
        return lc.make_event(genesis,policy,events,kind=kind,payload=payload,issued_at=at,signing_keys=keys)
    grant=event([],'delegate',{'subject_public_key_hex':key_hex(delegate),'artifact_root':manifest['logical_root'],
        'operations':['certify_artifact'],'not_before':100,'expires_at':200},[owner])
    revoked=event([grant],'revoke_grant',{'grant_ref':grant['event_ref']},[owner],140)
    recovered=event([grant,revoked],'recover',{'successor_public_key_hex':key_hex(successor)},guardians[:2]+[successor],150)
    rotated=event([],'rotate',{'successor_public_key_hex':key_hex(successor)},[owner,successor])
    suspended=event([],'suspend',{'reason':'fixture'},[owner])
    resumed=event([suspended],'resume',{'reason':'fixture'},[owner])
    keyrevoked=event([grant],'revoke_key',{'public_key_hex':key_hex(delegate)},[owner],140)
    cp=lc.make_checkpoint(genesis,policy,[grant],issued_at=120,expires_at=160,key=owner)
    cert=certify(manifest,delegate,namespace_root=genesis['namespace_root'])
    fixture={'schema':'dkn.lifecycle-fixtures.v0.2-f1','purpose':'PUBLIC_TEST_MATERIAL_NOT_PRODUCTION_KEYS',
        'policy':policy,'genesis':genesis,'manifest':manifest,'certificate':cert,
        'delegate_public_key_hex':key_hex(delegate),'checkpoint':cp,
        'chains':{'empty':[],'delegated':[grant],'revoked':[grant,revoked],'recovered':[grant,revoked,recovered],
                  'rotated':[rotated],'suspended':[suspended],'resumed':[suspended,resumed],
                  'key_revoked':[grant,keyrevoked]},'states':{}}
    for name,events in fixture['chains'].items():fixture['states'][name]=lc.verify_journal(genesis,policy,events)
    cases=[]
    def add(identifier,operation,arguments):
        request={'id':identifier,'operation':operation,'arguments':copy.deepcopy(arguments)}
        try:expected={'id':identifier,'outcome':'RETURNED','result':dispatch({'schema':'dkn.lifecycle-request.v0.2-f1','operation':operation,'arguments':arguments})}
        except Refusal as exc:expected={'id':identifier,'outcome':'REFUSED','code':exc.code}
        cases.append({'request':request,'expected':expected})
    add('policy','verify-policy',{'policy':policy})
    for name,events in fixture['chains'].items():
        add('journal-'+name,'verify-journal',{'genesis':genesis,'policy':policy,'events':events})
    reader={'genesis':genesis,'policy':policy,'events':[grant],'expected_namespace':genesis['namespace_root'],
        'expected_head':grant['event_ref'],'now':130,'max_checkpoint_age':30,'checkpoint':cp,'minimum':None,
        'subject_public_key_hex':key_hex(delegate),'artifact_root':manifest['logical_root'],'operation':'certify_artifact'}
    add('exact-scope','assess-delegation',reader)
    for name,changes in [('wrong-artifact',{'artifact_root':'a'*64}),('wrong-operation',{'operation':'publish_artifact'}),
        ('missing-checkpoint',{'checkpoint':None}),('expired-checkpoint',{'now':160}),
        ('stale-checkpoint',{'max_checkpoint_age':5}),('wrong-pin',{'expected_head':'f'*64}),
        ('rollback-floor',{'minimum':{'sequence':2,'head_ref':revoked['event_ref']}})]:
        add(name,'assess-delegation',{**reader,**changes})
    add('certificate','assess-certificate',{**{k:v for k,v in reader.items() if k not in ('subject_public_key_hex','artifact_root','operation')},
                                          'certificate':cert,'manifest':manifest})
    add('visible-fork','analyze-journals',{'genesis':genesis,'policy':policy,'chains':[[grant],[suspended]]})
    bad=copy.deepcopy(recovered);bad['signatures']=bad['signatures'][:1]
    add('recovery-threshold','verify-journal',{'genesis':genesis,'policy':policy,'events':[grant,revoked,bad]})
    bad=copy.deepcopy(grant);bad['body']['payload']['artifact_root']='b'*64
    add('tampered-scope','verify-journal',{'genesis':genesis,'policy':policy,'events':[bad]})
    add('unknown-operation','run-code',{})
    add('unknown-field','verify-policy',{'policy':policy,'trust_me':True})
    bad=copy.deepcopy(policy);bad['recovery_threshold']=True
    add('boolean-threshold','verify-policy',{'policy':bad})
    return fixture,{'schema':'dkn.lifecycle-conformance-corpus.v0.2-f1',
                    'provenance':'REFERENCE_ASSISTED_EXPECTATIONS_NOT_INDEPENDENT_EQUIVALENCE_PROOF','cases':cases}


def main():
    fixture,corpus=build()
    (ROOT/'vectors/v02').mkdir(parents=True,exist_ok=True)
    (ROOT/'vectors/v02/lifecycle-f1.json').write_bytes(canonical(fixture))
    (ROOT/'interop/lifecycle-f1-conformance.json').write_bytes(canonical(corpus))
    print(len(corpus['cases']))
if __name__=='__main__':main()
