"""Explicit DS-G1 fixture authoring, never invoked by runtime verification.

Scenario status expectations are hand-authored. Full conformance outputs and trace
roots are reference-assisted frozen examples, not independently proven oracles.
"""
from __future__ import annotations
import hashlib,json,sys
from copy import deepcopy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02 import canonical
from dkn_v02.distributed import object_hash
from dkn_v02.simulation import run_scenario
from examples.distributed_fixtures import extended_scenarios,EXPECTED_STATUSES,fixture_bundle
from tools.reference_distributed_conformance import execute


def build():
    scenarios=extended_scenarios();rows=[];traces={}
    for name,s in sorted(scenarios.items()):
        r=run_scenario(s);actual=[a['report']['status'] for a in r['assessments']]
        if actual!=EXPECTED_STATUSES[name]:raise ValueError('SCENARIO_EXPECTATION_FAILED:'+name)
        rows.append({'id':name,'scenario_sha256':hashlib.sha256(canonical(s)).hexdigest(),
            'scenario_ref':r['scenario_ref'],'trace_root':r['trace_root'],'expected_statuses':EXPECTED_STATUSES[name]})
        traces[name]=r
    vector={'schema':'dkn.distributed-vectors.v0.2-g1','simulation_only':True,'production_evidence':False,
            'status_expectations':'HAND_AUTHORED','hash_vectors':'REFERENCE_ASSISTED',
            'scenarios':rows,'authority_effect':'NONE'}
    b=fixture_bundle();requests=[]
    def case(name,op,args):requests.append({'id':name,'operation':op,'arguments':deepcopy(args)})
    for name in ('normal','partition-heal','delayed-revocation','recovery-fork','external-floor-rollback','common-cause-outage'):
        case(name,'simulate',{'scenario':scenarios[name]})
    for name in ('normal','witness-quorum','witness-equivocation','assurance-supported','assurance-refuted','transitive-shared-dependency'):
        s=scenarios[name];policy=s['readers'][0]['policy']
        # Only material explicitly sent to the reader, not the full catalog.
        names={step['object'] for step in s['steps'] if step['action']=='send'}
        objects=[{'kind':o['kind'],'value':o['value']} for o in s['objects'] if o['id'] in names]
        case('view-'+name,'assess',{'objects':objects,'reader':policy,'now':130})
    for name in ('normal','partition-heal'):
        case('replay-'+name,'verify-replay',{'scenario':scenarios[name],'transcript':traces[name]})
    for name,reader,objs,now in [
        ('view-empty',b['reader'],[],130),('view-stale',b['reader'],[b['objects']['artifact'],b['objects']['granted']],181),
        ('view-corrupt',b['reader'],[{'kind':'artifact','value':{}}],130),
        ('view-future-clock',b['reader'],[b['objects']['artifact'],b['objects']['granted']],99)]:
        case(name,'assess',{'objects':objs,'reader':reader,'now':now})
    for name,field,value in [('bad-operation','operation','execute'),('unknown-schema','schema','wrong'),
                              ('missing-witness-policy','require_witness',True),('wrong-root','expected_head','not-a-hash')]:
        r=deepcopy(b['reader']);r[field]=value
        case(name,'assess',{'objects':[],'reader':r,'now':130})
    case('bad-time','assess',{'objects':[],'reader':b['reader'],'now':-1})
    case('unknown-operation','launch',{})
    case('extra-argument','simulate',{'scenario':scenarios['normal'],'url':'https://example.invalid'})
    changed=deepcopy(traces['normal']);changed['trace_root']='0'*64
    case('replay-mutated','verify-replay',{'scenario':scenarios['normal'],'transcript':changed})
    bad=deepcopy(scenarios['normal']);bad['steps'].reverse()
    case('reversed-time','simulate',{'scenario':bad})
    bad=deepcopy(scenarios['normal']);bad['nodes'].append(deepcopy(bad['nodes'][0]))
    case('duplicate-node','simulate',{'scenario':bad})
    results=execute({'schema':'dkn.conformance-request.v0.2-rc2','cases':requests})['results']
    corpus={'schema':'dkn.portable-conformance.v0.2-rc2','profile':'DS-G1','authority_effect':'NONE',
       'claim_ceiling':'REFERENCE_ASSISTED_FROZEN_EXAMPLES_NOT_COMPLETE_EQUIVALENCE',
       'cases':[{'request':q,'expected':r} for q,r in zip(requests,results)]}
    canonical(corpus)
    return scenarios,vector,corpus


def main():
    scenarios,vector,corpus=build()
    folder=ROOT/'profiles/distributed-g1/scenarios';folder.mkdir(parents=True,exist_ok=True)
    for name,s in scenarios.items():(folder/(name+'.json')).write_bytes(canonical(s))
    (ROOT/'vectors/v02/distributed-g1.json').write_bytes(canonical(vector))
    (ROOT/'interop/distributed-g1-conformance.json').write_bytes(canonical(corpus))
    from dkn_v02.distributed_schemas import export_schemas
    folder=ROOT/'schemas/v02/distributed-g1';folder.mkdir(parents=True,exist_ok=True)
    for name,s in export_schemas().items():(folder/(name+'.schema.json')).write_bytes(canonical(s))
    print(json.dumps({'scenarios':len(scenarios),'conformance_cases':len(corpus['cases']),
                      'corpus_bytes':len(canonical(corpus)),'authority_effect':'NONE'},sort_keys=True))
if __name__=='__main__':main()
