"""DS-G1 read-only adapter to the existing frozen-corpus process envelope."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dkn_v02.core import canonical, read_canonical, exact, check, Refusal, MAX_META
from dkn_v02.distributed_abi import dispatch


def execute(request):
    canonical(request);exact(request,{'schema','cases'})
    check(request['schema']=='dkn.conformance-request.v0.2-rc2','CONF_REQUEST_INVALID')
    check(type(request['cases']) is list and 1<=len(request['cases'])<=128,'CONF_LIMIT')
    results=[];seen=set()
    for case in request['cases']:
        exact(case,{'id','operation','arguments'})
        check(type(case['id']) is str and case['id'] not in seen,'CONF_REQUEST_INVALID');seen.add(case['id'])
        try:
            result=dispatch({'schema':'dkn.distributed-request.v0.2-g1','operation':case['operation'],'arguments':case['arguments']})
            results.append({'id':case['id'],'outcome':'RETURNED','result':result})
        except Refusal as exc:results.append({'id':case['id'],'outcome':'REFUSED','code':exc.code})
    return {'schema':'dkn.conformance-response.v0.2-rc2','results':results,'authority_effect':'NONE'}


def main():
    try:result=execute(read_canonical(sys.stdin.buffer.read(MAX_META+1)));code=0
    except Refusal as exc:result={'outcome':'REFUSED','code':exc.code,'authority_effect':'NONE'};code=2
    sys.stdout.buffer.write(canonical(result));return code
if __name__=='__main__':raise SystemExit(main())
