"""Build normative DKN Core v0.1 r002 golden vectors."""

from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from dkn_core.canonical import canonical_bytes
from dkn_core.crypto import public_key_hex
from dkn_core.namespace import derive_namespace
from dkn_core.passport import create_passport
from dkn_core.records import build_collaborator_attestation, sign_record
from dkn_core.thr import build_thr_manifest

SEED = bytes.fromhex(
    "9d61b19deffd5a60ba844af492ec2cc4"
    "4449c5697b326919703bac031cae7f60"
)


def build_vectors() -> dict:
    key = Ed25519PrivateKey.from_private_bytes(SEED)
    public = public_key_hex(key)
    exact = derive_namespace(
        semantic_namespace="mosaic.ucm.v0.1", public_key_hex=public,
        purpose="collaboration", nonce="mosaic.ucm.v0.1", epoch_code="e0001")
    wildcard = derive_namespace(
        semantic_namespace="mosaic.ucm.*", public_key_hex=public,
        purpose="collaboration", nonce="mosaic.ucm.v0.1", epoch_code="e0001")
    passport = create_passport(public_key_hex=public, role="COLLABORATOR", namespace=exact)
    thr = build_thr_manifest(
        state={"artifact_sha256": "11" * 32},
        semantic={"artifact_role": "GOLDEN_VECTOR"},
        governance={"authority_effect": "NONE"})
    attestation_body = build_collaborator_attestation(
        collaborator_subject_id=passport["subject_id"],
        subject_hash="22" * 32,
        namespace_binding_hash=exact["namespace_binding_hash"],
        epoch_code="e0001",
        statement="Golden vector collaborator attestation.")
    attestation = sign_record(record_type="COLLABORATOR_ATTESTATION",
                              body=attestation_body, passport=passport, private_key=key)
    canonical_value = {"a": [True, None, -1], "unicode": "lambda-λ", "z": 2}
    encoded = canonical_bytes(canonical_value)
    return {
        "schema": "dkn.golden-vectors.v0.1",
        "public_version": "v0.1",
        "engineering_revision": "r002",
        "algorithms": {
            "serialization": "DKN-CJSON-1",
            "namespace_hash": "BLAKE3-256",
            "structural_hash": "SHA-256",
            "signature": "Ed25519",
        },
        "key": {
            "source": "RFC8032_TEST_VECTOR_1_SEED",
            "public_key_hex": public,
        },
        "accepted": {
            "canonical_json": {
                "value": canonical_value,
                "canonical_utf8_hex": encoded.hex(),
                "sha256": hashlib.sha256(encoded).hexdigest(),
            },
            "exact_namespace": exact,
            "wildcard_namespace": wildcard,
            "passport": passport,
            "thr_manifest": thr,
            "signed_collaborator_attestation": attestation,
        },
        "refused": [
            {"case": "duplicate_json_key", "input_utf8_hex": b'{"a":1,"a":2}'.hex(),
             "code": "DKN_CANONICAL_DUPLICATE_KEY"},
            {"case": "float", "input_utf8_hex": b'{"a":1.0}'.hex(),
             "code": "DKN_CANONICAL_NUMBER_INVALID"},
            {"case": "noncanonical_json", "input_utf8_hex": b'{"b":2, "a":1}'.hex(),
             "code": "DKN_CANONICAL_JSON_NOT_CANONICAL"},
            {"case": "nonterminal_wildcard", "semantic_namespace": "mosaic.*.ucm",
             "code": "DKN_NAMESPACE_INVALID"},
            {"case": "mosaic_key_substitution", "mosaic_id": "00" * 32,
             "public_key_hex": public, "code": "DKN_MOSAIC_ID_MISMATCH"},
            {"case": "credential_in_locator",
             "locator": "https://example.invalid/dkn.zip?token=secret",
             "code": "DKN_STORAGE_LOCATOR_CONTAINS_CREDENTIAL"},
        ],
        "standing": "INFORMATION_ONLY",
        "authority_effect": "NONE",
        "real_a5": False,
        "g0": "CLOSED",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "vectors" / "golden-vectors.json")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    raw = canonical_bytes(build_vectors()) + b"\n"
    if args.check:
        if not args.out.exists() or args.out.read_bytes() != raw:
            print("DKN_GOLDEN_VECTORS_STALE", file=sys.stderr)
            return 2
        print("DKN_GOLDEN_VECTORS_PASS")
        return 0
    args.out.write_bytes(raw)
    print(hashlib.sha256(raw).hexdigest())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

