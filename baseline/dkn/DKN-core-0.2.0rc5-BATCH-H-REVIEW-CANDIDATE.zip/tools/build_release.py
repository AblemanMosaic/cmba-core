"""Build deterministic DKN Core v0.1 r002 portable release artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dkn_core.archive import build_portable_archive, verify_portable_archive
from dkn_core.canonical import canonical_bytes

INCLUDE_FILES = {
    ".gitignore", "NOTICE", "README.md", "ROADMAP.md", "SECURITY.md", "pyproject.toml",
}
INCLUDE_DIRS = {"acceptance", "docs", "schemas", "src", "tests", "tools", "vectors"}
TEXT_SUFFIXES = {".md", ".json", ".py", ".toml", ".txt", ".vbs", ".cmd", ".ps1"}
ARCHIVE_NAME = "DKN-core-v0.1-r002.zip"


def collect_payloads(source: Path = ROOT) -> dict[str, bytes]:
    payloads: dict[str, bytes] = {}
    candidates = [source / name for name in INCLUDE_FILES]
    for directory in INCLUDE_DIRS:
        candidates.extend(path for path in (source / directory).rglob("*") if path.is_file())
    for path in candidates:
        if not path.exists() or any(part in {"__pycache__", ".pytest_cache"} for part in path.parts):
            continue
        relative = path.relative_to(source).as_posix()
        raw = path.read_bytes()
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in {"NOTICE", ".gitignore"}:
            if raw.startswith(b"\xef\xbb\xbf") or b"\r\n" in raw or b"\r" in raw:
                raise ValueError(f"DKN_SOURCE_TEXT_POLICY_INVALID:{relative}")
            raw.decode("utf-8")
        payloads[relative] = raw
    if not payloads:
        raise ValueError("DKN_RELEASE_PAYLOAD_EMPTY")
    return payloads


def build_release_bytes(source: Path = ROOT) -> bytes:
    return build_portable_archive(payloads=collect_payloads(source),
                                  engineering_revision="r002")


def _write_new_or_same(path: Path, raw: bytes) -> None:
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError(f"DKN_RELEASE_EXISTING_ARTIFACT_DIFFERS:{path.name}")
        return
    path.write_bytes(raw)


def build_outputs(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    archive_path = (out_dir / ARCHIVE_NAME).resolve()
    raw = build_release_bytes()
    verification = verify_portable_archive(raw)
    _write_new_or_same(archive_path, raw)
    sha_path = archive_path.with_suffix(archive_path.suffix + ".sha256")
    sha_raw = f"{verification['transport_sha256']}  {archive_path.name}\n".encode("ascii")
    _write_new_or_same(sha_path, sha_raw)
    receipt = {
        "schema": "dkn.release-packaging-receipt.v0.1",
        "artifact": archive_path.name,
        "public_version": "v0.1",
        "engineering_revision": "r002",
        "archive_verification": verification,
        "archive_sha256_external": verification["transport_sha256"],
        "publication_performed": False,
        "independent_review_performed": False,
        "portability_claim": "WINDOWS_NATIVE_EVIDENCE_ONLY",
        "standing": "INFORMATION_ONLY",
        "authority_effect": "NONE",
        "real_a5": False,
        "g0": "CLOSED",
    }
    receipt_path = (out_dir / "PACKAGING-RECEIPT.json").resolve()
    receipt_raw = canonical_bytes(receipt) + b"\n"
    _write_new_or_same(receipt_path, receipt_raw)
    boundary = {
        "schema": "codex.exact-artifact-boundary.v1",
        "boundary_id": "dkn-core-v0.1-r002-portable-release",
        "artifacts": [
            {
                "source_path": archive_path.as_posix(),
                "destination_path": archive_path.name,
                "sha256": verification["transport_sha256"],
                "required_by": "consumer:portable archive verification",
            },
            {
                "source_path": sha_path.as_posix(),
                "destination_path": sha_path.name,
                "sha256": hashlib.sha256(sha_raw).hexdigest(),
                "required_by": "consumer:external transport commitment",
            },
            {
                "source_path": receipt_path.as_posix(),
                "destination_path": receipt_path.name,
                "sha256": hashlib.sha256(receipt_raw).hexdigest(),
                "required_by": "consumer:packaging status and claim ceiling",
            },
        ],
        "runner_required_paths": [archive_path.name, sha_path.name, receipt_path.name],
        "allow_extra_artifacts": False,
        "policy": {
            "maximum_transfers": 1,
            "maximum_invocations": 1,
            "maximum_retries": 0,
            "preserve_prior_custody": True,
            "terminal_capture": ["stdout", "stderr", "exit_code", "terminal_receipt"],
        },
    }
    boundary_path = out_dir / "EXACT-ARTIFACT-BOUNDARY.json"
    # The boundary manifest intentionally does not inventory itself.
    _write_new_or_same(boundary_path, canonical_bytes(boundary) + b"\n")
    return {
        "archive": str(archive_path),
        "archive_sha256": verification["transport_sha256"],
        "receipt": str(receipt_path),
        "boundary_manifest": str(boundary_path.resolve()),
        "certificate_status": verification["certificate_status"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, default=ROOT / "release")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        expected = build_release_bytes()
        path = args.out_dir / ARCHIVE_NAME
        if not path.exists() or path.read_bytes() != expected:
            print("DKN_RELEASE_STALE", file=sys.stderr)
            return 2
        print(json.dumps(verify_portable_archive(expected), sort_keys=True))
        return 0
    print(json.dumps(build_outputs(args.out_dir), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

