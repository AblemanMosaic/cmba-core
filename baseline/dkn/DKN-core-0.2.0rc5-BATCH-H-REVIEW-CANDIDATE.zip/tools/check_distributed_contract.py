"""Check DS-G1 model/reference/realization/test bindings, not full semantic equivalence.

The commitment is compared to the local normative body. An external reviewer must pin
its accepted commitment independently; a self-consistent replacement model is not approval.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02.core import read_canonical, verify_dimension
from tools.check_semantic_contract import safe, symbols

def check(root=ROOT, report=None):
    model=read_canonical((root/'model/distributed-g1/CONTRACT.json').read_bytes())
    commitment=read_canonical((root/'model/distributed-g1/COMMITMENT.json').read_bytes())
    binding=read_canonical((root/'model/distributed-g1/REALIZATION-BINDING.json').read_bytes())
    base=read_canonical((root/'model/v02/SEMANTIC-COMMITMENT.json').read_bytes())
    verify_dimension(commitment,model,supplied=True,supported_schemas={'dkn.distributed-contract.v1'})
    findings=[]
    if model['base_semantic_digest']!=base['digest_hex']: findings.append('BASE_COMMITMENT_MISMATCH')
    lc=read_canonical((root/'model/lifecycle-f1/COMMITMENT.json').read_bytes())
    if model['lifecycle_semantic_digest']!=lc['digest_hex']: findings.append('LIFECYCLE_COMMITMENT_MISMATCH')
    if binding['semantic_digest']!=commitment['digest_hex']: findings.append('SEMANTIC_BINDING_MISMATCH')
    for name,rows in [('NORMATIVE',model['normative_references']),('SOURCE',binding['source_files'])]:
        paths=[r['path'] for r in rows]
        if paths!=sorted(set(paths)): findings.append(name+'_REFERENCE_SET_INVALID')
        for row in rows:
            if hashlib.sha256(safe(root,row['path']).read_bytes()).hexdigest()!=row['sha256']:
                findings.append('HASH_MISMATCH:'+row['path'])
    ids=[row['id'] for row in model['obligations']]
    traces=[row['obligation'] for row in binding['traceability']]
    expected=[f'G-{i:02d}' for i in range(1,15)]
    if ids!=expected or traces!=expected: findings.append('OBLIGATION_COVERAGE')
    if report is not None:
        from tools import verify_v02_candidate as runner
        old=runner.ROOT
        try:
            runner.ROOT=root
            if report.get('source_fingerprint')!=runner.source_fingerprint(): findings.append('EXECUTED_SOURCE_MISMATCH')
        finally: runner.ROOT=old
    count=0
    for row in binding['traceability']:
        if not row['implementation'] or not row['tests']: findings.append('EMPTY_TRACE:'+row['obligation'])
        for ref in row['implementation']+row['tests']:
            path,name=ref.split('::',1)
            if name not in symbols(safe(root,path)): findings.append('MISSING_SYMBOL:'+ref)
        for ref in row['tests']:
            count+=1
            if report is not None:
                path,name=ref.split('::',1);prefix=path[:-3].replace('/','.')+'::'+name
                matches=[c for c in report.get('test_cases',[]) if c['id']==prefix or c['id'].startswith(prefix+'[')]
                if not matches or any(c['result']!='PASS' for c in matches): findings.append('TEST_NOT_ESTABLISHED:'+ref)
    return {'schema':'dkn.distributed-binding-check.v0.2-g1','status':'FAIL' if findings else 'PASS_REFERENCE_INTEGRITY',
            'semantic_digest':commitment['digest_hex'],'base_semantic_digest':base['digest_hex'],
            'obligations':len(ids),'test_references':count,'source_files':len(binding['source_files']),
            'normative_references':len(model['normative_references']),
            'executed_test_binding':'CHECKED' if report is not None else 'NOT_CHECKED','findings':findings,
            'claim_ceiling':'HASH_SYMBOL_AND_RECORDED_TEST_TRACEABILITY_NOT_PROGRAM_EQUIVALENCE_PROOF',
            'authority_effect':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--report',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
    result=check(report=json.loads(a.report.read_text()) if a.report else None)
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text);return 0 if not result['findings'] else 2
if __name__=='__main__':raise SystemExit(main())
