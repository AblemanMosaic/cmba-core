"""Generate fixed deterministic candidate vectors; not independent cross-language evidence."""
import json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import *

def main():
    key=Ed25519PrivateKey.from_private_bytes(b'\x44'*32)
    second=Ed25519PrivateKey.from_private_bytes(b'\x55'*32)
    files={'README.md':b'hello DKN v02\n','a/data.json':b'{"example":true}\n'}
    dimension=commit('semantics','example.semantic',{'label':'Demo'})
    archive, manifest=pack(files,[dimension])
    genesis=declare_genesis(semantic_name='example.demo',purpose='publisher',nonce='demo1',legacy_instance='dkn:v0.1:b3:'+'aa'*32,key=key)
    event=transition(genesis,key,key_hex(second),epoch=1)
    cert=certify(manifest,key,namespace_root=genesis['namespace_root'])
    vector={'schema':'dkn.v02-candidate-vectors.v1','status':'REFERENCE_IMPLEMENTATION_GENERATED','dimension':dimension,
            'manifest':manifest,'archive_sha256':__import__('hashlib').sha256(archive).hexdigest(),
            'detached_certificate':cert,'genesis':genesis,'transition_1':event,
            'test_key_seed_hex':'44'*32,'second_test_key_seed_hex':'55'*32,
            'caution':'TEST KEYS: not for operational signing; legacy instance deliberately unverified'}
    assert verify_archive(archive)['logical_root']==manifest['logical_root']
    assert verify_certificate(cert,manifest)['signature']=='PASS'
    assert verify_transitions(genesis,[event])['signature_chain']=='PASS'
    dest=Path(__file__).resolve().parents[1]/'vectors'/'v02-candidate-vectors.json'
    dest.write_bytes(canonical(vector)+b'\n')
    print(dest)
if __name__=='__main__': main()
