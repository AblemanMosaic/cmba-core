"""Deterministic engineering source package; not a v0.1 portable archive certificate.

The file manifest excludes only itself. External SHA-256 covers the final ZIP.
Reproducibility refers to serializing the same frozen source/evidence tree.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT=Path(__file__).resolve().parents[1]
MANIFEST='REVIEW-RC2-FILE-MANIFEST.json'
PREDECESSOR='b775c6296d86b8586e38369bba1e1e458daa9a676e0f49adbbd0e9a499b4acbd'
EXCLUDED={'.git','__pycache__','.pytest_cache','.venv','dist','build','work'}


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')


def collect(root:Path):
    output={}
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if any(part in EXCLUDED or part.endswith('.egg-info') for part in rel.parts):continue
        if p.is_symlink():raise ValueError('CANDIDATE_SYMLINK')
        if not p.is_file() or p.suffix in ('.pyc','.pyo') or rel.as_posix()==MANIFEST:continue
        if rel.as_posix().startswith('evidence/batch-e/clean-replay/'):raise ValueError('CLEAN_REPLAY_EVIDENCE_MUST_BE_EXTERNAL')
        output[rel.as_posix()]=p.read_bytes()
    return output


def build(root:Path):
    files=collect(root)
    manifest={'schema':'dkn.review-rc2-file-manifest.v0.2-candidate',
              'scope':'ALL_ARCHIVE_FILES_EXCEPT_THIS_MANIFEST',
              'predecessor_archive_sha256':PREDECESSOR,
              'files':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(files.items())],
              'authority_effect':'NONE','signature':'NOT_SIGNED'}
    files[MANIFEST]=canonical(manifest)
    result=io.BytesIO()
    with zipfile.ZipFile(result,'w',compression=zipfile.ZIP_STORED,allowZip64=False) as z:
        for p,b in sorted(files.items()):
            i=zipfile.ZipInfo(p,date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_STORED
            i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16
            z.writestr(i,b)
    return result.getvalue(),manifest


def verify(raw:bytes):
    if type(raw) is not bytes or len(raw)>32*1024*1024:raise ValueError('CANDIDATE_LIMIT')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(infos)>4096 or sum(i.file_size for i in infos)>32*1024*1024:raise ValueError('CANDIDATE_LIMIT')
        if names!=sorted(set(names)):raise ValueError('CANDIDATE_ORDER_OR_DUPLICATE')
        for info in infos:
            n=info.filename;p=PurePosixPath(n)
            if p.is_absolute() or '..' in p.parts or '\\' in n or info.is_dir():raise ValueError('CANDIDATE_PATH')
            if info.file_size>8*1024*1024 or info.compress_type!=zipfile.ZIP_STORED:raise ValueError('CANDIDATE_LIMIT')
            if info.external_attr!=(stat.S_IFREG|0o644)<<16 or info.date_time!=(1980,1,1,0,0,0):raise ValueError('CANDIDATE_METADATA')
        if z.testzip() is not None:raise ValueError('CANDIDATE_ZIP_CRC')
        def pairs(rows):
            output={}
            for k,v in rows:
                if k in output:raise ValueError('CANDIDATE_DUPLICATE_KEY')
                output[k]=v
            return output
        manifest_raw=z.read(MANIFEST)
        manifest=json.loads(manifest_raw,object_pairs_hook=pairs)
        if canonical(manifest)!=manifest_raw:raise ValueError('CANDIDATE_NONCANONICAL_MANIFEST')
        if set(manifest)!={'schema','scope','predecessor_archive_sha256','files','authority_effect','signature'}:raise ValueError('CANDIDATE_SCHEMA')
        if (manifest['schema']!='dkn.review-rc2-file-manifest.v0.2-candidate' or
            manifest['scope']!='ALL_ARCHIVE_FILES_EXCEPT_THIS_MANIFEST' or
            manifest['predecessor_archive_sha256']!=PREDECESSOR or
            manifest['authority_effect']!='NONE' or manifest['signature']!='NOT_SIGNED'):raise ValueError('CANDIDATE_SCHEMA')
        rows=manifest['files']
        if type(rows) is not list or any(type(r) is not dict or set(r)!={'path','bytes','sha256'} for r in rows):raise ValueError('CANDIDATE_SCHEMA')
        if any(type(r['path']) is not str or type(r['bytes']) is not int or type(r['sha256']) is not str for r in rows):raise ValueError('CANDIDATE_SCHEMA')
        paths=[r['path'] for r in rows]
        if paths!=sorted(set(paths)):raise ValueError('CANDIDATE_INVENTORY_DUPLICATE')
        expected={r['path']:r for r in rows}
        if set(names)!=set(expected)|{MANIFEST}:raise ValueError('CANDIDATE_CLOSURE')
        for n,r in expected.items():
            b=z.read(n)
            if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('CANDIDATE_HASH')
    rebuilt=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(raw)) as src, zipfile.ZipFile(rebuilt,'w',compression=zipfile.ZIP_STORED,allowZip64=False) as dst:
        for name in names:
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3
            info.compress_type=zipfile.ZIP_STORED;info.external_attr=(stat.S_IFREG|0o644)<<16
            dst.writestr(info,src.read(name))
    if rebuilt.getvalue()!=raw:raise ValueError('CANDIDATE_NONCANONICAL_TRANSPORT')
    return {'status':'PASS','member_count':len(names),'payload_file_count':len(expected),
            'sha256':hashlib.sha256(raw).hexdigest(),'authority_effect':'NONE'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=ROOT)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    source=a.source.resolve();out=a.out.resolve()
    if out==source or source in out.parents:raise ValueError('OUTPUT_MUST_BE_OUTSIDE_SOURCE_TREE')
    first,manifest=build(source);second,_=build(source)
    if first!=second:raise ValueError('NONDETERMINISTIC_SERIALIZATION')
    r=verify(first);out.write_bytes(first)
    Path(str(out)+'.sha256').write_text(r['sha256']+'  '+out.name+'\n',encoding='ascii')
    (source/MANIFEST).write_bytes(canonical(manifest))
    print(json.dumps({**r,'two_serializations_byte_identical':True},sort_keys=True))


if __name__=='__main__':main()
