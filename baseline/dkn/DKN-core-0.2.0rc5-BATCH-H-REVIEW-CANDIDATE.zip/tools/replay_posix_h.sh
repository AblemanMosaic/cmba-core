#!/usr/bin/env sh
# Caller chooses an existing reviewed Python environment. No installs or network effects.
set -eu
if [ "$#" -lt 1 ]; then echo 'usage: replay_posix_h.sh EVIDENCE_DIR [--require-legacy]' >&2; exit 2; fi
OUT=$1; shift
PYTHON=${PYTHON:-python}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
for phase in tests examples audit assemble; do
  "$PYTHON" tools/verify_batch_h.py --out "$OUT" --phase "$phase" "$@"
done
