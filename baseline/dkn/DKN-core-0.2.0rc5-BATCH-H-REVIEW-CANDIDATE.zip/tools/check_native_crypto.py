"""Scoped cryptographic cross-check against the host's actual libsodium shared library.

No network, private operational keys, or new runtime dependency. Test seeds are public.
Older sodium point admission has documented mixed-order limitations; use the documented
[L-1]P + P = identity cross-check, NOT its is_valid_point result alone.
"""
from __future__ import annotations
import argparse
import ctypes as C
import ctypes.util
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT/'src') not in sys.path:sys.path.insert(0,str(ROOT/'src'))
from dkn_v02.core import key_hex, _verify_sig, Refusal
from dkn_v02.key_validation import admitted_public_key
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

L=2**252+27742317777372353535851937790883648493
IDENTITY=b'\x01'+b'\x00'*31
P=2**255-19

def run():
    name=C.util.find_library('sodium')
    if not name:return {'status':'BLOCKED','reason':'LIBSODIUM_NOT_AVAILABLE','authority_effect':'NONE'}
    sodium=C.CDLL(name);sodium.sodium_init()
    sodium.sodium_version_string.restype=C.c_char_p
    for f,n in [('crypto_core_ed25519_is_valid_point',1),('crypto_core_ed25519_add',3),
                ('crypto_scalarmult_ed25519_noclamp',3),('crypto_sign_seed_keypair',3)]:
        getattr(sodium,f).argtypes=[C.c_void_p]*n;getattr(sodium,f).restype=C.c_int
    sodium.crypto_sign_detached.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_ulonglong,C.c_void_p]
    sodium.crypto_sign_verify_detached.argtypes=[C.c_void_p,C.c_void_p,C.c_ulonglong,C.c_void_p]
    sodium.crypto_sign_detached.restype=sodium.crypto_sign_verify_detached.restype=C.c_int
    def native_admit(raw):
        if sodium.crypto_core_ed25519_is_valid_point(raw)!=1:return False
        product=C.create_string_buffer(32);summed=C.create_string_buffer(32)
        if sodium.crypto_scalarmult_ed25519_noclamp(product,(L-1).to_bytes(32,'little'),raw)!=0:return False
        if sodium.crypto_core_ed25519_add(summed,product,raw)!=0:return False
        return summed.raw==IDENTITY and raw!=IDENTITY
    failures=[];signatures=[];points=[]
    for i in range(24):
        seed=hashlib.sha256(b'DKN REVIEW PUBLIC FIXTURE SEED '+str(i).encode()).digest()
        key=Ed25519PrivateKey.from_private_bytes(seed);pub=bytes.fromhex(key_hex(key))
        pk=C.create_string_buffer(32);sk=C.create_string_buffer(64)
        assert sodium.crypto_sign_seed_keypair(pk,sk,seed)==0
        if pk.raw!=pub:failures.append('public-key-'+str(i))
        msg=b'PUBLIC INTEROP FIXTURE\x00'+bytes(range(i*3))
        sig=C.create_string_buffer(64);length=C.c_ulonglong()
        assert sodium.crypto_sign_detached(sig,C.byref(length),msg,len(msg),sk)==0
        okay=(length.value==64 and sig.raw==key.sign(msg))
        _verify_sig(pub.hex(),msg,sig.raw.hex())
        okay &= sodium.crypto_sign_verify_detached(key.sign(msg),msg,len(msg),pub)==0
        changed=bytearray(sig.raw);changed[i%64]^=1
        try:_verify_sig(pub.hex(),msg,bytes(changed).hex());rejected=False
        except Refusal:rejected=True
        okay &= rejected and sodium.crypto_sign_verify_detached(bytes(changed),msg,len(msg),pub)!=0
        if not okay:failures.append('signature-'+str(i))
        signatures.append({'case':i,'seed_sha256':hashlib.sha256(seed).hexdigest(),'public_key_hex':pub.hex(),
                           'valid_signature_agreement':okay,'mutated_signature_refused':bool(rejected)})
        points.append(('generated-'+str(i),pub))
        if i<12:
            mixed=C.create_string_buffer(32)
            torsion=(P-1).to_bytes(32,'little')
            assert sodium.crypto_core_ed25519_add(mixed,pub,torsion)==0
            points.append(('mixed-order-'+str(i),mixed.raw))
    for i in range(48):points.append(('hash-bytes-'+str(i),hashlib.sha256(b'PUBLIC POINT '+str(i).encode()).digest()))
    points += [('identity',IDENTITY),('identity-negative-zero',IDENTITY[:-1]+b'\x80'),
               ('zero',b'\x00'*32),('noncanonical-y',P.to_bytes(32,'little')),('order-two',(P-1).to_bytes(32,'little'))]
    point_results=[];naive_differences=[]
    for label,raw in points:
        python=admitted_public_key(raw);native=native_admit(raw)
        if python!=native:failures.append(label)
        naive=sodium.crypto_core_ed25519_is_valid_point(raw)==1
        if naive!=native:naive_differences.append(label)
        point_results.append({'case':label,'point_hex':raw.hex(),'dkn':python,'sodium_with_subgroup_check':native})
    return {'schema':'dkn.native-crypto-crosscheck.v0.2-rc2','status':'PASS' if not failures else 'FAIL',
            'backend':name,'backend_version':sodium.sodium_version_string().decode(),
            'scope':'FIXED_PUBLIC_KEY_AND_SIGNATURE_CORPUS_NOT_FULL_DKN_OR_INDEPENDENT_REVIEW',
            'point_comparisons':len(point_results),'signature_positive_cases':len(signatures),
            'signature_negative_cases':len(signatures),'failures':failures,
            'naive_sodium_point_admission_disagreements':naive_differences,
            'point_check_method':'is_valid_point AND [L-1]P+P==identity, nonidentity',
            'source':'https://doc.libsodium.org/advanced/point-arithmetic',
            'points':point_results,'signatures':signatures,'authority_effect':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path);a=p.parse_args();r=run()
    if a.out:a.out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in r.items() if k not in ('points','signatures')},sort_keys=True))
    return 0 if r['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
