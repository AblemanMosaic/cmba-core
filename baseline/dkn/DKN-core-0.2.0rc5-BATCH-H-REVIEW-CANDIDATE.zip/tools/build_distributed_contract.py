"""Explicit DS-G1 model/binding authoring. Verification never regenerates acceptance."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from dkn_v02 import canonical,commit

OBLIGATIONS=[
 ('Deterministic finite model','Identical scenario bytes produce identical model trace/results; no live service is implied.',
  ['simulation::run_scenario'],['simulation::test_exact_replay_and_no_input_mutation']),
 ('Local evidence visibility','Reader results use only delivered/local supplied objects and caller policy, never unseen catalog state.',
  ['simulation::run_scenario','distributed::assess_view'],['simulation::test_reader_has_no_hidden_catalog_oracle']),
 ('Exact signed publication join','Payload, manifest, certificate, signer and namespace match exact reader expectations; certify_artifact is not execution.',
  ['distributed::_verify_envelope','distributed::assess_view'],['views::test_exact_join_is_not_execution_authority','views::test_certificate_binds_subject_namespace_and_payload']),
 ('Pinned continuity and exact floors','Local and external ancestry floors both apply; known descendants do not silently advance pins.',
  ['distributed::assess_view'],['views::test_local_floor_cannot_erase_external_floor','views::test_known_newer_view_blocks_stale_pin_without_updating_it']),
 ('Caller-relative time and incompleteness','Age/validity/missing evidence remain scoped to explicit caller time; withheld updates are not globally detected.',
  ['distributed::assess_view'],['views::test_checkpoint_and_time_bounds','simulation::test_reference_scenarios_have_hand_authored_outcomes']),
 ('Visible conflicts and recovery limits','Valid visible lifecycle forks are retained without a winner; guardian signatures cannot prove legitimacy.',
  ['distributed::assess_view'],['views::test_supplied_recovery_forks_do_not_select_a_winner','simulation::test_colluding_guardians_can_meet_crypto_threshold_not_legitimacy']),
 ('Witness exactness','Supplied witness heads join only the exact lifecycle head/sequence/epoch; duplicates do not make a quorum.',
  ['distributed::assess_view'],['views::test_witness_exact_head_sequence_epoch_join','views::test_all_three_witness_subsets']),
 ('Scoped assurance and contradictions','Required evidence scopes are exact; configured optional checks do not hide applicable known contradictions.',
  ['distributed::validate_reader','distributed::assess_view'],['views::test_assurance_exact_scope_required','views::test_optional_evidence_cannot_hide_known_applicable_conflict']),
 ('Compositional diagnostics','Inherited composition discloses transitive shared dependencies/domains and metadata exposure without asserting independence.',
  ['distributed::assess_view'],['simulation::test_transitive_shared_failure_and_metadata_exposure']),
 ('Explicit delivery and common-cause model','Delivery order, blocked endpoints/links, explicit retries and overlapping failure domains obey the declared finite scheduler.',
  ['simulation::run_scenario'],['simulation::test_same_time_deliveries_precede_failure_control','simulation::test_domain_restore_does_not_clear_other_failure','simulation::test_exhaustive_three_replica_reachability']),
 ('Rollback boundary witnessed','Modeled local restore preserves externally held floors by assumption; real SQLite restoration tests show local floor loss.',
  ['simulation::run_scenario','distributed::assess_view'],['vault::test_whole_database_restore_loses_local_floor_but_external_pin_detects','vault::test_valid_recovery_fork_does_not_overwrite_local_selection']),
 ('Replay is recomputation','Replay compares complete recomputed transcript, not just an untrusted success label or internally consistent hash chain.',
  ['simulation::verify_replay','distributed::object_hash'],['simulation::test_transcript_mutations_refuse','interfaces::test_node_trace_domain_and_linkage']),
 ('Finite read-only interfaces','Closed schemas, finite byte/object/event/view budgets and typed refusals; no network, wall clock, signing or process execution in runtime.',
  ['distributed_abi::dispatch','distributed_schemas::validate_shape','simulation::validate_scenario'],['simulation::test_core_simulator_uses_no_network_clock_random_files_or_processes','views::test_nested_malformed_candidates_never_raise_untyped_errors','simulation::test_duplicate_ids_and_excess_assessments_refuse']),
 ('Separate semantics and realization','Frozen base/LC-F1 semantics, separately committed DS-G1 model and reference-assisted finite conformance; no equivalence proof.',
  ['simulation::verify_replay'],['interfaces::test_frozen_distributed_corpus','binding::test_all_three_semantic_contracts_bound_and_predecessors_unchanged'])]


def build(root=ROOT):
    def rows(paths):return [{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in sorted(set(paths))]
    base=json.loads((root/'model/v02/SEMANTIC-COMMITMENT.json').read_bytes())
    lc=json.loads((root/'model/lifecycle-f1/COMMITMENT.json').read_bytes())
    normative=['docs/batch-g/PROTOCOL.md','docs/batch-g/THREAT-MODEL.md','docs/batch-g/SCENARIO-CATALOG.md',
               'vectors/v02/distributed-g1.json','interop/distributed-g1-conformance.json']
    for folder in ('schemas/v02/distributed-g1','profiles/distributed-g1/scenarios'):
        normative += [p.relative_to(root).as_posix() for p in (root/folder).glob('*.json')]
    model={'schema':'dkn.distributed-contract.v1','profile':'DS-G1',
       'base_semantic_digest':base['digest_hex'],'lifecycle_semantic_digest':lc['digest_hex'],
       'authority_effect':'NONE','obligations':[{'id':f'G-{i:02d}','title':o[0],'realized_guarantee':o[1]} for i,o in enumerate(OBLIGATIONS,1)],
       'explicit_exclusions':['live networking or deployment','consensus safety or liveness','globally current state',
         'automated trust bootstrap or execution permission','independent clock or protected floor implementation',
         'honesty or independence of signers','real uptime or censorship resistance measurements',
         'hostile-host custody or physical failure simulation','whole-program semantic equivalence','independent approval'],
       'normative_references':rows(normative)}
    commitment=commit('distributed-contract','dkn.distributed-contract.v1',model)
    sources=[p.relative_to(root).as_posix() for p in (root/'src/dkn_v02').glob('*.py')]
    sources += [p.relative_to(root).as_posix() for p in (root/'tests_v02').glob('test_batch_g*.py')]
    sources += ['tools/'+n+'.py' for n in ('build_distributed_contract','check_distributed_contract',
        'build_distributed_vectors','reference_distributed_conformance','build_batch_g_candidate','verify_installed_g')]
    sources += ['tools/run_conformance.py','tools/verify_v02_candidate.py','pyproject.toml',
        'examples/distributed_fixtures.py','examples/v02_distributed_simulation.py',
        'interop/distributed_trace_check.mjs','interop/dkn_v02_verify.mjs']
    trace=[]
    for i,o in enumerate(OBLIGATIONS,1):
        trace.append({'obligation':f'G-{i:02d}',
          'implementation':['src/dkn_v02/'+m+'.py::'+f for m,f in (ref.split('::') for ref in o[2])],
          'tests':['tests_v02/test_batch_g_'+m+'.py::'+f for m,f in (ref.split('::') for ref in o[3])]})
    binding={'schema':'dkn.distributed-realization-binding.v1','distribution_version':'0.2.0rc4',
        'semantic_digest':commitment['digest_hex'],'source_files':rows(sources),'traceability':trace,
        'authority_effect':'NONE','claim_ceiling':'TRACEABILITY_NOT_FORMAL_REFINEMENT_PROOF'}
    folder=root/'model/distributed-g1';folder.mkdir(exist_ok=True)
    for name,obj in [('CONTRACT',model),('COMMITMENT',commitment),('REALIZATION-BINDING',binding)]:
        (folder/(name+'.json')).write_bytes(canonical(obj))
    # Refresh only source realization bindings, not the frozen predecessor contracts.
    for name in ('v02','lifecycle-f1'):
        p=root/'model'/name/'REALIZATION-BINDING.json';v=json.loads(p.read_bytes())
        v['distribution_version']='0.2.0rc4';v['source_files']=rows([r['path'] for r in v['source_files']])
        p.write_bytes(canonical(v))
    return {'semantic_digest':commitment['digest_hex'],'obligations':len(OBLIGATIONS),
            'normative_references':len(normative),'source_files':len(binding['source_files'])}
if __name__=='__main__':print(json.dumps(build(),sort_keys=True))
