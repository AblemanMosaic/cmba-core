"""Executable offline LC-F1 lifecycle + transactional vault, all keys temporary fixtures.

A production integration supplies protected keys, recognized pins, a clock and its own
admission policy. No public publication or automatic software execution occurs here.
"""
from pathlib import Path
import json
import tempfile
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import declare_genesis, key_hex, pack, certify
from dkn_v02 import lifecycle as lc
from dkn_v02.vault import TransactionalVault


def run():
    owner, delegate, successor = [Ed25519PrivateKey.generate() for _ in range(3)]
    guardians = sorted([Ed25519PrivateKey.generate() for _ in range(3)],key=key_hex)
    policy = lc.lifecycle_policy(recovery_keys=[key_hex(key) for key in guardians],
        recovery_threshold=2,allowed_operations=['certify_artifact'],max_grant_seconds=3600)
    genesis = declare_genesis(semantic_name='example.lifecycle',purpose='publisher',nonce='example',
        key=owner,recovery_policy_ref=lc.policy_reference(policy))
    raw,manifest=pack({'message.txt':b'The meaning stays pinned; the realization can change.\n'})
    events=[lc.make_event(genesis,policy,[],kind='delegate',issued_at=100,
        payload={'subject_public_key_hex':key_hex(delegate),'artifact_root':manifest['logical_root'],
                 'operations':['certify_artifact'],'not_before':100,'expires_at':500},signing_keys=[owner])]
    cert=certify(manifest,delegate,namespace_root=genesis['namespace_root'])
    checkpoint=lc.make_checkpoint(genesis,policy,events,issued_at=120,expires_at=240,key=owner)
    with tempfile.TemporaryDirectory(prefix='dkn-f-demo-') as directory:
        vault=TransactionalVault.create(Path(directory)/'vault.db')
        vault.put_artifact(raw,certificate=cert,genesis=genesis)
        pin=vault.advance_namespace(genesis,policy,events,expected_head=None)
        result=lc.inspect_with_lifecycle(raw,cert,genesis,policy,events,
            expected_namespace=genesis['namespace_root'],expected_head=pin['head_ref'],
            now=130,max_checkpoint_age=60,checkpoint=checkpoint)
        assert result['lifecycle']['status']=='MATCH_FOR_SUPPLIED_VIEW'
        revoked=lc.make_event(genesis,policy,events,kind='revoke_grant',issued_at=140,
            payload={'grant_ref':events[0]['event_ref']},signing_keys=[owner])
        events.append(revoked)
        vault.advance_namespace(genesis,policy,events,expected_head=pin['head_ref'])
        checkpoint=lc.make_checkpoint(genesis,policy,events,issued_at=145,expires_at=240,key=owner)
        denied=lc.inspect_with_lifecycle(raw,cert,genesis,policy,events,
            expected_namespace=genesis['namespace_root'],expected_head=revoked['event_ref'],
            now=150,max_checkpoint_age=60,checkpoint=checkpoint)
        assert denied['lifecycle']['status']=='NO_MATCH'
        recovered=lc.make_event(genesis,policy,events,kind='recover',issued_at=160,
            payload={'successor_public_key_hex':key_hex(successor)},signing_keys=guardians[:2]+[successor])
        events.append(recovered)
        vault.advance_namespace(genesis,policy,events,expected_head=revoked['event_ref'])
        state=vault.read_namespace(genesis['namespace_root'])['state']
        assert state['active_key']==key_hex(successor) and state['epoch']==1
        assert vault.resolve_exact(manifest['logical_root'])['result']['integrity']=='PASS'
    return {'status':'PASS','delegation':result['lifecycle']['status'],'after_revocation':denied['lifecycle']['status'],
            'recovery':'TWO_PRECOMMITTED_GUARDIANS_PLUS_SUCCESSOR_POSSESSION',
            'namespace_root_preserved':state['namespace_root']==genesis['namespace_root'],
            'global_currentness':'NOT_ESTABLISHED','authority_effect':'NONE'}

if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
