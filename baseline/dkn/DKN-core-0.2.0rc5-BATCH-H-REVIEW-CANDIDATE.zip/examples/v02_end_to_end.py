"""Publish -> mirror -> retrieve -> inspect -> traverse -> assess, entirely offline.

Public deterministic fixture keys, not operational identities. No network writes.
"""
import json
import tempfile
from pathlib import Path
from dkn_v02 import pack,certify,declare_genesis,inspect,LocalIndex,relation_commitment
from dkn_v02.storage import DirectoryStore,MemoryStore,retrieve
from dkn_v02.assured_navigation import inspect_with_assurance
from examples.v02_assurance import fixture_bundle


def run():
    b=fixture_bundle();raw,m=b['raw'],b['manifest'];key=b['issuer']
    g=declare_genesis(semantic_name='example.dkn',purpose='publisher',nonce='fixture-only',key=key)
    cert=certify(m,key,namespace_root=g['namespace_root'])
    with tempfile.TemporaryDirectory(prefix='dkn-e-example-') as tmp:
        disk=DirectoryStore(Path(tmp)/'store');mirror=MemoryStore('mirror')
        locations=[disk.put(raw),mirror.put(raw)]
        got,retrieval=retrieve(locations,{'local':disk,'mirror':mirror},expected_root=m['logical_root'])
        idx=LocalIndex(Path(tmp)/'index');idx.add(got,certificate=cert,genesis=g)
        relations=[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on',
                    'destination':m['logical_root'],'scope':'fixture dependency'}]
        parent,pm=pack({'README.txt':b'Offline dependency demonstration\n'},[relation_commitment(relations)])
        idx.add(parent,certificate=certify(pm,key),relations=relations)
        graph=idx.traverse(pm['logical_root'])
        joined=inspect_with_assurance(got,certificate=cert,genesis=g,
            **{k:b[k] for k in ('descriptor','contract','evidence','policy','context')})
        assert len(graph['nodes'])==2 and joined['assurance']['status']=='SATISFIES'
        assert idx.discover(semantic_name='example.dkn')['returned']==1
        return {'fixture_only':True,'retrieval':retrieval['status'],'verified_nodes':len(graph['nodes']),
                'assurance':joined['assurance']['status'],'recognition':joined['recognition'],
                'legacy_anchor_required':False,'authority_effect':'NONE'}

if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
