"""Executable pure offline partition/revocation demonstration; all material is synthetic."""
import json
from dkn_v02.simulation import run_scenario,verify_replay
if __package__:
    from .distributed_fixtures import extended_scenarios,EXPECTED_STATUSES
else:
    from distributed_fixtures import extended_scenarios,EXPECTED_STATUSES

def run():
    scenarios=extended_scenarios();results=[]
    for name in ('partition-heal','delayed-revocation','recovery-fork','external-floor-rollback','common-cause-outage'):
        r=run_scenario(scenarios[name]);assert verify_replay(scenarios[name],r)['status']=='MATCH_EXACT_SIMULATION_REPLAY'
        states=[a['report']['status'] for a in r['assessments']];assert states==EXPECTED_STATUSES[name]
        results.append({'scenario':name,'statuses':states,'trace_root':r['trace_root']})
    return {'status':'PASS','scenarios':results,'simulation_only':True,'production_evidence':False,
            'global_currentness':'NOT_ESTABLISHED','authority_effect':'NONE'}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
