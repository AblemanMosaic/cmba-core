"""Application-side policy example. DKN verifies bindings; this application admits a note.

Pins are reader-owned inputs, never learned from the untrusted bundle being checked.
The temporary demonstration generates a fresh key; it does not establish a real publisher.
"""
from __future__ import annotations
import io
import json
import zipfile
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import (Refusal, canonical, commit, pack, certify, declare_genesis,
                     verify_archive, verify_certificate, verify_dimension, key_hex, inspect)

SCHEMA='example.utf8-note.v1'


def accept_note(raw, manifest, certificate, genesis, declaration, *,
                expected_root, pinned_namespace_root, pinned_publisher_key):
    def require(condition,code):
        if not condition:raise Refusal(code)
    archive=verify_archive(raw,supported_schemas={SCHEMA})
    require(archive['logical_root']==expected_root,'APP_ARTIFACT_PIN_MISMATCH')
    verify_certificate(certificate,manifest)
    require(manifest['logical_root']==archive['logical_root'],'APP_MANIFEST_SUBSTITUTION')
    result=inspect(raw,certificate=certificate,genesis=genesis)
    require(result['namespace_root']==pinned_namespace_root,'APP_NAMESPACE_PIN_MISMATCH')
    require(result['signer_public_key_hex']==pinned_publisher_key,'APP_PUBLISHER_PIN_MISMATCH')
    require(result['namespace_authorization']=='PASS_FOR_SUPPLIED_CHAIN_ONLY','APP_NAMESPACE_BINDING_REQUIRED')
    dims=[d for d in manifest['dimensions'] if d['dimension_id']=='note-profile']
    require(len(dims)==1 and dims[0]['schema_id']==SCHEMA and dims[0]['critical'],'APP_REQUIRED_DIMENSION_MISSING')
    verify_dimension(dims[0],declaration,supplied=True,supported_schemas={SCHEMA})
    require(declaration=={'content_kind':'utf8-note','logical_filename':'note.txt','text_encoding':'utf-8'},
            'APP_PROFILE_UNSUPPORTED')
    # Exact archive verification has completed; read this declared payload member without extracting.
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require('note.txt' in z.namelist(),'APP_DECLARED_FILE_MISSING')
        try:text=z.read('note.txt').decode('utf-8')
        except UnicodeError as exc:raise Refusal('APP_PAYLOAD_ENCODING_MISMATCH') from exc
    return {'status':'ADMITTED_AS_UTF8_NOTE','text':text,
            'application_semantics':'PASS_FOR_THIS_NOTE_PROFILE_ONLY',
            'namespace_scope':'SUPPLIED_FOUNDER_CHAIN_ONLY','freshness':'NOT_ESTABLISHED',
            'execution_authorized':False,'authority_effect':'NONE'}


def make_demo():
    key=Ed25519PrivateKey.generate()
    genesis=declare_genesis(semantic_name='example.notes',purpose='publisher',nonce='demo',key=key)
    declaration={'content_kind':'utf8-note','logical_filename':'note.txt','text_encoding':'utf-8'}
    raw,manifest=pack({'note.txt':b'A portable note.\n','profile.json':canonical(declaration)},
                      [commit('note-profile',SCHEMA,declaration)])
    certificate=certify(manifest,key,namespace_root=genesis['namespace_root'])
    # In a real integration these pins come from protected reader configuration / an accepted release decision.
    pins={'expected_root':manifest['logical_root'],'pinned_namespace_root':genesis['namespace_root'],
          'pinned_publisher_key':key_hex(key)}
    return dict(raw=raw,manifest=manifest,certificate=certificate,genesis=genesis,declaration=declaration),pins,key


def run():
    bundle,pins,_=make_demo()
    result=accept_note(**bundle,**pins)
    assert result['execution_authorized'] is False
    return {**result,'fixture_only':True,'pins':'DEMONSTRATION_ONLY_NOT_EXTERNAL_RECOGNITION'}

if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
