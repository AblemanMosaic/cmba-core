"""Public deterministic TEST identities and bounded scenarios, never production keys.

Signing is fixture authoring outside the read-only simulator. Serialized scenarios
contain public records only. Control-domain labels are modeled assumptions.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import pack, certify, declare_genesis, key_hex
from dkn_v02 import lifecycle as lc
from dkn_v02.assurance import seal
from dkn_v02.federation import checkpoint_policy_ref
from dkn_v02.reference_profiles import reference_profile


def fixture_key(label):
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b'PUBLIC DKN BATCH G TEST KEY:'+label.encode()).digest())

def fixture_bundle():
    owner=fixture_key('owner');delegate=fixture_key('delegate')
    guardians=sorted([fixture_key('guardian-'+str(i)) for i in range(3)],key=key_hex)
    successors=[fixture_key('successor-'+str(i)) for i in range(2)]
    witnesses=[fixture_key('witness-'+str(i)) for i in range(3)]
    policy=lc.lifecycle_policy(recovery_keys=[key_hex(k) for k in guardians],recovery_threshold=2,
                              allowed_operations=['certify_artifact'],max_grant_seconds=3600)
    genesis=declare_genesis(semantic_name='fixture.distributed',purpose='publisher',nonce='g1',key=owner,
                           recovery_policy_ref=lc.policy_reference(policy))
    raw,manifest=pack({'message.txt':b'DKN DS-G1 public simulation fixture\n'})
    grant=lc.make_event(genesis,policy,[],kind='delegate',issued_at=100,
        payload={'subject_public_key_hex':key_hex(delegate),'artifact_root':manifest['logical_root'],
                 'operations':['certify_artifact'],'not_before':100,'expires_at':500},signing_keys=[owner])
    events=[grant]
    revoked=events+[lc.make_event(genesis,policy,events,kind='revoke_grant',issued_at=140,
        payload={'grant_ref':grant['event_ref']},signing_keys=[owner])]
    recovery=[]
    for i,k in enumerate(successors):
        recovery.append(events+[lc.make_event(genesis,policy,events,kind='recover',issued_at=140,
                    payload={'successor_public_key_hex':key_hex(k)},signing_keys=guardians[:2]+[k])])
    def journal(chain,key,at):
        return {'kind':'journal','value':{'genesis':genesis,'policy':policy,'events':chain,
            'checkpoint':lc.make_checkpoint(genesis,policy,chain,issued_at=at,expires_at=300,key=key)}}
    certificate=certify(manifest,delegate,namespace_root=genesis['namespace_root'])
    objects={'artifact':{'kind':'artifact','value':{'archive_hex':raw.hex(),'certificate':certificate}},
        'granted':journal(events,owner,120),'revoked':journal(revoked,owner,145),
        'recovery-a':journal(recovery[0],successors[0],145),'recovery-b':journal(recovery[1],successors[1],145)}
    for label,profile,admin in [('enterprise','ENTERPRISE_DISTRIBUTED','corporate-admin'),
                              ('mirror-a','P2P_CAS','peer-admin-a'),('mirror-b','P2P_CAS','peer-admin-b')]:
        body=reference_profile(profile);body.update(substrate_id='fixture.'+label,deployment_status='DECLARED_DEPLOYMENT',
           valid_from=0,valid_until=1000,assumptions=[],fault_domains=[{'dimension':'administration','domain_id':admin}])
        objects[label]={'kind':'substrate','value':seal('substrate',body,owner)}
    desc=objects['enterprise']['value']
    members=[{'public_key_hex':key_hex(w),'fault_domains':[{'dimension':'administration','domain_id':'witness-'+str(i)}]}
             for i,w in enumerate(witnesses)]
    wp={'schema':'dkn.checkpoint-policy.v0.2-candidate','policy_id':'fixture.witnesses',
        'protocol':'signed-head-observation-v1','substrate_ref':desc['record_hash'],
        'namespace_root':genesis['namespace_root'],'epoch':0,'members':members,'threshold':2,
        'independence_dimensions':['administration'],'max_age_seconds':60,'minimum_sequence':1,'valid_from':0,'valid_until':1000}
    for i,w in enumerate(witnesses):
        body={'schema':'dkn.head-observation.v0.2-candidate','policy_ref':checkpoint_policy_ref(wp),
              'substrate_ref':desc['record_hash'],'namespace_root':genesis['namespace_root'],'epoch':0,
              'sequence':1,'head_root':grant['event_ref'],'observed_at':120,'valid_until':300}
        objects['witness-'+str(i)]={'kind':'observation','value':seal('checkpoint',body,w)}
    conflict={**objects['witness-0']['value']['body'],'head_root':'f'*64}
    objects['witness-conflict']={'kind':'observation','value':seal('checkpoint',conflict,witnesses[0])}
    scope={'substrate_ref':desc['record_hash'],'artifact_root':manifest['logical_root'],'namespace_root':genesis['namespace_root']}
    contract={'schema':'dkn.assurance-contract.v0.2-candidate','contract_id':'fixture.integrity',
        'scope':scope,'dimension':'integrity','decision_rule':'evidence-obligations-v1',
        'requirements':[{'id':'retrieval','predicate':'retrieval.verified','methods':['OBSERVATION'],
                         'min_signers':1,'independence_dimensions':[],'max_age_seconds':60}],
        'assumptions':[],'valid_from':0,'valid_until':1000}
    ap={'schema':'dkn.assurance-policy.v0.2-candidate','policy_id':'fixture.recognition',
        'descriptor_signers':[key_hex(owner)],'observers':[{'public_key_hex':key_hex(witnesses[0]),
        'predicates':['retrieval.verified'],'fault_domains':members[0]['fault_domains']}]}
    ev={'schema':'dkn.assurance-evidence.v0.2-candidate','scope':scope,'predicate':'retrieval.verified',
        'method':'OBSERVATION','outcome':'SUPPORTS','observed_at':120,'valid_until':300,'basis_ref':None,
        'note':'PUBLIC SYNTHETIC FIXTURE, NOT A LIVE OBSERVATION'}
    objects['support']={'kind':'evidence','value':seal('evidence',ev,witnesses[0])}
    objects['refute']={'kind':'evidence','value':seal('evidence',{**ev,'outcome':'REFUTES'},witnesses[0])}
    r={'schema':'dkn.distributed-reader.v0.2-g1','expected_artifact_root':manifest['logical_root'],
       'expected_namespace':genesis['namespace_root'],'expected_head':grant['event_ref'],
       'subject_public_key_hex':key_hex(delegate),'operation':'certify_artifact',
       'max_checkpoint_age':60,'minimum':None,'external_minimum':None,
       'require_witness':False,'witness_policy':None,'require_assurance':False,'assurance':None,'composition_roots':[]}
    return dict(objects=objects,reader=r,witness_policy=wp,
        assurance={'descriptor_ref':desc['record_hash'],'contract':contract,'policy':ap,'accepted_premises':[]},
        genesis=genesis,policy=policy,events=events,revoked=revoked,recovery=recovery,raw=raw,manifest=manifest,
        owner=owner,delegate=delegate,guardians=guardians,successors=successors,witnesses=witnesses)


def scenario(name='normal',*,topology='FEDERATED',bundle=None):
    b=bundle or fixture_bundle()
    # Catalog may contain withheld material; the reader receives only its own node holdings.
    return {'schema':'dkn.distributed-scenario.v0.2-g1','scenario_id':name,'topology':topology,
       'objects':[{'id':name,**deepcopy(o)} for name,o in sorted(b['objects'].items())],
       'nodes':[{'id':'publisher','fault_domains':[{'dimension':'administration','domain_id':'publisher-admin'}],
                  'initial_objects':sorted(b['objects']),'clock_offset':0},
                {'id':'reader','fault_domains':[{'dimension':'administration','domain_id':'reader-admin'}],
                  'initial_objects':[],'clock_offset':0}],
       'readers':[{'id':'client','node':'reader','policy':deepcopy(b['reader'])}],
       'steps':[send('artifact'),send('granted'),assess('initial')],'until':160}

def send(obj,at=120,delay=0,source='publisher',target='reader'):
    return {'at':at,'action':'send','source':source,'target':target,'object':obj,'delay':delay}
def assess(label,at=130):return {'at':at,'action':'assess','reader':'client','label':label}
def configure(policy,at=150):return {'at':at,'action':'configure','reader':'client','policy':deepcopy(policy)}

def reference_scenarios():
    b=fixture_bundle();out={}
    def add(s):out[s['scenario_id']]=s
    add(scenario('normal',bundle=b))
    s=scenario('partition-heal',topology='P2P',bundle=b)
    s['steps']=[{'at':110,'action':'partition','left':'publisher','right':'reader','blocked':True},
       send('artifact'),send('granted'),assess('isolated'),
       {'at':140,'action':'partition','left':'publisher','right':'reader','blocked':False},
       send('artifact',145),send('granted',145),assess('healed',150)];add(s)
    s=scenario('delayed-revocation',bundle=b)
    r=deepcopy(b['reader']);r['expected_head']=b['revoked'][-1]['event_ref']
    s['steps'] += [send('revoked',145,10),assess('before-delivery',150),assess('newer-visible',155),
                   configure(r,156),assess('new-pin',157)];add(s)
    s=scenario('withheld-revocation',bundle=b)
    s['steps'] += [assess('still-locally-matches',160)];add(s)
    s=scenario('expired-checkpoint',bundle=b);s['steps'] += [assess('age-exceeded',181)];s['until']=181;add(s)
    s=scenario('duplicate-delivery',bundle=b);s['steps']=[send('artifact'),send('granted'),send('granted'),assess('deduplicated')];add(s)
    s=scenario('invalid-artifact-fallback',topology='P2P',bundle=b)
    bad=deepcopy(b['objects']['artifact']);bad['value']['archive_hex']='00'
    s['objects'].append({'id':'bad-artifact',**bad});s['nodes'][0]['initial_objects'].append('bad-artifact')
    s['steps']=[send('bad-artifact'),send('granted'),assess('bad-only'),send('artifact',140),assess('valid-fallback',145)];add(s)
    for name,extra in [('witness-quorum',[]),('witness-equivocation',[send('witness-conflict')]),
                       ('witness-shortfall',None)]:
        s=scenario(name,bundle=b);s['readers'][0]['policy'].update(require_witness=True,witness_policy=deepcopy(b['witness_policy']))
        s['steps']=[send('artifact'),send('granted'),send('witness-0')]
        if extra is not None:s['steps'] += [send('witness-1')]+extra
        s['steps'] += [assess('witness-result')];add(s)
    s=scenario('recovery-fork',bundle=b);s['steps'] += [send('recovery-a',145),send('recovery-b',145),assess('fork-visible',150)];add(s)
    s=scenario('hidden-recovery-fork',bundle=b)
    s['steps'] += [send('recovery-a',145),assess('one-branch-visible',150)];add(s)
    for name,negative in [('assurance-supported',False),('assurance-refuted',True)]:
        s=scenario(name,topology='ENTERPRISE',bundle=b)
        s['readers'][0]['policy'].update(require_assurance=True,assurance=deepcopy(b['assurance']))
        s['steps']=[send('artifact'),send('granted'),send('enterprise'),send('support')]
        if negative:s['steps'].append(send('refute'))
        s['steps'].append(assess('contract-result'));add(s)
    # Whole local state restoration loses local pins; separate external floor survives by model assumption.
    for name,external in [('local-rollback',False),('external-floor-rollback',True)]:
        s=scenario(name,topology='LOCAL',bundle=b)
        p=deepcopy(r)
        floor={'sequence':2,'head_ref':p['expected_head']}
        p['minimum']=floor
        if external:p['external_minimum']=floor
        s['steps'] += [{'at':131,'action':'snapshot','node':'reader','slot':'old'},send('revoked',145),
            configure(p,146),assess('revoked-before-restore',147),
            {'at':150,'action':'restore','node':'reader','slot':'old'},assess('after-restore',151)];add(s)
    s=scenario('common-cause-outage',topology='ENTERPRISE',bundle=b)
    s['nodes'][0]['fault_domains']=[{'dimension':'administration','domain_id':'corporate-admin'}]
    s['nodes'].append({'id':'mirror','fault_domains':[{'dimension':'administration','domain_id':'corporate-admin'}],
                       'initial_objects':['artifact','granted'],'clock_offset':0})
    s['steps']=[{'at':110,'action':'domain','dimension':'administration','domain_id':'corporate-admin','online':False},
                send('artifact'),send('granted',source='mirror'),assess('both-unreachable')];add(s)
    s=scenario('independent-mirror-path',topology='HYBRID',bundle=b)
    s['nodes'].append({'id':'mirror','fault_domains':[{'dimension':'administration','domain_id':'other-admin'}],
                       'initial_objects':['artifact','granted'],'clock_offset':0})
    s['steps']=[{'at':110,'action':'node','node':'publisher','online':False},send('artifact'),
               send('artifact',source='mirror'),send('granted',source='mirror'),assess('fallback')];add(s)
    s=scenario('clock-skew',bundle=b);s['steps'] += [{'at':140,'action':'clock','node':'reader','offset':-30},assess('clock-before-checkpoint',141)];add(s)
    s=scenario('drop-in-flight',bundle=b)
    s['steps']=[send('artifact',120,20),send('granted',120,20),{'at':125,'action':'drop','message':'m000001'},assess('incomplete',150)];add(s)
    s=scenario('failure-in-flight',bundle=b)
    s['steps']=[send('artifact',120,20),send('granted',120,20),{'at':125,'action':'node','node':'publisher','online':False},assess('dropped',150)];add(s)
    return out


def extended_scenarios():
    """Additional governance/common-cause scenarios; expected outcomes live separately."""
    b=fixture_bundle();out=reference_scenarios()
    def add(s):out[s['scenario_id']]=s
    # Distinct keys under one declared administrator do not fill independent slots.
    s=scenario('shared-witness-administrator',bundle=b)
    wp=deepcopy(b['witness_policy'])
    for row in wp['members']:row['fault_domains']=[{'dimension':'administration','domain_id':'single-admin'}]
    s['readers'][0]['policy'].update(require_witness=True,witness_policy=wp)
    for o in s['objects']:
        if o['id'] in ('witness-0','witness-1'):
            i=int(o['id'][-1]);body={**o['value']['body'],'policy_ref':checkpoint_policy_ref(wp)}
            o['value']=seal('checkpoint',body,b['witnesses'][i])
    s['steps']=[send('artifact'),send('granted'),send('witness-0'),send('witness-1'),assess('not-independent')];add(s)
    # A guardian threshold can sign an undesired successor: signatures are not honesty.
    s=scenario('guardian-threshold-collusion',bundle=b)
    new=b['successors'][0];new_cert=certify(b['manifest'],new,namespace_root=b['genesis']['namespace_root'])
    s['objects'].append({'id':'new-certificate','kind':'artifact','value':{'archive_hex':b['raw'].hex(),'certificate':new_cert}})
    s['nodes'][0]['initial_objects'].append('new-certificate')
    p=deepcopy(b['reader']);p['expected_head']=b['recovery'][0][-1]['event_ref'];p['subject_public_key_hex']=key_hex(new)
    s['steps']=[send('recovery-a',145),send('new-certificate',145),configure(p,146),assess('cryptographically-valid-recovery',150)];add(s)
    # Wrong but threshold-signed observation cannot be joined to another journal head.
    s=scenario('witness-head-mismatch',bundle=b)
    s['readers'][0]['policy'].update(require_witness=True,witness_policy=deepcopy(b['witness_policy']))
    for o in s['objects']:
        if o['id'] in ('witness-0','witness-1'):
            i=int(o['id'][-1]);body={**o['value']['body'],'head_root':'e'*64}
            o['value']=seal('checkpoint',body,b['witnesses'][i])
    s['steps']=[send('artifact'),send('granted'),send('witness-0'),send('witness-1'),assess('cannot-join')];add(s)
    # Signed stale fork testimony stays contradictory after expiry.
    s=scenario('expired-conflict-retained',bundle=b)
    s['readers'][0]['policy'].update(require_witness=True,witness_policy=deepcopy(b['witness_policy']))
    for o in s['objects']:
        if o['id']=='witness-conflict':
            o['value']=seal('checkpoint',{**o['value']['body'],'valid_until':125},b['witnesses'][0])
    s['steps']=[send('artifact'),send('granted'),send('witness-0'),send('witness-1'),send('witness-conflict'),assess('expired-but-visible')];add(s)
    # Transitive common identity dependency + public metadata leakage are diagnostic, not a score.
    shared=reference_profile('PUBLIC_HOSTING');shared.update(substrate_id='fixture.shared-idp',deployment_status='DECLARED_DEPLOYMENT',
        valid_from=0,valid_until=1000,assumptions=[],fault_domains=[{'dimension':'identity','domain_id':'shared-idp'}])
    common=seal('substrate',shared,b['owner']);parents=[]
    s=scenario('transitive-shared-dependency',topology='HYBRID',bundle=b)
    s['objects'].append({'id':'common-idp','kind':'substrate','value':common})
    for i in range(2):
        body=reference_profile('ENTERPRISE_DISTRIBUTED');body.update(substrate_id='fixture.parent-'+str(i),
          deployment_status='DECLARED_DEPLOYMENT',valid_from=0,valid_until=1000,assumptions=[],
          dependencies=[common['record_hash']],fault_domains=[{'dimension':'administration','domain_id':'admin-'+str(i)}])
        p=seal('substrate',body,b['owner']);parents.append(p)
        s['objects'].append({'id':'parent-'+str(i),'kind':'substrate','value':p})
    s['nodes'][0]['initial_objects'] += ['common-idp','parent-0','parent-1']
    s['readers'][0]['policy']['composition_roots']=[p['record_hash'] for p in parents]
    s['steps']=[send('artifact'),send('granted'),send('parent-0'),send('parent-1'),send('common-idp'),assess('composed')];add(s)
    # Shared signers issue two views to isolated readers; healing reveals no canonical winner.
    s=scenario('partitioned-witness-fork',topology='FEDERATED',bundle=b)
    s['readers'][0]['policy'].update(require_witness=True,witness_policy=deepcopy(b['witness_policy']))
    other=deepcopy(s['nodes'][1]);other['id']='other-reader';s['nodes'].append(other)
    rp=deepcopy(s['readers'][0]);rp.update(id='other-client',node='other-reader');s['readers'].append(rp)
    for i in range(2):
        o={'id':'conflict-'+str(i),'kind':'observation','value':seal('checkpoint',
            {**b['objects']['witness-'+str(i)]['value']['body'],'head_root':'f'*64},b['witnesses'][i])}
        s['objects'].append(o);s['nodes'][0]['initial_objects'].append(o['id'])
    s['steps']=[{'at':110,'action':'partition','left':'reader','right':'other-reader','blocked':True},
        send('artifact'),send('granted'),send('witness-0'),send('witness-1'),
        send('artifact',target='other-reader'),send('granted',target='other-reader'),
        send('conflict-0',target='other-reader'),send('conflict-1',target='other-reader'),
        assess('left-isolated'),{'at':130,'action':'assess','reader':'other-client','label':'right-isolated'},
        {'at':140,'action':'partition','left':'reader','right':'other-reader','blocked':False},
        send('conflict-0',145,source='other-reader'),send('conflict-1',145,source='other-reader'),assess('healed-conflict',150)];add(s)
    return out

EXPECTED_STATUSES={
 'normal':['MATCH_FOR_SUPPLIED_VIEW'],
 'partition-heal':['INDETERMINATE','MATCH_FOR_SUPPLIED_VIEW'],
 'delayed-revocation':['MATCH_FOR_SUPPLIED_VIEW','MATCH_FOR_SUPPLIED_VIEW','INDETERMINATE','NO_MATCH'],
 'withheld-revocation':['MATCH_FOR_SUPPLIED_VIEW','MATCH_FOR_SUPPLIED_VIEW'],
 'expired-checkpoint':['MATCH_FOR_SUPPLIED_VIEW','INDETERMINATE'],
 'duplicate-delivery':['MATCH_FOR_SUPPLIED_VIEW'],
 'invalid-artifact-fallback':['INDETERMINATE','MATCH_FOR_SUPPLIED_VIEW'],
 'witness-quorum':['CONDITIONAL'],'witness-equivocation':['CONTRADICTED'],'witness-shortfall':['INDETERMINATE'],
 'recovery-fork':['MATCH_FOR_SUPPLIED_VIEW','CONTRADICTED'],
 'hidden-recovery-fork':['MATCH_FOR_SUPPLIED_VIEW','INDETERMINATE'],
 'assurance-supported':['MATCH_FOR_SUPPLIED_VIEW'],'assurance-refuted':['CONTRADICTED'],
 'local-rollback':['MATCH_FOR_SUPPLIED_VIEW','NO_MATCH','MATCH_FOR_SUPPLIED_VIEW'],
 'external-floor-rollback':['MATCH_FOR_SUPPLIED_VIEW','NO_MATCH','INDETERMINATE'],
 'common-cause-outage':['INDETERMINATE'],'independent-mirror-path':['MATCH_FOR_SUPPLIED_VIEW'],
 'clock-skew':['MATCH_FOR_SUPPLIED_VIEW','INDETERMINATE'],'drop-in-flight':['INDETERMINATE'],
 'failure-in-flight':['INDETERMINATE'],'shared-witness-administrator':['INDETERMINATE'],
 'guardian-threshold-collusion':['MATCH_FOR_SUPPLIED_VIEW'],'witness-head-mismatch':['INDETERMINATE'],
 'expired-conflict-retained':['CONTRADICTED'],'transitive-shared-dependency':['MATCH_FOR_SUPPLIED_VIEW'],
 'partitioned-witness-fork':['CONDITIONAL','INDETERMINATE','CONTRADICTED']}
