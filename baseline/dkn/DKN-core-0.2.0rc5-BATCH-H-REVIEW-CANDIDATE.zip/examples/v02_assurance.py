"""Offline executable Batch D demonstration. ALL keys and deployments are fixtures.

Creates no permanent files, publishes to no network, grants no authority.
"""
from __future__ import annotations
import json
import tempfile
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02.core import pack, key_hex, certify
from dkn_v02.assurance import seal, evaluate, compose, sam_hash
from dkn_v02.federation import checkpoint_policy_ref, assess_checkpoints, make_handoff
from dkn_v02.reference_profiles import reference_profile
from dkn_v02.storage import DirectoryStore, MemoryStore, retrieve
from dkn_v02.assured_navigation import inspect_with_assurance
from dkn_v02.sam_schemas import V


def fixture_bundle():
    """Public deterministic test seeds; NEVER use for real identities."""
    issuer = Ed25519PrivateKey.from_private_bytes(bytes([101])*32)
    witness1 = Ed25519PrivateKey.from_private_bytes(bytes([102])*32)
    witness2 = Ed25519PrivateKey.from_private_bytes(bytes([103])*32)
    raw, manifest = pack({'hello.txt': b'DKN Batch D offline fixture\n'})
    body = reference_profile('LOCAL_VAULT')
    body.update(deployment_status='DECLARED_DEPLOYMENT', substrate_id='fixture.vault',
                valid_from=900, valid_until=2000, assumptions=[],
                fault_domains=[{'dimension': 'administration', 'domain_id': 'fixture-owner'}])
    descriptor = seal('substrate', body, issuer)
    scope = {'substrate_ref': descriptor['record_hash'], 'artifact_root': manifest['logical_root'], 'namespace_root': None}
    contract = {'schema': 'dkn.assurance-contract.'+V, 'contract_id': 'fixture.integrity',
                'scope': scope, 'dimension': 'integrity', 'decision_rule': 'evidence-obligations-v1',
                'requirements': [{'id': 'retrieval', 'predicate': 'retrieval.verified',
                                  'methods': ['OBSERVATION'], 'min_signers': 1,
                                  'independence_dimensions': [], 'max_age_seconds': 60}],
                'assumptions': [], 'valid_from': 900, 'valid_until': 2000}
    policy = {'schema': 'dkn.assurance-policy.'+V, 'policy_id': 'fixture.local-policy',
              'descriptor_signers': [key_hex(issuer)],
              'observers': [{'public_key_hex': key_hex(w), 'predicates': ['retrieval.verified'],
                             'fault_domains': [{'dimension': 'administration', 'domain_id': 'witness-'+str(i)}]}
                            for i,w in enumerate((witness1,witness2), 1)]}
    ev_body = {'schema': 'dkn.assurance-evidence.'+V, 'scope': scope,
               'predicate': 'retrieval.verified', 'method': 'OBSERVATION', 'outcome': 'SUPPORTS',
               'observed_at': 990, 'valid_until': 1100, 'basis_ref': None,
               'note': 'Synthetic observation fixture, not empirical deployment evidence'}
    evidence = [seal('evidence', ev_body, witness1)]
    context = {'schema': 'dkn.assurance-context.'+V, 'at_time': 1000, 'accepted_premises': []}
    cp_policy = {'schema': 'dkn.checkpoint-policy.'+V, 'policy_id': 'fixture.federation',
                 'protocol': 'signed-head-observation-v1', 'substrate_ref': descriptor['record_hash'],
                 'namespace_root': 'a'*64, 'epoch': 0,
                 'members': [{'public_key_hex': o['public_key_hex'], 'fault_domains': o['fault_domains']} for o in policy['observers']],
                 'threshold': 2, 'independence_dimensions': ['administration'],
                 'max_age_seconds': 60, 'minimum_sequence': 2, 'valid_from': 900, 'valid_until': 2000}
    checkpoint = {'schema': 'dkn.head-observation.'+V, 'policy_ref': checkpoint_policy_ref(cp_policy),
                  'substrate_ref': descriptor['record_hash'], 'namespace_root': 'a'*64,
                  'epoch': 0, 'sequence': 2, 'head_root': manifest['logical_root'],
                  'observed_at': 990, 'valid_until': 1100}
    checkpoints = [seal('checkpoint', checkpoint, w) for w in (witness1,witness2)]
    return dict(raw=raw, manifest=manifest, issuer=issuer, witnesses=[witness1,witness2],
                descriptor=descriptor, contract=contract, policy=policy, context=context,
                evidence=evidence, checkpoint_policy=cp_policy, checkpoints=checkpoints)


def run():
    b = fixture_bundle()
    with tempfile.TemporaryDirectory(prefix='dkn-sam-demo-') as tmp:
        local = DirectoryStore(Path(tmp)/'vault')
        memory = MemoryStore('mirror')
        loc = local.put(b['raw'])
        mirrored = memory.put(b['raw'])
        raw, retrieval = retrieve([loc, mirrored], {'local': local, 'mirror': memory},
                                  expected_root=b['manifest']['logical_root'])
        assessment = inspect_with_assurance(raw, descriptor=b['descriptor'], contract=b['contract'],
                    evidence=b['evidence'], policy=b['policy'], context=b['context'],
                    certificate=certify(b['manifest'], b['issuer']))
    cp = assess_checkpoints(b['checkpoints'], b['checkpoint_policy'], at_time=1000)
    handoff = make_handoff(b['checkpoints'], b['checkpoint_policy'], at_time=1000, consumer='CCP')
    assert assessment['assurance']['status'] == 'SATISFIES'
    assert cp['status'] == 'CONDITIONAL' and cp['global_currentness'] == 'NOT_ESTABLISHED'
    assert handoff['execution_authorized'] is False
    return {'fixture_only': True, 'offline_retrieval': retrieval['status'],
            'evidence_contract': assessment['assurance']['status'],
            'federation_observation': cp['status'], 'consensus_safety': cp['consensus_safety'],
            'ccp_admission': handoff['admission'], 'authority_effect': 'NONE'}


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True))
