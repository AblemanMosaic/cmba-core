"""Executable offline example (PYTHONPATH=src python examples/v02_publish_verify.py)."""
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import commit, pack, certify, verify_archive, verify_certificate
key=Ed25519PrivateKey.from_private_bytes(bytes.fromhex('44'*32)) # TEST KEY ONLY
archive,manifest=pack({'README.md':b'Hello from DKN v0.2\n'},[commit('semantics','example.description',{'purpose':'demonstration'})])
cert=certify(manifest,key)
assert verify_archive(archive)['status']=='PASS'
assert verify_certificate(cert,manifest)['signature']=='PASS'
print('DKN v0.2 offline demonstration PASS:',manifest['logical_root'])
