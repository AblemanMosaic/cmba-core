"""Executable local navigation example using deterministic demonstration keys only."""
import json
import tempfile
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import LocalIndex,pack,certify,relation_commitment


def run():
    key=Ed25519PrivateKey.from_private_bytes(b'\x39'*32) # FIXTURE ONLY
    dependency,dep_m=pack({'library.txt':b'hello'})
    edges=[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on',
            'destination':dep_m['logical_root'],'scope':'example dependency claim'}]
    app,app_m=pack({'app.txt':b'world'},[relation_commitment(edges)])
    with tempfile.TemporaryDirectory() as tmp:
        vault=LocalIndex(Path(tmp)/'vault')
        vault.add(dependency,certificate=certify(dep_m,key))
        vault.add(app,certificate=certify(app_m,key),relations=edges)
        result=vault.traverse(app_m['logical_root'])
        assert len(result['nodes'])==2 and result['edges'][0]['relation_authentication']=='PASS'
        assert result['global_completeness']=='NOT_ESTABLISHED'
        print(json.dumps({'example':'PASS','nodes':len(result['nodes']),
                          'signed_claims':len(result['edges']),'global_completeness':result['global_completeness'],
                          'authority_effect':'NONE'},sort_keys=True))

if __name__=='__main__':run()
