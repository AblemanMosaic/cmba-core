# Developer guide

## Install the candidate

Use Python 3.12+; the actual rc2 runner is recorded in the receipt. From the extracted
source tree, install `python -m pip install .` for v0.2 or `python -m pip install '.[legacy]'`
for both tracks. Runtime dependencies are cryptography>=46,<47 and jsonschema>=4.23,<5;
the legacy extra adds blake3>=1.0,<2. For tests add `.[test]`. No package publication is
performed by this release. Review source before installation in a trusted environment.

The `dkn` command retains the legacy entry point, with a typed refusal when BLAKE3 is
missing. `dkn-v02`, `dkn-nav`, `dkn-sam` expose the candidate. Source-only use works with
`PYTHONPATH=src:.` on POSIX or `$env:PYTHONPATH="src;."` in PowerShell.

A local wheel build/installation is evidence of packaging, not a clean download of all
transitive dependencies. The rc2 isolated environment uses exact copies of already-installed external
dependencies; the full legacy extra remains blocked in this execution environment.

## Small publishing/reading example

```python
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import pack, certify, verify_archive, verify_certificate, declare_genesis
from dkn_v02.navigation import inspect
from dkn_v02.storage import MemoryStore, retrieve

# Ephemeral demonstration key. Production custody/recovery is the application's job.
key = Ed25519PrivateKey.generate()
genesis = declare_genesis(semantic_name="example.application", purpose="publisher",
                         nonce="initial", key=key)
raw, manifest = pack({"README.txt": b"Hello, DKN.\n"})
certificate = certify(manifest, key, namespace_root=genesis["namespace_root"])
mirror = MemoryStore("demo")
locator = mirror.put(raw)
received, observation = retrieve([locator], {"demo": mirror},
                                 expected_root=manifest["logical_root"])
if received is None:
    raise RuntimeError(observation)
assert verify_archive(received)["logical_root"] == manifest["logical_root"]
assert verify_certificate(certificate, manifest)["signature"] == "PASS"
report = inspect(received, certificate=certificate, genesis=genesis)
assert report["authority_effect"] == "NONE"
```

A recipient needs a trusted expected commitment or publisher-recognition policy; an
attacker can otherwise replace both data and its self-consistent accompanying manifest.
The example establishes signed bytes and supplied-chain key association, not institutional
trust, currentness, safety to execute, or ownership of the human-readable spelling.

## Navigation

Create `LocalIndex(path)`, add an archive and its supplied certificate/relations/genesis/
transitions, then call `resolve_exact(root)`, `discover(...)`, `traverse(...)`, or
`compare_namespace(root)`. Every read verifies bytes and attached evidence. Incoming edges
are discovered only within the supplied local collection; no empty result proves global
absence. A failed or corrupt indexed candidate fails the query closed rather than being
silently omitted. This permits denial of service by someone who can corrupt the index;
protect local custody and use a trusted single-writer environment.

Outgoing relation types are depends_on, derived_from, supersedes, attests, governed_by,
published_at and witnesses. Bind relation values with `relation_commitment`; passing an
uncommitted edge is refused. A signed relation is a publisher's assertion, not its truth.
The local index stores one evidence envelope per logical root; merging alternative
certificates/evidence is not yet implemented. There is no cursor API or online crawler.

`python examples/v02_end_to_end.py` exercises packaging, namespace certification, local
and memory mirroring, verified fallback retrieval, discovery, a dependency graph and an
assurance join in one offline workflow. All example keys and deployments are fixtures.

## Assurance and governance

Build a substrate descriptor from an explicit profile, fill in actual declarations, and
sign it with `seal`. Pin observer keys, permitted predicates, membership and failure-domain
labels in reader policy. Call `evaluate` with exact-scoped signed evidence and explicit time.
Inspect status, unmet obligations, assumptions, excluded evidence and limitations.
`SATISFIES` is not proof of future availability, consensus or real-world truth.

`compose` finds declared shared dependencies/control domains; missing labels never prove
independence. `assess_checkpoints` handles supplied signed head observations.
`make_handoff(..., consumer="CHC"/"CCP")` recomputes its report; admission remains external.

No operational signer credentials are shipped. Published deterministic test seeds must
never be copied into a real application. Supply a key-management design, policy update
process, clock policy and actual authorization layer before any operational use.
