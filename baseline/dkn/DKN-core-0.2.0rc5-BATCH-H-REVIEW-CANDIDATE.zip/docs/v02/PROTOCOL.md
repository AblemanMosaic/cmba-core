# Candidate protocol: exact implemented contract

## Scope and identity

`dkn_core` is unchanged v0.1 r002 runtime source. `dkn_v02` is a separate experimental
SHA-256/Ed25519 implementation. It does not reinterpret BLAKE3 identifiers, establish
MosaicID parity by fiat, or turn cryptographic checks into execution authority.
A distribution numbered 0.2.0rc2 is not a ratified public v0.2 protocol.

A logical artifact root commits an exact canonical manifest inventory and dimension list.
A transport SHA-256 commits the actual ZIP bytes. Backend IDs and retrieval locations are
not logical identity inputs. Current packing accepts only one canonical ZIP realization;
arbitrary tarballs, recompressed ZIPs and executable-bit/symlink-preserving transports are
not implemented. Multiple transports per logical root are an architectural extension,
not demonstrated interoperability here.

## Canonical encoding

Candidate encoding is UTF-8 JSON without BOM, whitespace, trailing newline, duplicate keys,
floats, exponent numbers, nonfinite numbers, unpaired surrogates or negative zero spelling.
Allowed values: null, booleans, signed 64-bit integers, Unicode scalar-value strings,
lists and string-keyed objects. Object keys sort lexicographically by Unicode code points,
not locale and not UTF-16 code units. Strings use JSON minimal escapes (including the
standard short control-character escapes); non-ASCII scalars and `/` remain literal.
String values are not globally normalized; archive paths independently require NFC.

Limits: 4 MiB canonical metadata, depth 32, up to 4096 members per list/object.
Time values are explicit nonnegative signed-64-bit Unix seconds supplied by the caller;
there is no trusted internal clock or implicit wall-clock decision.

This is **not RFC 8785 JCS**: JCS uses UTF-16 ordering and ECMAScript number semantics.
Node interop uses a lossless BigInt JSON parser and code-point sorting, never ordinary
`JSON.parse` followed by number conversion. See RFC 8785 sections 3.2.2 and 3.2.3 for the
external comparison; DKN's actual rules above and its vectors are the candidate contract.

## Commitments

For a domain byte prefix D and canonical value X, commitment = lowercase hexadecimal
SHA-256(D || canonical(X)). Prefixes include a terminal zero byte, not two printable
characters. Core prefixes are:

| Use | Prefix before terminal zero |
|---|---|
| Dimension value | `DKN_V02_DIMENSION` |
| Logical manifest | `DKN_V02_LOGICAL_ARTIFACT` |
| Namespace genesis | `DKN_V02_NAMESPACE_GENESIS` |
| Transition body | `DKN_V02_NAMESPACE_TRANSITION` |
| Detached certificate signature | `DKN_V02_CERTIFICATE` |

A dimension is `{schema, dimension_id, schema_id, algorithm, digest_hex, critical}`.
Its value commitment covers `{schema_id,value}`; its label and critical flag are bound
by the enclosing manifest. SHA-256 is the only accepted dimension algorithm.
Dimensions sort by `dimension_id`, which is unique. There is no arbitrary hash fallback.

`validate_manifest` checks structure and commitment, not payload possession.
`verify_manifest` also checks exact supplied files. `verify_archive` opens and verifies
all contained files and requires exact canonical transport bytes. Dimension content
checking is explicit through `verify_dimension(..., supplied=True)`.

**Commitment-only versus semantic acceptance:** no support policy means structural/hash
inspection, with `dimension_semantics=NOT_CHECKED`. Supplying `supported_schemas` rejects
unknown critical schemas; noncritical unknowns remain unsupported. A list of supported
schema names is not a semantic interpreter or evidence that the dimension's assertions
are true. Applications must supply/check required dimensions and their values. No generic
`verified=true` field implies this work was done.

## Portable-files-only-v1 profile

At most 4096 regular files; each at most 64 MiB; total payload at most 256 MiB. Inventory
rows include exact path, type=`file`, integer size, lowercase SHA-256. Rows sort by exact
Unicode code points. No directories as inventory entries, symlinks, permission semantics,
ACLs, owner IDs or executable bits are conveyed. Empty payloads are valid.

Paths are relative, slash-separated, NFC, with no empty/dot/dot-dot components, backslashes,
control/DEL/surrogate characters, Windows-invalid punctuation, trailing dots/spaces, or
DOS reserved basenames (including extensions). Components are <=255 UTF-8 bytes; the whole
path <=1024 bytes. Casefold aliases and file/directory prefix conflicts refuse. This is a
portable admission policy tested on Linux, **not an actual Windows filesystem run**.
Unicode normalization/casefold behavior follows the Python runtime's Unicode database;
full cross-language filesystem alias equivalence remains a separate interoperability gate.

The root `.dkn` subtree is reserved for the transport manifest. ZIP entries are lexically
ordered, uncompressed, 1980-01-01 00:00:00, Unix regular 0644, no extraneous members,
prefix/suffix data or metadata variation. ZIP limits are checked before payload reads;
repacking must reproduce every exact byte. No archive extraction is needed by verification.

## Ed25519 admission and signatures

Signatures are pure Ed25519 over exact domain-prefixed canonical bodies, using the
`cryptography` implementation. Public-key admission additionally requires canonical
Edwards point encoding, a nonidentity point and prime-order subgroup membership. The
v0.2 checker reuses the mathematical public-point validation already present in r002,
without importing its BLAKE3 dependency. Signature scalar S must be < the group order.
Private scalar arithmetic/signature generation is not reimplemented here.

Batch B–D did not enforce this key-admission boundary. Batch E's preserved witness shows
an identity public key and zero-scalar signature being accepted by those candidate paths
in this environment. Batch E refuses that case. This is not evidence that a legitimate
pinned publisher key could be impersonated. RFC 8032 section 7.1 TEST 1 is used as an
external positive test vector; DKN's stricter key admission is its own profile decision.

## Namespaces and lineage

A genesis signs an exact body: schema, semantic_name, purpose, nonce, legacy_instance,
founder_public_key_hex, recovery_policy_ref. `namespace_root` commits that body. Names
are lowercase ASCII `[a-z0-9][a-z0-9._-]{0,254}` and are **not globally exclusive**.
Purpose/nonce follow the runtime token grammar. New namespaces may use legacy_instance=null.
A non-null legacy reference remains `legacy_binding=NOT_ESTABLISHED`; it is not verified
by a signature over the reference. Recovery-policy references are descriptive only.

A transition commits/signs the root, predecessor/successor public keys, epoch and exact
previous transition hash. Complete chains start at epoch 1; each subsequent epoch advances
by one. Both terminal and intermediate keys are admitted. The genesis root persists across
rotation. No separate v0.2 operational-instance derivation is implemented.

`analyze_lineage(genesis, chains)` verifies every supplied full chain, records divergent
signed successors and selects no winner. Limits: 64 chains, 512 total supplied events,
within metadata limits. No visible fork does not prove global uniqueness. The analysis
does not decide revocation, recovery, temporal authorization, head freshness or authority.

## Substrate and federation records

Existing Batch D schemas remain under `schemas/v02/sam-*.schema.json`. A signed record
binds schema, kind, body and signer. Its record hash uses `DKN_V02_SAM_RECORD` + zero;
its signature uses `DKN_V02_SAM_SIGNATURE` + zero. Record kind and full body are validated.

Report/reference roots use `DKN_V02_SAM_` + uppercase label + zero for the closed labels
record, contract, policy, context, assessment, composition, checkpoint-policy,
checkpoint-membership, checkpoint-report and handoff. `report_hash` excludes itself.
Reader policy hashes are commitments to caller inputs, not proof those policies are valid.

Checkpoint membership identity excludes mutable reader age/high-water-mark fields, but
includes the declared members, scope, validity, threshold, protocol and independence rules.
Only the highest eligible sequence is considered for quorum; a newer incomplete sequence
is not hidden by an older quorum. Conflicting signed heads are retained even after expiry.
No result establishes Byzantine consensus, global currentness or revocation completeness.

## Report schemas and sources

27 exported candidate input/report schemas reside in `schemas/v02/runtime/`; nine prior
SAM input schemas remain in `schemas/v02/`. Source-of-truth modules are `runtime_schemas.py`
and `sam_schemas.py`. These validate structure; they cannot validate signature truth or
prove correspondence to evidence without recomputation. SAM ABI validates returned reports.

External design/test references (not authority sources for DKN):
- RFC 8032, https://www.rfc-editor.org/rfc/rfc8032.html
- RFC 8785, https://www.rfc-editor.org/rfc/rfc8785.html

## 0.2.0rc2 reviewed refinements (normative for this candidate)

These rules tighten or clarify the preceding candidate implementation; they do not redefine
accepted SHA-256 domain prefixes, signed record bytes or previously valid fixture roots.

* The case-folded `.dkn` payload path, and all descendants, are reserved at **all** inventory
  boundaries, not only at ZIP packaging. A self-consistent manifest does not exempt this rule.
* `load_directory` uses an explicit bounded scan. A directory enumeration/read error refuses
  the operation rather than publishing a silently incomplete scan. Source symlinks and
  symlink ancestors are refused, including an empty source. This is not a concurrent snapshot
  or hostile-writer race defense; readers require externally controlled source custody.
* Canonical ZIP admission checks its fixed, comment-free, single-disk, non-ZIP64 end record,
  central-directory count and size before constructing `ZipFile`. The manifest entry is
  limited to 4 MiB before reading it. These are parser-budget checks, not a process sandbox.
* Existing index root, `objects` and `evidence` paths must be directories; a wrong-kind path or
  local I/O failure is a typed refusal, not evidence of an empty collection. A genuinely
  absent index can still denote an empty local collection. All authority and global coverage
  conclusions remain explicitly unestablished.
* Traversal reports retain at most 4,096 edges, record `max_edges:4096` and `edge_limited`, and
  set `truncated` when exploration is curtailed. The report itself must fit the canonical
  4-MiB/depth/collection budgets; otherwise `DKN_V02_NAV_LIMIT` is returned. Refusing an
  oversized result is distinct from returning a successful exhaustive report.
* Namespace comparisons put missing optional genesis-name information in
  `unnamed_candidate_roots`. Such a candidate is not discarded and no non-string JSON map
  key is introduced. A claimed namespace root without sufficient ownership evidence remains
  only a claim, even when another key's signature is cryptographically valid.
* Strict consumers must adopt the additive rc2 traversal and candidate-report schema fields.

**Critical dimensions:** With no `supported_schemas` supplied, verification checks commitments
and reports semantic interpretation as `NOT_CHECKED`. With an explicit support set, unknown
critical schemas refuse. Support-set membership alone does not execute a semantic validator.
Applications must separately require their needed dimensions, verify supplied values against
the commitments, and run a handler for those values and the corresponding payload.

**Secrets:** Public record constructors do not embed the signing private key. Arbitrary
caller-supplied payload bytes are not inspected for secrets; no general private-key scrubber
is implemented. An application publishing a credential file will bind it, not magically
redact it. This is an explicit narrowing of historical design obligation INV-15.
