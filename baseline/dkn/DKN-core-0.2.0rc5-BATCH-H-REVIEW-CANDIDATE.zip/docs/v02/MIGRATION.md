# Migration and compatibility

## Preserved material

The final inheritance delta compares every file against the exact Batch D archive and
r002. All original `src/dkn_core`, original `tests`, v0.1 schemas/tools and golden vectors
remain byte-identical. Public v0.1 hash/signature domains are not reused for changed values.
The actual legacy runtime was not rerun because BLAKE3 is unavailable; preservation is
not a substitute for full behavioral parity. Legacy THR SHA-256 octets are separately
checked against the original vectors in Python and Node.

The cumulative `pyproject.toml`, top-level README/roadmap/security and selected v0.2 files
change intentionally. Version 0.2.0rc1 marks a distribution candidate, not approval of a
new public protocol. Default pytest targets the v0.2 suite; the release runner separately
reports legacy availability. Use `--require-legacy` to make that prerequisite gating.

## Security-relevant changes from Batch D

1. Nonidentity prime-order public-key admission now applies to certificate, genesis,
   transition and SAM signatures. Old identity-key forgery fixtures are deliberately refused.
2. Verifiers validate all signed genesis fields and every terminal successor key. Transition
   construction checks epoch type, first predecessor and prior-link shape.
3. Canonical manifest structure is checked before certification; boolean/file-size ambiguity,
   extra fields and invalid inventory types refuse. Caller-supplied nested dimensions are
   detached to avoid accidental mutation after manifest construction.
4. Portable archive paths reject Windows device/punctuation/trailing-character aliases,
   control/surrogate characters, and casefold-prefix conflicts. Earlier permissive archives
   may now refuse; published valid fixture roots are unchanged.
5. Reads enforce byte budgets before loading entire files. Observed symlink ancestors and
   aggregate local scan limits are checked. This does not claim transactional/race-free custody.
6. Depth-limited traversal reports explicit truncation. New verified lineage analysis exposes
   visible forks; old candidate comparison still does not equate multiple releases with a fork.
7. New namespace genesis may carry `legacy_instance=null`. Existing non-null anchors keep
   their original root/signature bytes and remain unverified references.
8. 27 additional structural schemas, optional legacy installation, CLI entry points,
   standalone Node byte/signature checks and release tooling are added.

These are explicit experimental-candidate changes, not silent modifications to a ratified
v0.2 protocol. Recheck dependent clients against current output schemas (notably added
`legacy_binding` and `depth_limited`). The old vectors remain frozen and tested.

## Historical certificates and manifests

`MANIFEST.json`, the four original META documents, and BATCH-D-FILE-MANIFEST.json are retained
history, not certification of this candidate. Only BATCH-E-FILE-MANIFEST.json inventories
the new source ZIP, excluding itself; the external SHA-256 binds the entire ZIP. The manifest
is unsigned and cannot authenticate itself without a trusted external commitment.
Do not run the historical r002 archive verifier expecting it to certify the upgraded tree.

## Scope still deferred

Operational namespace-instance derivation, legacy-anchor proof bridge, delegation/recovery,
revocation freshness, human-recognition UI, pagination cursors, online providers, durable
antirollback storage and independent target-platform verification are not filled in by the
presence of a new schema or profile. See the reconciled acceptance matrix for each item.

## rc1 to rc2 — self-review revision

The new distribution version is `0.2.0rc2`; existing valid artifact/namespace/vector
commitments are not renumbered. Invalid reserved-path inventories and damaged index layouts
now refuse earlier. Failed source enumeration no longer yields a partial publication.
ZIP parser admission is budgeted earlier. Traversal is additionally bounded by edges and
canonical result size. These corrections can intentionally refuse inputs accepted by rc1.
Traversal and namespace-candidate reports gain fields; update strict schema consumers.
The original r002 runtime, tests, schemas and vectors remain byte-identical. Its genuine
BLAKE3-dependent replay is still a separate prerequisite, not inferred from source equality.
New implementation-neutral semantic contract and realization binding describe the **bounded
implemented profile**, not a declaration that all original fifty aspirations are complete.
