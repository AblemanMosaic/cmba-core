> **Batch F note — Base API profile.** This document describes the retained RC2 base.
> The separately versioned LC-F1 and transactional-vault extension is documented in
> `docs/batch-f/`. Its scoped additions do not change the base semantic contract.
> Current acceptance dispositions are in `docs/batch-f/ACCEPTANCE.md`.

# Implemented API and schema surface

## Core (`dkn_v02` / `dkn_v02.core`)

| API | Contract |
|---|---|
| `canonical(value) -> bytes` / `read_canonical(bytes)` | Strict bounded candidate encoding; no floats or duplicate/noncanonical encodings. |
| `commit(id,schema,value,critical=True)` | Typed value commitment, not semantic proof. |
| `verify_dimension(item,value=None,supplied=False,supported_schemas=None)` | Exact optional value check and explicit unknown-critical support policy. |
| `build_manifest(files,dimensions=None)` | Closed logical inventory; nested dimensions detached from caller data. |
| `validate_manifest(manifest,supported_schemas=None)` | Structure/root only; payload NOT_CHECKED. |
| `verify_manifest(manifest,files,supported_schemas=None)` | Structure and exact supplied payload. |
| `pack(files,dimensions=None)` | Returns canonical ZIP bytes and manifest. |
| `verify_archive(raw,supported_schemas=None)` | Exact canonical transport, member closure and payload integrity. |
| `load_directory(path)` | Bounded regular-file collection; not an atomic snapshot or race-free custody proof. |
| `certify(manifest,key,namespace_root=None)` | Detached Ed25519 commitment statement. |
| `verify_certificate(certificate,manifest)` | Structural binding/signature; authorization NOT_CHECKED. |
| `declare_genesis(semantic_name,purpose,nonce,key,legacy_instance=None,recovery_policy_ref=None)` | Signed stable root; all parameters keyword-only. |
| `verify_genesis(value)` | Admitted founder key, exact fields/root/signature; no exclusive spelling claim. |
| `transition(genesis,predecessor_key,successor_key_hex,epoch=...,previous_transition_hash=None)` | Construct a signed transition; full chain still needed for later epochs. |
| `verify_transitions(genesis,events)` | Verify a full ordered chain; active key is scoped to that chain. |
| `analyze_lineage(genesis,chains)` | Verified visible-fork evidence, never a selected global head. |

## Navigation/storage

`LocalIndex.add`, `resolve_exact`, `discover`, `traverse`, `compare_namespace`, plus
`inspect`, `validate_relations`, `relation_commitment`. Read-only operations do not upload,
execute or mutate recognition policy. `add` is a create-only single-writer convenience.
Directory names/entries, aggregate scan bytes, hops, nodes and returned rows have limits.
There are no pagination cursors. Depth/node/edge truncation is explicit; oversized canonical reports refuse.

`MemoryStore(backend_id)` and `DirectoryStore(path,backend_id)` implement `put/get`.
`retrieve(locators,stores,expected_root=...)` tries at most 16 sources and independently
checks transport and logical identity. Exhaustion means INDETERMINATE, not global absence.
Third-party adapters may do I/O; callers must enforce their time/network/access budgets.

## Substrate, federation and read-only JSON ABI

`assurance.seal`, `verify_record`, `evaluate`, `compose`; `federation.checkpoint_policy_ref`,
`assess_checkpoints`, `make_handoff`; `assured_navigation.inspect_with_assurance`.
`sam_abi.dispatch` accepts exactly schema, operation and arguments. Operations are verify,
evaluate, compose, checkpoints and handoff. Unknown operations/fields refuse; no eval,
plugin execution, network URL or arbitrary path exists in that ABI.

`dkn_v02.runtime_schemas.validate_report(kind,value)` validates an exported structural
contract. `tools/export_runtime_schemas.py` reproduces 27 schemas; the inherited SAM
exporter reproduces nine input schemas and six reference profiles. JSON Schema itself
cannot check hashes, signature admissibility, root linkage or conclusion correctness.
The reference runtime performs those separately. Do not trust a submitted report because
its fields happen to fit a schema; recompute it from bounded evidence.

## CLIs and exit semantics

- `dkn-v02 pack SOURCE OUTPUT`, `verify ARCHIVE`, `verify-certificate CERT MANIFEST`.
- `dkn-nav inspect/index/resolve/discover/traverse/compare`, `lineage GENESIS CHAINS`.
- `dkn-sam CANONICAL_REQUEST_JSON`.

Success is exit 0; typed refusals exit 2. A well-formed assessment with INSUFFICIENT or
CONTRADICTED also exits 0: the status is a computed result, not transport failure or
approval. argparse syntax failures use argparse's error surface. File-read errors within
operations are typed JSON refusals. Private-key persistence/ceremonies are not exposed by
the v0.2 CLI. The legacy ceremony exists only in the explicitly selected legacy track.

## Refusal families

Core: DKN_V02_{TYPE_INVALID,NUMBER_INVALID,STRING_INVALID,DEPTH_LIMIT,LIMIT,
DUPLICATE_KEY,JSON_INVALID,JSON_NOT_CANONICAL,SCHEMA_INVALID,DOMAIN_UNKNOWN,
ALGORITHM_UNSUPPORTED,DIGEST_INVALID,TOKEN_INVALID,CRITICAL_UNSUPPORTED,
DIMENSION_MISMATCH,DIMENSION_DUPLICATE,PATH_INVALID,PATH_COLLISION,RESERVED_PATH,
MANIFEST_MISMATCH,ARCHIVE_INVALID,ARCHIVE_NOT_CANONICAL,PUBLIC_KEY_INVALID,
SIGNATURE_INVALID,NAME_INVALID,INSTANCE_INVALID,EPOCH_INVALID,LINEAGE_INVALID,
LINEAGE_LIMIT,SOURCE_INVALID,SOURCE_SYMLINK_REFUSED,SOURCE_CHANGED,IO_ERROR}.

Navigation adds NAV_* and RELATION_*; assurance adds SAM_*; storage adds STORE_*;
report schema validation adds REPORT_*; optional legacy startup uses
DKN_LEGACY_DEPENDENCY_UNAVAILABLE. Machine-generated `REFUSAL-CATALOG.json` enumerates
literal refusal tokens found in the source, with locations; it is a source inventory,
not a theorem that every possible programmer/runtime failure has a typed conversion.

## rc2 report and source-admission refinements

`LocalIndex.traverse` adds `max_edges` (4096) and `edge_limited`, includes that limit in
`truncated`, and refuses output exceeding canonical report budgets. Comparison reports add
`unnamed_candidate_roots` for validly inspected candidates lacking optional genesis-name
information. `discover`, `traverse`, and comparisons return canonicalizable bounded reports.
Corrupt directory layout and local I/O are not converted to empty search results.
`load_directory` refuses failed scans and symlink ancestors; it is not an atomic snapshot.
The `.dkn` namespace is reserved in every manifest inventory, not just ZIP construction.
Use the exported rc2 schemas with strict consumers; older closed report schemas reject new
fields. See `examples/v02_reader_policy.py` for a complete reader-owned admission handler.
The conformance process adapter in `tools/` is a test interface, not a production JSON ABI.
