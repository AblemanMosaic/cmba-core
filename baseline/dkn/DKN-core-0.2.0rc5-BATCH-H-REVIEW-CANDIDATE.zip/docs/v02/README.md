> **Batch F note — Base-profile documentation.** This document describes the retained RC2 base.
> The separately versioned LC-F1 and transactional-vault extension is documented in
> `docs/batch-f/`. Its scoped additions do not change the base semantic contract.
> Current acceptance dispositions are in `docs/batch-f/ACCEPTANCE.md`.

# DKN Core 0.2.0rc2 documentation

This directory describes the bounded implementation, not every proposal in the historical
A–E design trail. The distribution version is `0.2.0rc2`; wire identifiers remain explicitly
experimental `v0.2-candidate`. Original v0.1 sources and identities are separate.

| Document | Purpose |
|---|---|
| [User and integrator guide](USER-AND-INTEGRATOR-GUIDE.md) | System, subsystems, workflows, Python integration, reader policy |
| [Review and repairs](REVIEW-RC2.md) | Findings, fixes, exact claim ceiling, replay |
| [Semantic contract map](SEMANTIC-CONTRACT-MAP.md) | Sixteen original design obligations mapped to actual scope |
| [Replacement realization](REALIZATION-REPLACEMENT.md) | Preserve semantics across a rewritten implementation/toolchain |
| [Protocol](PROTOCOL.md) | Exact canonical bytes, hashing, keys, signatures and bounds |
| [API reference](API-REFERENCE.md) | Existing call signatures and structured results |
| [Developer guide](DEVELOPER-GUIDE.md) | Additional executable publishing/navigation examples |
| [Security and assurance](SECURITY-AND-ASSURANCE.md) | Threat models, trust and operational boundaries |
| [Migration](MIGRATION.md) | Preserved identities and tightened admission/report changes |
| [Original acceptance ledger](ACCEPTANCE-RECONCILIATION.md) | All fifty original obligations, including incomplete ones |
| [Batch E defects](DEFECTS.md) | Historical pre-rc2 repairs, including key admission |
| [Release and independent review](RELEASE-AND-REVIEW.md) | Current commands and retained historical review record |

The new model, schema exports, frozen conformance corpus and code are checked together by
`tools/check_semantic_contract.py`. This is mechanical traceability, not a semantic theorem.
Current evidence is under `evidence/self-review-rc2`; Batch E and earlier evidence is retained
as history. The final archive and clean-replay hashes are external to avoid circularity.
