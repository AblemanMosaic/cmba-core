# Security models and guarantee boundaries

## Shared threat model

Adversaries may supply malformed JSON/archives, alternate publisher keys with identical
human names, dishonest metadata, incorrect storage locators, conflicting signatures,
stale observations, duplicate witness identities and shared-control replicas. Runtime
cryptographic checks and bounded evidence rules address only their declared cases.

Trusted premises include the verifier/software environment, protected caller pins/policy,
appropriate cryptographic assumptions and explicit clock policy. A compromised host can
replace the verifier itself. A self-consistent archive plus checksum received through the
same adversarial channel does not authenticate its expected publisher. Identity is not
identity ownership, trust, semantics, truth or permission to execute.

## Six modeled backends

| Profile | Modeled mechanisms/strengths | Limits not dissolved by a profile label |
|---|---|---|
| LOCAL_VAULT | Offline access, direct local custody, content verification. | Host compromise/loss, backup durability, currentness; local adapter not a transactional vault. |
| ENTERPRISE_DISTRIBUTED | Managed control domains, replication, institutional recognition policies. | Administrator concentration, common providers/identity roots, untested SLAs; no enterprise service deployed. |
| PUBLIC_HOSTING | Portable public locators and independent downloaded-byte verification. | Provider deletion, stale metadata, access loss; no HTTP/Git adapter shipped. |
| P2P_CAS | Multiple possible content-addressed retrieval sources. | Sybils, eclipse/bootstrap dependencies, unproven retention and censorship resistance; no live P2P protocol shipped. |
| FEDERATED_CCP | Pinned members, signed observations and governance handoffs. | Quorum does not prove consensus/constitutional legitimacy; collusion, partitions and membership authority remain explicit. |
| HYBRID | Declared composition of local and distributed mechanisms. | Shared failure domains, incompatible assumptions, public metadata leaks; no additive security score. |

All profile files are TEMPLATE status. Merely signing one cannot establish assurance.
A mechanism declaration is not a measurement. A signed test-result statement is still
someone's assertion about a test unless the application verifies the underlying evidence.

## Evidence evaluation semantics

SATISFIES: exact supplied obligations meet the reader's permitted-observer/method/scope/
validity rules, with no outstanding declared premises. CONDITIONAL: the result relies on
premises or witness-domain labels not established by the evaluator. INSUFFICIENT: required
material, eligible observations or recognition is absent. CONTRADICTED: eligible refuting
material or incompatible premises exists. No result establishes a physical deployment's
security theorem. Invalid schemas/signatures refuse instead of becoming weak evidence.

Independent-signer selection uses caller-declared domains, not inferred institutional
independence. Same-key duplicate observations cannot fill a threshold. `compose` retains
transitive dependencies and shared controls; even no known overlap means independence
NOT_ESTABLISHED. No probability arithmetic or future-availability SLA is inferred.

## Operational limits

The shipped adapters are local and in-memory. DirectoryStore checks observed links,
regular-file type, size/mtime and content; LocalIndex refuses observed symlink ancestors
and re-verifies records. Neither is race-free against an active concurrent filesystem
writer. Interrupted writes can leave candidates that fail closed. There is no multiwriter
transaction protocol, crash-recovery journal, durable pinset, revocation server, authenticated
time service, online transparency proof, P2P consensus or publisher key-recovery engine.

Metadata is not encrypted. Confidentiality of files does not imply confidentiality of
names, relation graphs, publisher identities, locators or access patterns. Profile/evidence
assessment cannot grant access or constrain an application's subsequent execution effects.

## Interoperability boundary

The independently written Node checker exercises code-point canonicalization, 64-bit
integers, SHA-256 domains, point admission and Ed25519 verification. It does not reproduce
the complete Python archive, filesystem-alias, navigation or assurance-policy engine.
Node and Python can both rely on OpenSSL-derived signature implementations. This is neither
cryptographic-backend independence nor independent human/institutional review. Rust and
non-Linux platforms remain separate unexecuted gates.

## Portability and resource control

Published file/hop/member limits constrain operations; signature admission uses a bounded
public-key cache. This is not a CPU/memory isolation sandbox or an availability guarantee.
Snapshot checks cannot defeat adversarial inode replacement. Unicode path normalization
uses the active runtime Unicode database; identical filenames across OS/filesystem versions
need target-platform tests. Protect caches/indexes; isolate untrusted plugins outside DKN.

## rc2 review boundary

Current corrections and remaining assumptions are in `REVIEW-RC2.md`. A signed semantic
commitment proves a statement was bound, not that the payload satisfies it. `SEMANTIC-
CONTRACT-MAP.md` explicitly separates full design aspirations from implemented guarantees.
In particular no payload secret scrubber, generic semantic interpreter, delegated-authority
engine, recovery service, revocation oracle, P2P daemon or multiwriter transactional vault is
implemented. Bounded reports may return a typed limit refusal instead of a large partial
object. Reader-provided clocks, pins, observer recognition and failure-domain assignments
remain trust inputs rather than facts inferred by DKN.
