> **Batch F note — Historical RC2 acceptance reconciliation.** This document describes the retained RC2 base.
> The separately versioned LC-F1 and transactional-vault extension is documented in
> `docs/batch-f/`. Its scoped additions do not change the base semantic contract.
> Current acceptance dispositions are in `docs/batch-f/ACCEPTANCE.md`.

# Acceptance reconciliation — original 50 obligations

No row is promoted merely because a test suite passed. PASS_SCOPED means only its named
fixtures/checks. PARTIAL, BLOCKED, DEFERRED and NOT_PERFORMED are not successful feature
implementations. The machine-readable source is `design-v0.2/acceptance/MATRIX.json`.

## A-COMPAT-01 — source inventory/byte preservation

**PASS_SCOPED**. Original r002 runtime/test/schema/vector files are byte-compared; top-level cumulative documentation and package metadata intentionally change.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-COMPAT-02 — v0.1 namespace parity

**BLOCKED_DEPENDENCY**. v0.1 BLAKE3 namespace positive/negative suite requires genuine blake3; install unavailable here.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-COMPAT-03 — legacy MosaicID parity

**BLOCKED_DEPENDENCY**. MosaicID cross-language BLAKE3 derivation is not implemented or executed by the Node checker.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-COMPAT-04 — THR commitments parity

**PASS_SCOPED**. Frozen legacy THR state/semantic/governance/manifest SHA-256 vectors recomputed by Python and Node; not full legacy runtime replay.

Executable references: `test_batch_e_interop::test_original_thr_sha256_vectors`.

## A-COMPAT-05 — old client refuses new version

**BLOCKED_DEPENDENCY**. Original client sources are unchanged, but version-refusal behavior is not rerun without legacy dependency.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-COMPAT-06 — no authority promotion

**PASS_SCOPED**. Implemented v0.2 outputs preserve no-authority boundary; no claim about untested external applications.

Executable references: `test_batch_e_schemas::test_authority_promotion_refused`, `test_batch_d_federation::test_handoffs_no_authority`.

## A-COMPAT-07 — algorithm downgrade refusal

**PASS_SCOPED**. v0.2 dimension algorithm downgrade and closed record fields; complete legacy algorithm suite blocked.

Executable references: `test_batch_e_integration::test_algorithm_downgrade_refused`.

## A-CRYPTO-01 — canonical bytes

**PASS_SCOPED**. Strict candidate bytes tested with Unicode/code-point and signed-64-bit edge cases; not JCS.

Executable references: `test_batch_e_hardening::test_canonical_invalid_inputs`, `test_batch_e_interop::test_canonical_python_node`, `test_batch_e_interop::test_invalid_canonical_node`.

## A-CRYPTO-02 — logical/transport distinction

**PARTIAL**. Logical and transport identities are separate; runtime only accepts canonical ZIP, not arbitrary equivalent containers.

Executable references: `test_batch_b::test_pack_verify`, `test_batch_e_integration::test_candidate_transport_exactness`.

## A-CRYPTO-03 — file mutation

**PASS_SCOPED**. Payload mutation fixtures refuse.

Executable references: `test_batch_e_hardening::test_archive_closure_mutations`.

## A-CRYPTO-04 — inventory closure

**PASS_SCOPED**. Missing/extra/tampered members and canonical source-package closure tested.

Executable references: `test_batch_e_hardening::test_archive_closure_mutations`, `test_batch_d_packaging::test_candidate_extra_member_refused`.

## A-CRYPTO-05 — path semantics

**PASS_SCOPED**. Portable admission and Linux symlink/alias fixtures; actual Windows and Unicode database parity remain external gates.

Executable references: `test_batch_e_hardening::test_portable_path_refusals`, `test_batch_e_hardening::test_casefold_alias_and_prefix`, `test_batch_e_hardening::test_valid_portable_paths`.

## A-CRYPTO-06 — dimension separation

**PASS_SCOPED**. Typed schema/value domains and enclosing label/root commitments tested.

Executable references: `test_batch_e_integration::test_typed_dimension_domain_separation`, `test_batch_e_interop::test_domain_separated_hashes`.

## A-CRYPTO-07 — unknown critical dimension

**PARTIAL**. Explicit support policy refuses unknown critical schema. Default is honest commitment-only inspection, not semantic admission.

Executable references: `test_batch_e_hardening::test_unknown_critical_with_explicit_support_policy`.

## A-CRYPTO-08 — absent dimension

**PARTIAL**. Absent required relation/evidence refuses or is insufficient. No universal dimension requirement/semantic engine exists.

Executable references: `test_batch_c::test_unbound_relation_refused`, `test_batch_d_assurance::test_no_evidence_no_promotion`.

## A-CRYPTO-09 — detached certification

**PASS_SCOPED**. Detached signatures, signed metadata and inadmissible identity keys tested; not full independent cryptographic review.

Executable references: `test_batch_b::test_certification`, `test_batch_e_hardening::test_identity_key_forgery_rejected`.

## A-CRYPTO-10 — cross-lang vectors

**PARTIAL**. Node independently written primitive checker executed; Rust/full second-language archive/policy verifier not implemented.

Executable references: `test_batch_e_interop::test_existing_core_signed_vectors`, `test_batch_e_interop::test_existing_sam_signed_vectors`, `test_batch_e_interop::test_original_v02_commitment_roots`.

## A-NAME-01 — root vs instance

**PARTIAL**. Stable genesis root and operational key epochs implemented; new per-epoch v0.2 instance derivation deferred.

Executable references: `test_batch_e_lineage::test_rotation_keeps_genesis_root`.

## A-NAME-02 — same spelling multiple keys

**PASS_SCOPED**. Same human spelling may coexist under different keys without a globally selected winner.

Executable references: `test_batch_c::test_namespace_nonexclusive`, `test_batch_b::test_namespace_lineage`.

## A-NAME-03 — fork preserved

**PASS_SCOPED**. Divergent signed successors retained after verifying each complete supplied chain; no undiscovered-fork claim.

Executable references: `test_batch_e_lineage::test_two_valid_successors_retained_without_winner`.

## A-NAME-04 — rotation proof

**PASS_SCOPED**. Exact key/predecessor/link/epoch verification including final key; no temporal authorization.

Executable references: `test_batch_e_hardening::test_final_successor_admission`, `test_batch_e_hardening::test_transition_creation_checks_first_predecessor`, `test_batch_e_lineage::test_rotation_keeps_genesis_root`.

## A-NAME-05 — unauthorized delegation

**DEFERRED_WITH_BOUNDARY**. Delegation-grant engine not implemented. Verification and handoff never create a capability grant.

Executable references: `test_batch_d_federation::test_handoffs_no_authority`.

## A-NAME-06 — lost key recovery

**DEFERRED**. Lost-key recovery and recovery-policy execution are not implemented; references do not enable takeover.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-NAME-07 — revocation freshness

**PARTIAL**. Supplied-checkpoint freshness/high-water checks only; revocation status remains NOT_CHECKED.

Executable references: `test_batch_d_federation::test_maximum_age`, `test_batch_d_federation::test_high_water_mark_rejects_rollback`.

## A-NAME-08 — homoglyph name

**PARTIAL**. Non-ASCII namespace spellings refused. ASCII confusables, recognition UX and display-warning engine deferred.

Executable references: `test_batch_e_hardening::test_signed_genesis_schema_checked`.

## A-NAV-01 — outgoing verified edge

**PASS_SCOPED**. Outgoing commitments and signer assertions checked; relation truth remains external.

Executable references: `test_batch_c::test_relation_traversal`, `test_batch_c::test_unsigned_binding_is_not_authenticated`.

## A-NAV-02 — inbound untrusted index

**PASS_SCOPED**. Inbound local candidates reverified before result use; no global reverse-index completeness.

Executable references: `test_batch_c::test_relation_traversal`, `test_batch_c::test_tampering_fails_closed`.

## A-NAV-03 — empty results

**PASS_SCOPED**. Empty/no-result local view never establishes global completeness or absence.

Executable references: `test_batch_c::test_exact_and_discovery`.

## A-NAV-04 — cycle bound

**PASS_SCOPED**. Synthetic cyclic graph tests visited-set control flow only, not a realizable cyclic immutable-hash corpus.

Executable references: `test_batch_e_integration::test_traversal_cycle_control_flow_is_bounded`.

## A-NAV-05 — fanout limit

**PASS_SCOPED**. Node/depth/scan budgets and explicit truncation; no unlimited crawler.

Executable references: `test_batch_c::test_relation_traversal`, `test_batch_e_hardening::test_depth_bound_is_explicit`, `test_batch_e_hardening::test_discovery_scan_budget`.

## A-NAV-06 — poisoned cursor

**DEFERRED**. No cursor/pagination API exists; snapshot/query-bound cursor semantics are not implemented.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-NAV-07 — unavailable peer

**PASS_SCOPED**. Supplied-source exhaustion returns indeterminate; actual remote peer/network behavior not deployed.

Executable references: `test_batch_d_storage_abi::test_missing_all_is_not_absence`, `test_batch_d_storage_abi::test_failed_backend_fallback`.

## A-NAV-08 — conflicting heads

**PASS_SCOPED**. Visible supplied competing heads retained; local candidate comparison is not a global namespace resolver.

Executable references: `test_batch_d_federation::test_conflicting_heads_no_majority_override`, `test_batch_e_lineage::test_two_valid_successors_retained_without_winner`.

## A-NAV-09 — no implicit networking

**PASS_SCOPED**. Complete built-in offline flow tested with socket creation disabled; third-party adapters are caller-controlled.

Executable references: `test_batch_e_integration::test_full_offline_flow_with_socket_access_forbidden`.

## A-SAM-01 — no profile implied assurance

**PASS_SCOPED**. Six template labels cannot satisfy evidence requirements by themselves.

Executable references: `test_batch_d_assurance::test_profiles_never_establish_assurance`.

## A-SAM-02 — fault domain overlap

**PASS_SCOPED**. Shared declared administrator/dependency detected; real institutional independence not proved.

Executable references: `test_batch_d_assurance::test_common_administrator_not_independent`, `test_batch_d_composition::test_transitive_shared_dependency`.

## A-SAM-03 — quorum without protocol

**PASS_SCOPED**. Quorum stays scoped observation and consensus safety NOT_ESTABLISHED.

Executable references: `test_batch_d_federation::test_quorum_is_not_consensus`.

## A-SAM-04 — expiry

**PASS_SCOPED**. Explicit supplied-time validity/age boundaries checked; no authenticated clock.

Executable references: `test_batch_d_assurance::test_time_boundaries`, `test_batch_d_federation::test_expired_checkpoint`.

## A-SAM-05 — replica-count claim

**PASS_SCOPED**. Replica declaration does not become observed future availability.

Executable references: `test_batch_d_assurance::test_declared_replica_count_is_not_observed`.

## A-SAM-06 — CHC stale evidence

**PASS_SCOPED**. CHC interface consumes bounded observations and caller rollback floor, not global freshness.

Executable references: `test_batch_d_federation::test_maximum_age`, `test_batch_d_federation::test_high_water_mark_can_advance_without_resigning`.

## A-SAM-07 — CCP admission boundary

**PASS_SCOPED**. Recomputed evidence handoff leaves admission external; no executable CCP authority system.

Executable references: `test_batch_d_federation::test_handoffs_no_authority`, `test_batch_d_federation::test_precomputed_assessment_not_accepted`.

## A-SAM-08 — metadata confidentiality

**PASS_SCOPED**. Declared public metadata exposure propagated; no encryption/traffic-analysis guarantee.

Executable references: `test_batch_d_assurance::test_public_metadata_flagged`, `test_batch_d_composition::test_dependency_public_metadata_leak`.

## A-SAM-09 — contradictory evidence

**PASS_SCOPED**. Eligible refutation produces contradiction under exact reader policy.

Executable references: `test_batch_d_assurance::test_refutation_dominates_positive`.

## A-SAM-10 — composition incompatibility

**PASS_SCOPED**. Declared incompatible premises flagged; no unrestricted theorem prover.

Executable references: `test_batch_d_composition::test_mutually_exclusive_assumptions`.

## A-RELEASE-01 — deterministic package

**PASS_SCOPED**. Exact frozen-tree serialization and clean-extracted reserialization are checked separately; not independent build-authority review.

Executable references: `test_batch_d_packaging::test_candidate_two_serializations`.

## A-RELEASE-02 — secrets exclusion

**PARTIAL**. Bounded operational-secret pattern scan with explicit public fixture-key exceptions; not proof of absence of arbitrary secrets.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-RELEASE-03 — environment repeatability

**PARTIAL**. Fresh venv wheel installation uses preinstalled external dependencies; no complete offline dependency lock/download proof; legacy extra blocked.

Executable references: `test_batch_e_integration::test_packaging_metadata`.

## A-RELEASE-04 — cross-platform

**NOT_RUN**. Linux actual evidence only; native Windows, WSL and macOS not available. Portable wheel metadata is not target-platform testing.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-RELEASE-05 — review independence

**NOT_PERFORMED**. No independent human/institutional review. Same-session Node code, fresh extraction and isolated install do not provide this.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

## A-RELEASE-06 — publication state

**NOT_PERFORMED**. No external publication occurred; intentionally outside the local review-candidate gate.

Evidence obligation: see the linked dossier or explicit deferred prerequisite; no executable case is invented.

