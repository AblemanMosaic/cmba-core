> **Batch F note — RC2 base semantic contract.** This document describes the retained RC2 base.
> The separately versioned LC-F1 and transactional-vault extension is documented in
> `docs/batch-f/`. Its scoped additions do not change the base semantic contract.
> Current acceptance dispositions are in `docs/batch-f/ACCEPTANCE.md`.

# Original constitutional obligations → realized offline contract

This map does **not** mark all original aspirations complete. It specifies the narrower
implemented contract and the boundaries that must remain visible to a replacement realization.
The machine-readable model and its semantic commitment are separate from implementation
source hashes and review evidence. `check_semantic_contract.py` checks those references.

## INV-01 — Legacy separation

**Original:** Existing v0.1 namespace / identity / THR hashes and certificates retain exact meaning and bytes.

**Realized:** Original r002 implementation/tests/schemas/vectors are byte-preserved; candidate domains are separate.

**Boundary:** BLAKE3-dependent behavioral parity is not rerun here.

Code: `src/dkn_v02/legacy_entrypoint.py::main`. Regression: `tests_v02/test_batch_e_integration.py::test_optional_legacy_dependency_explicit`.

## INV-02 — Explicit interpretation

**Original:** Unknown version, codec, hash, signature, critical extension or relation semantics yield typed refusal, never an inferred fallback.

**Realized:** Closed version/algorithm/signed-record shapes refuse unsupported inputs. Unknown critical dimension schemas refuse when an explicit support policy is supplied.

**Boundary:** Default commitment-only verification does not interpret arbitrary dimension semantics; applications require dimensions and handlers.

Code: `src/dkn_v02/core.py::verify_dimension`. Regression: `tests_v02/test_batch_e_hardening.py::test_unknown_critical_with_explicit_support_policy`.

## INV-03 — Typed commitments

**Original:** Every object commitment binds schema ID, canonical byte form, algorithm and domain; identical input across different domains must not alias.

**Realized:** Domain-separated digests bind canonical values and schema identifiers; enclosing manifests bind dimension identifiers and criticality.

**Boundary:** A bare dimension digest does not separately include its display label; the enclosing manifest commits that label.

Code: `src/dkn_v02/core.py::commit`. Regression: `tests_v02/test_batch_e_integration.py::test_typed_dimension_domain_separation`.

## INV-04 — Logical versus transport identity

**Original:** Logical artifact digest binds a complete normalized entry inventory; archive-container byte digest is separately computed.

**Realized:** Complete admitted portable-file inventory and dimensions form the logical root; exact canonical ZIP bytes have a separate transport digest.

**Boundary:** Only canonical ZIP and portable regular-file bytes are realized, not arbitrary containers or filesystem metadata semantics.

Code: `src/dkn_v02/core.py::verify_archive`. Regression: `tests_v02/test_review_rc2.py::test_reserved_payload_paths_refuse_at_every_manifest_boundary`.

## INV-05 — Testimony is not authority

**Original:** Signed witness or publisher testimony asserts only its precise scope; acceptance and operational authority remain external.

**Realized:** Verified signatures and finite evidence satisfaction do not establish asserted facts or automatically authorize operations.

**Boundary:** Caller-recognized observers, policies, clocks and premises remain external trust inputs.

Code: `src/dkn_v02/assurance.py::evaluate`. Regression: `tests_v02/test_batch_d_assurance.py::test_signature_is_not_truth`.

## INV-06 — No authority gained by traversal

**Original:** No trust is gained by traversal: edges preserve claimant, proof, query scope and provenance; no unsigned claim silently becomes authenticated.

**Realized:** Bound relation evidence is rechecked; unsigned assertions remain unauthenticated and truth remains external.

**Boundary:** A dependency assertion does not prove compatibility, execution or third-party assent.

Code: `src/dkn_v02/navigation.py::inspect`. Regression: `tests_v02/test_batch_c.py::test_unsigned_binding_is_not_authenticated`.

## INV-07 — Bounded local coverage

**Original:** Index search, name matching and inbound discovery never imply exhaustiveness without a specified snapshot/coverage proof.

**Realized:** Discovery and reverse relations are relative to a bounded local collection; corruption is refused and truncation reported.

**Boundary:** No globally complete search/index, online discovery or authoritative absence proof.

Code: `src/dkn_v02/navigation.py::LocalIndex`. Regression: `tests_v02/test_review_rc2.py::test_invalid_index_container_is_not_empty`.

## INV-08 — Scoped freshness

**Original:** Freshness is relative to source, checkpoint, observation interval and policy; a disconnected client does not assert global currentness.

**Realized:** Checkpoint observations are checked under reader membership, age, sequence and supplied time.

**Boundary:** No global-currentness oracle, revocation fetch or trusted clock is provided.

Code: `src/dkn_v02/federation.py::assess_checkpoints`. Regression: `tests_v02/test_batch_d_federation.py::test_high_water_mark_can_advance_without_resigning`.

## INV-09 — Supplied continuity and visible forks

**Original:** Revocation, rotation, delegation and successor selection are separate signed claims and external choice; forks are represented, not hidden.

**Realized:** Genesis and key-transition chains verify; visible competing successors remain represented with no automatic selected winner.

**Boundary:** General delegated authority, lost-key recovery and live revocation are not implemented.

Code: `src/dkn_v02/lineage.py::analyze_lineage`. Regression: `tests_v02/test_batch_e_lineage.py::test_two_valid_successors_retained_without_winner`.

## INV-10 — Conditional substrate assessment

**Original:** Substrate guarantees must state assumptions, fault thresholds, evidence and expiry; profile labels alone grant nothing.

**Realized:** Only the finite supported evidence-contract predicates can be evaluated against recognized exact-scoped records.

**Boundary:** Profile labels and signed declarations do not prove availability, confidentiality, censorship resistance or consensus safety.

Code: `src/dkn_v02/assurance.py::evaluate`. Regression: `tests_v02/test_batch_d_assurance.py::test_evidence_satisfaction_has_claim_ceiling`.

## INV-11 — Common-cause accounting

**Original:** Replica/witness independence is an evidence question; overlapping control makes additive availability or Byzantine assumptions invalid.

**Realized:** Composition retains supplied common control, transitive dependencies, conflicting assumptions and metadata exposure.

**Boundary:** Different labels do not prove real-world administrative or Byzantine independence.

Code: `src/dkn_v02/assurance.py::compose`. Regression: `tests_v02/test_batch_d_composition.py::test_shared_control_not_replica_independence`.

## INV-12 — Read/verify authority boundary

**Original:** Verification of read-only material may not install, execute, publish, mutate trust state or fetch secrets.

**Realized:** Shipped verification and handoff operations do not install, execute, publish or grant authority; explicit store/index writes are separate calls.

**Boundary:** Third-party storage adapters and chosen test executables are host-authorized code, not sandboxed by DKN.

Code: `src/dkn_v02/federation.py::make_handoff`. Regression: `tests_v02/test_batch_d_federation.py::test_handoffs_no_authority`.

## INV-13 — Explicit finite budgets

**Original:** Bounded reads, recursion, graph fan-out, zip expansion, decompression, time and remote I/O are explicit; no unbounded traversal.

**Realized:** Admitted bytes, inventories, JSON structure, source scans, graph nodes/depth/edges and canonical results have finite limits and typed refusals.

**Boundary:** No universal CPU deadline, hostile-writer exclusion, crash-consistent transaction or memory sandbox is claimed.

Code: `src/dkn_v02/navigation.py::LocalIndex`. Regression: `tests_v02/test_review_rc2.py::test_real_acyclic_graph_reports_edge_limit`.

## INV-14 — Separate result dimensions

**Original:** Invalid or incomplete objects do not return partial VERIFIED state; typed outcomes distinguish missing/unsupported/conflicting/failed evidence.

**Realized:** Reports distinguish cryptographic validity, supplied evidence, authorization, semantic interpretation, truncation and uncertainty; required failures refuse.

**Boundary:** A successful process exit is not equivalent to a SATISFIES contract, recognized publisher or permission.

Code: `src/dkn_v02/runtime_schemas.py::validate_report`. Regression: `tests_v02/test_batch_e_schemas.py::test_authority_promotion_refused`.

## INV-15 — Public signing records, caller-controlled payloads

**Original:** Custody of private keys is separate from public manifests; no plaintext key material in published artifact.

**Realized:** Constructed public signing records contain public keys/signatures rather than the signer private key; publication payloads remain caller-provided bytes.

**Boundary:** No secret scrubber is implemented. The historical universal no-private-material assertion is not a delivered guarantee.

Code: `src/dkn_v02/core.py::certify`. Regression: `tests_v02/test_review_rc2.py::test_packer_does_not_claim_to_scrub_payload_secrets`.

## INV-16 — Commitment versus semantic realization

**Original:** Representation is agnostic about philosophical truth: content claims and empirical assertion correctness remain outside cryptographic integrity.

**Realized:** Hash/signature correctness does not establish truth or application behavior; an explicit application handler can verify a bounded semantic predicate.

**Boundary:** No generic truth engine, theorem prover or automatic equivalence certifier is implemented.

Code: `examples/v02_reader_policy.py::accept_note`. Regression: `tests_v02/test_review_rc2.py::test_application_rejects_signed_but_semantically_invalid_payload`.


The original fifty-case acceptance ledger retains its partial/deferred/blocked states.
Successful traceability checks cannot convert them into implemented features or deployment guarantees.
