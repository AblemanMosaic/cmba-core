# 0.2.0rc2 — bounded self-review and repairs

## Status and meaning

The exact Batch E input ZIP is SHA-256
`b775c6296d86b8586e38369bba1e1e458daa9a676e0f49adbbd0e9a499b4acbd`.
The baseline 549-case suite passed unchanged before review. Additional probes still found
real defects; baseline success was therefore not treated as sufficient assurance.

This is a **self-review of our own implementation**, with separately executed Node and native
cryptographic cross-checks. It is not a genuinely independent evaluator's decision. The
repaired offline profile is an engineering candidate; public-release approval remains
`NOT_CLEARED`. Final executed counts, artifact hashes, environment, install provenance and
fresh-extraction results are in the externally supplied rc2 review receipt. No hypothetical
platform run or unavailable legacy dependency is recorded as a pass.

## Findings and dispositions

| ID | Finding | Correction / evidence boundary |
|---|---|---|
| R001 | Python 3.13 recursive glob can suppress directory scan errors, producing an incomplete source inventory. | Explicit bounded `os.scandir` walk; scan failure refuses. Injected scan failure and empty symlink-ancestor regressions. No coherent concurrent snapshot claimed. |
| R002 | A wrong-kind `evidence`/`objects`/root container could appear empty instead of corrupt. | Validate existing directory/ancestor kinds; refuse local I/O failures. Missing index still legitimately denotes an empty local collection. |
| R003 | A real 34-node graph produced 4,257 edges and 4,224 unresolved edges without truncation; its report exceeded the canonical collection bound. | 4,096-edge cap, truthful `edge_limited`/`truncated`, canonical output admission and typed byte/depth budget refusal. |
| R004 | Reserved `.dkn` payload paths were rejected by ZIP packaging but accepted by standalone manifest construction, validation and certification. | One reserved-payload admission function used across inventory boundaries. Self-consistent malformed manifests also refuse. |
| R005 | Replay fingerprint omitted legacy tests/vectors and model/profile material; test logs were not bound; a legacy zero-test run could be counted as success. | Wider source/contract fingerprint, stdout/stderr binding, positive unittest-count requirement. Stage assembly checks unchanged source and logs. Receipts remain unsigned. |
| R006 | Central-directory allocation and manifest read budgeting could occur too late. | Fixed canonical ZIP end-record/count/size checks before `ZipFile`; manifest size checked before `read`. Early-rejection regression evidence, not a demonstrated signature forgery or exhaustive resource-exhaustion proof. |
| R007 | Namespace comparison without optional genesis-name evidence introduced a `None` map key; a nominally successful result could not be serialized canonically. | Preserve such candidates in `unnamed_candidate_roots`; string-only name groups and canonical output checks. No authority inferred from missing evidence. |
| R009 | Fresh extraction passed all tests but its source fingerprint differed because six generated `.egg-info` files were included only in the working-tree fingerprint. | Exclude generated build metadata consistently with source packaging; preserve the failed identity-comparison witness and add a regression requiring real source changes to remain detectable. |
| R008 | Historical constitutional text implied generic semantic enforcement, secret scrubbing and wider operational bounds than realized. | Explicit sixteen-obligation realized-scope map; reader-owned semantic handler example; unimplemented capabilities remain excluded, not waived into a pass. |

The initial scan probe used the wrong interception point and did not reproduce R001. That
attempt is retained in `baseline/reproduced-findings.json`. The confirmed reproduction uses
the actual cached glob scanner and is in `baseline/partial-scan-confirmed.json`. Root-user
permission behavior is not treated as proof that real permission failures cannot occur.
R003 is a realizable acyclic hash graph, not a fictional cyclic immutable commitment.

The first rc2 pre-freeze artifact was superseded after R009: 665 tests passed in both
trees, but source identity evidence did not yet align. The final receipt binds the repaired
rerun, not that earlier archive. `R009-PREFREEZE-WITNESS.json` records the discrepancy.

No new valid-publisher-key signature forgery was established. The previous Batch E repair
rejecting inadmissible identity keys remains present. New native cross-checks compare strict
point admission and deterministic Ed25519 signatures on finite public fixture corpora.

## Expanded evidence

`tests_v02/test_review_rc2.py` contains the repaired-boundary tests, 1,000 seeded ZIP bit
mutations, 264 signed-record top-level field mutations, application semantic-admission
checks, and the frozen portable conformance cases. Those mutation loops are **not** counted
as thousands of distinct pytest test cases. They do not exhaust the input space.

`tools/check_native_crypto.py` compares 89 point-admission cases and 24 valid / 24 mutated
signature cases against the installed native libsodium implementation. It explicitly checks
prime-subgroup membership rather than treating an old library's point predicate as a complete
oracle. This is additional cryptographic implementation diversity, not a second complete DKN
implementation or an independent security audit.

`interop/portable-conformance-rc2.json` freezes 47 full request/result/refusal cases spanning
byte commitments, manifests, archives, signatures, namespace continuity, inspection, assurance,
composition and checkpoint handoffs. Expected results were authored/checked in this review,
not supplied by an independent oracle. The separate Node checker remains scoped to 55
primitive byte/hash/signature cases. Passing both corpora does not prove all-input equivalence.

`examples/v02_reader_policy.py` demonstrates a real application interpretation: a signed
UTF-8 note declaration plus independent pins and a payload decoder. Tests refuse a validly
signed but invalid UTF-8 payload, missing required dimension and wrong reader pins. DKN's
cryptographic acceptance is deliberately not the application's semantic admission.

## Model and documentation alignment

`model/v02/SEMANTIC-CONTRACT.json` declares the bounded offline semantics, normative material,
exclusions and original-invariant mapping. `SEMANTIC-COMMITMENT.json` commits that model;
`REALIZATION-BINDING.json` separately binds this source realization and test references.
The checker verifies referenced bytes/symbols and, when supplied, corresponding executed test
records. It does not prove source correctness or approve a different toolchain automatically.

The original fifty-obligation acceptance ledger is retained. Partial/deferred/blocked rows
are not silently converted to full passes because the narrower offline profile is useful.
The source and current explanatory docs have been updated for the repaired behavior; old
A–E specifications/receipts remain explicitly historical where they conflict.

## Replay

```sh
python -m pip install '.[test]'
export PYTHONPATH="src:."
python tools/verify_v02_candidate.py --out /tmp/dkn-rc2 --phase tests
python tools/verify_v02_candidate.py --out /tmp/dkn-rc2 --phase examples
python tools/verify_v02_candidate.py --out /tmp/dkn-rc2 --phase assemble
python tools/audit_acceptance.py --report /tmp/dkn-rc2/LOCAL-RUN.json --out /tmp/dkn-acceptance.json
python tools/check_semantic_contract.py --report /tmp/dkn-rc2/LOCAL-RUN.json
python tools/run_conformance.py --out /tmp/dkn-conformance.json --command python tools/reference_conformance.py
python tools/check_native_crypto.py --out /tmp/dkn-native-crypto.json
python tools/build_review_candidate.py --out /tmp/dkn-rc2.zip
# A separate real prerequisite, not a mock-compatible success:
python tools/verify_v02_candidate.py --out /tmp/dkn-rc2-legacy --require-legacy
```

The native checker needs a system libsodium library; the Node tests need Node. Missing
capabilities are explicit missing evidence, not failures in the artifact being checked.
Windows uses `PYTHONPATH=src;.` and appropriate shell syntax; those commands are not Windows
execution evidence. Do not run an arbitrary replacement executable without host authorization.

## Remaining gates and residual assumptions

Genuine BLAKE3 legacy replay; actual native Windows/WSL/macOS behavior; clean public-index
dependency installation; independent security review; complete alternative-language verifier;
application-specific trust/authorization and deployment checks. Hostile concurrent writers,
crash consistency, live federation consensus, globally current revocation, key recovery,
general delegation, secret scrubbing and network P2P deployment are not realized guarantees.

A wheel import/run in a separate environment uses exact copies of genuine **preinstalled host dependencies**,
not a claimed successful fresh dependency download. The initial nested-venv smoke failed
because `jsonschema` was not inherited; that failure and the copied-file hashes are retained. A reproducible source ZIP serializes the
same frozen source/evidence tree; rerunning time-bearing evidence does not recreate the same
logs. All final artifacts remain unsigned, authority effect `NONE`, publication `NOT_PERFORMED`.
