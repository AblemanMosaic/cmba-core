# Replacing a realization without silently replacing its contract

## The three things that must not be collapsed

A **semantic contract** states the selected observable behavior, byte rules, admissible inputs,
refusals, effect boundaries and deliberately unimplemented capabilities. A **realization** is
one program/toolchain that attempts to implement it. **Evidence** establishes particular facts
about that attempt under a named environment and test corpus.

This review supplies three separate machine-readable artifacts under `model/v02/`:

- `SEMANTIC-CONTRACT.json`: the implementation-neutral, bounded offline contract and its
  immutable protocol/schema/corpus references. It does not contain Python source hashes.
- `SEMANTIC-COMMITMENT.json`: a DKN dimension commitment to the contract's exact value.
- `REALIZATION-BINDING.json`: the semantic commitment reference, this realization's source
  hashes, and obligation-to-symbol-to-test links. A replacement needs a new binding.

The original numbered design papers remain historical ambitions. The realized contract maps
all sixteen original invariants to delivered scope or explicitly deferred obligations. In
particular, default inspection is not semantic admission; revocation/recovery/delegation are
not implemented; filesystem operations are not an atomic hostile-writer vault; packing is
not a universal secret detector. These are not waived away by a test count.

## What can stay stable and what must change

| Item | Same-contract replacement |
|---|---|
| Exact semantic contract and commitment | Can remain unchanged. |
| Public wire schemas, canonical bytes, hash/signature domains | Must preserve their admitted meaning for protocol compatibility. |
| Golden/frozen input-output obligations | Must still be satisfied for the claimed profile. |
| Source language, modules, algorithms, build system | May change within the observable contract. |
| Source/executable hashes and realization binding | Must change when bytes change. |
| Test/review evidence | Must be regenerated for the replacement. |
| Recognition, deployment and execution permission | Must be decided by the appropriate external policy; not inherited from a shared hash. |

A replacement package can carry the same semantic dimension and a different content root.
That is not a hash collision; it is the point of separating what is promised from the concrete
program used to realize it. Do not reuse an old certificate over a changed logical artifact.
An authorized namespace publisher may publish a new release/derivation relation, but DKN
itself does not decide that the replacement is acceptable.

## A practical generation program

### Freeze the input boundary

Give the generator the semantic contract, PROTOCOL.md, runtime schemas, the current code as
an informative reference, the public fixture vectors, frozen conformance cases and the refusal
catalog. Identify a target: same-language refactor, native Rust/C implementation, JVM service,
etc. List which capabilities are in the replacement's profile. Do not promise full DKN while
silently implementing only hash/signature primitives.

Protect these frozen materials from automatic edits by the candidate-generation process.
An implementation that fails a case should be repaired or submit an explicit contract-change
proposal. It must not rewrite expected outputs until its own tests become green.

### Define the observable equivalence relation

For deterministic kernel operations, require exact canonical bytes, commitments, signature
acceptance rules, typed refusals and result fields. Preserve null/absent distinctions and integer
limits. For navigation, require deterministic ordering, local-coverage labels, unresolved nodes
and honest truncation. For assurance, require exact scope, recognized predicates, age/validity
rules, contradictory evidence handling and no authority promotion.

Filesystem and timing behavior require platform-specific obligations, not merely byte vectors.
A replacement that adds asynchronous I/O, caching, concurrency or network transports must
model those effects and test their failure behavior separately. Preserving a function name does
not preserve its security assumptions.

### Build the adapter before translating everything

`tools/reference_conformance.py` is a deliberately read-only **test harness**, not a new
production authorization ABI. It accepts one canonical JSON request with a bounded list of
cases on stdin, and emits one canonical JSON response. It accepts no paths, plugins, network
references or signing keys. Its operations cover canonical bytes, dimensions, manifests,
archives, signatures, namespace chains/forks, inspection and the existing SAM ABI.

A replacement can implement that adapter in its own language. Then run:

```sh
python tools/run_conformance.py --out replacement-result.json --command ./candidate-verifier
```

For the Python reference:

```sh
python tools/run_conformance.py --out reference-result.json
```

The frozen corpus currently contains 47 cases, including refusal and insufficient-evidence
outcomes. Expected results are generated from this reviewed reference and checked against
its targeted regressions; they are **not an independent universal oracle**. A test process is
still executable code: select, authorize and sandbox it using the host's execution policy.
The harness does not sandbox a malicious candidate program.

### Expand beyond the frozen corpus

Replay all applicable regression tests, mutation cases and malformed encodings. Differentially
compare both implementations on additional generated inputs; preserve disagreements as
new evidence rather than letting one implementation silently redefine the other. Use actual
independent cryptographic backends and published vectors for positive/negative checks.

Test native platform behavior: paths, Unicode normalization/casefold tables, filesystem races,
interrupted writes, access failures, command exit semantics and output bounds. Test the
installed artifact outside its source tree. Record compiler/runtime/dependency versions and
all assumptions. Rebuild the same frozen source twice; distinguish byte-identical packaging
from repeatability of computations containing timestamps or environment-dependent paths.

### Bind and review the result

The existing `tools/check_semantic_contract.py` checks source/reference binding integrity
and, when given a local-run report, verifies that cited regression cases actually passed.
It does not prove that the model is complete or that a program implements every implication.

A replacement must issue a new realization binding and new evidence receipts, preserving the
semantic commitment only when its contract is unchanged. Its review gate should distinguish
byte conformance, behavioral tests, static analysis, formal proof where available, operational
observations and external recognition. Approval from one layer must not be silently promoted
to another.

## Cross-toolchain hazards that matter here

The candidate codec is **not RFC 8785 JCS**. It sorts object keys by Unicode scalar/code-point
order and admits signed 64-bit integers. Ordinary JavaScript Number parsing loses integer
precision; the included Node checker uses BigInt and explicit parsing. Do not replace the codec
with a familiar JSON library's defaults and expect matching roots.

Do not silently normalize arbitrary string values; only path admission requires NFC.
Unicode filename alias behavior depends on the runtime database and target filesystem.
Preserve the exact zero-terminated hash/signature domain bytes, lowercase hex, closed schemas,
reserved `.dkn` payload path, canonical ZIP metadata and strict public-key admission. A valid
signature under an unrecognized key is still not publisher recognition.

The runtime has no generic theorem that a bound semantic declaration is true of arbitrary
software. A C or Rust version can share the exact contract and still have memory-safety,
undefined-behavior, resource or FFI defects. A Python regeneration can also be wrong. Toolchain
choice changes the proof obligations; it does not erase them.

## What this enables—and what it does not

This package supplies a stable target, traceable claims and executable comparison material.
That is substantially stronger than asking a generator to “rewrite this code similarly.”
It is not an already implemented UCM/GOORRT code generator, a verified compiler, or a machine
proof of arbitrary semantic equivalence. DKN makes the contract, realization and evidence
independently referencable. Generation/orchestration and ratification remain external.
