# Current rc2 release/review instructions

Use `tools/verify_v02_candidate.py --out <external-directory>` (or its separate test/example/
assemble phases), `tools/check_semantic_contract.py --report <directory>/LOCAL-RUN.json`,
`tools/run_conformance.py --out <report> --command python tools/reference_conformance.py`,
and `tools/build_review_candidate.py --out <external-archive.zip>` for this revision.
`tools/check_native_crypto.py` additionally requires the system libsodium shared library.
`--require-legacy` remains a real release prerequisite and must not be bypassed by a mock hash.

Self-review is not independent review. See `REVIEW-RC2.md` for findings and claim limits;
`REALIZATION-REPLACEMENT.md` for the separately bound semantic contract and reimplementation
harness. The external final receipt records exact current artifacts and clean replay.
The following Batch E record is preserved as **historical**; its counts, versions, paths and
BATCH-E inventory are not the current release certification.

---

# Release replay and bounded review handoff

## Recommendation

Use this package for **independent review and controlled offline integration**, not as a
ratified universal security guarantee or unattended production trust root. The five planned
construction batches are complete for the bounded implementation; public release approval,
legacy dependency replay, target-platform runs and independent review are separate gates.

## Artifacts and exact boundary

The Batch E ZIP is the complete cumulative source/docs/tests/evidence repository. The external
`.sha256` binds exact transport bytes. BATCH-E-FILE-MANIFEST.json covers every other archived
file and records the exact Batch D predecessor. No production signing key, publication or
authority promotion is performed. An unsigned hash receipt is integrity evidence relative
to a trusted expected hash, not independent publisher authentication.

The separately supplied wheel packages the Python library/CLIs, not the full research dossier.
Its exact hash and isolated-install checks appear in the release receipt. It is reproducibly
built from the same frozen source with SOURCE_DATE_EPOCH=1794009600. Source-package byte
reproducibility means serializing the same frozen tree; regenerating logs with timing/path
fields is not claimed to produce the same research artifact.

## POSIX replay

```sh
python -m pip install '.[test]'
export PYTHONPATH="src:."
python tools/verify_v02_candidate.py --out /tmp/dkn-batch-e-tests
# With genuine BLAKE3 installed; no replacement hash or mock is acceptable:
python tools/verify_v02_candidate.py --out /tmp/dkn-batch-e-full --require-legacy
python tools/build_v02_candidate.py --out /tmp/dkn-e.zip
python tools/audit_acceptance.py --report /tmp/dkn-batch-e-tests/LOCAL-RUN.json --out /tmp/dkn-acceptance.json
```

Node 22+ is the tested cross-language runner family; the actual version is in the receipt.
Without Node, interoperability cases skip and the consolidated gate refuses to call the
whole suite PASS. Rust is not substituted by the Node checks; it remains unexecuted.

## Windows replay (commands, not evidence)

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python -m pip install '.[test,legacy]'
$env:PYTHONPATH="src;."
.\.venv\Scripts\python tools/verify_v02_candidate.py --out C:\Temp\dkn-e --require-legacy
.\.venv\Scripts\python tools/build_v02_candidate.py --out C:\Temp\dkn-e.zip
```

Source symlink/FIFO tests require actual platform support and may need targeted adaptation;
skips are reported, not promoted to passes. Run Linux, native Windows and WSL as distinct
execution contexts. Cross-platform claims do not follow from a universal wheel tag.

## Independent reviewer worklist

Recheck E-001 key admission mathematically and against multiple Ed25519 implementations;
exercise malformed key/R/S encodings and parser differentials. Verify all signed body shapes,
optional-anchor semantics, domain separation and the distinction between content/root checks.
Challenge archive name aliases, ZIP metadata ambiguity, symlink/race assumptions, directory
scan limits and memory/CPU limits. Recompute the Node checks without relying on Python output
as the sole expected source. Inspect assurance contradictions, scope substitution, observer
recognition, threshold/domain common causes and checkpoint rollback rules. Review schema-to-
runtime differences and failure interpretation. Verify every claimed acceptance row directly.

There is no independent review receipt in this package. Same-session tests, a second language,
a fresh extraction and an isolated install are different kinds of engineering evidence, not
substitutes for a genuinely independent review authority. Do not transmit to an external
courthouse or publish automatically; this handoff requires an explicit selected review path.

## Interrupted executions and staged replay

Outer execution timeouts interrupted several combined runs after completed tests or examples.
The retained `evidence/batch-e/runner-interrupted/` records are not final completion receipts.
The completed local run uses separately executable, source-bound stages. External pytest
plugin autoload is disabled to prevent unrelated installed plugins from altering the runner.
No specific plugin is proven to have caused the interruptions. In constrained execution
environments, use these separate commands against the same unchanged source tree:

```sh
python tools/verify_v02_candidate.py --out /tmp/dkn-e-run --phase tests
python tools/verify_v02_candidate.py --out /tmp/dkn-e-run --phase examples
python tools/verify_v02_candidate.py --out /tmp/dkn-e-run --phase assemble
```

Assembly refuses changed source fingerprints, changed test XML, missing stage receipts or
changed example logs. A test count without a completed assembly is not a completed gate.
The source fingerprint binds implementation, tests, tools, schemas, examples, interop and
packaging metadata; the final file inventory also binds documentation and evidence.

## Installed-wheel evidence boundary

The library is imported from a separate virtual environment outside the source tree. Its
cryptography/JSON Schema dependencies are genuine installed host packages copied into that
environment; dependency downloads and fresh dependency resolution are not established. The
initial probe failed because a nested virtual environment did not inherit the host's jsonschema;
that environment repair and package hashes are recorded in INSTALL-DEPENDENCIES.json. The
installed-wheel check does not establish Python 3.12, Windows, WSL or macOS compatibility.

The final local run records 549 passing tests (182 inherited, 367 new), including 55 scoped
Python/Node comparisons. Four executable examples pass. The original 50 obligations reconcile
to 32 PASS_SCOPED, nine PARTIAL, three BLOCKED_DEPENDENCY, two DEFERRED, one DEFERRED_WITH_BOUNDARY,
two NOT_PERFORMED and one NOT_RUN. These categories are deliberately not collapsed into a
complete protocol or security certification.
