# Batch E findings and dispositions

Initial probes are preserved in `evidence/batch-e/pre-repair/DEFECT-PROBES.json`, bound by
the exact Batch D predecessor checksum. The initial inherited suite passed 182 cases.
That result did not cover the defects found below. Regression additions are in tests_v02.
No operational victim, credential or deployment was used.

| ID | Pre-repair observation / gap | Disposition and regression |
|---|---|---|
| E-001 | Identity-key/zero-scalar signature accepted by v0.2 certificate verification in this environment. SAM uses the same primitive. | FIXED: r002-derived full public-point admission; tests for certificate/genesis/SAM, invalid keys, RFC vector and scalar malleability. |
| E-002 | Correctly signed malformed genesis name accepted. Other body fields not uniformly checked by verifier. | FIXED: shared constructor/verifier validation; signed malformed-field fixtures. |
| E-003 | Invalid last successor key accepted as active key; epoch strings caused TypeError. | FIXED: every successor admitted; ordered type and link checks; parameterized regressions. |
| E-004 | Relation type=[] caused an untyped TypeError. | FIXED: type admission before set membership; malformed-relation regressions. |
| E-005 | Windows drive/device/punctuation paths, trailing-dot/control names and casefold file/prefix aliases accepted. | FIXED in portable-profile admission; Linux tests only, Windows filesystem gate remains open. |
| E-006 | Certificate verification checked root math without complete manifest structural admission. | FIXED: validate_manifest before certify/verify_certificate; typed inventory sizes and full field closure. |
| E-007 | Some CLI/index reads loaded entire files before limit checks; index ancestor symlinks were not rejected. | FIXED for supplied readers with bounded reads/static ancestor checks; hostile concurrent writers remain excluded. |
| E-008 | Source-loader aggregate budget was checked only after retaining files. | FIXED: remaining budget applied before reading each file; aggregate regression. |
| E-009 | Depth-limited traversal could report no truncation despite omitted edges. | FIXED: depth_limited plus truncation; bounded-cycle control-flow fixture. |
| E-010 | Runtime report shapes lacked a complete exported structural contract for the implemented surface. | ADDED: 27 schemas and per-schema positive/unknown-field/authority tests; no semantic-proof claim. |
| E-011 | Source-package verifier did not require exact canonical envelope bytes. | FIXED: exact reconstruction check; prefix/suffix/comment mutations refuse. |
| E-012 | A new standalone namespace required a syntactically valid but unverified legacy anchor. | FIXED: null anchor supported explicitly; old anchor bytes unchanged; no implied migration proof. |
| E-013 | Later evidence lineage needed an explicit Batch D predecessor and new packaging boundary. | FIXED: Batch E inventory, boundary, inheritance delta and external transport commitment. |
| E-014 | Full dependency/platform/independent-review prerequisites remain unavailable. | OPEN: legacy BLAKE3 install failed, Windows/WSL/macOS and Rust not run, independent review not performed. |

One intermediate bounded-read patch changed the SAM missing-file refusal code. The inherited
regression caught it; the existing SAM code was restored. An early new security test expected
PUBLIC_KEY_INVALID while the signature wrapper normalized it as SIGNATURE_INVALID; the key
check was moved before that catch so the diagnostic is now precise. These failed intermediate
runs are retained as engineering history, not erased or misrepresented as final passes.

E-001 is a key-admission failure for attacker-chosen inadmissible keys, not a demonstrated
forgery under a legitimate pinned nonidentity publisher key. Its repair is still a candidate
change requiring independent review; regression success is not a complete security proof.

E-015 — **Runner completion boundary.** Combined execution attempts exceeded outer execution
limits after producing passing test output. No completed local receipt was inferred from those
attempts. The runner now supports source-bound test/example/assembly stages, captures subprocess
timeout failures, checks log integrity, and disables ambient pytest plugin autoload. The final
local receipt comes from completed stages, while interrupted logs remain in the package.
