# DKN: use, integration, and the meaning of its results

Current distribution: **0.2.0rc2, self-reviewed offline engineering candidate**. Start with
REVIEW-RC2.md for the evidence and remaining gates. This guide describes implemented
behavior; it does not promote historical design goals into delivered guarantees.

## 1. The system in one sentence

DKN lets an application bind precise bytes, identities, declarations, and relationships,
then independently inspect those bindings under explicit reader policies, without making
a storage server the source of the artifact's identity.

A useful mental model is **a portable evidence envelope and a disciplined reader**.
It is not a blockchain, cloud repository, certificate authority, secret scrubber, execution
sandbox, search engine, or automatic judge of what is true. Its strength is separating those
questions rather than collapsing all of them into a green check mark.

The installed distribution is named `dkn-core`. The candidate Python import is `dkn_v02`.
`dkn_core` remains the separate original v0.1 implementation; it needs the optional genuine
BLAKE3 dependency. The candidate uses SHA-256 and Ed25519. These identifiers are not aliases
for the legacy BLAKE3 namespaces.

## 2. What travels with a publication

The payload is a finite mapping from portable relative paths to bytes. A logical manifest
lists every admitted file, its size and hash, and a sorted set of typed commitment dimensions.
The **logical root** identifies this inventory and its dimension commitments. The **transport
hash** identifies the exact ZIP bytes. A detached certificate signs the logical root and an
optional namespace reference. A signed namespace genesis identifies a claimant and the root
of a continuity chain. Relations, semantic values and other evidence must also be supplied
when a reader wants to check their commitments; hashes alone do not carry their preimages.

A dimension might bind a data schema, API contract, dependency declaration, governance
policy or test dossier. These are labels and commitments, not built-in interpreters of all
those domains. `verify_dimension(..., supplied=True)` checks that a supplied value matches.
An application-specific handler must check what that value means and whether the artifact
actually satisfies it.

Files may move between a local directory and a memory mirror without changing their logical
identity. The current transport verifier accepts **one canonical ZIP format**. Supporting
arbitrary tarballs, recompressed ZIPs, executable bits, symlinks or ACL semantics is not
established by the separation between logical and transport hashes.

## 3. The subsystems

| Subsystem | Actual implementation | Its boundary |
|---|---|---|
| Byte/commitment kernel | `core.canonical`, `commit`, manifest and archive functions | Exact admitted bytes and hashes, not truth. |
| Public identity and signatures | `certify`, `verify_certificate`, strict point admission | A valid key signed a statement, not that the reader trusts that key. |
| Namespace continuity | Genesis, transitions, `analyze_lineage` | Supplied chains and visible forks, not a globally current owner. |
| Reading and navigation | `inspect`, `LocalIndex`, discovery/traversal | Reverified local candidates; no network-wide completeness. |
| Substrate assurance | Signed declarations/evidence, `evaluate`, `compose` | Finite evidence obligations under caller policy, not a deployment theorem. |
| Federation observations | `assess_checkpoints`, `make_handoff` | Bounded witness observations, not consensus or permission. |
| Storage | `MemoryStore`, `DirectoryStore`, `retrieve` | Operational local/memory adapters; external adapters are caller-controlled. |
| Schemas and test interfaces | Runtime schemas, SAM ABI, conformance harness | Shape/behavior contracts, not proof that submitted results are authentic. |

All shipped read/verification operations leave capability effects at `NONE`. Publishing to
local storage is an explicit operation. No built-in operation deploys an enterprise cluster,
contacts P2P peers, executes an artifact, updates a trust registry, or secretly fetches keys.
A third-party adapter is ordinary executable code; the host must authorize and constrain it.

## 4. What “nearly unsquattable” actually means

Two people may both declare `example.application`. Their genesis bodies bind different
public keys, so their namespace roots differ. Copying the spelling is not taking over the
other cryptographic namespace. A reader must pin or recognize the intended root/key.

This does not eliminate misleading display names, Sybil identities, malicious search
rankings, key compromise or human confusion. A recognizable name is a discovery hint.
The cryptographic root and reader recognition policy decide which claimant is intended.

The stable genesis root survives ordinary verified key transitions. An operational key is
valid only relative to the supplied chain. Two signed successors are preserved as competing
branches; DKN does not quietly pick a winner. Recovery-policy references are descriptive.
There is no delivered general lost-key recovery, revocation service or delegation engine.

## 5. Install and first use

Install the provided wheel into an application environment, or install from the extracted
repository. Python 3.12+ is declared; the actual review ran on Linux/Python 3.13.5. Dependency
resolution from the public package index was unavailable in this review environment.

```sh
python -m pip install ./dkn_core-0.2.0rc2-py3-none-any.whl
# Or, from the extracted repository:
python -m pip install .
python examples/v02_reader_policy.py
```

The source tree contains the full model/specifications/tests/evidence. The wheel contains
the library, its runtime schemas and CLI entry points, not the whole review dossier.

A minimal producer is ordinary library code:

```python
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import declare_genesis, commit, pack, certify

# Demonstration only. Real applications provide protected, persistent signing custody.
key = Ed25519PrivateKey.generate()
genesis = declare_genesis(
    semantic_name="example.notes", purpose="publisher", nonce="initial", key=key
)
profile = {
    "content_kind": "utf8-note",
    "logical_filename": "note.txt",
    "text_encoding": "utf-8",
}
dimension = commit("note-profile", "example.utf8-note.v1", profile, critical=True)
archive, manifest = pack({"note.txt": b"A portable note.\n"}, [dimension])
certificate = certify(manifest, key, namespace_root=genesis["namespace_root"])
```

The application decides where to store/transmit the archive and sidecars. Do not place
production private keys in that payload. DKN intentionally accepts arbitrary file bytes;
it cannot reliably recognize all encodings of secrets. Publish from an explicitly selected
release tree, not blindly from a home directory, repository checkout or credentials folder.

## 6. The reader's responsibilities

An attacker can replace a self-consistent archive, manifest and self-signed certificate
together. Self-certifying does not mean self-trusting. The reader needs protected expected
roots, publisher/namespace pins, or a separately recognized policy that establishes them.

A safe integration distinguishes these checks:

1. Verify the archive and compare its root with the reader's expected root.
2. Verify the detached certificate against the manifest for that same root.
3. Check the namespace chain and the reader's publisher/root recognition policy.
4. Require the dimensions the application needs, verify their supplied values, and run
   the relevant semantic handlers.
5. Evaluate any required freshness/assurance evidence, then make an **external** admission
   or execution decision. Refuse or retain uncertainty when required evidence is absent.

`examples/v02_reader_policy.py` executes this sequence for a UTF-8 note. Its application
handler checks that the signed declaration matches the required note profile and that the
actual declared payload decodes as UTF-8. A cryptographically valid archive containing
invalid UTF-8 is refused by that handler. This is a small example of realized semantics,
not proof of arbitrary program behavior.

The demonstration obtains pins from its own producer because it is a self-contained test.
Production readers must obtain pins through their accepted recognition/configuration path,
not from the untrusted bundle they are about to authenticate.

### Results are deliberately not one boolean

`signature=PASS` means the signature checked. `authorization=NOT_CHECKED` is not permission.
`namespace_authorization=PASS_FOR_SUPPLIED_CHAIN_ONLY` is not evidence of current revocation
status or signing-time authority. `dimension_semantics=NOT_CHECKED` means the application
still owes interpretation. Discovery may return candidates whose namespace authorization is
not established. Applications must inspect these fields rather than accepting a name match.

A successful CLI process exit means the requested computation completed. A SAM assessment
of `INSUFFICIENT` or `CONTRADICTED` still exits zero. Read the result, not just the exit code.

## 7. Navigation in an application

```python
from dkn_v02 import LocalIndex

index = LocalIndex("./local-dkn-index")
index.add(archive, certificate=certificate, genesis=genesis)
view = index.resolve_exact(manifest["logical_root"])
choices = index.discover(semantic_name="example.notes")
graph = index.traverse(manifest["logical_root"], max_depth=3, max_nodes=64)
```

This explicitly writes a local index. Reads reverify bytes and sidecar evidence. A damaged
index container is refused rather than treated as empty. An uncreated index may legitimately
have no local results. A corrupt candidate causes a closed refusal rather than silent omission.

Forward relations come from bound metadata. Incoming relations are found only among locally
known objects. A signed `depends_on` edge proves a publisher asserted the relationship; it
does not prove compatibility or successful execution. Relation types are closed and their
destinations are logical-root references, not arbitrary executable lookup instructions.

Depth, node and edge truncation are reported. The edge ceiling is 4096; an output that cannot
fit the 4 MiB canonical envelope refuses with `DKN_V02_NAV_LIMIT`. Reduce the query bounds or
split the investigation. There is no pagination cursor, globally exhaustive index or transactional
multiwriter vault in this release.

## 8. Storage and assurance are different layers

A store's `put`/`get` moves bytes. `retrieve` tries supplied locators and independently checks
transport and logical roots. A successful fetch proves access during that invocation, not
that a provider will retain the object or remain available tomorrow.

The six reference profiles describe local vault, enterprise distributed, public hosting,
P2P CAS, federated CCP and hybrid deployments. They are **templates**. Naming a deployment
`P2P_CAS` creates no peer network or censorship-resistance guarantee.

A signed substrate descriptor declares mechanisms, control/failure domains, assumptions,
exposure, dependencies and validity. A contract defines exact-scoped predicates, methods,
required signers and age bounds. A reader policy recognizes observers and their predicates;
a context supplies the clock and accepted premises. The evaluator recomputes the result.

`SATISFIES` means supplied obligations are met under that policy. `CONDITIONAL` retains
premises not established by the evaluator. `INSUFFICIENT` identifies missing or ineligible
material. `CONTRADICTED` retains recognized refutations/conflicting premises. A signed
`TEST_RESULT` remains an observer's assertion unless the application also checks its basis.

Composition retains shared administrators, providers, transitive dependencies, incompatible
assumptions and public metadata exposure. Three stores under one administrator do not become
three independent failure domains. Even no known overlap does not prove independence.

## 9. CHC/CCP use

Checkpoint assessment uses reader-pinned membership, thresholds, observation-age bounds and
rollback floors. The membership commitment excludes the reader's changing age/sequence bounds,
so tightening them does not rewrite history. Conflicting supplied signed heads remain visible,
even when old observations expire. No network consensus protocol is run.

A CHC/CCP handoff recomputes the assessment and keeps `EXTERNAL_DECISION_REQUIRED` plus
`execution_authorized=false`. The receiving application supplies recognition, revocation,
freshness and capability policy. DKN carries the evidence; it does not appoint itself the court.

## 10. Deployable scope today

This candidate is useful for controlled offline publishing, portable verification, local
navigation, explicit evidence-policy experiments and integrations whose threat model accepts
the documented single-writer limitations. It is not cleared as an unattended production trust
root. Native Windows/WSL/macOS, genuine legacy runtime replay, independent review and live
network/federation guarantees remain separate gates.

For a different implementation or toolchain, continue with REALIZATION-REPLACEMENT.md.
The crucial separation is **same semantic contract, different realization, new evidence**.
