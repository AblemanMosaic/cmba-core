# ABI and CLI

The ABI request is canonical JSON:

```json
{"arguments":{},"operation":"namespace.derive","request_id":"request-1","schema":"dkn.abi-request.v0.1"}
```

Supported pure operations are `namespace.derive`, `namespace.verify`,
`passport.create`, `passport.import_mosaic`, `passport.verify`, `thr.build`,
`thr.verify`, and `record.verify`. Responses always carry either a result or a
typed refusal and preserve the non-authority boundary.

CLI groups are:

- `namespace derive`
- `passport create|import-mosaic|verify`
- `ceremony new`
- `thr build`
- `record sign|verify`
- `retrieval verify`
- `archive verify`
- `abi REQUEST.json`

Signing and ceremony commands read passphrases interactively. No command accepts
a raw private key, token, password, or credential as an argument. No command
performs network access, publication, installation, or external dispatch.

