# Consolidated DKN review dossier — 0.2.0rc5

This is the current entry point. Batch A–G documents remain historical/normative sources
for their named profiles; H adds no new runtime protocol. Distribution version, protocol
profile, semantic commitment, source fingerprint and transport hash are distinct identities.

## Reading routes

| Need | Read |
|---|---|
| Understand and integrate the library | [Architecture and use](ARCHITECTURE-AND-USE.md) |
| Know precisely what is and is not guaranteed | [Claims and acceptance](CLAIMS-AND-ACCEPTANCE.md) |
| Replace the realization without changing the contract | [Replacement qualification](REPLACEMENT-QUALIFICATION.md) |
| Reproduce local and target-machine evidence | [Replay](REPLAY.md) |
| Review repairs made during H | [Findings](FINDINGS.md) |
| Conduct independent review or deploy deliberately | [Review handoff](REVIEW-HANDOFF.md) |
| Understand artifact and dependency provenance | [Provenance](PROVENANCE.md) |

Detailed interfaces remain in `docs/v02/API-REFERENCE.md`, `docs/batch-f/DEVELOPER-GUIDE.md`
and `docs/batch-g/DEVELOPER-GUIDE.md`. Normative protocol references are committed by the
three models in `model/v02`, `model/lifecycle-f1`, and `model/distributed-g1`.

## Evidence navigation

`evidence/batch-h/local-run/H-REVIEW.json` binds the completed local stages and summarizes
tests, workflows, model checks, acceptance reconciliation and conformance. Raw XML and logs
are alongside it. The exact frozen source inventory is `BATCH-H-FILE-MANIFEST.json`.
Post-freeze replay, installation and rebuild receipts are supplied externally so no receipt
attempts to include the hash of the archive that contains that receipt.

The original fifty obligations remain 35 scoped passes and fifteen limitations. The 42
model obligations have finite implementation/test traceability, not whole-program proofs.
A local PASS does not close Windows/WSL/macOS, fresh dependency installation, genuine BLAKE3,
full alternative-language verification, independent security review, or deployment approval.
The exact measured status of each leg is in the release receipts, not inferred from this index.

**Authority effect NONE. Independent review NOT_PERFORMED. Public release NOT_CLEARED.**
