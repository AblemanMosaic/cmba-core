# DKN architecture and practical use

## One object, several questions

DKN separates the exact content of an artifact, the statement signed about it, the identity
and history claimed by its publisher, the evidence supporting infrastructure claims, and the
reader's decision to recognize or act on it. Those questions must not be compressed into one
ambiguous verified=true flag.

The reusable distribution is `dkn-core`; the candidate Python import is `dkn_v02`. `dkn_core`
is the preserved legacy v0.1 implementation and requires genuine BLAKE3. Installing rc5 does
not reinterpret old identifiers, migrate storage, replace keys, or advance reader pins.

## Commitment and publishing kernel

`canonical` encodes the candidate's strict bounded JSON grammar. This is not JCS: integer
range, Unicode key ordering and forbidden representations are specified by DKN's protocol.
`commit` binds an application's schema and canonical declaration under a typed domain. A
manifest encloses dimensions and a complete portable regular-file inventory. `pack` returns
canonical ZIP bytes and a logical manifest; `certify` constructs a detached signature.

The logical root identifies the inventory and committed dimensions. The separate transport
SHA-256 identifies exact ZIP bytes. Changing a locator does not change logical identity.
The current library admits only its canonical ZIP encoding; general alternative archive
containers are not a delivered feature. Executable bits, symlinks and arbitrary filesystem
metadata are not portable payload semantics under this profile.

A declaration's hash establishes which declaration was committed, not whether it is true.
The value behind a detached dimension must be supplied to check it. Unknown critical schema
handling needs an explicit application support policy. An application must require its
needed dimensions and run their actual semantic handlers rather than treating the default
commitment-only verifier as an application admission engine.

## A developer's publishing workflow

1. Maintain a protected signing identity and the reader-recognized namespace/policy material.
2. Build a finite mapping of admitted file paths to bytes, plus typed declaration commitments.
3. Package it and sign the logical manifest. Store/archive the detached verification material.
4. Distribute those bytes through any application-selected transport. The shipped adapters are
   local directory and memory; network transfer remains the integrator's implementation.

Run `python examples/v02_publish_verify.py` for the implemented API. The example keys are
local demonstration material, not a production key ceremony. DKN does not scrub payload
secrets. A file deliberately containing a private key remains a caller-provided payload.

## A reader's workflow

Obtain expected artifact roots, publisher/namespace recognition, clock policy and any protected
rollback floor from accepted configuration, not simply from the bundle being checked. Verify
the artifact inventory and bytes, certificate binding, signing-key admission and supplied
namespace evidence. Supply required semantic values and run application handlers. Evaluate
freshness and substrate evidence only under the explicitly selected profile and policy.
Only the application's authority path decides to install, execute, accept or recognize.

`python examples/v02_reader_policy.py` demonstrates a bounded semantic handler that requires
a precise text profile and actually checks UTF-8 decoding. It rejects a cryptographically
valid artifact that fails that application predicate. This is a concrete semantic check,
not a universal interpreter or proof that arbitrary software behaves as documented.

## Namespace identity and continuity

Human-readable spellings are nonexclusive. Different founder keys/genesis bodies can use
the same spelling without receiving the same cryptographic root. Readers pin the intended
root; a copied spelling is not control of that identity. This limits identity squatting,
not social impersonation, key compromise, deceptive discovery or homograph confusion.

Base transition records verify a supplied chain and preserve visible forks. LC-F1 is an
explicitly selected, separately committed lifecycle profile. It adds finite direct grants
for exact artifact/subject/operation, revocation, suspension, dual-signature rotation and
precommitted guardian-threshold recovery with successor possession. It preserves the root
while deriving operational epoch instances. Rotation invalidates prior grants; resuming
suspension does not silently revive invalidated grants.

Recovery policy must be bound in genesis. It cannot be invented after the loss. Guardians
can endorse the same proposal separately; the public collector need not hold all private
keys. Distinct keys do not establish independent people or legitimate intentions. The finite
journal limit is 256 events; no guardian-policy amendment or subdelegation engine exists.
Run `python examples/v02_lifecycle_vault.py` for the complete local workflow.

## Reading, navigation and local persistence

`LocalIndex` provides exact resolution, name-based candidate discovery and bounded graph
traversal. Stored material is reverified. Signed edges establish publisher assertions, not
the truth of dependency/derivation claims. Incoming relations are discovered only among
known local artifacts. Empty results do not prove global absence; truncation is explicit.
The directory index is a single-writer convenience, not a hardened multiwriter service.

`TransactionalVault` is an opt-in SQLite alternative for cooperating local clients. It adds
atomic writes, verified snapshot reads, explicit compare-and-swap namespace-head advancement
with ancestry checks, and all-or-nothing import from a quiescent directory index. Read calls
do not advance pins. A hostile administrator or rollback of the whole database can restore
old internal knowledge; a protected external floor must actually be supplied by deployment.

## Substrate assurance and supplied views

Assurance descriptors represent mechanisms, controls, assumptions and evidence. Six reference
profiles cover local vaults, enterprise distribution, public hosting, P2P, federated CCP and
hybrids. Profiles are templates, not automatic security guarantees or live backend services.
The finite evaluator checks exact scopes, recognized observers, time bounds, methods,
contradictions and premises. Composition retains shared-control and dependency risks rather
than adding replica counts into an unsupported independence claim.

Federation observations evaluate signed statements under pinned membership, thresholds,
sequence floors and supplied time. They are not consensus. DS-G1 `assess_view` joins actual
artifact/certificate, LC-F1 history, optional witnesses and assurance with exact identities
and scopes. A known applicable contradiction is not hidden by making its check optional.
The result is about `certify_artifact`, never execute/install authorization.

## Simulation is not deployment

DS-G1 schedules explicit sends, delays, partitions, failure domains, clock offsets, snapshots
and restores around the actual verifiers. Each reader knows only its local holdings. Hidden
revocations do not become magically visible. Full replay recomputes results, not merely hash
chain consistency. There are 27 public scenarios and 28 frozen conformance cases.

Run `python examples/v02_distributed_simulation.py`. The evaluator is separately reusable
outside simulation; actual retrieval, time, budgets, recognition and operational authority
remain application responsibilities. No live enterprise/P2P daemon is shipped.

## Integrating with a larger constitutional stack

UCM, CCP, CHC, Courthouse and orchestration systems can bind their models, decisions and
receipts with DKN, then interpret those objects under their own authority rules. The shipped
handoffs retain an external-decision boundary. Installing this library does not constitute
an operational integration or establish another system's acceptance. Independent developers
can use DKN without adopting any of those systems.
