# Artifact, dependency and evidence provenance

The predecessor is the exact G source archive SHA-256
`cb659af507734796c8b69602449b7fe93efb31a3c66407b997f6e2d882994e97`.
The H review baseline records 43 runtime source hashes, six semantic body/commitment hashes,
and three corpus hashes. H keeps those bytes unchanged. Package metadata, review tools,
realization bindings and current explanatory documents change explicitly.

`release/DEPENDENCY-INVENTORY.json` inventories observed installed distributions and hashed
metadata. It is a local inventory, not a CycloneDX compliance claim, vulnerability scan,
proof of trustworthy upstream provenance, dependency lock, or license/legal certification.
The existing requirements files describe observed versions. They are not a hash-locked,
portable dependency bundle. No dependency wheel or third-party signing material is silently
vendored into the source candidate.

A genuine BLAKE3 download was attempted through the normal package index and did not succeed
in this environment. The captured log is in `evidence/batch-h/dependency-probe/`. No replacement
hash, stub or false compatibility result is provided. Installed-wheel evidence must say
whether it uses copied genuine preinstalled distributions or a fresh resolver/download.

The public PyPI BLAKE3 project and pip's documentation were consulted as external background:

- https://pypi.org/project/blake3/
- https://github.com/oconnor663/blake3-py
- https://pip.pypa.io/en/stable/topics/repeatable-installs/
- https://pip.pypa.io/en/stable/topics/secure-installs/

Those sources explain package availability and repeatable-install techniques; they do not
validate this DKN implementation. The externally described use of version pins, reviewed
hashes and platform-specific wheelhouses is distinct from the locally observed installation
result. Retrieval did not establish a usable BLAKE3 distribution here.

Source ZIP and wheel hashes bind exact transport bytes. Logical DKN roots, semantic model
commitments, implementation bindings and test-source fingerprints have different domains
and scopes. None should be substituted for another. Post-freeze replay artifacts remain
external to avoid circular self-hashing. Engineering records are unsigned and same-author;
independent approval and publisher recognition require their own accepted provenance.
