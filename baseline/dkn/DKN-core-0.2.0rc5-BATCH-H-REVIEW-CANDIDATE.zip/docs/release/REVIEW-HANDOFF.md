# Independent review and deployment gate

## Requested next action

The A–H construction program ends at this frozen bounded engineering candidate. Stop feature
expansion while a separately selected reviewer and target-machine operator evaluate the
candidate. No external courthouse submission or publication is automatic. No approval is
predeclared here.

## Review inputs

Use the externally pinned H source ZIP, checksum and release receipt. The active file manifest
binds every other member; prior manifests and certificates are historical. Pin the three
semantic commitments and frozen corpora separately. Replay the H phases against unchanged
source. Inspect H's retained pre-repair conformance-oracle witnesses; independently challenge
the new exact-byte comparison and common-context evidence checks.

## Security and semantic review priorities

Re-examine key admission and malformed Ed25519 encodings under multiple implementations.
Review exact canonical representations, signed body shapes, domain separation, byte budgets,
archive closure and portable path semantics. Challenge independent publisher pin acquisition,
profile selection, scope joins, optional-check contradiction handling and report interpretation.

For lifecycle, inspect threshold signing, proof of successor possession, current-key and
recovery authority, time windows, revoked/suspended grant handling, fork visibility and the
finite journal cap. Verify that recovery cannot be introduced after genesis. Distinguish
valid guardian signatures from real-world independence and legitimacy.

For storage, challenge concurrency, snapshots, compare-and-swap, migration and process-crash
behavior on the actual filesystem/OS. Whole-database rollback and external floor protection
must be tested as distinct mechanisms. Do not infer hostile-host safety or power-loss
resilience from process termination tests.

For distributed modeling, independently recompute scenarios and hidden-information boundaries.
Do not treat simulated clocks, administrative labels, replicas or matching observations as
live deployment guarantees. Challenge a correctly hash-linked transcript containing a forged
conclusion; full replay must recompute it.

## Gates intentionally still open

| Gate | Evidence needed; not supplied by a local v0.2 PASS |
|---|---|
| Genuine legacy replay | Install genuine BLAKE3, run inherited r002 tests, examine namespace/MosaicID/old-client compatibility obligations individually |
| Target platforms | Native Windows, WSL and macOS receipts on exact source; explain any skipped/refused cases |
| Fresh dependency installation | Reviewed fetched distributions, resolver/install record, hashes and dependency checks |
| Alternative realization | Full selected-profile implementation, not just Node primitive checks; independent differential/adversarial tests |
| Independent security review | A different reviewer actually inspects/replays and signs or otherwise authenticates their own scoped findings |
| Deployment acceptance | Real storage/transport/custody, clock/pins/floors, guardian ceremony and relevant authority approval |

A reviewer may approve a narrower scope while retaining other gates. Neither this document,
a model checker nor the unsigned release receipt has standing to grant those approvals.
Results must name exactly which artifact, profile, environment and threat assumptions were
reviewed. Matching code hashes or a test count is insufficient as an authority record.

## Stop condition

Unresolved external prerequisites stay unresolved rather than generating another speculative
feature batch. New findings lead to bounded repairs, new source commitments, regression
evidence and renewed review. No automatic trust transfer, forced upgrade or live deployment.
