# Claims, realization and acceptance

## Three layers of evidence, three distinct meanings

| Evidence | Establishes in its bounded scope | Does not establish |
|---|---|---|
| Hash/signature/manifest verification | Exact admitted bindings and signed statements | Truth, intended publisher recognition, safety to execute |
| Finite behavior tests and replay | Observed agreement for executed inputs/environment | Whole-program correctness, untested platforms, live deployment |
| Semantic-model traceability | Referenced specifications, implementations and recorded tests match | A proof that all program behavior refines the model |

The current release keeps every inherited runtime module and all six semantic body/commitment
files byte-identical to Batch G. H changes review tooling, metadata, bindings and documentation.
The base, LC-F1 and DS-G1 contracts remain independently selected profiles. New bindings point
to the same model commitments with refreshed implementation metadata; verification never
regenerates a model to fit a failed realization.

## Original fifty-obligation ledger

`design-v0.2/acceptance/MATRIX.json` remains unchanged from G: 35 PASS_SCOPED, 8 PARTIAL,
3 BLOCKED_DEPENDENCY, 1 DEFERRED, 2 NOT_PERFORMED and 1 NOT_RUN. `tools/audit_acceptance.py`
checks referenced executed tests but does not promote these dispositions. Each existing row
retains its explanation; the newer 42 model obligations are not substituted for this ledger.

## Current functional boundary

The base provides canonical bindings, canonical ZIP inventories, detached certification,
supplied namespace continuity, local navigation and finite assurance contracts. LC-F1 adds
finite lifecycle controls and the cooperative SQLite vault. DS-G1 adds supplied-view
composition and deterministic finite simulation. All are locally testable; the exact measured
results and environment are in the H review receipt.

The maintained restrictions include canonical-ZIP-only transport, explicit application schema
handlers, caller-controlled recognition/time/floors, bounded local search, finite journals,
no policy amendments/subdelegation, no payload secret scrubbing or automatic key custody,
no live network adapter/consensus/currentness oracle, and no full alternative-language stack.

## Approval policy

A successful H run reports `PASS_SCOPED_ENGINEERING_EXTERNAL_GATES_OPEN`, with
`public_release_gate=NOT_CLEARED`, `independent_review=NOT_PERFORMED`, and `authority_effect=NONE`.
This is an honest terminal state for the construction program, not an implied production
approval. Independent review, target-platform/deployment evidence, and recognition decisions
must be represented as new evidence from the parties actually performing them.

No dependency availability, test count, universal wheel tag, simulated quorum or hash chain
can substitute for those absent records. An unsigned engineering receipt also cannot serve
as independent publisher authentication when its expected hash comes from the same untrusted
source as the object it is meant to authenticate.
