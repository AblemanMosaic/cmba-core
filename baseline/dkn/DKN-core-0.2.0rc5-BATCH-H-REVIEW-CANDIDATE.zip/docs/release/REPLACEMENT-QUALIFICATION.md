# Qualifying a replacement realization

## Pin what must remain the same

Pin all selected semantic commitments independently of the replacement bundle. Preserve the
normative schemas, canonical bytes, signature domains, refusal behavior, resource boundaries,
authority limits and scheduler/visibility rules of those profiles. The three committed models
remain the specification targets; the existing source is a reference implementation, not the
sole definition of correctness.

Base: `0fbd636ce484dd37e4afc4083f5207d86143ec1de0ee031ce76d1e67137497fb`

LC-F1: `cdb44fd68c6e60d5317b889a123837c413aa629c0c77a121c17133b055a63e19`

DS-G1: `5efb09f47bf1dc3fb6e674ad4a74192682a4f2df434df2123c49f86e529ce391`

A same-language rewrite and a Rust/C/Go/JavaScript port follow the same rule: preserve the
contract or explicitly version a changed one. Do not silently regenerate golden expectations
to make a candidate pass. Source/binary/toolchain identities and evidence must change with
the realization even when its targeted semantic commitment stays the same.

## Execute the frozen corpora

Implement the small read-only conformance test adapter, then select its reviewed executable:

```sh
python tools/run_conformance.py --corpus interop/portable-conformance-rc2.json \
  --out base-port.json --command /absolute/path/to/port base
python tools/run_conformance.py --corpus interop/lifecycle-f1-conformance.json \
  --out lifecycle-port.json --command /absolute/path/to/port lifecycle
python tools/run_conformance.py --corpus interop/distributed-g1-conformance.json \
  --out distributed-port.json --command /absolute/path/to/port distributed
```

`port` above is supplied by the developer; no such complete port is shipped. The command is
an explicit argv, not shell evaluation, but it is still host-authorized executable code and
must be reviewed/sandboxed externally. The corpus results are exactly compared in canonical
bytes: booleans and integers are distinct, null is not a valid response envelope, and missing,
extra or reordered outputs fail. H's mutation tests verify those oracle properties.

The 47 base + 24 LC-F1 + 28 DS-G1 cases are reference-assisted finite expectations, not 99
proofs of program equivalence. The Node checker is separately written for bytes/hashes/
signatures and trace linkage; it is not a second complete DKN runtime or simulator.

## Additional qualification beyond corpus agreement

Test independent cases, malformed input, signed/unsigned scope substitution, parser
cross-language differentials, complete false/unknown/truncated outcomes, finite budgets and
platform-specific filesystem behavior. For a new storage engine, establish transactional
behavior under its own custody/crash assumptions; cryptographic corpus agreement says nothing
about durability or isolation. For a new scheduler, preserve visibility and tie ordering and
falsify forged but internally hash-consistent transcripts by recomputation.

Create a new realization binding, exact source and binary hashes, build/toolchain/dependency
provenance, test results and reviewer records. The current AST/symbol traceability checker is
Python-specific; another toolchain needs an equivalent evidence mapping rather than fabricated
Python symbols. Reuse the semantic commitment only when the selected contract remains exact.

Acceptance is a separate decision. Neither a code generator, the reference author, nor a
passing harness automatically grants recognition, production deployment or forced upgrade.
H contains the qualification materials and runners, not an automatic realization generator,
formal refinement prover, or universal cross-language build system.
