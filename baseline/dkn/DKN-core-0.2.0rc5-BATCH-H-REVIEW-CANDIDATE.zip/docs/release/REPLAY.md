# Replaying the frozen H candidate

## Inputs and scope

Verify the expected external archive checksum obtained through an accepted channel, then
extract into a new directory. The Python wheel is not the whole dossier. Read the current
META boundary; do not mistake an inherited certificate for certification of the current tree.
Install only reviewed genuine dependencies. Python 3.12+ is declared in metadata; the actual
executed environment is recorded in the receipt, not inferred from that requirement.

A fresh installation on a target machine is a separate gate:

```sh
python -m venv .venv
.venv/bin/python -m pip install '.[test,legacy]'
.venv/bin/python -m pip check
```

Windows uses `.venv\Scripts\python.exe`. Existing environments may use their own selected
Python executable. The source checkout must be unchanged between phases. Do not run source
edits, vector generators or model-authoring tools during a replay.

## Staged review

```sh
python tools/verify_batch_h.py --out /tmp/dkn-h --phase tests
python tools/verify_batch_h.py --out /tmp/dkn-h --phase examples
python tools/verify_batch_h.py --out /tmp/dkn-h --phase audit
python tools/verify_batch_h.py --out /tmp/dkn-h --phase assemble
```

All phases run within the current invocation; no scheduled work or remote service is needed.
Add `--require-legacy` to each command to make a missing/failed genuine BLAKE3 leg gating.
A blocked legacy leg is explicitly visible in a bounded v0.2-only run. A mandatory legacy
run cannot PASS by skipping it. The inherited low-level runner remains available, but only
the H wrapper creates the new common-context stage receipts and H-REVIEW.json.

Tests and workflows must all pass; skips/errors are not promoted. The audit recomputes the
three model bindings, original acceptance references, finite native crypto checks and all
three frozen corpora. Stage receipts bind source fingerprint, environment and output hashes;
assembly refuses mismatched source/context or changed files. This is integrity within a
trusted local process, not authentication of a potentially malicious evidence author.

Target replay helpers are `tools/replay_windows_h.ps1` and `tools/replay_posix_h.sh`. They do
not install packages or send material to external services. They require an existing reviewed
environment. Windows, WSL, macOS and Linux are separate evidence contexts. Platform-specific
symlink or process tests may refuse/skip; record and investigate rather than relabeling them.

## Packaging and installed-wheel check

```sh
python tools/build_batch_h_candidate.py --out /tmp/dkn-h-rebuilt.zip
SOURCE_DATE_EPOCH=1794009600 python -m pip wheel --no-deps --no-build-isolation . -w /tmp/dkn-h-wheel
```

The source builder rejects an output inside its source tree. It emits the exact inventory
and checksum; metadata timestamps are deterministic. Wheel rebuilds require the same genuine
build toolchain. Serializing a frozen tree can be byte-identical; regenerating timestamped
logs and changing their paths does not recreate the same source-evidence archive.

Install the wheel in a distinct virtual environment and work outside the source tree with
PYTHONPATH removed. The tools `verify_installed_v02.py`, `verify_installed_f.py`, and
`verify_installed_g.py` exercise their respective installed layers. Compare installed package
files against the wheel. Dependency provenance must distinguish copied genuine host packages
from independently resolved/downloaded packages. A pure-Python wheel tag is not OS parity.

## Evidence custody

Retain raw JUnit XML, stdout/stderr, stage records, H-REVIEW.json, model/conformance/native
reports and exact candidate hashes. Post-freeze receipts stay outside the archive. A reviewer
should record their own identity, environment, tools, findings and scope, not reuse the
reference author's designation. No tool here grants independent approval.
