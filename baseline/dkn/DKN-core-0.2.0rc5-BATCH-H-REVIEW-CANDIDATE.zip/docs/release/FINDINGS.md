# Batch H findings and dispositions

## H-001 — Python equality accepted typed conformance mismatches (repaired)

`tools/run_conformance.py` compared decoded Python values. Python equates True with 1 and
False with 0, including within lists/dictionaries. A constructed replacement response changed
34 boolean fields in the base corpus into integers. The old oracle returned PASS despite
unequal canonical bytes. The pre-repair witness is retained under
`evidence/batch-h/findings/H-001-before.json`.

The oracle now compares exact canonical response bytes. Per-case diagnostics also compare
canonical values rather than Python object equality. Regression tests apply boolean/integer
substitutions in both directions to each of the three frozen corpora. The runtime protocol
and corpus expected values were not changed. This is a test-oracle defect, not a demonstrated
runtime signature forgery or authorization bypass.

## H-002 — JSON null bypassed response mismatch checking (repaired)

The same tool used None to represent failed parsing and also the successfully parsed JSON
null value. A successful child process returning `null` reached no mismatch check and could
receive PASS. `H-002-before.json` preserves the old result. A separate decoded flag now
ensures every successfully parsed response is compared to the full expected envelope.
Null, scalars, arrays, empty objects, missing/duplicate/reordered cases, authority changes,
wrong schemas/outcomes, noncanonical framing and nonzero process exits are regression-tested.

## H-003 — current security pointers contradicted later release metadata (reconciled)

The cumulative SECURITY.md contained several headings marked current and an RC2 inventory
pointer while the active candidate was G/RC4. The entire predecessor text is preserved at
`docs/history/SECURITY-RC4.md`; the new current document names only H's active inventory and
links to historical findings. Normative documents already bound by frozen semantic contracts
remain unchanged, including historical distribution references within them.

## H-004 — phase receipts lacked enforced common execution context (strengthened)

The inherited runner binds source and logs but did not require its separate phases to use the
same interpreter/dependency/platform context. H wraps those stages with start/end source
checks, exact output hashes and a common environment record. The strict final gate also
cross-checks complete JUnit leaf-suite counts, unique test identities, skipped/error results,
process statuses, workflow completeness and authority boundaries.

These checks prevent accidental mixed or partial evidence from becoming a clean H report.
They do not authenticate a malicious author controlling the runner, files and unsigned receipts.
An external reviewer still independently pins the candidate and reruns it.

## Interrupted and unavailable probes

An initial outer-tool invocation ended without a completed stage receipt; it is not counted
as a completed gate. A subsequent direct baseline run emitted 1,075 passing XML cases, but
its process exit was not captured in a completion record. Final acceptance uses the newly
completed H stages and clean-extraction replay, not that initial baseline observation.
A genuine BLAKE3 download attempt reported no matching distribution from this environment.
That is evidence of an unsuccessful local attempt, not evidence that upstream has no release.
No mock or substitute digest was used.
