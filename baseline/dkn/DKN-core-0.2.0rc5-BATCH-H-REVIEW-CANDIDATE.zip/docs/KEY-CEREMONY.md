# User and agent key ceremony

`dkn ceremony new` generates an Ed25519 key, writes an encrypted PKCS#8 private
key through exclusive creation, and writes a separate public passport. The
passphrase is read interactively twice and never accepted as a command-line
argument or written to output.

```powershell
$env:PYTHONPATH = "src"
py -3.12 -m dkn_core ceremony new `
  --role USER `
  --private-out C:\protected\dkn-user.pk8 `
  --passport-out .\dkn-user-passport.json `
  --semantic-namespace example.identity `
  --purpose identity --nonce example.identity.v0.1 --epoch-code e0001
```

The private output must not use `.json` or `.zip`, and neither output may exist.
If public-passport writing fails after private-key custody is created, the
implementation preserves the private file rather than deleting or replaying an
uncertain ceremony. Operators should inspect custody and rerun with new paths.

Hardware keys and external custody providers can create the public passport
directly and supply signing operations without exporting private material.

