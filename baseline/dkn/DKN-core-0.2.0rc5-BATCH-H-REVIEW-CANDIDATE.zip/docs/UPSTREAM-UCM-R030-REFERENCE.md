# Qualified UCM r030 read-only reference boundary

DKN Core r002 pins qualified UCM v0.1 r030 only as an external compatibility
reference. It neither copies UCM authority nor makes DKN a UCM subsystem.

## Exact upstream identity

| Commitment | Value |
|---|---|
| Source root | `7ada98546cbd1330eeaca3f01125a3e428d047a427fc5cd34ba395acf52b5e07` |
| Qualification root | `25436291af27ecfadfc4c8babb2b8ba4adc348851a87d3751e4f8f0c8e8c259e` |
| Qualification result | 448/448 PASS, zero failures, zero skips |
| Release root | `e6f85b37af9eb207ac014e67051a8a3019517ea588f6c9964282cc1538a1d4ac` |
| Runtime SHA-256 | `a57749706aa83bc3df828292929ebfc1c42b72969052289e1e1ff6abd3dfabe9` |
| Review transport SHA-256 | `9d28412594bd15fb0e0d8889590f876d23de089b78319840313cebece4a9aae1` |
| Constitutional atlas root | `6a69f185c5b623add63feab776c879845342f482658cc633fc6fc24767c585a7` |
| Pipeline model root | `99d309fc7305313e42c47bb83f55f624c3126a2163aa3c6d2b0045da1d52b01e` |

The machine-readable pin is `acceptance/UCM-R030-REFERENCE.json`.

## Relevant surface hashes

- `release_certification.py`: `747b2f38df23365024947a6b13af07dd6fc631d59bac9af7ec41170cf451549c`
- `pippi_constitution.py`: `0e6bbbe97f284eb519f7d9e3a82189c366cc82c599921a241c8832b88652e0bd`
- `identity.py`: `d1e5a9f32218138f2c26277ce1c8cea3ba7daeaaef09cb8b682fdecbc77e0816`

The supplied surface name `pippi_identity.py` does not exist in the qualified
r030 source tree; the public MosaicID/passport implementation remains
`src/ucm/identity.py`.

## r030 delta relevant to DKN

Compared with r029:

- `identity.py` is byte-unchanged;
- `release_certification.py` is byte-unchanged;
- publication signing now calls a complete storage-locator validator, including
  credential-marker checks;
- a public retrieval-receipt validator binds the receipt back to the exact
  signed publication receipt;
- local credential envelopes are fully validated before any parent directory,
  pending file, or target is created.

DKN r001 already revalidated locators and required the originating publication
receipt plus actual retrieved bytes. R002 records those verified correspondences
and preserves its stronger actual-byte check. Its encrypted key ceremony creates
the envelope itself and completes passphrase/path validation and encryption
before the first filesystem write.

## Explicit non-inheritance

The UCM roots above prove only which source was inspected. DKN imports none of
UCM's AMCAS admission, CCP decision, Courthouse jurisdiction, Operational
Gateway authority, or G1/G2/G3 effect custody. `INFORMATION_ONLY` and authority
effect `NONE` remain unchanged.

