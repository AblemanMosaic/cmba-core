# TransactionalVault — local format 1

This is an OPTIONAL replacement for the directory index's storage discipline. `LocalIndex`
remains unchanged. The vault reuses its verified discovery and traversal algorithms over
an isolated SQLite snapshot; it does not replace cryptographic verification with SQL trust.

## Storage and operations

One SQLite database holds complete artifact bytes plus canonical evidence in the same row,
full public lifecycle journals, and a monotonically increasing local revision. Application ID
is 0x444B4E46; user_version is 1. Table definitions are fixed; unknown schema versions,
extra tables/views/triggers, malformed meta rows and non-DELETE journal modes refuse.

Creation is explicit and exclusive, with mode 0600 on POSIX. Open uses mode=rw, never implicit
create. Mutations use BEGIN IMMEDIATE, synchronous=FULL and rollback journal mode DELETE.
Readers use a read transaction and query_only; the revision and rows come from one committed
snapshot before expensive verification. SQLite may recover a hot journal during access: a
read API does not imply zero disk writes by the storage engine, but it does not advance
application recognition, pins or permission state.

`put_artifact` verifies before insertion. Identical bytes AND evidence are idempotent. A
conflicting envelope under the same logical root refuses rather than overwriting evidence.
Artifact insertion and revision increment commit or roll back together. A failed commit or
busy writer is a typed refusal, not a fabricated success. A lost acknowledgement after a
successful commit may be retried with identical material. Namespace pins use a separate API;
there is no combined artifact-plus-namespace transaction or network atomicity claim.

`resolve_exact`, `discover`, `traverse` return a NEW wrapper schema with `snapshot_revision`,
`snapshot_scope` and nested `result`. They are not silent drop-in old-schema replacements.
Each result rechecks stored bytes, transport/root, signature, relation and namespace evidence.
Enumeration damage is not reported as an empty collection. Every returned JSON report is
canonical-budget bounded. `read_artifact` returns checked raw bytes and its public envelope.

`advance_namespace` is an explicit caller decision to remember one valid lifecycle branch.
First insert requires expected_head=None. Subsequent writes require the exact stored head
(compare-and-swap) AND its exact ancestry in the new chain. Greater sequence on a different
branch refuses. Equal head is idempotent. The journal and local revision move atomically.
Concurrent attempts from one predecessor have at most one accepted successor in this local
vault. This local serialization neither elects a global winner nor invalidates another
cryptographically valid branch. `read_namespace` replays stored evidence rather than trusting
a cached assessment. It does not infer authority from the existence of a pin.

## Migration and failure behavior

`import_local_index` explicitly imports a quiescent old directory index into an empty artifact
table in one transaction. It rejects orphan/missing payloads, unrecognized entries, malformed
metadata and detected source changes. The source is not modified. No SQL version migration
exists because this is the first vault format; future versions must have explicit migration
contracts. Opening never rewrites an unsupported version. A failed initial creation may
leave an incomplete owned file; open refuses it. Inspect/remove it explicitly, not automatically.

The migration is bounded to 256 artifacts and does two exact reads to detect observed change.
This is NOT an atomic snapshot of an actively or maliciously changing source directory.
Cooperating sources must stop writing during migration.

## Limits and trust assumptions

Up to 4,096 artifact rows, 1,024 namespace rows, 512 MiB aggregate artifact+envelope bytes,
512 MiB aggregate namespace bundle bytes, 1 GiB admitted database/sidecar file size. Per artifact
and metadata limits remain those of the base protocol. A full scan has the base 512 MiB bound.
SQL step/progress, statement length, attachment count and lock-wait limits are finite; these
are not a universal CPU deadline or a hard process-memory sandbox. Large eligible objects
may occupy more than their stored size while verified. Choose external process budgets.

Observed static symlinks, hardlinks, nonregular DB/sidecar files and POSIX non-owner or
other-writable database files refuse. The containing hierarchy must remain trusted during
operation. These checks do not prove race-free inode custody against hostile local writers.
OS/root compromise, broken disk flushing/locking, malicious SQLite engine behavior, NFS,
cloud-sync contention and simultaneous database replacement remain outside the tested profile.
The library does not encrypt the database. Use an appropriate encrypted filesystem when needed.

A whole-database restore can roll back its internally stored revision AND pin together.
This cannot be detected from that database alone; retain an independently protected external
floor when rollback resistance across backup/restore is required. No monotonic hardware
counter, external witness or anti-rollback device is implemented here.

Tests exercise actual local files, competing connections, rollback on injected exceptions,
process exit before commit (including a 3 MiB cache-spill case), persistence after commit and
CAS conflicts. They do not simulate power removal or prove all filesystem durability behavior.
