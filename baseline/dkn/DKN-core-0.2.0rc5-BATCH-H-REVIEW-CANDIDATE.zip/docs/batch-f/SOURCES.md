# External design references — not execution evidence

Consulted 2026-11-07. These references inform threat modeling and the storage mechanism;
they do not certify DKN or establish that its implementation meets their guarantees.

1. SQLite, *Isolation In SQLite*, https://sqlite.org/isolation.html . Distinct connections,
   serialized writes and read-snapshot behavior informed the BEGIN IMMEDIATE/read-transaction
   design. DKN exercises a local cooperative subset; not cross-host storage.
2. SQLite, *Atomic Commit In SQLite*, https://sqlite.org/atomiccommit.html . Rollback journaling,
   hardware/OS assumptions and failure modes inform the vault's bounded claim. Process-exit
   tests are not power-cut tests, and cannot establish all platform assumptions.
3. SQLite, *Transaction*, https://www.sqlite.org/lang_transaction.html . Busy/transaction
   behavior informs typed refusal and compare-and-swap boundaries.
4. The Update Framework Specification 1.0.37 (page dated 8 October 2026),
   https://theupdateframework.github.io/specification/latest/ . Threshold identity, explicit
   version continuity and freeze/rollback threats are comparison context. LC-F1 is NOT a TUF
   implementation or compatibility claim. Its immutable recovery policy, direct exact-artifact
   delegation and reader-pinned journal are this project's distinct bounded design.

The uploaded RC2 repository is the engineering baseline. External references do not fill
missing execution evidence or substitute for its frozen manifests and test records.
