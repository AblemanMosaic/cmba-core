# Batch F — protocol and security closure, bounded candidate

Distribution: **0.2.0rc3**. Base protocol: unchanged **v0.2-candidate**.
Opt-in namespace lifecycle extension: **LC-F1** (`dkn.lifecycle.v0.2-f1`).
New local vault: SQLite format **1**, not an HTTP/P2P/federation service.

This batch implements a finite offline lifecycle and transactional reference vault. It does
not claim the original fifty obligations or the planned F–H program are all complete.
Public release, independent approval and production-deployment acceptance remain separate.

## Documentation

- `LIFECYCLE-PROTOCOL.md`: normative byte commitments, seven actions, checkpoint/pin semantics.
- `VAULT-CONTRACT.md`: atomicity, snapshots, CAS, migration and custody/failure boundaries.
- `DEVELOPER-GUIDE.md`: actual Python API, separately held key endorsements, CLI and examples.
- `SECURITY-AND-REVIEW.md`: threats, construction findings, failure cases, residual risk.
- `ACCEPTANCE.md`: exact relationship to the original fifty obligations and new test references.
- `REPLAY-AND-HANDOFF.md`: source/wheel replay and Batch G/H boundaries.
- `SOURCES.md`: external design references, distinguished from this implementation's evidence.

Machine-readable contract: `model/lifecycle-f1/CONTRACT.json`. Its typed commitment and
realization binding are separate. The original `model/v02/SEMANTIC-CONTRACT.json` and semantic
commitment remain byte-identical to RC2. The base realization binding is renewed for the
new distribution metadata/runner; the F extension has its own contract, source references
and test traceability. Neither checker proves program equivalence.

The existing `LocalIndex` remains a single-writer directory index. Applications deliberately
select `TransactionalVault`; there is no silent on-open database migration or new permission
granted by installing the package. Existing namespace transition records are not LC-F1 events.

All source archives, checksums and receipts are unsigned engineering artifacts. Checksums
are meaningful relative to a trusted expected value, not self-authentication of a publisher.

## Model and realization separation

`model/v02/SEMANTIC-CONTRACT.json` and its commitment retain the RC2 bytes. Its realization
binding is refreshed for changed build/test metadata. The optional F extension has its own
`model/lifecycle-f1/CONTRACT.json`, `COMMITMENT.json` and `REALIZATION-BINDING.json`, with
twelve finite obligations. Both checkers verify reference/test traceability, not program
equivalence. The explicit `build_lifecycle_contract.py` authoring tool regenerates bindings;
verification never calls it. Readers must independently pin accepted semantic commitments.
The machine-readable refusal catalogue inventories source tokens, not every runtime failure.
