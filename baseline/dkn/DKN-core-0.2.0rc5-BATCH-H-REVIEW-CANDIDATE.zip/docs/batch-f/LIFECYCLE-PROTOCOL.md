# LC-F1 — normative bounded offline namespace lifecycle

Status: experimental extension, not a ratified replacement for v0.1 or the RC2 wire profile.
Implementations use the existing strict DKN candidate canonical JSON and admitted Ed25519
public-key/signature profile. See `docs/v02/PROTOCOL.md`; this is not generic JCS/JSON.

## 1. Domains and anchoring

All new hash/signature messages begin with ASCII `DKN_LC_F1` followed by a zero byte.
Then append the ASCII purpose, another zero byte and canonical JSON bytes. SHA-256 yields a
lowercase 64-character hexadecimal digest. Ed25519 signs these exact bytes, not the digest.
Purposes are `policy`, `anchor`, `event`, `event-signature`, `checkpoint`, and `instance`.
Hashes use policy/anchor/event/instance; signatures use event-signature/checkpoint.

A policy has exactly `schema`, `recovery_keys`, `recovery_threshold`, `allowed_operations`,
`max_grant_seconds`. Schema is `dkn.lifecycle-policy.v0.2-f1`. Public keys and operation
names are strictly increasing sorted unique arrays. There may be zero to 16 recovery keys;
threshold is zero exactly when the array is empty, otherwise 1 through its length. Operations
are 1–16 DKN tokens. Maximum grant lifetime is 1–31,622,400 seconds. Booleans are not integers.
The policy reference is `dkn:lc-f1:sha256:` plus its policy-domain digest.

Before namespace creation, the founder chooses this policy. The existing genesis's
`recovery_policy_ref` MUST equal this exact reference. The founder MUST NOT also be a recovery
key. An unbound prior genesis cannot gain a recovery policy after key loss. LC-F1 does not
mutate an existing genesis or import/reinterpret an RC2 transition chain.

The anchor hashes `{schema: "dkn.lifecycle.v0.2-f1", namespace_root, policy_ref}` in the
anchor domain. Initial sequence/epoch are zero; the controller is the genesis founder and
the namespace is not suspended. An empty journal has the anchor as its head. The namespace
root remains the original genesis root throughout valid lifecycle transitions.

The epoch instance reference hashes `{namespace_root, policy_ref, epoch, epoch_start_ref,
active_key}` in the instance domain. `epoch_start_ref` is the anchor initially, then the
rotate/recover event reference. Grants, revocations, suspension and resumption change the
journal head but not the epoch instance. This is not a reinterpretation of a v0.1 instance ID.

## 2. Event envelope and ordering

An event has exactly `body`, `event_ref`, `signatures`. The body has exactly `schema`,
`namespace_root`, `policy_ref`, `sequence`, `previous_ref`, `issued_at`, `kind`, `payload`.
Schema is `dkn.lifecycle-event.v0.2-f1`. Sequence advances by EXACTLY one from genesis.
Predecessor reference equals the preceding event's event-domain digest, or the initial anchor.
Namespace and policy match genesis. Issued times are nondecreasing, nonnegative signed-64-bit
Unix seconds. These times are issuer declarations, NOT proof of real event time.

`event_ref` hashes the body in the event domain; it excludes the signatures. Different
sufficient proof collections for the identical body identify the same event. Signatures
are a sorted unique list of `{public_key_hex, signature_hex}` over the event-signature
message. Unknown fields/kinds, duplicates, inadmissible keys, invalid signatures and unrelated
signers refuse. There are at most 256 events per complete supplied journal and 18 proofs per
event. No checkpoint compaction or unlimited-history protocol is implemented.

## 3. Seven actions

| Kind | Required signers | Payload and exact effect |
|---|---|---|
| `delegate` | Current controller | Exact subject public key, exact artifact root, sorted operations subset, `not_before`, `expires_at`. No wildcard, namespace-wide or transitive grant. |
| `revoke_grant` | Current controller | `grant_ref` names an existing not-already-revoked grant in this journal; invalidates it prospectively in the supplied view. |
| `revoke_key` | Current controller | `public_key_hex`; permanently excludes that delegate/future controller in this branch. Cannot revoke current controller or immutable guardians this way. |
| `rotate` | Current controller AND successor | `successor_public_key_hex`; proves both retirement authorization and successor possession; increments epoch and invalidates ALL prior grants. |
| `recover` | Precommitted guardian threshold AND successor | Same successor field. Does not require the lost controller. Increments epoch, invalidates ALL prior grants, and leaves the namespace unsuspended. |
| `suspend` | Current controller | Nonempty `reason` up to 256 characters; enters suspended state and invalidates every existing grant. |
| `resume` | Current controller | Same reason shape; leaves suspended state, without reviving any old grant. |

For delegation, issued_at <= not_before < expires_at, and expires_at - issued_at must not
exceed policy.max_grant_seconds. A grant subject cannot be a used controller, a revoked key
or a guardian. No grant is created while suspended. Rotate/recover successors must be new
controller keys, unrevoked and outside the guardian set. Rotation during suspension preserves
suspension; recovery explicitly clears it. Repeated suspend/resume in the wrong state refuse.
Guardians cannot be rotated in this profile: a future policy-change protocol needs separate
specification and evidence. A delegate never becomes a lifecycle event author by delegation.

## 4. Separately held signing keys

`prepare_event` constructs an unsigned context-bound proposal. `endorse_event` independently
rechecks the supplied genesis/policy/journal/proposal and returns ONE public endorsement using
ONE locally held private key. `assemble_event` takes only public endorsements, sorts without
deduplication and verifies the whole extended journal. Duplicate signatures never increase a
threshold. Every guardian and the successor may run on a different machine; no key aggregation
is required. This batch tests separate calls, not live independent custodian ceremonies.
`make_event` is a convenience for keys already legitimately held together, especially fixtures.
An operator must separately recognize the intended proposal before authorizing its signature.

## 5. Checkpoints, reader pins, and assessment

A checkpoint has schema `dkn.lifecycle-checkpoint.v0.2-f1`, exact namespace/policy/head/sequence,
issued_at, expires_at, signer_public_key_hex and signature_hex. The controller of the supplied
journal signs it in the checkpoint domain. The reader requires journal.last_time <= issued_at
<= now < expires_at, and now-issued_at <= reader.max_checkpoint_age. The reader supplies the
clock, maximum age, recognized namespace and chosen head; these are not inferred from the
untrusted bundle. Reader bounds do not require a historical signature to change.

Assessment replays ALL supplied events, verifies exact `expected_namespace` and `expected_head`,
and optionally checks an exact ancestral floor `{sequence, head_ref}`. A longer different
branch does not satisfy that floor. Future-declared events refuse. Missing checkpoint returns
INDETERMINATE; invalid/mismatching/expired checkpoints refuse. A matching scope and current
controller/delegate yield MATCH_FOR_SUPPLIED_VIEW. Suspended, revoked, wrong-scope or expired
grants yield NO_MATCH. Validity interval is half-open: not_before <= now < expires_at.

Public-key scope matching does not prove the requester possesses the key. `assess_certificate`
verifies an actual certificate and fixes the operation to `certify_artifact`; its subject and
artifact cannot be caller-overridden. `inspect_with_lifecycle` also verifies actual payload
bytes. Neither function automatically installs, executes, publishes or grants a capability.
All results retain `authority_effect=NONE`, `acceptance=EXTERNAL_DECISION_REQUIRED`, and
`global_currentness=NOT_ESTABLISHED`. Revocation is SUPPLIED_PINNED_VIEW_ONLY.

A malicious or isolated controller may withhold newer events or equivocate. A reader still
using an old pin and an eligible old checkpoint may match old evidence. This is an explicit
residual boundary, demonstrated by a test, NOT a global freshness or revocation guarantee.
Old signatures remain mathematically valid; their present eligibility is a different question.

## 6. Forks and non-goals

`analyze_journals` accepts 1–32 complete chains, at most 512 supplied events total, verifies each,
and reports distinct successors of a shared predecessor. It selects no winning head. A
recovery/rotation conflict remains a visible conflict; signature thresholds are not consensus.
Guardian key distinctness does not prove organizational independence or non-collusion.

No live revocation fetch, trusted clock, global ordering, automatic recovery trigger, guardian
policy amendment, unlimited grant graph, secret store, OS capability broker or production
network is supplied. These omissions must survive replacement realization and UI integration.
