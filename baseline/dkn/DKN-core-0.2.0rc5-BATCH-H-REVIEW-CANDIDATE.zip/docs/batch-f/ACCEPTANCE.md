# Batch F acceptance reconciliation

The original fifty obligations remain the ledger; tests are evidence for named finite
claims, not permission to convert unspecified behavior into guarantees. Three previously
partial/deferred rows now have **scoped LC-F1 passes**. Revocation freshness stays partial.
All dependency, independent-review and target-platform gaps remain visible.

| Disposition | Obligations |
|---|---:|
| BLOCKED_DEPENDENCY | 3 |
| DEFERRED | 1 |
| NOT_PERFORMED | 2 |
| NOT_RUN | 1 |
| PARTIAL | 8 |
| PASS_SCOPED | 35 |

## Changed obligations

### A-NAME-01 — root vs instance

PARTIAL → **PASS_SCOPED**. LC-F1 stable genesis plus distinct epoch instance; legacy v0.1 instances and base transition bytes unchanged. No universal namespace-instance translation.

Tests: `test_batch_f_interfaces::test_epoch_instance_stable_within_epoch_changes_on_rotation`

### A-NAME-05 — unauthorized delegation

DEFERRED_WITH_BOUNDARY → **PASS_SCOPED**. LC-F1 direct exact-artifact/operation grants; unauthorized signers and subdelegation refuse. Match is relative to reader-pinned evidence and grants no application capability.

Tests: `test_batch_f_lifecycle::test_no_subdelegation`, `test_batch_f_lifecycle::test_scope_does_not_widen`, `test_batch_f_lifecycle::test_actor_identity_does_not_become_authority`

### A-NAME-06 — lost key recovery

DEFERRED → **PASS_SCOPED**. LC-F1 precommitted guardian threshold plus successor possession tested with fixtures and detached endorsements. Not live custodians, retrospective takeover, or guardian-policy amendment.

Tests: `test_batch_f_lifecycle::test_threshold_recovery_without_old_controller`, `test_batch_f_lifecycle::test_no_retroactive_policy_or_recovery`, `test_batch_f_lifecycle::test_separate_custodian_endorsements_need_no_private_key_aggregation`

### A-NAME-07 — revocation freshness

PARTIAL → **PARTIAL**. LC-F1 signed grant/key revocation and invalidation checked in an exact reader-pinned journal with checkpoint-age and ancestor floor. No live revocation fetch or global currentness.

Tests: `test_batch_f_lifecycle::test_revoke_and_omission_require_pinned_head`, `test_batch_f_lifecycle::test_prefix_floor_blocks_longer_alternate_fork`, `test_batch_f_lifecycle::test_bad_checkpoints`

## Extension evidence beyond the original ledger

The extension model maps finite invariants to implementation and actual test references.
Vault cases exercise atomic writes, concurrent cooperative writers, reader snapshots,
process termination before commit (small and cache-spilling writes), recovery after
reopen, exact namespace CAS/ancestry and all-or-nothing import. They do not establish
hostile-host custody, all filesystem durability behavior, physical power-failure safety,
or a deployed multi-region service. Dependency installation attempts are retained.

The original 47-case behavioral corpus remains unchanged. The 24-case LC-F1 corpus is
additional reference-assisted evidence, not a complete second implementation. The Node
checker cross-checks new domains and action signatures only. Model-checker passes mean
hash/symbol/executed-test traceability, not full program equivalence.
