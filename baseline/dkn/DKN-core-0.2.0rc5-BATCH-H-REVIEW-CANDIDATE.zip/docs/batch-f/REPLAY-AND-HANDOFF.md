# Replay and next gates

Baseline source SHA-256:
`29e8151167c9aedbc62d11ed4f104298f508e65d2a210488feac41e444d534f8`.
Current inventory: `BATCH-F-FILE-MANIFEST.json`. Current external transport checksum binds
this ZIP; older RC2/E/D/r002 manifests and receipts are historical only.

## Local replay

Python >=3.12 declared; the actual tested environment is recorded separately. Node is required
for primitive cross-language tests. Missing prerequisites or skipped cases do not clear the gate.

```sh
python -m pip install '.[test]'
export PYTHONPATH="src:."
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
python tools/verify_v02_candidate.py --out /tmp/dkn-f-run
python tools/check_semantic_contract.py --report /tmp/dkn-f-run/LOCAL-RUN.json
python tools/check_lifecycle_contract.py --report /tmp/dkn-f-run/LOCAL-RUN.json
python tools/audit_acceptance.py --report /tmp/dkn-f-run/LOCAL-RUN.json
python tools/run_conformance.py --out /tmp/base-conformance.json
python tools/run_conformance.py --corpus interop/lifecycle-f1-conformance.json \
  --out /tmp/lc-conformance.json --command python tools/reference_lifecycle_conformance.py
python tools/check_native_crypto.py --out /tmp/native-crypto.json
python tools/build_batch_f_candidate.py --out /tmp/dkn-f.zip
SOURCE_DATE_EPOCH=1794009600 python -m pip wheel --no-deps --no-build-isolation . -w /tmp/dkn-f-wheel
```

`--phase tests`, `--phase examples`, `--phase assemble` on the runner allow staged runs against
one unchanged fingerprint. --require-legacy additionally gates the genuine-BLAKE3 r002 suite.
Do not substitute a different digest algorithm or a mock to make that gate pass.

Windows PowerShell: set `$env:PYTHONPATH="src;."`, install the same declared dependencies and
use the same Python tools. Run native Windows, WSL and Linux as distinct contexts. POSIX
permission/symlink and actual crash-recovery expectations require platform-specific evidence.
Cross-platform support is not established by a wheel's `py3-none-any` filename.

Reproducibility means serializing/rebuilding the SAME frozen source/evidence tree. New execution
logs include paths/timing and are not promised to recreate an identical research dossier.
Fresh-extraction replay evidence remains outside the candidate to avoid self-hash cycles.

## Batch G

Model the already implemented lifecycle and vault in deterministic network/failure scenarios:
withheld or conflicting checkpoints, corporate common-control assumptions, partitions, stale
pins, guardian collusion, divergent recovery branches, and external-floor preservation. Reuse
LC-F1 and the base SAM; do not invent a new overlapping authority engine. No real availability,
Byzantine consensus, universal currentness or institutionally recognized authority follows
from simulated success.

## Batch H and external review

Consolidate F/G evidence and claims, replay on target machines with genuine legacy dependencies,
check a full alternative realization where available, then freeze one external-review candidate.
Independent security review and live deployment validation remain separate gates. No automatic
external submission/publication is authorized by this handoff.

## Installed-wheel evidence

The local installed-wheel probe uses an isolated venv outside the source tree. Dependencies
are exact copies of genuine host distributions, with source and destination hash checks.
A nested system-site venv initially failed to expose jsonschema; that failed attempt is
retained. Successful final imports do not establish network dependency resolution. The wheel
contains library and CLI code, not the complete semantic-model/test/review dossier.
