# Batch F threat model and construction review

## New trust inputs

Recognized genesis and policy, chosen head/ancestral floor, caller clock, admissible operation
semantics, guardian custody and local DB/filesystem administration. None is inferred from a
profile label, public key, quorum count, successful command or a supplied report.

## Tested negative boundaries

- Delegates cannot create lifecycle events or widen a grant to another artifact/operation.
- Recovery requires a precommitted policy, unique threshold keys, and successor possession.
- Controller/guardian roles are disjoint; used controllers and explicitly revoked keys
  cannot be revived as successor/delegate keys in the same branch.
- Changed policy, predecessor, namespace, sequence, event body, signature or proof proposal
  refuses. Two valid branches remain two branches, not a selected winner.
- Grants expire at their exclusive upper boundary. Suspension, rotation and recovery invalidate
  old grants without later resumption reviving them.
- Exact namespace/head pins and paired sequence/head floors prevent supplied-history rollback
  and substitution of a longer alternate branch. They cannot reveal withheld remote history.
- Schema/byte limits, malformed inputs and unknown extensions refuse rather than granting.
- SQLite writes/revision and namespace-pin updates are transactional; conflict or busy state
  refuses. Damaged rows, schemas and static filesystem aliases do not become verified data.
- Import is source-preserving and atomic at the destination. Partial/orphan inputs refuse.

## Construction findings and resolutions

F-R01: An early test helper created a checkpoint before honoring an explicit no-checkpoint
input. The future-event case hit CHECKPOINT_TIME rather than its intended FUTURE_EVENT path.
Corrected the helper; no protocol check was weakened. Initial failure output is retained.

F-R02: A first schema allowlist sketch used SQL LIKE 'sqlite_%', where '_' is a wildcard.
Replaced it before release with exact implicit-autoindex names and exact table definitions;
a sqliteXhidden-table regression now refuses. This was a construction review correction,
not evidence of a defect in the inherited RC2 code.

F-R03: Namespace-update aggregate-byte bounds and final namespace-report serialization needed
explicit checks, not just insert bounds. Both are implemented. Limits remain finite budgets,
not a proof of total process-memory or wall-clock confinement.

F-R04: Recovery must not require centralized private-key custody. Added unsigned proposals,
one-key public endorsements and public-only assembly with duplicate/threshold/replay checks.
These are tested calls, not a performed external custodian ceremony.

F-R05: LC-F1 must not silently change RC2 namespaces, reports or transition interpretation.
The extension has a pre-genesis policy anchor, separate domains/schemas/ABI and its own semantic
commitment. The SQLite vault is separately selected. All inherited runtime source files remain
byte-identical. Only the inherited package-metadata test is adjusted for version/entrypoints.

F-R06: The first isolated-install rehearsal used a nested venv with system-site packages,
but the parent venv's jsonschema was not exposed. The import failed rather than passing.
Recreated an isolated venv, copied exact genuine host dependency files with hash receipts,
reinstalled the wheel and reran outside the source tree. Fresh network dependency resolution
remains NOT_ESTABLISHED; the environment repair is not a cryptographic code fix.

## Intentionally open

Recovery-policy amendments, delegated delegation, global freshness, automatic fork selection,
external authority approval, actor independence, key generation/storage ceremonies, private
payload scrubbing, hardware rollback protection, live network backends, formal semantic
refinement and a full second-language protocol realization are not established.

A signer who retains a valid key may create an old-view checkpoint or fork. A backup restore
may roll back a database and its internal floor. Separate protected recognition/freshness
infrastructure is necessary when these threats are in scope. G will model such environments;
a simulation must not be promoted to deployed assurance.

Library workflows and tests do not publish or contact a live federation. No external
courthouse submission or authority promotion occurs. Dependency-download attempts and public
technical-documentation lookup are separate engineering activities, not artifact publication.
Tests use public deterministic fixture keys or ephemeral local keys. Receipts are unsigned
self-generated evidence, not independent review.
