# Developer integration — the opt-in Batch F layer

Install the supplied 0.2.0rc3 wheel or `pip install .`. Base imports remain `dkn_v02` and
legacy `dkn_core`; new modules are `dkn_v02.lifecycle`, `dkn_v02.vault`,
`dkn_v02.lifecycle_abi`, and `dkn_v02.lifecycle_schemas`. SQLite comes from Python's standard
library. No new runtime third-party dependency is introduced.

Run `python examples/v02_lifecycle_vault.py` for a fully executable temporary-key workflow:
create a precommitted policy/genesis, delegate an exact artifact certificate, store it,
pin a journal, inspect it, revoke the grant, observe refusal to match, recover with two
of three guardians plus successor possession, and retain the same namespace root.

## Library surface

| Operation | Purpose |
|---|---|
| `lifecycle_policy(...)`, `policy_reference(policy)` | Construct a strict policy and its pre-genesis reference. |
| `lifecycle_anchor(genesis, policy)` | Validate genesis-policy binding and derive initial journal anchor. |
| `prepare_event(...)` | Build a context-bound unsigned proposal. |
| `endorse_event(genesis,policy,events,proposal,key)` | One participant signs with one locally held key after context checks. |
| `assemble_event(...,signatures)` | Verify public proof aggregation, threshold, possession, and full journal. |
| `make_event(...)` | Convenience when signers are already held in one legitimate process. |
| `verify_journal(...)` | Replay supplied finite history; obtain root, epoch instance, head and scoped state. |
| `make_checkpoint(...)` | Controller signs head/sequence/time interval. |
| `assess_delegation(...)` | Evaluate exact artifact/operation/subject under reader pins, floor, clock and checkpoint. |
| `assess_certificate(...)` | Bind certificate signature to fixed certify_artifact delegation assessment. |
| `inspect_with_lifecycle(...)` | Include actual payload verification. |
| `analyze_journals(...)` | Preserve supplied fork evidence without winner selection. |
| `TransactionalVault.create(path)` | Explicit create-only owned local database. |
| `put_artifact`, `read_artifact`, `resolve_exact`, `discover`, `traverse` | Store and reverify artifact evidence on committed local snapshots. |
| `advance_namespace`, `read_namespace` | Explicit monotone local pin, compare-and-swap and ancestry check. |
| `import_local_index(path)` | Non-destructive, all-or-nothing quiescent directory migration. |

For a detached recovery ceremony, all participants receive the SAME public genesis, policy,
predecessor journal and proposal. Each calls endorse_event with only their own private key.
The collector needs public endorsements only. An artifact or UI MUST NOT reinterpret a
signature request as proof that the human operator recognized the correct namespace.

## Reader ownership of decisions

Supply expected_namespace and expected_head from accepted configuration/pins, not from an
untrusted bundle's self-description. Protect the local vault and any external ancestry floor.
Supply a trusted-enough clock for the application's age policy. Pin the intended protocol
profile; an old RC2 transition chain and a new LC-F1 journal are separate evidence languages.

Read operations do not update pins. `advance_namespace` is explicit caller-selected local
recognition state, not external publication or a capability grant. It requires continuity to
the previously selected head. To compare forks, use analyze_journals before an external
resolution decision; this API will not overwrite the current pin with a conflicting branch.

The ordinary navigation inspection may still say namespace_authorization=NOT_ESTABLISHED
for a delegated/recovered signer: its existing checker knows only RC2 transition evidence.
Use inspect_with_lifecycle for LC-F1. Do not replace an old report's status with a broad PASS.

## JSON ABI / CLI

`dispatch` accepts exactly `{schema, operation, arguments}` with schema
`dkn.lifecycle-request.v0.2-f1`. Operations: verify-policy, verify-journal, analyze-journals,
assess-delegation, assess-certificate. JSON argument sets are closed. Assessment requests
include minimum explicitly (null when absent). There are no signing, filesystem-writing,
URL-fetching, evaluation-of-code, or plugin operations in this ABI.

```
dkn-lifecycle canonical-request.json
# or
python -m dkn_v02.lifecycle_cli - < canonical-request.json
```

Successful computation exits 0 even for NO_MATCH or INDETERMINATE. A malformed/invalid request
or cryptographic failure exits 2 with a typed refusal. Process success is not acceptance.
The 17 exported schemas describe shape. Runtime cryptographic checks, ordering, threshold,
ancestry, validity intervals and state transitions remain independently necessary.

## Replacement realizations

Retain the base semantic commitment. Separately pin `model/lifecycle-f1/COMMITMENT.json`,
protocol/vault contracts, schemas and the frozen LC-F1 corpus. A replacement must preserve
signature message bytes, state transitions, refusals, external-decision boundaries and
finite budgets. It may replace SQLite with a different mechanism only if its own evidence
establishes the promised atomicity/isolation/durability under explicitly stated assumptions.
Passing the cryptographic corpus alone does not establish storage equivalence.

```
python tools/run_conformance.py --corpus interop/lifecycle-f1-conformance.json \
  --out /tmp/lc-conformance.json --command python tools/reference_lifecycle_conformance.py
```

Replace the explicit command with a reviewed local replacement executable. The harness does
not sandbox it. Corpus expectations are reference-assisted, not an independent equivalence
proof. Supply additional independently authored cases and platform-specific storage tests.
