# Threat model

## Protected properties

- exact key-to-identity and key-to-namespace binding;
- unambiguous cross-language bytes;
- separation of state, meaning, and governance commitments;
- signer provenance for lifecycle and custody statements;
- public-only portable artifacts;
- replay-resistant domain and epoch separation at the protocol layer.

## Required threats and controls

| Threat | Control | Residual boundary |
|---|---|---|
| Key substitution | Derive subject/MosaicID from the exact verified Ed25519 key; embed the passport in signed records; require body identity equality. | Trust or admission of that identity belongs to the consumer. |
| Namespace laundering | Commit exact semantic name, exact/wildcard kind, key, purpose, nonce, epoch, algorithms, and version in one canonical body. | A wildcard statement grants no namespace ownership or delegation. |
| Replay across domains or epochs | Domain prefix plus committed `purpose`, `nonce`, and `epoch_code`; signed lifecycle records also commit epoch. | Consumers must enforce local freshness and accepted epoch transitions. |
| Ambiguous canonicalization | Strict UTF-8 canonical JSON; duplicate-key/float/BOM refusal; ASCII namespace grammar; no raw concatenation. | Implementations must run golden vectors. |
| Unsigned metadata change | THR governance hash and signed record envelopes cover exact metadata fields; archives have closed manifests. | Presentation outside committed fields is not authenticated. |
| Credential leakage | Portable archives reject private-key/credential filenames and PEM private-key blocks; locators reject credential markers; ceremony encrypts private custody separately. | Local endpoints must still protect key files and passphrases. |

Additional threats include malicious ZIP paths, case aliases on insensitive
filesystems, low-order Ed25519 points, artifact byte mutation after publication,
identity assertions not derived from keys, record-type confusion, algorithm
downgrade, and archive self-hash circularity.

## Out of scope

DKN does not provide endpoint security, malware detection, key recovery,
hardware attestation, global uniqueness governance, federation admission,
execution authorization, network transport security, or independent review.

