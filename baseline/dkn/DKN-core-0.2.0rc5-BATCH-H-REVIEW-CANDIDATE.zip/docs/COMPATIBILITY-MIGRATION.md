# Compatibility and migration

## MosaicID

Existing MosaicID is preserved exactly as BLAKE3 over the raw 32-byte Ed25519
public key. Import requires both the declared MosaicID and public key and refuses
any mismatch. A DKN passport adds a separately domain-separated DKN subject ID;
it does not rename or replace the imported MosaicID.

## UCM legacy DKN dimension profile

UCM r029 uses the explicit profile:

```text
dimension_id = BLAKE3(UTF8(phase_code) || raw_ed25519_public_key)
profile = DKN.AUTHORITY_KEYED_DIMENSION.UTF8_RAW_ED25519.V1
```

This profile can be recomputed for compatibility, but it is not the canonical
DKN Core namespace because it lacks the standalone canonical semantic namespace,
purpose, nonce, epoch, and algorithm body. A migration record must carry:

- legacy profile identifier, phase code, dimension ID, and public key;
- new `dkn.namespace.v0.1` object;
- exact legacy and new binding hashes;
- signer passport and signed constitutional-change or epoch-transition record;
- consumer-specific admission evidence outside DKN.

No migration may infer authority from equal keys, equal names, or a valid
signature. UCM policy roots, P/PPI work-selection roots, Courthouse admission,
and gateway permits stay external.

Qualified UCM r030 is pinned as the current read-only compatibility reference in
`acceptance/UCM-R030-REFERENCE.json`. That pin does not make the UCM source or
its qualification receipt part of DKN identity or authority.

## Version rules

- Missing algorithm/version fields are not guessed.
- Unknown fields and unknown public versions are refused.
- `v0.1` engineering successors use `r###`.
- A public-version change needs a signed external decision over exact predecessor
  and successor roots; file names, Git tags, or chat text do not suffice.

