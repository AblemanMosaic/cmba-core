# DKN Core protocol v0.1

Engineering revision: r002. Status: standalone reference implementation.

## 1. Scope and non-authority invariant

DKN authenticates the relationship between a semantic name, an Ed25519 public
key, a purpose/nonce domain, and an epoch. It also authenticates public identity
descriptors and signed statements about content and lifecycle events.

DKN does not decide namespace ownership, trust, admissibility, execution,
capabilities, publication permission, delegation, or local policy. Every DKN
record defaults to `INFORMATION_ONLY`, `authority_effect=NONE`, `real_a5=false`,
and `g0=CLOSED`. A consumer must make its own separately rooted authority and
admission decisions.

## 2. Algorithms and identifiers

| Role | Identifier | Definition |
|---|---|---|
| JSON serialization | `DKN-CJSON-1` | UTF-8, no BOM, compact JSON, object keys ordered by Unicode code point, no floats, signed 64-bit integers only, no duplicate keys. |
| Namespace hash | `BLAKE3-256` | 32-byte BLAKE3 digest. |
| Structural commitments | `SHA-256` | 32-byte SHA-256 digest. |
| Signing key/signature | `Ed25519` | Canonical nonidentity prime-subgroup public key and 64-byte signature. |
| Public version | `v0.1` | May change only by explicit external authorization. |
| Engineering revision | `r###` | Normal compatible engineering evolution. |

Human identifiers are lower-case:

- namespace: `dkn:v0.1:b3:<64 hex>`
- subject: `dknid:v0.1:b3:<64 hex>`
- MosaicID compatibility value: `<64 hex>`

## 3. Canonical namespace construction

The input `semantic_namespace` is lower-case ASCII labels separated by `.`.
Labels contain lower-case letters, digits, `_`, or `-`, start and end with an
alphanumeric character, and are at most 63 characters. The whole input is at
most 255 characters.

The only wildcard form is a terminal `.*`, for example `mosaic.ucm.*`. It is
encoded as `namespace_kind=WILDCARD_TERMINAL` and
`semantic_namespace=mosaic.ucm`. `*` is forbidden everywhere else. An exact
form uses `namespace_kind=EXACT`.

Construct the following object:

```json
{"epoch_code":"e0001","hash_algorithm":"BLAKE3-256","key_algorithm":"Ed25519","namespace_kind":"EXACT","nonce":"mosaic.ucm.v0.1","protocol_version":"v0.1","public_key_hex":"<64 lower-case hex>","purpose":"collaboration","schema":"dkn.namespace-material.v0.1","semantic_namespace":"mosaic.ucm.v0.1","serialization":"DKN-CJSON-1"}
```

Then:

```text
namespace_digest = BLAKE3(
  UTF8("DKN_NAMESPACE_V0.1") || 0x00 || DKN-CJSON-1(material)
)
namespace_id = "dkn:v0.1:b3:" || lowercase_hex(namespace_digest)
```

`purpose`, `nonce`, and `epoch_code` are committed fields. Reusing the same key
and semantic name under another purpose, domain nonce, or epoch produces a
different namespace. No concatenation without lengths or a canonical container
is used.

## 4. Identity binding and passports

The DKN subject identifier is:

```text
BLAKE3(UTF8("DKN_SUBJECT_V0.1") || 0x00 || raw_ed25519_public_key)
```

For compatibility, MosaicID remains exactly:

```text
BLAKE3(raw_ed25519_public_key)
```

A `dkn.passport.v0.1` includes the public key, both derived identifiers, role,
and optional namespace object. Its `passport_hash` is SHA-256 over the
domain-separated canonical passport body. The passport contains no private key,
credential, permission, or proof of current possession.

Import of an existing MosaicID succeeds only when recomputation from the exact
public key equals the declared MosaicID. Authentication still requires a fresh
challenge and replay-safe local consumption by the consumer.

## 5. Three Hash Rule

`dkn.thr-manifest.v0.1` commits three complete canonical components with three
different domain prefixes:

```text
state_hash      = SHA256("DKN_THR_STATE_V0.1"      || 0x00 || canonical(state))
semantic_hash   = SHA256("DKN_THR_SEMANTIC_V0.1"   || 0x00 || canonical(semantic))
governance_hash = SHA256("DKN_THR_GOVERNANCE_V0.1" || 0x00 || canonical(governance))
```

State equality does not prove semantic equality. Semantic equality does not
prove governance/admissibility. Governance equality does not prove authority.
Locality and receipt commitments may be carried inside governance or as
consumer-specific adjacent roots; they must never be substituted for any of
the three core commitments.

## 6. Signed records

Supported record types are constitutional change, collaborator attestation,
publication receipt, retrieval receipt, revocation/supersession, and epoch
transition. Each signing message is:

```text
UTF8("DKN_SIGNED_RECORD_V0.1") || 0x00 || DKN-CJSON-1({
  "schema": "dkn.record-signing-input.v0.1",
  "record_type": TYPE,
  "body": BODY,
  "signer_passport_hash": PASSPORT_HASH
})
```

The envelope embeds the complete public passport. Verification recomputes the
passport, requires the body identity field to equal the key-derived subject,
checks type-specific invariants, verifies the signature, and recomputes the
envelope hash. A separately asserted signer identity is never trusted.

- Constitutional changes bind predecessor/result THR roots, exact changed
  objects, acceptance cases, namespace binding, epoch, and revision.
- Collaborator attestations bind a subject hash and exact statement. They do
  not create a collaborator role or authority.
- Publication receipts bind the artifact SHA-256, all three THR commitments,
  DKN binding, replaceable locator root, publisher key, and epoch.
- Retrieval receipts bind a verified publication receipt and SHA-256 of bytes
  actually opened after retrieval. After-the-fact verification requires the
  receipt, publication receipt, and retrieved bytes.
- Revocation/supersession and epoch transition records are signed statements.
  Consumers decide their admissibility and effective scope.

## 7. Storage and archive certification

Storage locators may identify GitHub, private storage, HTTPS/WebDAV/SFTP,
MEGA-like services, local files, or offline media. Locators are replaceable and
must not contain credentials. They never enter namespace or artifact identity.

A portable ZIP contains logical payload plus four internal records:

- `META/STATE-MANIFEST.json`
- `META/THR-MANIFEST.json`
- `META/DKN-BINDING.json`
- `META/SELF-CERTIFICATE.json`

`MANIFEST.json` inventories every other member. Members use portable POSIX paths,
code-point ordering, stored compression, fixed 1980 timestamp, and fixed file
mode. The complete ZIP SHA-256 is external because an archive cannot contain
its own complete-byte hash.

Without a supplied external publisher key, the certificate status is
`READY_FOR_EXTERNAL_DKN_CERTIFICATION`, not self-certified. With a matching
passport and private key it is `PASS_SELF_CERTIFIED`. Neither status authorizes
publication or substitutes for independent review.

## 8. Versioning

Compatible schemas and engineering repairs advance `r###` while public version
remains `v0.1`. A consumer must refuse unknown public versions or algorithms.
Any public version transition requires a signed external decision bound to the
exact predecessor and successor protocol identities.

