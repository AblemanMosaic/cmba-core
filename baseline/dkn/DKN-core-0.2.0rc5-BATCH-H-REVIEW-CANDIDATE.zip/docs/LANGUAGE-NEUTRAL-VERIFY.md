# Language-neutral verification specification

An implementation in any language reports PASS only after all applicable steps
complete without a partial result.

1. Read bounded bytes. Refuse a UTF-8 BOM, invalid UTF-8, duplicate JSON keys,
   floats, non-finite numbers, integers outside signed 64-bit, excessive depth,
   unknown fields, and unsupported schema/version/algorithm identifiers.
2. Re-encode as `DKN-CJSON-1`: compact UTF-8, keys in Unicode code-point order,
   no escaping unless JSON requires it, and no trailing newline in hashed bytes.
3. Validate Ed25519 public keys as canonical, nonidentity points in the prime
   subgroup before deriving identity or verifying signatures.
4. Derive namespace and subject identifiers using the exact domain bytes and
   formulas in `PROTOCOL.md`. Compare complete identifiers, not prefixes.
5. Recompute passport, namespace-binding, THR, storage-locator, signed-envelope,
   and archive roots from the fields named by their schemas.
6. For signed records, derive signer identity from the embedded public key,
   require it equals the body identity, and verify Ed25519 over the exact signing
   input. Never trust a declared identity separately.
7. For a retrieval receipt, first verify the publication receipt, then open and
   hash the retrieved artifact, compare all three artifact hashes, and compare
   the locator and publication-receipt roots.
8. For a ZIP, reject absolute/backslash/dot-segment paths, case aliases,
   duplicates, undeclared members, private-key/credential files, wrong ZIP
   metadata, or noncanonical JSON. Compare every size and SHA-256 and rebuild
   the exact deterministic ZIP bytes.
9. Preserve `INFORMATION_ONLY`, `NONE`, `false`, and `CLOSED`. A verifier must
   never convert signature validity into authority or publication permission.

Golden vectors in `vectors/golden-vectors.json` are normative for r002. An
implementation must match every accepted value and refuse every negative case
with its listed stable code.

