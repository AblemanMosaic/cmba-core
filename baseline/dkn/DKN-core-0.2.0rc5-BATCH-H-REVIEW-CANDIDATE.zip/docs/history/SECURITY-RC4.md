# Batch F security boundary (current)

See `docs/batch-f/SECURITY-AND-REVIEW.md`, `LIFECYCLE-PROTOCOL.md` and
`VAULT-CONTRACT.md`. LC-F1 grants are evidence under caller-pinned heads and supplied
clock bounds, not live revocation or authority. Recovery is precommitted and guardians
are distinct keys, not proven independent people. No unbounded journal, guardian-policy
amendment, subdelegation, encryption, payload secret scrubber or hostile-host isolation.
SQLite crash recovery is locally tested for process termination, not physical power loss.
The original r002 implementation is preserved, not hardened by these new code paths.
No independent security certification, global freshness or public-release clearance.

---

## Historical predecessor security notes (scope is that predecessor)

# Batch E security advisory and claim ceiling

Earlier v0.2 B–D accepted an inadmissible identity-key signature fixture in this environment.
Batch E adds strict public-key admission and regression coverage. See docs/v02/DEFECTS.md.
This does not establish a forgery against legitimate pinned keys or independent security
certification. Review all residual risks in docs/v02/SECURITY-AND-ASSURANCE.md.

---

# Security

Report suspected protocol or implementation vulnerabilities privately to the
maintainer. Do not include private keys, credentials, live tokens, or sensitive
archives in a report. A valid signature or self-certificate is provenance only;
it must never be interpreted as permission or execution authority.


### v0.2 Batch C navigation caveats

The local index is a single-writer offline prototype with re-verification on read, not a hardened multi-tenant filesystem vault. `relation_authentication=PASS` proves a signer attested an archive containing the bound relation values, **not** the relation's truth. `namespace_authorization=PASS_FOR_SUPPLIED_CHAIN_ONLY` does not prove authorization at the time the artifact was signed. Inbound edges and name search are local-snapshot candidates; no index completeness, freshness, non-equivocation, or global head is established. See design-v0.2/12 and /13.


### v0.2 Batch D assurance caveats

Signed statements bind their authors and bytes, not their real-world truth. A caller
controls observer/membership recognition and must protect that policy and its clock.
Fault-domain labels cannot prove independent institutions. A quorum of observations is
not consensus, current revocation status, or an authority grant. Metadata exposure is
separate from payload encryption. Retention/availability are not inferred from replica
counts. Unsupported proof rules refuse rather than downgrade silently.

New local storage checks symlinks and hardlink aliases at observed snapshots but does
not claim race-free custody against an active local writer; interrupted writes can
leave refused partial candidates. Examples/tests contain publicly known fixture keys
that must never become production identities. All runtime authority effects remain NONE.
See design documents 15–19 for exact semantics, residual risks, and evidence boundaries.

## Current self-review revision: 0.2.0rc2

See `docs/v02/REVIEW-RC2.md` for source-scan completeness, index-layout, report-size,
reserved-path, replay-binding, ZIP-budget and missing-name repairs. No new valid-key
signature forgery was established in this review. The previous E key-admission repair is
retained and additionally compared against a native cryptographic implementation on a finite
corpus; this is not independent review or a general proof.

**Payload secrecy is the publisher's responsibility.** DKN does not scrub arbitrary payloads
for credentials. Stable canonical bytes and valid signatures do not establish application
semantics, publisher recognition, signing time, live availability or globally current state.
Use the reader policy example to keep those decisions separate. Source scans, index writes,
local stores and report generation are not a hostile-writer sandbox or multiwriter database.
The package's current inventory is `REVIEW-RC2-FILE-MANIFEST.json`; old manifests/certificates
are historical. Public release and independent approval remain NOT_CLEARED/NOT_PERFORMED.


## Batch G security boundary

DS-G1 uses finite public fixture inputs, deterministic model time and explicit message schedules. Reader configuration/floors remain external trust assumptions. Simulation results are not live observations; no network, signatures, trust migration or execution is produced by the simulator. See docs/batch-g/THREAT-MODEL.md.
