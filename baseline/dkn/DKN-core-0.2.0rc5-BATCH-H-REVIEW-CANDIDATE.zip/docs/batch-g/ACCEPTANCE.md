# Batch G acceptance reconciliation

The original fifty-obligation ledger is retained byte-for-byte from Batch F:
**35 PASS_SCOPED; 8 PARTIAL; 3 BLOCKED_DEPENDENCY; 1 DEFERRED; 2 NOT_PERFORMED; 1 NOT_RUN.**
Simulation does not promote live deployment, global freshness, cross-platform evidence,
legacy BLAKE3 parity or independent review. Existing partial semantics are not rewritten
as universal guarantees merely because a new finite test corpus passes.

DS-G1 adds fourteen separately committed obligations with exact code/test references in
`model/distributed-g1/REALIZATION-BINDING.json`. These extend the evidence vocabulary;
they do not redefine the RC2 base or LC-F1 models. `check_distributed_contract.py` validates
hashes, symbols and optionally current recorded test results. That is traceability, not
formal semantic equivalence or independent approval.

## Evidence classes

* `test_batch_g_views.py`: actual artifact/certificate/journal/witness/assurance composition;
  exact identity and scope; time/floors; all eight subsets of three witnesses; duplicate
  handling; typed malformed inputs; contradiction precedence and no authority promotion.
* `test_batch_g_simulation.py`: all 27 authored scenario outcome sequences; deterministic
  replay; visibility; delivery ties; domain overlap; all eight subsets of three replicas;
  sixteen deterministic seeded finite schedules; no implicit retry; no external I/O;
  transcript tampering and input/size admission.
* `test_batch_g_vault.py`: real cooperative SQLite old-file restore and fork-selection
  boundary. Not physical crash resistance or an external protected-floor implementation.
* `test_batch_g_interfaces.py`: 28 frozen corpus cases, six schema exports, read-only CLI,
  exact fixture regeneration and six Node domain/linkage comparisons. These cases are
  included in the cumulative suite, not counted again as additional passing tests.
* `test_batch_g_binding.py`: the three semantic models, mutation detection, current-source
  evidence binding and exact predecessor/source-archive closure.

The inherited suites, executable workflows, native cryptographic cross-check, installed
wheel probe, exact file inventory and fresh-extraction replay remain separate evidence
legs. Their measured counts/statuses appear in the accompanying release/replay receipts.
No count in this document substitutes for those completed receipts.

## Deliberately unclosed obligations

Genuine BLAKE3 legacy execution, a full independently implemented protocol stack, native
Windows/WSL/macOS replay, fresh dependency resolution, live distributed transport,
consensus/liveness, production custody/recovery ceremonies and independent security
approval remain external or future gates. A universal wheel tag is not platform evidence.
The original finite LC-F1 256-event cap and no-policy-amendment/subdelegation boundaries
remain intact. No payload secret scrubber or universal application-semantic interpreter
has been added.
