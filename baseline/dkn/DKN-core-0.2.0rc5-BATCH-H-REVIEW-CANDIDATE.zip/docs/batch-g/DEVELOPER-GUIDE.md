# Using the distributed model and supplied-view evaluator

Install the wheel or `python -m pip install .`. Existing modules retain their APIs.
New imports are `dkn_v02.distributed`, `simulation`, `distributed_schemas`,
`distributed_abi`, and `distributed_cli`. No new runtime dependency is introduced.

## Evaluate evidence in an application

`assess_view(objects, reader, now=...)` takes a bounded list of object envelopes and a
reader-owned configuration. The returned artifact/lifecycle/witness/assurance components
are recomputed. Do not submit a precomputed PASS report instead of signed material.
`validate_reader(reader)` and `validate_shape(kind,value)` check admission; shape checks
alone do not authenticate a report or establish its conclusions.

Use an independently accepted artifact root/publisher/namespace pin, exact LC-F1 head,
selected time policy and any independent ancestry floor. Set require_witness and/or
require_assurance when these are necessary for your use. The configured policy must
exist when required. Optional checks still disclose and propagate known applicable
contradictions. The fixed operation is certify_artifact, never execute/install.

The evidence evaluator can operate independently of the simulator. Production callers
must separately implement trusted pin acquisition, real retrieval/time/resource limits,
protection of floors, schema handlers for application semantics, and admission decisions.
A supplied view is not a globally current view or a capability authorization.

## Run the executable example

From an installed source checkout:

```sh
python examples/v02_distributed_simulation.py
```

The example exercises real signatures/verifiers under five representative schedules.
Full public inputs for all 27 cases are in `profiles/distributed-g1/scenarios/`.

```python
from pathlib import Path
from dkn_v02 import read_canonical
from dkn_v02.simulation import run_scenario, verify_replay

scenario = read_canonical(
    Path("profiles/distributed-g1/scenarios/partition-heal.json").read_bytes()
)
transcript = run_scenario(scenario)
replay = verify_replay(scenario, transcript)
assert replay["status"] == "MATCH_EXACT_SIMULATION_REPLAY"
assert transcript["production_evidence"] is False
```

The simulator performs no writes. Saving its transcript is an explicit caller action.
Nodes know only their initial and delivered objects. Add scenarios by explicitly modeling
nodes/failure domains, public signed fixture objects, reader policies and finite actions.
Do not silently add automatic retry or pin selection to an existing profile.

## Closed read-only JSON ABI

Requests have exactly schema `dkn.distributed-request.v0.2-g1`, operation, arguments.

* `assess`: arguments objects, reader, now.
* `simulate`: argument scenario.
* `verify-replay`: arguments scenario, transcript.

`dkn-sim request.json` or `python -m dkn_v02.distributed_cli -` consumes canonical JSON.
The '-' form reads stdin. Output is canonical JSON plus a framing newline. Successful
computation exits 0 even for NO_MATCH/INDETERMINATE/CONTRADICTED. Invalid requests or
failed replay exit 2 with a typed refusal. A process exit status is not admission.

## Replacement realizations

Pin all three semantic commitments: the base model, LC-F1, and DS-G1. Preserve canonical
bytes, signature domains, scheduler tie order, visibility, exact joins, conclusion
precedence, replay behavior and resource-limit refusals. Alternative event queues,
programming languages and storage engines may be used without changing the declared
contract, but their actual evidence must be renewed. The existing Python code is one
reference realization, not the definition of correctness by itself.

```sh
python tools/run_conformance.py --corpus interop/distributed-g1-conformance.json \
  --out /tmp/ds-conformance.json \
  --command python tools/reference_distributed_conformance.py
```

Replace the explicit command with a reviewed replacement executable speaking the frozen
conformance request/response envelope. No shell eval is used, but the executable is
host-authorized code, not sandboxed. Full expected results are reference-assisted;
passing 28 cases is not complete semantic equivalence. Add independent and platform-
specific cases; review differences rather than regenerating expected output to fit a port.
