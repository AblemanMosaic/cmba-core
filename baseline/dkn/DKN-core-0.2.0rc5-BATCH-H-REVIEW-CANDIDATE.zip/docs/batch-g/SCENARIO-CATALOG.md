# DS-G1 reference scenario catalog

These are finite synthetic schedules, not deployments. Status sequences below are hand-authored expectations, checked against actual library evaluations. Transcript roots are separately frozen reference-assisted vectors in `vectors/v02/distributed-g1.json`.

| Scenario | Topology label | Expected reader conclusions, in order |
|---|---|---|
| assurance-refuted | ENTERPRISE | CONTRADICTED |
| assurance-supported | ENTERPRISE | MATCH_FOR_SUPPLIED_VIEW |
| clock-skew | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → INDETERMINATE |
| common-cause-outage | ENTERPRISE | INDETERMINATE |
| delayed-revocation | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → MATCH_FOR_SUPPLIED_VIEW → INDETERMINATE → NO_MATCH |
| drop-in-flight | FEDERATED | INDETERMINATE |
| duplicate-delivery | FEDERATED | MATCH_FOR_SUPPLIED_VIEW |
| expired-checkpoint | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → INDETERMINATE |
| expired-conflict-retained | FEDERATED | CONTRADICTED |
| external-floor-rollback | LOCAL | MATCH_FOR_SUPPLIED_VIEW → NO_MATCH → INDETERMINATE |
| failure-in-flight | FEDERATED | INDETERMINATE |
| guardian-threshold-collusion | FEDERATED | MATCH_FOR_SUPPLIED_VIEW |
| hidden-recovery-fork | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → INDETERMINATE |
| independent-mirror-path | HYBRID | MATCH_FOR_SUPPLIED_VIEW |
| invalid-artifact-fallback | P2P | INDETERMINATE → MATCH_FOR_SUPPLIED_VIEW |
| local-rollback | LOCAL | MATCH_FOR_SUPPLIED_VIEW → NO_MATCH → MATCH_FOR_SUPPLIED_VIEW |
| normal | FEDERATED | MATCH_FOR_SUPPLIED_VIEW |
| partition-heal | P2P | INDETERMINATE → MATCH_FOR_SUPPLIED_VIEW |
| partitioned-witness-fork | FEDERATED | CONDITIONAL → INDETERMINATE → CONTRADICTED |
| recovery-fork | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → CONTRADICTED |
| shared-witness-administrator | FEDERATED | INDETERMINATE |
| transitive-shared-dependency | HYBRID | MATCH_FOR_SUPPLIED_VIEW |
| withheld-revocation | FEDERATED | MATCH_FOR_SUPPLIED_VIEW → MATCH_FOR_SUPPLIED_VIEW |
| witness-equivocation | FEDERATED | CONTRADICTED |
| witness-head-mismatch | FEDERATED | INDETERMINATE |
| witness-quorum | FEDERATED | CONDITIONAL |
| witness-shortfall | FEDERATED | INDETERMINATE |

A matching stale view in withheld-revocation and local-rollback is an intentional boundary witness, not an assertion of global correctness. The external-floor scenario assumes its floor is stored outside the restored state. The actual-vault regression repeats the distinction with real SQLite file restoration.

The guardian-threshold-collusion case shows that possession of the configured signing threshold can create valid recovery evidence. Cryptography cannot determine whether that action deserves social or institutional recognition.

The transitive shared-dependency case keeps a matching artifact/lifecycle result while separately reporting composition conflicts and public metadata exposure. Composition is not silently made into a permission or availability score.
