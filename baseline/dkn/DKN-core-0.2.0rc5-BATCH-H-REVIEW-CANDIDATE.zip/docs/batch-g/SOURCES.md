# External design references, separate from DKN evidence

Consulted during Batch G on 2026-11-07 (America/Los_Angeles). These references explain
established design ideas; none evaluates, approves or certifies DKN.

* FoundationDB primary documentation, `testing.rst`, Simulation section:
  https://github.com/apple/foundationdb/blob/main/documentation/sphinx/source/testing.rst
  Describes deterministic simulation of a cluster. DKN borrows the testing discipline,
  not FoundationDB's implementation, scale or established test coverage. DS-G1 is a
  finite evidence-transport model around DKN verifiers, not a simulation of a deployed
  full networking/storage stack.
* The Update Framework specification, rollback/freeze checks:
  https://theupdateframework.github.io/specification/latest/
  Illustrates version high-water marks and expiration as distinct checks. DS-G1 uses
  DKN's exact LC-F1 ancestry floors and explicit caller time; it is not TUF-compatible
  and does not implement TUF metadata/update roles.
* SQLite primary isolation documentation:
  https://sqlite.org/isolation.html
  Explains transaction isolation and committed reads. The inherited F vault uses its
  own documented local SQLite configuration (rollback journal, not a new WAL claim).
  Batch G's actual quiescent database-restore test does not establish physical crash
  durability, protected floors or multi-host network-filesystem safety.

The normative DKN definitions are in PROTOCOL.md and the inherited LC-F1/base contracts.
Local test XML, exact source bindings, examples, corpus and replay receipts are the
engineering evidence. Citation of external designs is not a substitute for those checks.
