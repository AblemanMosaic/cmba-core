# Batch G — distributed evidence modeling and simulation

Distribution **0.2.0rc4**; optional model profile **DS-G1**. Base `v0.2-candidate` and
LC-F1 remain unchanged. This is an offline, deterministic model around actual DKN
verifiers, not a P2P daemon, federation consensus algorithm, network deployment,
production trust decision, or independent security certification.

Start with `DEVELOPER-GUIDE.md`. `PROTOCOL.md` is the normative finite model;
`THREAT-MODEL.md` explains assumptions; `SCENARIO-CATALOG.md` records manually specified
scenario outcomes; `ACCEPTANCE.md` maps evidence and retained limits. `REVIEW-AND-HANDOFF.md`
records development findings and the Batch H boundary; `SOURCES.md` distinguishes
external design references from evidence produced by this package.

## Delivered parts

`dkn_v02.distributed.assess_view` joins an exact signed artifact, a reader-pinned LC-F1
journal, optional federation observations and assurance contracts. Invalid supplied
candidates are explicitly quarantined. A certificate is checked against its actual
payload manifest, expected signer and namespace. The operation is fixed to
`certify_artifact`; a certificate does not establish permission to install or execute.

`dkn_v02.simulation.run_scenario` models nodes, their local object holdings, explicit
sends, delays, partitions, administrative/provider failure domains, modeled crashes,
clock offsets, explicit pin changes, snapshots and local restore. All received
material is untrusted until checked. Scheduling owns visibility, not truth or authority.

`verify_replay` recomputes the whole model result. A correctly hash-chained forged
conclusion does not pass replay merely because its hash chain is internally consistent.
The separately written Node checker checks commitment domains and trace links only.

Twenty-seven public reference scenarios use real fixture signatures. Hand-authored
expected status sequences are separate from reference-assisted golden trace roots.
The portable conformance corpus contains 28 bounded request/result/refusal cases.
No passing finite corpus establishes whole-program equivalence or live availability.

## Preservation and selection

The frozen Batch F predecessor archive is SHA-256
`18138c2af53ac18057017a07fdd5e3f5abf72d935a5d88b7701052c6407b247a`.
All inherited runtime modules, base semantic contract/commitment and LC-F1 semantic
contract/commitment retain their bytes. Only realization bindings are refreshed where
build/test metadata changed. DS-G1 has a separate contract and commitment. Installing
this version does not alter a vault, migrate a namespace or update a reader's pins.

All engineering receipts remain unsigned same-author evidence. `authority_effect=NONE`;
`public_release_gate=NOT_CLEARED`. The full source package includes the models, tests,
scenarios and dossier; the wheel contains the reusable runtime library and CLI.
