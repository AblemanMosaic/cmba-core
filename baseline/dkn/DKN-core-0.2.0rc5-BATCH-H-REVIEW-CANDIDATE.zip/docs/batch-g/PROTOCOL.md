# DS-G1 finite protocol and simulation contract

## 1. Byte representation and identity

Use the existing strict DKN candidate canonical encoding, not generic JSON or JCS.
All profile input/output passes canonical bounds before processing. DS-G1 hashes are
SHA-256 of `b"DKN_DS_G1\0" + ASCII(domain) + b"\0" + canonical(value)`. Domains are
`object`, `reader`, `view`, `scenario`, `trace-start`, `trace-entry`. This model does not
change any existing DKN commitment or signature domain. Times/ticks are integers from
0 through 2^53-1, explicitly narrower than the base signed-64-bit data range.

An object envelope has exactly `kind` and `value`. Artifact values contain canonical
ZIP bytes encoded as lowercase hexadecimal and a detached certificate (or explicit
null). Journal values contain genesis, policy, events and checkpoint (or null). Other
kinds contain signed substrate, evidence or head-observation records. Catalog IDs in
a scenario are local labels, NOT authenticated names. Object identity binds its full
canonical envelope. The public fixture generator is an authoring tool, not a verifier.

## 2. Reader-owned composition

A reader declares exact expected artifact root, namespace root, LC-F1 head, subject key,
`certify_artifact`, checkpoint maximum age, optional local and external ancestry floors,
optional witness policy and assurance contract/policy, and composition roots. Required
witness/assurance flags demand corresponding policies. Pins are caller configuration;
reading does not select a new pin or copy trust expectations out of received material.

The evaluator is pure with respect to external state. Time and all objects are explicit.
Each candidate is checked with existing archive, certificate, lifecycle or SAM verifiers.
Invalid candidates are recorded by object commitment and typed refusal; they cannot
satisfy requirements. Invalid unrelated material does not veto otherwise sufficient
evidence. Exact duplicates are counted diagnostically and deduplicated; repeated
signatures from one identity cannot become several observers.

Artifact matching requires verified payload, expected logical root, a valid certificate,
expected certificate signer and expected namespace. A bare matching archive is insufficient
for this signed-publication join. The evaluator neither interprets arbitrary semantic
dimensions nor supplies a universal application-admission handler.

Journal matching requires the exact expected namespace/head. Every supplied valid same-
namespace journal participates in visible fork analysis. A known valid descendant of the
pinned head yields `PIN_NOT_MAXIMAL_IN_SUPPLIED_VIEW`; it never silently advances that pin.
Any visible lifecycle fork yields contradiction, without selecting a winner. Both local
and external floors must match exact ancestry; one cannot erase a conflict in the other.
Checkpoint validity uses the caller time/age bound. Missing or stale checkpoint material
cannot establish a match. Future signed branches can conservatively expose conflict;
the simulator does not adjudicate the truth of declared event times.

Witness assessment calls the existing finite observer evaluator. A usable observation
set must bind the selected lifecycle namespace, head, sequence and epoch. A threshold
attesting another head cannot be joined to this journal. Membership and substrate scope
remain caller-selected; a witness label is not proof of independent administration.
Assurance contracts must have exactly the selected artifact, namespace and descriptor
scope. Signed descriptors and evidence are verified before finite contract evaluation.
Composition is diagnostic: shared dependencies/domains, missing material and metadata
exposure remain visible, not converted to a scalar security/availability score.

## 3. Conclusions

The overall conclusion combines the mandatory signed-artifact/lifecycle checks and
explicitly required optional checks. Applicable contradictions in a configured optional
witness/assurance check still block a positive result; optional means missing evidence
need not block, not that known contradictions may be erased. Precedence:

1. `CONTRADICTED`: a relevant, verified supplied conflict/refutation.
2. `NO_MATCH`: a valid pinned lifecycle assessment establishes no matching grant/controller.
3. `INDETERMINATE`: any remaining required check lacks adequate matching material.
4. `CONDITIONAL`: required checks match but at least one retains conditional premises.
5. `MATCH_FOR_SUPPLIED_VIEW`: required finite checks match in this bounded supplied view.

A wrong artifact root can produce NO_MATCH because the valid journal establishes no
exact grant for it, even while the artifact itself is unavailable. Diagnostic components
are preserved; a top-level result is not a replacement for reading those components.

Every view explicitly withholds global currentness and consensus safety, retains
`EXTERNAL_DECISION_REQUIRED`, and sets execution authorization false and authority effect
NONE. A valid signature does not prove honesty, human consent, institutional legitimacy,
semantic correctness, or future availability.

## 4. Deterministic network model

A scenario fixes a catalog of public objects, nodes with initial holdings/failure domains/
clock offsets, readers with caller policies, an ordered step list and terminal horizon.
The topology label (LOCAL/ENTERPRISE/P2P/FEDERATED/HYBRID) is descriptive only; no label
adds properties. There is no automatic routing, replication, consensus, clock source,
real network, disk persistence, key generation, signing or randomness in the simulator.

Step actions are send, partition, node, domain, clock, drop, assess, configure, snapshot,
restore. All referenced nodes/readers/objects must exist. Times are nondecreasing; input
order breaks same-time step ties. Before each step, deliver queued messages due at or
before that step's tick in (due time, send index) order. A zero-delay send delivers after
its own step. Therefore a delivery scheduled exactly at a later outage step arrives
before that outage. This is a declared model convention, not network timing evidence.

Every send receives a sequential `mNNNNNN` identifier. A source must actually hold its
object; catalog existence alone never allows sending. Offline endpoints or a blocked
undirected link reject sending. The same conditions are checked again at delivery;
failed deliveries are dropped, not silently retried after healing. Endpoint availability
at delivery is a simplified request/response assumption: the model does not claim that
all real in-flight bytes disappear when their original sender crashes. Source holdings
need only exist at send; a later disk restore does not retract an already queued message.

Downing a domain affects every node declaring it. A node is usable only if its own state
and ALL its declared domains are online. Restoring one domain does not restore another.
Crash modeling retains node holdings as modeled durable state. A receiver adds bytes to
its untrusted holdings; only assess invokes verifiers. Duplicate deliveries are explicit.
Messages beyond the terminal horizon remain pending and are listed, not treated as lost
or delivered. Retries and gossip are explicit sends in the schedule.

An assessment sees only its node's holdings and configured reader policy, at simulated
tick plus that node's clock offset. Catalog knowledge, withheld branches, other nodes'
state, and scenario expectations do not enter the evaluator. A negative/out-of-range
clock yields a typed refusal. Read-only evaluation does not mutate pins or floors.

Configure is an explicit modeled external recognition input, not network evidence.
A snapshot captures node holdings and its readers' local policies. Restore reinstates
those local values but preserves each current external floor. This models a separately
protected floor BY ASSUMPTION; it does not implement protected storage. Snapshots do not
roll back the global message queue, network clock or failure scheduler.

## 5. Transcripts and replay

Scenario reference commits the entire canonical scenario. Initial trace hash commits
`{"scenario_ref":...}` under trace-start. Each trace entry binds its ordinal, model time,
type, details, and previous hash under trace-entry; entry_hash is excluded from its own
hash. terminal trace_root is the last entry hash (or initial hash for an empty trace).
Assessment entries contain computed results, not expected answers. Transcript includes
those assessments and terminal visibility/pending-message summaries. Every transcript
is labeled simulation-only and not production evidence. No real timestamp is invented.

Verify-replay runs the scenario again and compares the COMPLETE canonical transcript.
It does not accept a submitted report or a self-consistent hash chain as proof of correct
model execution. Trace hash alone is not publisher authentication. An external reader
must obtain a trusted expected commitment or separately recognized signature.

## 6. Finite limits and exclusions

Limits: 64 objects, 16 nodes, 8 readers, 256 scheduled steps, 32 assessments, 16 snapshot
slots, 16 supplied journals with at most 512 total supplied events, 256 KiB per artifact
in this model, 1,000,000 ticks of send delay or clock-offset magnitude, 1,024 trace records.
All canonical inputs, cumulative trace and final report fit the base 4 MiB metadata
budget. Payloads larger than this model's sample budget must be tested outside DS-G1.
Existing LC-F1 per-journal and SAM signature/record limits also apply.

There is no universal wall-clock deadline, process memory sandbox, proof of liveness,
complete Byzantine-state enumeration, physical crash model, live deployment guarantee,
independent review, or universal equivalence claim. Correct behavior is bounded by these
semantics, explicit fixture assumptions and the supplied inputs.
