# Threat and assumption ledger

The adversary may withhold, delay, drop, duplicate, corrupt or replay supplied objects;
partition communication; remove a replica; fail all nodes in a declared common domain;
show different validly signed views to different readers; restore modeled local state;
and control fixture signers, including a recovery threshold. These actions are finite
explicit schedules, not an operational exploit kit or an attack on external services.

Cryptography and the LC-F1/SAM validators are the actual library implementations, not
mock success flags. Malformed material is quarantined with its refusal. Fixtures use
public deterministic test seeds; NEVER use those identities for actual publishing.

Reader pins, recognition policies, accepted premises, clock quality and separately
protected floors remain external assumptions. Their accuracy is not established by
signing their declarations. Shared domain labels make dependencies inspectable but
missing/inaccurate labels cannot be detected by the cryptography. Recovery signatures
establish that a configured threshold signed; they do not prove the signers' consent
was informed, that they are independent, or that the result is institutionally legitimate.

A withheld revocation scenario intentionally leaves the old view matching until more
evidence or expiration changes the assessment. That is not a test failure: it witnesses
why a disconnected reader cannot assert global currentness. A visible descendant stops
matching under a stale pin; a visible fork is retained without selecting a winner.

The simulated snapshot's external floor is protected only by model construction. Two
integration tests use the actual SQLite vault: restoration of an old quiescent database
loses the newer internal pin, while separately retained exact ancestry detects rollback;
a valid competing recovery branch cannot overwrite an already selected branch through
ordinary monotone advancement. Neither test establishes hostile-host resistance,
physical power-loss durability or deployment of an external monotonic store.

All app-level and simulator operations are read-only in the JSON ABI. CLI file paths
are explicit operator input only; no path, shell command, URL, plugin or production
private key comes from simulation metadata. No automatic publication, installation,
execution or trust-policy migration occurs. Test harness commands execute selected
local programs and are NOT a sandbox; review those programs before invoking them.

The 27 scenarios, bounded enumeration of three-witness and three-replica subsets, seeded
finite schedules, malformed-input tests and hash-link cross-checks are local engineering
evidence. They are not empirical uptime measurements or a consensus safety proof.
