# Batch G review, replay and Batch H handoff

## Construction record and findings

The supplied Batch F archive's SHA-256 was checked before extraction. Its 861 tests
replayed with no failure or skip in this environment. Inherited runtime modules and
base/LC-F1 semantic contract bytes are preserved. Development logs include unsuccessful
attempts; final completion is determined by the source-bound complete run and clean replay.

G-001 — Initial expected outcome for a different artifact root incorrectly required
INDETERMINATE. The valid pinned history establishes NO_MATCH for that exact ungranted
artifact. The test expectation was corrected; conclusion precedence was documented.
The runtime was not weakened to satisfy a mistaken test.

G-002 — A nested-malformed-input test initially asserted 108 substitutions; the actual
five envelope kinds/24 public top-level fields produced 144. The assertion and comment
were corrected after all 144 checks already completed without untyped parser failures.
This was a test bookkeeping defect, not a cryptographic acceptance finding.

G-003 — During design review the artifact join was made explicitly certificate-bound,
not a combination of an arbitrary payload and someone else's valid delegation. The
reader operation is fixed to certify_artifact. Regression cases reject missing,
wrong-signer, wrong-namespace and invalid certificates and operation aliases.

G-004 — Configured optional checks cannot suppress known applicable contradictions.
Optional evidence may be missing without blocking a match, but a verified conflicting
witness view/refutation propagates even when quorum/evidence presence is not required.
The pure evaluator recomputes evidence; schemas and supplied reports are not authority.

G-005 — The new source-script example imports its fixture helper in both direct-script
and package contexts. Package library/CLI imports are independently tested from outside
the source tree. Root documentation names the current G inventory, not the historical F
inventory. Historical receipts remain historical rather than silently reissued.

G-006 — The first cumulative run completed with the inherited packaging assertion still
expecting RC3 (and the old CLI set). That metadata-only test was updated for RC4 and the
new explicit dkn-sim entry point; its failure is preserved. The current META boundary
was also updated from F to G, and the F inventory remains historical. No inherited
runtime behavior or semantic commitment was changed to make these assertions pass.

None of these same-author checks is independent review. The native cryptographic checker
and Node byte-domain checker supply distinct evidence scopes, not a new review authority.

## Replay from an extracted source archive

Install genuine dependencies with `python -m pip install '.[test]'` in the selected target
environment. This is an operator instruction, not a claim that downloads occurred here.

```sh
python tools/verify_v02_candidate.py --out /tmp/dkn-g-run --phase tests
python tools/verify_v02_candidate.py --out /tmp/dkn-g-run --phase examples
python tools/verify_v02_candidate.py --out /tmp/dkn-g-run --phase assemble
python tools/check_semantic_contract.py --report /tmp/dkn-g-run/LOCAL-RUN.json
python tools/check_lifecycle_contract.py --report /tmp/dkn-g-run/LOCAL-RUN.json
python tools/check_distributed_contract.py --report /tmp/dkn-g-run/LOCAL-RUN.json
python tools/check_native_crypto.py --out /tmp/dkn-g-native.json
python tools/run_conformance.py --out /tmp/dkn-g-base.json
python tools/run_conformance.py --corpus interop/lifecycle-f1-conformance.json \
  --out /tmp/dkn-g-lc.json --command python tools/reference_lifecycle_conformance.py
python tools/run_conformance.py --corpus interop/distributed-g1-conformance.json \
  --out /tmp/dkn-g-ds.json --command python tools/reference_distributed_conformance.py
python tools/build_batch_g_candidate.py --out /tmp/dkn-g.zip
```

Use `--require-legacy` on the consolidated runner when genuine BLAKE3 is installed;
absence is a blocked gate, not a substitute digest. Node is needed for the full scoped
interop suite; skips prevent a whole-suite PASS. Under PowerShell choose actual temporary
paths and use the chosen virtual environment's Python. These commands are not Windows
execution evidence.

Exact source ZIP reproducibility serializes the same frozen tree, including frozen logs.
It does not claim rerunning tests recreates elapsed times, process IDs or log timestamps.
The source manifest excludes only itself; exact transport hash remains external. Wheel
builds use SOURCE_DATE_EPOCH=1794009600. Post-freeze replay evidence stays external to avoid
circular dependencies. Receipts are unsigned engineering evidence relative to pinned hashes.

## Batch H boundary

Consolidate the three profile commitments and all findings into one externally reviewable
candidate. Replay available dependency/platform legs without inventing results; broaden
replacement tests where feasible; reconcile every claim against realized behavior; freeze
one exact handoff. Do not keep adding live services or redefine F/DS-G1 under the same
profile identifiers to make the acceptance ledger green. A full alternative implementation,
actual network deployment and genuinely independent review remain separately evidenced.
No automatic courthouse transmission, external publication or authority promotion.
