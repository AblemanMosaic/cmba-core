# Integration note for UCM, P/PPI, Courthouse, MosaicID, THR, and SemCrys

DKN Core is a dependency, not a child authority domain. Consumers should import
only its public verification outputs and keep their own authority roots.

## Recommended mapping

| Consumer concept | DKN input/output | Must remain external |
|---|---|---|
| MosaicID | `passport.mosaic_id`, exact public key | possession challenge, replay consumption, local admission |
| UCM locality | namespace object/hash, passport hash, epoch | namespace policy, delegation, AMCAS contract, capability grant |
| P/PPI collaborator | signed collaborator attestation | acceptance case, work selection, journal head, effect ceiling |
| THR/CAS | state/semantic/governance hashes | UCM locality/receipt extensions and admissibility interpretation |
| Courthouse | signed change/revocation/epoch/publication records | jurisdiction, admission envelope, workflow, executor and G1/G2/G3 receipts |
| SemCrys | semantic component/hash or signed statement | semantic resolution authority and consumer interpretation |

## Import procedure

1. Pin DKN public version, schema IDs, algorithm IDs, and verifier source or
   package hash.
2. Strictly parse and verify the passport/namespace/record/archive.
3. Derive all identities from the verified key. Refuse separately asserted
   identity values.
4. Store DKN results as provenance/locality evidence with
   `authority_effect=NONE`.
5. Evaluate consumer-specific namespace admission, current-use policy,
   jurisdiction, and capability separately.
6. For publication, open the exact artifact, verify the external archive
   SHA-256, internal closed manifest, THR, DKN binding, and certificate. A
   self-certificate is still not publication permission.
7. For retrieval, verify again against actual retrieved bytes. Do not accept a
   caller's receipt status label.

## Qualified UCM r030 boundary incorporated

- MosaicID derivation and signer/key equality are retained.
- Provider-neutral locators are projections, not identities.
- The inherited UCM dimension concatenation is supported only as a named legacy profile;
  canonical DKN Core uses a domain-separated canonical object.
- R030's public retrieval-receipt validation is mirrored, and DKN additionally
  requires the actual retrieved bytes during later verification.
- Locator credential checks are re-run during verification, not only creation.
- R030 source, qualification, release, runtime, transport, atlas, and pipeline
  roots are pinned in `acceptance/UCM-R030-REFERENCE.json`.

This package neither modifies nor supersedes UCM r029, r030, or any successor
workspace. The UCM authority model is not inherited.

