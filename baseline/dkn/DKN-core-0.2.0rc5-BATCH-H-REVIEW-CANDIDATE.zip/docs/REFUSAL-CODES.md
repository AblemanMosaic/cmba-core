# Typed refusal codes

Stable refusal codes are declared in `src/dkn_core/errors.py`. Families are:

- `DKN_CANONICAL_*`: parse, type, numeric, duplicate-key, depth, or canonical-byte failure.
- `DKN_NAMESPACE_*`, `DKN_PURPOSE_*`, `DKN_NONCE_*`, `DKN_EPOCH_*`: namespace material failure.
- `DKN_PUBLIC_KEY_*`, `DKN_IDENTITY_*`, `DKN_MOSAIC_*`, `DKN_PASSPORT_*`: public identity failure.
- `DKN_THR_*`: commitment or domain-separation failure.
- `DKN_RECORD_*`, `DKN_RECEIPT_*`: body, signer, signature, lifecycle, or custody failure.
- `DKN_STORAGE_*`: invalid or credential-bearing locator.
- `DKN_ARCHIVE_*`: path, manifest, deterministic-byte, credential, or ZIP failure.
- `DKN_CEREMONY_*`, `DKN_PRIVATE_KEY_*`: private-custody failure.
- `DKN_ABI_*`, `DKN_SCHEMA_*`, `DKN_VERSION_*`: interface, schema, or compatibility failure.

Refusal never returns a partial verified result. CLI refusals exit with code 2;
ABI refusals return `ok=false`.

