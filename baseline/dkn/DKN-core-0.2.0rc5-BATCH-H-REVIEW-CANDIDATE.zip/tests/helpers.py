from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from dkn_core.crypto import public_key_hex
from dkn_core.namespace import derive_namespace
from dkn_core.passport import create_passport

RFC8032_SEED = bytes.fromhex(
    "9d61b19deffd5a60ba844af492ec2cc4"
    "4449c5697b326919703bac031cae7f60"
)


def key():
    return Ed25519PrivateKey.from_private_bytes(RFC8032_SEED)


def public_hex():
    return public_key_hex(key())


def namespace(wildcard: bool = False, epoch: str = "e0001"):
    return derive_namespace(
        semantic_namespace="mosaic.ucm.*" if wildcard else "mosaic.ucm.v0.1",
        public_key_hex=public_hex(),
        purpose="collaboration",
        nonce="mosaic.ucm.v0.1",
        epoch_code=epoch,
    )


def passport(role: str = "USER"):
    return create_passport(public_key_hex=public_hex(), role=role, namespace=namespace())

