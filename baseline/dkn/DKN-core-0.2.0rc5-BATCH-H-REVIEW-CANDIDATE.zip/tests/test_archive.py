import unittest

from dkn_core.archive import build_portable_archive, verify_portable_archive
from dkn_core.errors import DKNRefusal

from tests.helpers import key, namespace, passport


class ArchiveTests(unittest.TestCase):
    def test_unbound_archive_is_deterministic_and_not_self_certified(self):
        payloads = {"README.md": b"public\n", "src/example.txt": b"exact\n"}
        first = build_portable_archive(payloads=payloads)
        second = build_portable_archive(payloads=dict(reversed(list(payloads.items()))))
        self.assertEqual(first, second)
        result = verify_portable_archive(first)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["certificate_status"], "READY_FOR_EXTERNAL_DKN_CERTIFICATION")
        self.assertFalse(result["private_material_found"])

    def test_bound_archive_self_certificate_verifies(self):
        raw = build_portable_archive(payloads={"payload.txt": b"payload"},
                                     namespace=namespace(), passport=passport(),
                                     private_key=key())
        result = verify_portable_archive(raw)
        self.assertEqual(result["certificate_status"], "PASS_SELF_CERTIFIED")
        self.assertEqual(result["authority_effect"], "NONE")

    def test_private_key_path_and_pem_refused(self):
        with self.assertRaises(DKNRefusal) as raised:
            build_portable_archive(payloads={"secret.pem": b"not even a key"})
        self.assertEqual(raised.exception.code, "DKN_ARCHIVE_CREDENTIAL_MATERIAL_REFUSED")
        pem = b"-----BEGIN " + b"PRIVATE KEY-----\nabc\n"
        with self.assertRaises(DKNRefusal):
            build_portable_archive(payloads={"notes.txt": pem})

    def test_archive_byte_mutation_refused(self):
        raw = bytearray(build_portable_archive(payloads={"a.txt": b"a"}))
        raw[len(raw) // 2] ^= 1
        with self.assertRaises(DKNRefusal):
            verify_portable_archive(bytes(raw))


if __name__ == "__main__":
    unittest.main()

