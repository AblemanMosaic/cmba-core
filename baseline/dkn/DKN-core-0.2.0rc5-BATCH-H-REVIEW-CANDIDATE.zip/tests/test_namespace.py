import unittest

from dkn_core.canonical import canonical_bytes, strict_load_canonical, strict_loads
from dkn_core.errors import DKNRefusal
from dkn_core.namespace import derive_namespace, verify_namespace

from tests.helpers import namespace, public_hex


class CanonicalNamespaceTests(unittest.TestCase):
    def test_exact_is_deterministic(self):
        first = namespace()
        second = namespace()
        self.assertEqual(first, second)
        self.assertEqual(verify_namespace(first), first)
        self.assertEqual(first["material"]["namespace_kind"], "EXACT")

    def test_wildcard_is_explicit_and_not_authority(self):
        value = namespace(wildcard=True)
        self.assertEqual(value["material"]["semantic_namespace"], "mosaic.ucm")
        self.assertEqual(value["material"]["namespace_kind"], "WILDCARD_TERMINAL")
        self.assertFalse(value["wildcard_grants_subnamespace_authority"])
        self.assertNotEqual(value["namespace_id"], namespace()["namespace_id"])

    def test_domain_epoch_purpose_and_key_substitution_change_id(self):
        base = namespace()["namespace_id"]
        variants = [
            derive_namespace(semantic_namespace="mosaic.ucm.v0.1", public_key_hex=public_hex(),
                             purpose="release", nonce="mosaic.ucm.v0.1", epoch_code="e0001"),
            derive_namespace(semantic_namespace="mosaic.ucm.v0.1", public_key_hex=public_hex(),
                             purpose="collaboration", nonce="other.domain", epoch_code="e0001"),
            namespace(epoch="e0002"),
        ]
        self.assertTrue(all(item["namespace_id"] != base for item in variants))

    def test_namespace_laundering_refused(self):
        for bad in ("Mosaic.ucm", "mosaic.*.ucm", "mosaic..ucm", "mosaic.ucm*", "*.mosaic"):
            with self.subTest(bad=bad), self.assertRaises(DKNRefusal) as raised:
                derive_namespace(semantic_namespace=bad, public_key_hex=public_hex(),
                                 purpose="collaboration", nonce="domain", epoch_code="e1")
            self.assertEqual(raised.exception.code, "DKN_NAMESPACE_INVALID")

    def test_canonical_parser_refuses_duplicate_float_and_noncanonical(self):
        with self.assertRaisesRegex(DKNRefusal, "DKN_CANONICAL_DUPLICATE_KEY"):
            strict_loads(b'{"a":1,"a":2}')
        with self.assertRaisesRegex(DKNRefusal, "DKN_CANONICAL_NUMBER_INVALID"):
            strict_loads(b'{"a":1.0}')
        with self.assertRaisesRegex(DKNRefusal, "DKN_CANONICAL_JSON_NOT_CANONICAL"):
            strict_load_canonical(b'{"b":2, "a":1}')
        value = {"z": 1, "a": "unicode-\u03bb"}
        self.assertEqual(strict_load_canonical(canonical_bytes(value)), value)


if __name__ == "__main__":
    unittest.main()

