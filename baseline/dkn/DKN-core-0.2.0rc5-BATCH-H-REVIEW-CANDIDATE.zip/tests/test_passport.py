import tempfile
import unittest
from pathlib import Path

from dkn_core.ceremony import load_encrypted_private_key, new_key_ceremony
from dkn_core.crypto import mosaic_id, public_key_hex
from dkn_core.errors import DKNRefusal
from dkn_core.passport import import_mosaic_id, verify_passport

from tests.helpers import passport, public_hex


class PassportTests(unittest.TestCase):
    def test_public_passport_and_mosaic_import(self):
        value = passport()
        self.assertEqual(verify_passport(value), value)
        self.assertEqual(value["mosaic_id"], mosaic_id(public_hex()))
        self.assertTrue(value["public_material_only"])
        self.assertFalse(value["permission_granted"])
        imported = import_mosaic_id(mosaic_id_value=value["mosaic_id"],
                                    public_key_hex=public_hex(), role="USER")
        self.assertEqual(imported["status"], "PASS_KEY_DERIVATION")

    def test_mosaic_key_substitution_refused(self):
        with self.assertRaises(DKNRefusal) as raised:
            import_mosaic_id(mosaic_id_value="00" * 32,
                             public_key_hex=public_hex(), role="USER")
        self.assertEqual(raised.exception.code, "DKN_MOSAIC_ID_MISMATCH")

    def test_passport_namespace_key_substitution_refused(self):
        value = passport()
        forged = dict(value)
        forged["mosaic_id"] = "00" * 32
        with self.assertRaises(DKNRefusal):
            verify_passport(forged)

    def test_new_key_ceremony_separates_encrypted_private_material(self):
        with tempfile.TemporaryDirectory() as raw:
            private_path = Path(raw) / "user.pk8"
            passport_path = Path(raw) / "user-passport.json"
            result = new_key_ceremony(
                role="AGENT", passphrase=b"correct horse battery staple",
                private_out=private_path, passport_out=passport_path,
                semantic_namespace="example.agent",
            )
            self.assertIn(b"BEGIN ENCRYPTED PRIVATE KEY", private_path.read_bytes())
            self.assertNotIn(b"PRIVATE KEY", passport_path.read_bytes())
            key = load_encrypted_private_key(private_path, b"correct horse battery staple")
            self.assertEqual(public_key_hex(key), result["passport"]["public_key_hex"])
            self.assertEqual(verify_passport(result["passport"]), result["passport"])

    def test_ceremony_never_overwrites(self):
        with tempfile.TemporaryDirectory() as raw:
            private_path = Path(raw) / "exists.pk8"
            passport_path = Path(raw) / "passport.json"
            private_path.write_bytes(b"existing")
            with self.assertRaises(DKNRefusal) as raised:
                new_key_ceremony(role="USER", passphrase=b"long enough password",
                                 private_out=private_path, passport_out=passport_path)
            self.assertEqual(raised.exception.code, "DKN_CEREMONY_OUTPUT_EXISTS")
            self.assertEqual(private_path.read_bytes(), b"existing")


if __name__ == "__main__":
    unittest.main()

