import hashlib
import unittest

from dkn_core.errors import DKNRefusal
from dkn_core.records import (
    build_collaborator_attestation,
    build_constitutional_change,
    build_epoch_transition,
    build_revocation_supersession,
    sign_record,
    verify_signed_record,
)
from dkn_core.thr import build_thr_manifest, verify_thr_manifest

from tests.helpers import key, namespace, passport, public_hex


class RecordTests(unittest.TestCase):
    def test_thr_domains_are_distinct_and_verified(self):
        manifest = build_thr_manifest(state={"x": 1}, semantic={"x": 1}, governance={"x": 1})
        commitments = manifest["commitments"]
        self.assertEqual(len(set(commitments.values())), 3)
        self.assertEqual(verify_thr_manifest(manifest), manifest)
        forged = {**manifest, "commitments": {**commitments, "state_hash": commitments["semantic_hash"]}}
        with self.assertRaises(DKNRefusal):
            verify_thr_manifest(forged)

    def test_constitutional_change_signature_and_identity(self):
        p = passport()
        body = build_constitutional_change(
            base_thr_manifest_hash="11" * 32,
            result_thr_manifest_hash="22" * 32,
            changed_objects=[{
                "path": "docs/PROTOCOL.md", "before_sha256": "33" * 32,
                "after_sha256": "44" * 32, "semantic_role": "PROTOCOL",
            }],
            acceptance_case_hashes=["55" * 32],
            namespace_binding_hash=namespace()["namespace_binding_hash"],
            epoch_code="e0001", engineering_revision="r002",
            author_subject_id=p["subject_id"],
        )
        record = sign_record(record_type="CONSTITUTIONAL_CHANGE", body=body,
                             passport=p, private_key=key())
        self.assertEqual(verify_signed_record(record), record)
        forged = {**record, "signature_hex": "00" * 64}
        with self.assertRaises(DKNRefusal) as raised:
            verify_signed_record(forged)
        self.assertEqual(raised.exception.code, "DKN_RECORD_SIGNATURE_INVALID")

    def test_collaborator_signature_is_provenance_not_authority(self):
        p = passport("COLLABORATOR")
        body = build_collaborator_attestation(
            collaborator_subject_id=p["subject_id"], subject_hash="66" * 32,
            namespace_binding_hash=namespace()["namespace_binding_hash"],
            epoch_code="e0001", statement="I reviewed the exact subject bytes.")
        record = sign_record(record_type="COLLABORATOR_ATTESTATION", body=body,
                             passport=p, private_key=key())
        checked = verify_signed_record(record)
        self.assertFalse(checked["record_grants_authority"])
        self.assertFalse(checked["body"]["attestation_grants_authority"])

    def test_signed_identity_substitution_refused(self):
        p = passport("COLLABORATOR")
        body = build_collaborator_attestation(
            collaborator_subject_id=p["subject_id"], subject_hash="66" * 32,
            namespace_binding_hash=namespace()["namespace_binding_hash"],
            epoch_code="e0001", statement="statement")
        record = sign_record(record_type="COLLABORATOR_ATTESTATION", body=body,
                             passport=p, private_key=key())
        record["body"] = {**record["body"], "collaborator_subject_id": "dknid:v0.1:b3:" + "00" * 32}
        with self.assertRaises(DKNRefusal):
            verify_signed_record(record)

    def test_revocation_supersession_and_epoch_transition(self):
        p = passport()
        successor = "dknid:v0.1:b3:" + "77" * 32
        revocation = build_revocation_supersession(
            revoker_subject_id=p["subject_id"], target_subject_id=p["subject_id"],
            target_public_key_hex=public_hex(), disposition="SUPERSEDED",
            reason_code="KEY_ROTATION", effective_epoch_code="e0002",
            successor_subject_id=successor)
        self.assertEqual(verify_signed_record(sign_record(
            record_type="REVOCATION_SUPERSESSION", body=revocation,
            passport=p, private_key=key()))["body"]["disposition"], "SUPERSEDED")
        next_ns = namespace(epoch="e0002")
        transition = build_epoch_transition(
            author_subject_id=p["subject_id"],
            current_namespace_id=namespace()["namespace_id"],
            next_namespace_id=next_ns["namespace_id"], from_epoch_code="e0001",
            to_epoch_code="e0002", next_subject_id=p["subject_id"],
            reason_code="SCHEDULED_TRANSITION")
        self.assertEqual(verify_signed_record(sign_record(
            record_type="EPOCH_TRANSITION", body=transition,
            passport=p, private_key=key()))["body"]["to_epoch_code"], "e0002")


if __name__ == "__main__":
    unittest.main()

