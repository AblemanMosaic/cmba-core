import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import jsonschema

from dkn_core.abi import invoke
from dkn_core.canonical import strict_loads
from dkn_core.legacy import PROFILE, build_migration_binding, derive_ucm_legacy_dimension
from dkn_core.namespace import derive_namespace

from tests.helpers import namespace, public_hex

ROOT = Path(__file__).resolve().parents[1]


class AbiSchemaCompatibilityTests(unittest.TestCase):
    def test_abi_success_and_typed_refusal(self):
        request = {
            "schema": "dkn.abi-request.v0.1", "request_id": "r1",
            "operation": "namespace.derive", "arguments": {
                "semantic_namespace": "mosaic.ucm.v0.1",
                "public_key_hex": public_hex(), "purpose": "collaboration",
                "nonce": "mosaic.ucm.v0.1", "epoch_code": "e0001",
            }}
        response = invoke(request)
        self.assertTrue(response["ok"])
        refused = invoke({**request, "operation": "unknown"})
        self.assertFalse(refused["ok"])
        self.assertEqual(refused["refusal"]["code"], "DKN_ABI_OPERATION_UNKNOWN")

    def test_cli_and_abi_namespace_parity(self):
        command = [sys.executable, "-m", "dkn_core", "namespace", "derive",
                   "--semantic-namespace", "mosaic.ucm.v0.1",
                   "--public-key-hex", public_hex(), "--purpose", "collaboration",
                   "--nonce", "mosaic.ucm.v0.1", "--epoch-code", "e0001"]
        completed = subprocess.run(command, cwd=ROOT, env={**__import__("os").environ,
            "PYTHONPATH": str(ROOT / "src")}, capture_output=True, check=True)
        cli = json.loads(completed.stdout)
        self.assertEqual(cli, namespace())
        with tempfile.TemporaryDirectory() as raw:
            request = Path(raw) / "request.json"
            request.write_bytes(b'{"schema":"dkn.abi-request.v0.1", "request_id":"x","operation":"unknown","arguments":{}}')
            refused = subprocess.run(
                [sys.executable, "-m", "dkn_core", "abi", str(request)], cwd=ROOT,
                env={**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")},
                capture_output=True)
            self.assertEqual(refused.returncode, 2)
            self.assertEqual(json.loads(refused.stdout)["code"],
                             "DKN_CANONICAL_JSON_NOT_CANONICAL")

    def test_json_schemas_accept_reference_objects(self):
        schema_dir = ROOT / "schemas"
        ns_schema = json.loads((schema_dir / "namespace.schema.json").read_text())
        resolver = jsonschema.RefResolver(base_uri=schema_dir.as_uri() + "/",
                                          referrer=ns_schema)
        jsonschema.validate(namespace(), ns_schema, resolver=resolver)

    def test_ucm_legacy_profile_is_explicit_not_canonical(self):
        legacy = derive_ucm_legacy_dimension(phase_code="mosaic.ucm.v0.1",
                                             public_key_hex=public_hex())
        self.assertEqual(legacy["profile_id"], PROFILE)
        self.assertFalse(legacy["canonical_dkn_namespace"])
        migration = build_migration_binding(phase_code="mosaic.ucm.v0.1",
                                             public_key_hex=public_hex(),
                                             namespace=namespace())
        self.assertEqual(migration["migration_status"], "PROPOSED_REBINDING_ONLY")
        self.assertTrue(migration["consumer_admission_required"])
        self.assertNotEqual(legacy["dimension_id"], namespace()["namespace_id"].split(":")[-1])

    def test_pinned_ucm_r030_reference_is_non_authorizing(self):
        reference = strict_loads((ROOT / "acceptance" / "UCM-R030-REFERENCE.json").read_bytes())
        schema = json.loads((ROOT / "schemas" / "upstream-reference.schema.json").read_text())
        jsonschema.validate(reference, schema)
        self.assertEqual(reference["r030"]["source_root"],
            "7ada98546cbd1330eeaca3f01125a3e428d047a427fc5cd34ba395acf52b5e07")
        self.assertEqual(reference["r030"]["qualification"]["root"],
            "25436291af27ecfadfc4c8babb2b8ba4adc348851a87d3751e4f8f0c8e8c259e")
        self.assertEqual(reference["r030"]["qualification"]["test_count"], 448)
        self.assertEqual(reference["r030"]["qualification"]["status"], "PASS")
        self.assertEqual(reference["pin_status"], "EXACT_READ_ONLY_REFERENCE")
        self.assertEqual(reference["standing"], "INFORMATION_ONLY")
        self.assertEqual(reference["authority_effect"], "NONE")
        self.assertIn("UCM_AUTHORITY_MODEL", reference["not_inherited"])


if __name__ == "__main__":
    unittest.main()

