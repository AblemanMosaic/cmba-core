import unittest
from pathlib import Path

from dkn_core.canonical import canonical_bytes, strict_loads

from tools.build_vectors import build_vectors

ROOT = Path(__file__).resolve().parents[1]


class GoldenVectorTests(unittest.TestCase):
    def test_checked_vectors_are_fresh(self):
        expected = canonical_bytes(build_vectors()) + b"\n"
        actual = (ROOT / "vectors" / "golden-vectors.json").read_bytes()
        self.assertEqual(actual, expected)
        parsed = strict_loads(actual)
        self.assertEqual(parsed["public_version"], "v0.1")
        self.assertEqual(parsed["engineering_revision"], "r002")


if __name__ == "__main__":
    unittest.main()

