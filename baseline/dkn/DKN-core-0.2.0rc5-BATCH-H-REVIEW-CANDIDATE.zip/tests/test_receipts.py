import hashlib
import unittest

from dkn_core.errors import DKNRefusal
from dkn_core.records import (
    build_publication_receipt,
    build_retrieval_receipt,
    build_storage_locator,
    sign_record,
    verify_retrieval_receipt,
    verify_signed_record,
    verify_storage_locator,
)
from dkn_core.thr import build_thr_manifest

from tests.helpers import key, namespace, passport


class ReceiptTests(unittest.TestCase):
    def _publication(self, artifact: bytes):
        p = passport()
        artifact_hash = hashlib.sha256(artifact).hexdigest()
        locator = build_storage_locator(provider_id="GITHUB",
            locator="https://github.example/releases/dkn.zip", artifact_sha256=artifact_hash)
        thr = build_thr_manifest(state={"artifact": artifact_hash},
                                 semantic={"role": "release"},
                                 governance={"publication_authorized": False})
        body = build_publication_receipt(
            publisher_subject_id=p["subject_id"], artifact_sha256=artifact_hash,
            thr_manifest=thr, namespace_binding_hash=namespace()["namespace_binding_hash"],
            storage_locator=locator, published_epoch_code="e0001")
        return sign_record(record_type="PUBLICATION_RECEIPT", body=body,
                           passport=p, private_key=key())

    def test_publication_and_after_the_fact_retrieval(self):
        artifact = b"exact artifact bytes"
        publication = self._publication(artifact)
        verify_signed_record(publication)
        p = passport()
        body = build_retrieval_receipt(
            retriever_subject_id=p["subject_id"], publication_receipt=publication,
            artifact_bytes=artifact, retrieved_epoch_code="e0002")
        receipt = sign_record(record_type="RETRIEVAL_RECEIPT", body=body,
                              passport=p, private_key=key())
        self.assertEqual(verify_retrieval_receipt(
            receipt=receipt, publication_receipt=publication,
            artifact_bytes=artifact), receipt)
        with self.assertRaises(DKNRefusal) as raised:
            verify_retrieval_receipt(receipt=receipt, publication_receipt=publication,
                                     artifact_bytes=artifact + b"mutated")
        self.assertEqual(raised.exception.code, "DKN_RECEIPT_ARTIFACT_MISMATCH")

    def test_retrieval_creation_refuses_mutated_bytes(self):
        publication = self._publication(b"original")
        with self.assertRaises(DKNRefusal):
            build_retrieval_receipt(
                retriever_subject_id=passport()["subject_id"],
                publication_receipt=publication, artifact_bytes=b"changed",
                retrieved_epoch_code="e0002")

    def test_locator_rechecks_credentials(self):
        with self.assertRaises(DKNRefusal) as raised:
            build_storage_locator(provider_id="HTTPS",
                locator="https://example.invalid/a?token=secret", artifact_sha256="00" * 32)
        self.assertEqual(raised.exception.code, "DKN_STORAGE_LOCATOR_CONTAINS_CREDENTIAL")
        good = build_storage_locator(provider_id="OFFLINE", locator="media/volume-1/dkn.zip",
                                     artifact_sha256="00" * 32)
        forged = {**good, "locator": "media/dkn.zip?password=x"}
        with self.assertRaises(DKNRefusal):
            verify_storage_locator(forged)


if __name__ == "__main__":
    unittest.main()

