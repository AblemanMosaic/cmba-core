# DKN Core 0.2.0rc5 — Batch H review candidate

**Portable cryptographic bindings, reader-owned evidence policy, explicit limits.**
This is the consolidated A–H reference library and dossier, not an independently
approved production trust root. Public release remains **NOT_CLEARED**.

Start at **[the consolidated documentation](docs/release/README.md)**.

| Layer | Delivered purpose | Protocol selection |
|---|---|---|
| `dkn_v02` | Commit, package, certify, inspect and verify artifacts | `v0.2-candidate` |
| Navigation and assurance | Local discovery, typed relationships, finite evidence contracts | Base candidate |
| `dkn_v02.lifecycle`, `vault` | Exact grants, revocation, precommitted recovery, cooperative transactions | Opt-in LC-F1 |
| `dkn_v02.distributed`, `simulation` | Supplied-view evaluation, deterministic finite schedules and replay | Opt-in DS-G1 |
| `dkn_core` | Preserved v0.1 r002 implementation | Optional genuine BLAKE3 legacy track |

## Install and start

```sh
python -m pip install .
python examples/v02_publish_verify.py
python examples/v02_reader_policy.py
python examples/v02_lifecycle_vault.py
python examples/v02_distributed_simulation.py
```

The wheel contains runtime library/CLI code. The source archive additionally contains
all models, schemas, tests, public fixture corpora and evidence. It is required for review
or replacement-realization work. `pip install '.[test,legacy]'` requests the test and
legacy dependencies; do not substitute another hash function when BLAKE3 is absent.

## What H changes

No runtime module, protocol schema, frozen conformance corpus, or semantic commitment is
changed from G. H fixes the conformance **test oracle** to require exact canonical response
bytes (including JSON boolean/integer distinction and null-envelope refusal), adds
source/context-bound review gates, and consolidates current documentation and release
provenance. These are tooling corrections, not a new operational namespace profile.

## Reproduce the review

```sh
python tools/verify_batch_h.py --out /tmp/dkn-h --phase tests
python tools/verify_batch_h.py --out /tmp/dkn-h --phase examples
python tools/verify_batch_h.py --out /tmp/dkn-h --phase audit
python tools/verify_batch_h.py --out /tmp/dkn-h --phase assemble
```

Use one unchanged source tree and one environment for all phases. Add `--require-legacy`
to every command to make the legacy leg gating. Without it, an explicitly blocked legacy
leg does not turn into a successful legacy test result. See the [replay guide](docs/release/REPLAY.md).

## Trust boundary

A verified signature is not truth. A matching supplied view is not global currentness,
recognition, or permission to execute. The reader owns its expected artifact/publisher/
namespace pins, clock, policy and independently protected rollback floor. Storage transport
and authority decisions remain separate. There is no automatic key custody, secret scrubber,
network deployment, consensus protocol, or universal semantic-equivalence proof.

LC-F1 has a finite 256-event journal and requires recovery policy at genesis. No guardian
policy amendment or subdelegation is implemented. SQLite guarantees are scoped to cooperating
clients on a trusted local filesystem, not hostile-host custody or proven physical-power-loss
behavior. DS-G1 simulation is not production network evidence.

## Exact release boundary

`BATCH-H-FILE-MANIFEST.json` covers every other member. The external SHA-256 binds the final
ZIP; an unsigned checksum is meaningful relative to an independently trusted expected value.
Every earlier manifest/certificate/receipt is historical for its named predecessor. The
exact Batch G predecessor hash is recorded in `release/REVIEW-BASELINE.json` and
`META/V02-CANDIDATE-BOUNDARY.json`.

The original fifty-obligation ledger remains 35 scoped passes and fifteen explicit limits.
The three frozen semantic models contain 42 traceable obligations, not 42 universal proofs.
Actual counts and environment details are in `evidence/batch-h/local-run/H-REVIEW.json` and
the separate post-freeze replay receipt. All evidence is same-author engineering evidence.
No publication, authority promotion, external review submission, or forced migration occurs.
