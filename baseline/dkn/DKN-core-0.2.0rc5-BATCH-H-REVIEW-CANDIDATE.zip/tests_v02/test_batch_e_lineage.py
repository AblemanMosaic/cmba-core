import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import *

A=Ed25519PrivateKey.from_private_bytes(b'\x31'*32)
B=Ed25519PrivateKey.from_private_bytes(b'\x32'*32)
C=Ed25519PrivateKey.from_private_bytes(b'\x33'*32)

def genesis():return declare_genesis(semantic_name='new.app',purpose='publisher',nonce='initial',key=A)

def test_standalone_genesis_needs_no_legacy_placeholder():
    g=genesis();r=verify_genesis(g)
    assert g['legacy_instance'] is None and r['legacy_binding']=='NOT_APPLICABLE'

def test_unverified_legacy_anchor_explicit():
    g=declare_genesis(semantic_name='new.app',purpose='publisher',nonce='initial',key=A,legacy_instance='dkn:v0.1:b3:'+'11'*32)
    assert verify_genesis(g)['legacy_binding']=='NOT_ESTABLISHED'

def test_two_valid_successors_retained_without_winner():
    g=genesis();b=transition(g,A,key_hex(B),epoch=1);c=transition(g,A,key_hex(C),epoch=1)
    r=analyze_lineage(g,[[b],[c]])
    assert r['fork_evidence']=='OBSERVED' and len(r['forks'])==1 and r['selected_head'] is None
    assert r==analyze_lineage(g,[[c],[b]])

def test_unique_chain_cannot_prove_no_hidden_fork():
    g=genesis();b=transition(g,A,key_hex(B),epoch=1)
    r=analyze_lineage(g,[[b]])
    assert r['fork_evidence']=='NOT_OBSERVED_IN_SUPPLIED_CHAINS' and r['global_head']=='NOT_ESTABLISHED'

def test_same_chain_twice_does_not_create_fork():
    g=genesis();b=transition(g,A,key_hex(B),epoch=1)
    assert analyze_lineage(g,[[b],[b]])['forks']==[]

def test_chains_must_be_verified_not_just_counted():
    g=genesis();b=transition(g,A,key_hex(B),epoch=1);b['signature_hex']='00'*64
    with pytest.raises(Refusal):analyze_lineage(g,[[b]])

def test_rotation_keeps_genesis_root():
    g=genesis();b=transition(g,A,key_hex(B),epoch=1)
    c=transition(g,B,key_hex(C),epoch=2,previous_transition_hash=b['transition_hash'])
    assert b['namespace_root']==c['namespace_root']==g['namespace_root']
    assert verify_transitions(g,[b,c])['active_key']==key_hex(C)

@pytest.mark.parametrize('chains',[[],[None],[[{}]],{},[[]]*65])
def test_malformed_chain_collection_refuses(chains):
    with pytest.raises(Refusal):analyze_lineage(genesis(),chains)
