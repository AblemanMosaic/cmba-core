"""LC-F1 positive behavior, hostile inputs and explicit claim ceilings."""
from copy import deepcopy
import hashlib
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import pack, certify, declare_genesis, key_hex, Refusal, canonical
from dkn_v02 import lifecycle as lc


def key(label):
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(label.encode()).digest())


@pytest.fixture
def setup():
    owner, delegate, successor = [key(s) for s in ('owner', 'delegate', 'successor')]
    guardians = sorted([key('guardian-a'), key('guardian-b'), key('guardian-c')], key=key_hex)
    policy = lc.lifecycle_policy(recovery_keys=[key_hex(k) for k in guardians], recovery_threshold=2,
                                 allowed_operations=['certify_artifact', 'publish_artifact'], max_grant_seconds=1000)
    genesis = declare_genesis(semantic_name='test.lifecycle', purpose='publisher', nonce='test',
                              key=owner, recovery_policy_ref=lc.policy_reference(policy))
    raw, manifest = pack({'a.txt': b'artifact'})
    return owner, delegate, successor, guardians, policy, genesis, raw, manifest


def event(setup, events, kind, payload, keys=None, issued=10):
    owner, delegate, successor, guardians, policy, genesis, raw, manifest = setup
    return lc.make_event(genesis, policy, events, kind=kind, payload=payload, issued_at=issued,
                         signing_keys=[owner] if keys is None else keys)


def grant(setup, events=None, **overrides):
    _, delegate, _, _, _, _, _, manifest = setup
    payload = dict(subject_public_key_hex=key_hex(delegate), artifact_root=manifest['logical_root'],
                   operations=['certify_artifact'], not_before=10, expires_at=100)
    payload.update(overrides)
    return event(setup, events or [], 'delegate', payload)


def assessment(setup, events, *, signer=None, now=20, **overrides):
    owner, delegate, successor, guardians, policy, genesis, raw, manifest = setup
    state = lc.verify_journal(genesis, policy, events)
    checkpoint = overrides.get('checkpoint')
    if 'checkpoint' not in overrides:
        checkpoint = lc.make_checkpoint(genesis, policy, events, issued_at=now, expires_at=now+100, key=signer or owner)
    args = dict(expected_namespace=genesis['namespace_root'], expected_head=state['head_ref'],
                subject_public_key_hex=key_hex(delegate), artifact_root=manifest['logical_root'],
                operation='certify_artifact', now=now, max_checkpoint_age=60, checkpoint=checkpoint)
    args.update(overrides)
    return lc.assess_delegation(genesis, policy, events, **args)


def test_exact_delegate_and_certificate_inspection(setup):
    owner, delegate, _, _, policy, genesis, raw, manifest = setup
    events = [grant(setup)]
    result = assessment(setup, events)
    assert result['status'] == 'MATCH_FOR_SUPPLIED_VIEW'
    assert result['authority_effect'] == 'NONE' and result['acceptance'] == 'EXTERNAL_DECISION_REQUIRED'
    assert result['subject_possession'] == 'NOT_CHECKED' and result['global_currentness'] == 'NOT_ESTABLISHED'
    certificate = certify(manifest, delegate, namespace_root=genesis['namespace_root'])
    checkpoint = lc.make_checkpoint(genesis, policy, events, issued_at=20, expires_at=40, key=owner)
    combined = lc.inspect_with_lifecycle(raw, certificate, genesis, policy, events,
            expected_namespace=genesis['namespace_root'], expected_head=events[-1]['event_ref'],
            now=20, max_checkpoint_age=20, checkpoint=checkpoint)
    assert combined['artifact']['status'] == 'PASS'
    assert combined['lifecycle']['subject_possession'] == 'SIGNATURE_VERIFIED'
    assert combined['lifecycle']['status'] == 'MATCH_FOR_SUPPLIED_VIEW'


@pytest.mark.parametrize('mutation', [dict(artifact_root='a'*64), dict(operation='publish_artifact'),
                                      dict(operation='unlisted'), dict(subject_public_key_hex=key_hex(key('outsider')))])
def test_scope_does_not_widen(setup, mutation):
    assert assessment(setup, [grant(setup)], **mutation)['status'] == 'NO_MATCH'


@pytest.mark.parametrize('at,expected', [(9, 'NO_MATCH'), (10, 'MATCH_FOR_SUPPLIED_VIEW'),
                                       (99, 'MATCH_FOR_SUPPLIED_VIEW'), (100, 'NO_MATCH')])
def test_expiry_boundaries(setup, at, expected):
    # Grant issued at 0; exact interval, no clock-dependent test scheduling.
    payload = dict(subject_public_key_hex=key_hex(setup[1]), artifact_root=setup[-1]['logical_root'],
                   operations=['certify_artifact'], not_before=10, expires_at=100)
    e = event(setup, [], 'delegate', payload, issued=0)
    assert assessment(setup, [e], now=at)['status'] == expected


def test_revoke_and_omission_require_pinned_head(setup):
    first = grant(setup)
    revoke = event(setup, [first], 'revoke_grant', {'grant_ref': first['event_ref']}, issued=15)
    assert assessment(setup, [first, revoke])['status'] == 'NO_MATCH'
    with pytest.raises(Refusal, match='PIN_MISMATCH'):
        assessment(setup, [first], expected_head=revoke['event_ref'])
    # An old still-valid reader pin/checkpoint can still match: no global-currentness fiction.
    assert assessment(setup, [first])['status'] == 'MATCH_FOR_SUPPLIED_VIEW'


def test_revoked_delegate_cannot_be_regranted(setup):
    first = grant(setup)
    revoked = event(setup, [first], 'revoke_key', {'public_key_hex': key_hex(setup[1])}, issued=10)
    assert assessment(setup, [first, revoked])['reason'] == 'KEY_REVOKED_IN_SUPPLIED_VIEW'
    with pytest.raises(Refusal, match='RETIRED_KEY'):
        grant(setup, [first, revoked])


def test_no_subdelegation(setup):
    with pytest.raises(Refusal, match='SIGNER_UNAUTHORIZED'):
        event(setup, [grant(setup)], 'delegate', dict(subject_public_key_hex=key_hex(key('other')),
              artifact_root=setup[-1]['logical_root'], operations=['certify_artifact'], not_before=10, expires_at=50),
              keys=[setup[1]])


def test_suspend_resume_never_revives_grants(setup):
    first = grant(setup)
    suspend = event(setup, [first], 'suspend', {'reason': 'incident'})
    assert assessment(setup, [first, suspend])['reason'] == 'NAMESPACE_SUSPENDED'
    resume = event(setup, [first, suspend], 'resume', {'reason': 'repaired'})
    assert assessment(setup, [first, suspend, resume])['status'] == 'NO_MATCH'
    new = grant(setup, [first, suspend, resume])
    assert assessment(setup, [first, suspend, resume, new])['status'] == 'MATCH_FOR_SUPPLIED_VIEW'


def test_rotation_requires_possession_and_invalidates_grants(setup):
    owner, _, successor, _, policy, genesis, _, _ = setup
    first = grant(setup)
    with pytest.raises(Refusal, match='SIGNER_UNAUTHORIZED'):
        event(setup, [first], 'rotate', {'successor_public_key_hex': key_hex(successor)})
    rotated = event(setup, [first], 'rotate', {'successor_public_key_hex': key_hex(successor)}, keys=[owner, successor])
    state = lc.verify_journal(genesis, policy, [first, rotated])
    assert state['epoch'] == 1 and state['active_key'] == key_hex(successor)
    assert state['namespace_root'] == genesis['namespace_root']
    assert assessment(setup, [first, rotated], signer=successor)['status'] == 'NO_MATCH'
    with pytest.raises(Refusal, match='SIGNER_UNAUTHORIZED'):
        event(setup, [first, rotated], 'suspend', {'reason': 'old-key'})
    with pytest.raises(Refusal, match='RETIRED_KEY'):
        event(setup, [first, rotated], 'rotate', {'successor_public_key_hex': key_hex(owner)}, keys=[successor, owner])


def test_threshold_recovery_without_old_controller(setup):
    _, _, successor, guardians, policy, genesis, _, _ = setup
    first = grant(setup)
    suspend = event(setup, [first], 'suspend', {'reason': 'lost-controller'})
    recovered = event(setup, [first, suspend], 'recover', {'successor_public_key_hex': key_hex(successor)},
                      keys=guardians[:2] + [successor])
    state = lc.verify_journal(genesis, policy, [first, suspend, recovered])
    assert state['active_key'] == key_hex(successor) and not state['suspended']
    assert assessment(setup, [first, suspend, recovered], signer=successor)['status'] == 'NO_MATCH'


@pytest.mark.parametrize('case', ['one', 'duplicate', 'outsider', 'no_successor', 'owner_only', 'bad_signature'])
def test_bad_recovery_proofs(setup, case):
    owner, _, successor, guardians, policy, genesis, _, _ = setup
    sets = {'one': [guardians[0], successor], 'duplicate': [guardians[0], guardians[0], successor],
            'outsider': [guardians[0], key('stranger'), successor], 'no_successor': guardians[:2],
            'owner_only': [owner, successor]}
    if case == 'bad_signature':
        e = event(setup, [], 'recover', {'successor_public_key_hex': key_hex(successor)}, keys=guardians[:2]+[successor])
        e['signatures'][0]['signature_hex'] = '00'*64
        with pytest.raises(Refusal): lc.verify_journal(genesis, policy, [e])
    else:
        with pytest.raises(Refusal):
            event(setup, [], 'recover', {'successor_public_key_hex': key_hex(successor)}, keys=sets[case])


def test_no_retroactive_policy_or_recovery(setup):
    owner, _, _, _, policy, genesis, _, _ = setup
    unbound = declare_genesis(semantic_name='test.unbound', purpose='publisher', nonce='test', key=owner)
    with pytest.raises(Refusal, match='POLICY_UNBOUND'): lc.verify_journal(unbound, policy, [])
    alternate = deepcopy(policy); alternate['max_grant_seconds'] += 1
    with pytest.raises(Refusal, match='POLICY_UNBOUND'): lc.verify_journal(genesis, alternate, [])


def test_recovery_disabled_is_explicit(setup):
    owner, _, successor, _, _, _, _, _ = setup
    policy = lc.lifecycle_policy(recovery_keys=[], recovery_threshold=0, allowed_operations=['certify_artifact'])
    genesis = declare_genesis(semantic_name='test.none', purpose='publisher', nonce='test', key=owner,
                             recovery_policy_ref=lc.policy_reference(policy))
    with pytest.raises(Refusal, match='RECOVERY_DISABLED'):
        lc.make_event(genesis, policy, [], kind='recover', payload={'successor_public_key_hex': key_hex(successor)},
                      issued_at=10, signing_keys=[successor])


@pytest.mark.parametrize('field,value', [('recovery_threshold', True), ('recovery_threshold', 0),
    ('recovery_threshold',4), ('max_grant_seconds',0), ('max_grant_seconds',True),
    ('recovery_keys', ['01'+'00'*31]), ('allowed_operations',[]), ('allowed_operations',['*']),
    ('allowed_operations',['z','a']), ('allowed_operations',['a','a']), ('schema','wrong')])
def test_bad_policy(setup, field, value):
    policy = deepcopy(setup[4]); policy[field] = value
    with pytest.raises(Refusal): lc.validate_policy(policy)


@pytest.mark.parametrize('payload', [dict(operations=['*']), dict(operations=['recover']),
    dict(not_before=True), dict(not_before=9), dict(expires_at=10), dict(expires_at=1011),
    dict(artifact_root='*'), dict(subject_public_key_hex='01'+'00'*31), dict(extra='ignored')])
def test_bad_grant(setup, payload):
    with pytest.raises(Refusal): grant(setup, **payload)


@pytest.mark.parametrize('mutation', ['sequence', 'previous', 'namespace', 'signature', 'event_hash', 'unknown', 'future', 'reorder', 'extra'])
def test_event_mutation_refuses(setup, mutation):
    first = grant(setup); events = [first]
    if mutation == 'future':
        with pytest.raises(Refusal, match='FUTURE_EVENT'):
            assessment(setup, events, now=5, checkpoint=None)
        return
    if mutation == 'reorder':
        second = event(setup, events, 'suspend', {'reason': 'incident'})
        events = [second, first]
    elif mutation == 'signature': first['signatures'][0]['signature_hex'] = '00'*64
    elif mutation == 'event_hash': first['event_ref'] = 'a'*64
    elif mutation == 'extra': first['extra'] = 'ignored'
    else:
        field, value = {'sequence':('sequence', 2), 'previous':('previous_ref','f'*64),
                        'namespace':('namespace_root','a'*64), 'unknown':('kind','new_kind')}[mutation]
        first['body'][field] = value
    with pytest.raises(Refusal): lc.verify_journal(setup[5], setup[4], events)


@pytest.mark.parametrize('kind,payload', [('resume',{'reason':'not suspended'}),
    ('revoke_grant', {'grant_ref':'a'*64}), ('revoke_key',{'public_key_hex':key_hex(key('owner'))})])
def test_invalid_state_transition(setup, kind, payload):
    with pytest.raises(Refusal): event(setup, [], kind, payload)


def test_forks_are_preserved_not_selected(setup):
    a = event(setup, [], 'suspend', {'reason': 'a'})
    b = event(setup, [], 'suspend', {'reason': 'b'})
    report = lc.analyze_journals(setup[5], setup[4], [[a], [b]])
    assert report['fork_evidence'] == 'OBSERVED' and len(report['forks']) == 1
    assert report['selected_head'] is None and report['authority_effect'] == 'NONE'


def test_prefix_floor_blocks_longer_alternate_fork(setup):
    first = grant(setup)
    alternate = event(setup, [], 'suspend', {'reason': 'alternate'})
    later = event(setup, [alternate], 'resume', {'reason': 'repaired'})
    with pytest.raises(Refusal, match='ROLLBACK_OR_FORK'):
        assessment(setup, [alternate,later], minimum={'sequence': 1, 'head_ref': first['event_ref']})
    floor = {'sequence':0,'head_ref':lc.lifecycle_anchor(setup[5], setup[4])}
    assert assessment(setup, [first], minimum=floor)['status'] == 'MATCH_FOR_SUPPLIED_VIEW'


def test_missing_checkpoint_is_indeterminate(setup):
    result = assessment(setup, [grant(setup)], checkpoint=None)
    assert result['status'] == 'INDETERMINATE' and result['checkpoint'] == 'NOT_CHECKED'


@pytest.mark.parametrize('case', ['expired', 'too_old', 'future', 'wrong_head', 'signature', 'old_controller'])
def test_bad_checkpoints(setup, case):
    owner, _, successor, _, policy, genesis, _, _ = setup
    events = [grant(setup)]
    cp = lc.make_checkpoint(genesis, policy, events, issued_at=10, expires_at=30, key=owner)
    overrides = dict(checkpoint=cp)
    if case == 'expired': overrides['now'] = 30
    elif case == 'too_old': overrides['max_checkpoint_age'] = 5
    elif case == 'future':
        cp = lc.make_checkpoint(genesis, policy, events, issued_at=21, expires_at=30, key=owner)
        overrides['checkpoint'] = cp
    elif case == 'wrong_head': cp['head_ref'] = 'a'*64
    elif case == 'signature': cp['signature_hex'] = '00'*64
    else:
        e = event(setup, events, 'rotate', {'successor_public_key_hex': key_hex(successor)}, keys=[owner,successor])
        events.append(e); overrides['signer'] = successor
    with pytest.raises(Refusal): assessment(setup, events, **overrides)


def test_actor_identity_does_not_become_authority(setup):
    result = assessment(setup, [], subject_public_key_hex=key_hex(setup[0]))
    assert result['status'] == 'MATCH_FOR_SUPPLIED_VIEW' and result['authority_effect'] == 'NONE'
    assert result['acceptance'] == 'EXTERNAL_DECISION_REQUIRED'


def test_protocols_are_not_interchangeable(setup):
    from dkn_v02 import transition
    owner, _, successor, _, policy, genesis, _, _ = setup
    legacy = transition(genesis, owner, key_hex(successor), epoch=1)
    with pytest.raises(Refusal): lc.verify_journal(genesis, policy, [legacy])


def test_epoch_invalidation_survives_recovery_and_new_grant(setup):
    owner, delegate, successor, guardians, policy, genesis, _, manifest = setup
    a = grant(setup)
    b = event(setup, [a], 'recover', {'successor_public_key_hex': key_hex(successor)}, keys=guardians[:2]+[successor])
    assert assessment(setup, [a,b], signer=successor)['matching_grants'] == []
    c = lc.make_event(genesis, policy, [a,b], kind='delegate', payload=a['body']['payload'],
                       issued_at=10, signing_keys=[successor])
    assert assessment(setup, [a,b,c], signer=successor)['matching_grants'] == [c['event_ref']]


def test_role_overlap_refused(setup):
    owner, _, _, guardians, policy, _, _, _ = setup
    genesis = declare_genesis(semantic_name='test.roles', purpose='publisher', nonce='test', key=guardians[0],
                             recovery_policy_ref=lc.policy_reference(policy))
    with pytest.raises(Refusal, match='ROLE_OVERLAP'): lc.verify_journal(genesis, policy, [])
    with pytest.raises(Refusal, match='ROLE_OVERLAP'): grant(setup, subject_public_key_hex=key_hex(guardians[0]))


def test_resource_bound(setup, monkeypatch):
    monkeypatch.setattr(lc, 'MAX_EVENTS', 0)
    with pytest.raises(Refusal, match='LIMIT'): lc.verify_journal(setup[5], setup[4], [grant_event_placeholder()])


def grant_event_placeholder():
    return {}


def test_certificate_cannot_override_subject_or_operation(setup):
    owner, delegate, _, _, policy, genesis, _, manifest = setup
    certificate = certify(manifest, delegate, namespace_root=genesis['namespace_root'])
    with pytest.raises(Refusal, match='ARGUMENT_INVALID'):
        lc.assess_certificate(certificate, manifest, genesis, policy, [], operation='publish_artifact')


def test_binding_does_not_change_with_transport_location(setup):
    policy, genesis = setup[4:6]
    first = lc.lifecycle_anchor(genesis, policy)
    assert first == lc.lifecycle_anchor(deepcopy(genesis), deepcopy(policy))
    assert canonical(lc.verify_journal(genesis, policy, []))


def test_separate_custodian_endorsements_need_no_private_key_aggregation(setup):
    _, _, successor, guardians, policy, genesis, _, _ = setup
    proposal=lc.prepare_event(genesis,policy,[],kind='recover',
                             payload={'successor_public_key_hex':key_hex(successor)},issued_at=10)
    # Separate participant calls receive the same public proposal and their own key only.
    one=lc.endorse_event(genesis,policy,[],proposal,guardians[0])
    two=lc.endorse_event(genesis,policy,[],proposal,guardians[1])
    possession=lc.endorse_event(genesis,policy,[],proposal,successor)
    assembled=lc.assemble_event(genesis,policy,[],proposal,[possession,two,one])
    assert lc.verify_journal(genesis,policy,[assembled])['active_key']==key_hex(successor)
    assert set(one)=={'public_key_hex','signature_hex'}
    with pytest.raises(Refusal):lc.assemble_event(genesis,policy,[],proposal,[possession,one,one])


def test_detached_proof_cannot_move_to_another_proposal(setup):
    _, _, successor, guardians, policy, genesis, _, _ = setup
    a=lc.prepare_event(genesis,policy,[],kind='recover',payload={'successor_public_key_hex':key_hex(successor)},issued_at=10)
    b=lc.prepare_event(genesis,policy,[],kind='recover',payload={'successor_public_key_hex':key_hex(successor)},issued_at=11)
    proofs=[lc.endorse_event(genesis,policy,[],a,k) for k in guardians[:2]+[successor]]
    with pytest.raises(Refusal,match='SIGNATURE_INVALID'):lc.assemble_event(genesis,policy,[],b,proofs)


def test_proposal_signer_rechecks_context_and_refuses_unknown_fields(setup):
    owner, _, successor, _, policy, genesis, _, _ = setup
    proposal=lc.prepare_event(genesis,policy,[],kind='rotate',payload={'successor_public_key_hex':key_hex(successor)},issued_at=10)
    proposal['body']['previous_ref']='a'*64
    with pytest.raises(Refusal,match='PROPOSAL_MISMATCH'):lc.endorse_event(genesis,policy,[],proposal,owner)
    proposal['extra']='hidden'
    with pytest.raises(Refusal,match='PROPOSAL_INVALID'):lc.endorse_event(genesis,policy,[],proposal,owner)
