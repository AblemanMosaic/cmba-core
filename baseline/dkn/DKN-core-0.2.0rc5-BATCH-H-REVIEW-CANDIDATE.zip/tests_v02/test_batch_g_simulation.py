"""Explicit finite schedules, visibility, replay, crash and partition boundaries."""
from copy import deepcopy
import hashlib
import socket
import subprocess
import time
import builtins
from itertools import permutations
import pytest
from dkn_v02 import canonical, Refusal
from dkn_v02.simulation import run_scenario, verify_replay, validate_scenario
from examples.distributed_fixtures import (extended_scenarios, EXPECTED_STATUSES, fixture_bundle,
                                         scenario, send, assess)

@pytest.fixture(scope='module')
def catalog():return extended_scenarios()

@pytest.mark.parametrize('name',sorted(EXPECTED_STATUSES))
def test_reference_scenarios_have_hand_authored_outcomes(catalog,name):
    result=run_scenario(catalog[name])
    assert [row['report']['status'] for row in result['assessments']]==EXPECTED_STATUSES[name]
    assert result['simulation_only'] and not result['production_evidence']
    assert result['authority_effect']=='NONE'

@pytest.mark.parametrize('name',['partition-heal','recovery-fork','external-floor-rollback'])
def test_exact_replay_and_no_input_mutation(catalog,name):
    s=deepcopy(catalog[name]);before=canonical(s);r=run_scenario(s)
    assert canonical(s)==before and canonical(run_scenario(s))==canonical(r)
    assert verify_replay(s,r)['status']=='MATCH_EXACT_SIMULATION_REPLAY'

@pytest.mark.parametrize('mutation',['root','result','boundary','time','omission'])
def test_transcript_mutations_refuse(catalog,mutation):
    s=catalog['normal'];r=run_scenario(s)
    if mutation=='root':r['trace_root']='0'*64
    elif mutation=='result':r['assessments'][0]['report']['status']='NO_MATCH'
    elif mutation=='boundary':r['production_evidence']=True
    elif mutation=='time':r['trace'][0]['time']+=1
    else:r['trace'].pop(0)
    with pytest.raises(Refusal):verify_replay(s,r)

def test_reader_has_no_hidden_catalog_oracle(catalog):
    s=deepcopy(catalog['normal']);r=run_scenario(s)['assessments'][0]['report']
    # Hidden global state differs but received evidence is byte-identical.
    s['objects']=[o for o in s['objects'] if o['id'] in ('artifact','granted')]
    s['nodes'][0]['initial_objects']=['artifact','granted']
    assert run_scenario(s)['assessments'][0]['report']==r

def test_transitive_shared_failure_and_metadata_exposure(catalog):
    r=run_scenario(catalog['transitive-shared-dependency'])['assessments'][0]['report']
    c=r['composition']['assessment']
    assert c['status']=='DECLARED_CONFLICTS_DETECTED' and c['pairs'][0]['shared_dependencies']
    assert c['public_metadata_descriptors'] and c['independence']=='NOT_ESTABLISHED'

def test_colluding_guardians_can_meet_crypto_threshold_not_legitimacy(catalog):
    r=run_scenario(catalog['guardian-threshold-collusion'])['assessments'][0]['report']
    assert r['status']=='MATCH_FOR_SUPPLIED_VIEW'
    assert r['execution_authorized'] is False and r['admission']=='EXTERNAL_DECISION_REQUIRED'

def test_same_time_deliveries_precede_failure_control(catalog):
    s=deepcopy(catalog['normal'])
    s['steps']=[send('artifact',120,10),send('granted',120,10),
                {'at':130,'action':'node','node':'publisher','online':False},assess('after',130)]
    r=run_scenario(s)
    assert r['assessments'][0]['report']['status']=='MATCH_FOR_SUPPLIED_VIEW'
    assert [t['type'] for t in r['trace']]==['send','send','delivery','delivery','node','assessment']

def test_domain_restore_does_not_clear_other_failure(catalog):
    s=deepcopy(catalog['normal']);s['nodes'][0]['fault_domains'].append({'dimension':'provider','domain_id':'cloud'})
    s['steps']=[{'at':100,'action':'domain','dimension':'administration','domain_id':'publisher-admin','online':False},
        {'at':101,'action':'domain','dimension':'provider','domain_id':'cloud','online':False},
        {'at':110,'action':'domain','dimension':'administration','domain_id':'publisher-admin','online':True},
        send('artifact'),send('granted'),assess('no-recovery')]
    assert run_scenario(s)['assessments'][0]['report']['status']=='INDETERMINATE'

def test_dropped_delivery_is_not_automatically_retried(catalog):
    s=deepcopy(catalog['failure-in-flight'])
    s['steps'] += [{'at':155,'action':'node','node':'publisher','online':True},assess('restarted',156)]
    assert run_scenario(s)['assessments'][-1]['report']['status']=='INDETERMINATE'

def test_pending_messages_not_silently_delivered_at_horizon(catalog):
    s=deepcopy(catalog['normal']);s['steps']=[send('artifact',120,100),send('granted',120,100),assess('pending')]
    r=run_scenario(s);assert len(r['terminal']['pending_messages'])==2
    assert r['assessments'][0]['report']['status']=='INDETERMINATE'

def test_sender_cannot_send_hidden_object_it_does_not_have(catalog):
    s=deepcopy(catalog['normal']);s['nodes'][0]['initial_objects']=[]
    r=run_scenario(s);assert r['trace'][0]['details']['outcome']=='SOURCE_LACKS_OBJECT'
    assert r['assessments'][0]['report']['status']=='INDETERMINATE'

@pytest.mark.parametrize('seed',range(16))
def test_deterministic_seeded_delivery_schedules(catalog,seed):
    s=deepcopy(catalog['normal']);s['readers'][0]['policy']['require_witness']=True
    b=fixture_bundle();s['readers'][0]['policy']['witness_policy']=b['witness_policy']
    names=['artifact','granted','witness-0','witness-1']
    ordered=sorted(names,key=lambda n:hashlib.sha256(f'{seed}:{n}'.encode()).digest())
    s['steps']=[send(n,120,i) for i,n in enumerate(ordered)]+[assess('complete',130)]
    r=run_scenario(s);assert r['assessments'][0]['report']['status']=='CONDITIONAL'
    assert run_scenario(s)==r

@pytest.mark.parametrize('subset',range(8))
def test_exhaustive_three_replica_reachability(subset):
    b=fixture_bundle();s=scenario('replica-mask',bundle=b)
    s['steps']=[]
    for i in range(3):
        name='peer-'+str(i)
        s['nodes'].append({'id':name,'fault_domains':[],'initial_objects':['artifact','granted'],'clock_offset':0})
        if not subset&(1<<i):s['steps'].append({'at':110,'action':'node','node':name,'online':False})
    for i in range(3):s['steps'] += [send('artifact',source='peer-'+str(i)),send('granted',source='peer-'+str(i))]
    s['steps'].append(assess('retrieval'))
    assert run_scenario(s)['assessments'][0]['report']['status']==('MATCH_FOR_SUPPLIED_VIEW' if subset else 'INDETERMINATE')

def test_core_simulator_uses_no_network_clock_random_files_or_processes(catalog,monkeypatch):
    def forbidden(*a,**k):raise AssertionError('UNEXPECTED_SIDE_EFFECT')
    with monkeypatch.context() as m:
        m.setattr(socket,'socket',forbidden);m.setattr(time,'time',forbidden)
        m.setattr(builtins,'open',forbidden);m.setattr(subprocess,'Popen',forbidden)
        import os;m.setattr(os,'urandom',forbidden)
        r=run_scenario(catalog['normal'])
    assert r['assessments'][0]['report']['status']=='MATCH_FOR_SUPPLIED_VIEW'

@pytest.mark.parametrize('field,value',[('schema','wrong'),('until',-1),('nodes',[]),('steps',None),('objects',{}),('topology','BLOCKCHAIN')])
def test_bad_scenario_shapes_refuse(catalog,field,value):
    s=deepcopy(catalog['normal']);s[field]=value
    with pytest.raises(Refusal):run_scenario(s)

@pytest.mark.parametrize('step',[
 {'at':120,'action':'send','source':'ghost','target':'reader','object':'artifact','delay':0},
 {'at':120,'action':'send','source':'reader','target':'reader','object':'artifact','delay':0},
 {'at':120,'action':'drop','message':'m000001'},
 {'at':120,'action':'restore','node':'reader','slot':'absent'},
 {'at':120,'action':'execute','command':'echo forbidden'},
 {'at':True,'action':'node','node':'reader','online':False}])
def test_unknown_references_or_operations_refuse(catalog,step):
    s=deepcopy(catalog['normal']);s['steps']=[step]
    with pytest.raises(Refusal):run_scenario(s)

def test_nonmonotone_schedule_refuses(catalog):
    s=deepcopy(catalog['normal']);s['steps'][1]['at']=100
    with pytest.raises(Refusal,match='TIME_ORDER'):run_scenario(s)

def test_duplicate_ids_and_excess_assessments_refuse(catalog):
    s=deepcopy(catalog['normal']);s['nodes'].append(deepcopy(s['nodes'][0]))
    with pytest.raises(Refusal,match='DUPLICATE'):run_scenario(s)
    s=deepcopy(catalog['normal']);s['steps']=[assess('x'+str(i)) for i in range(33)]
    with pytest.raises(Refusal,match='LIMIT'):run_scenario(s)
