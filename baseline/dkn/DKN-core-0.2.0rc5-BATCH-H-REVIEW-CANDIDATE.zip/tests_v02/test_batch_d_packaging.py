import io
from pathlib import Path
import zipfile
import pytest
from tools.build_v02_candidate import build, verify, MANIFEST


def test_candidate_two_serializations(tmp_path):
    (tmp_path/'README.md').write_text('fixture',encoding='utf-8')
    a,_=build(tmp_path);b,_=build(tmp_path)
    assert a==b
    assert verify(a)['member_count']==2


def test_candidate_inventory_tamper(tmp_path):
    (tmp_path/'README.md').write_text('fixture',encoding='utf-8')
    raw,_=build(tmp_path);out=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(raw)) as src, zipfile.ZipFile(out,'w') as dst:
        for info in src.infolist():
            data=src.read(info.filename)
            if info.filename=='README.md':data=b'poisoned'
            dst.writestr(info,data)
    with pytest.raises(ValueError,match='HASH'):verify(out.getvalue())


def test_candidate_extra_member_refused(tmp_path):
    (tmp_path/'README.md').write_text('fixture',encoding='utf-8')
    raw,_=build(tmp_path);out=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(raw)) as src, zipfile.ZipFile(out,'w') as dst:
        for info in src.infolist():dst.writestr(info,src.read(info.filename))
        info=zipfile.ZipInfo('z.txt',date_time=(1980,1,1,0,0,0))
        info.create_system=3;info.external_attr=(0o100644)<<16
        dst.writestr(info,b'extra')
    with pytest.raises(ValueError,match='CLOSURE'):verify(out.getvalue())


def test_candidate_excludes_caches_and_previous_inventory(tmp_path):
    (tmp_path/'README.md').write_text('fixture',encoding='utf-8')
    (tmp_path/'__pycache__').mkdir();(tmp_path/'__pycache__/x.pyc').write_bytes(b'cache')
    (tmp_path/MANIFEST).write_bytes(b'obsolete self inventory')
    raw,m=build(tmp_path)
    assert [r['path'] for r in m['files']]==['README.md']
    verify(raw)
