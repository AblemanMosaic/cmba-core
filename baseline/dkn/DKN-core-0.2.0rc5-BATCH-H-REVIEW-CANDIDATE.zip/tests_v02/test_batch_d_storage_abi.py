from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import pytest
from dkn_v02.core import Refusal, canonical, read_canonical, pack
from dkn_v02.storage import MemoryStore, DirectoryStore, retrieve
from dkn_v02.assured_navigation import inspect_with_assurance
from dkn_v02.sam_abi import dispatch
from dkn_v02.assurance import seal
from examples.v02_assurance import fixture_bundle, run
from dkn_v02.sam_schemas import V

ROOT=Path(__file__).resolve().parents[1]

@pytest.fixture
def b():return fixture_bundle()


def test_memory_retrieval(b):
    m=MemoryStore();loc=m.put(b['raw'])
    raw,r=retrieve([loc],{'memory':m},expected_root=b['manifest']['logical_root'])
    assert raw==b['raw'] and r['status']=='RETRIEVED' and r['authority_effect']=='NONE'


def test_directory_roundtrip_idempotent(b,tmp_path):
    s=DirectoryStore(tmp_path/'store')
    loc=s.put(b['raw'])
    assert s.put(b['raw'])==loc
    assert s.get(loc['transport_sha256'])==b['raw']
    assert len(list(s.root.iterdir()))==1


def test_backend_migration_preserves_identity(b,tmp_path):
    local=DirectoryStore(tmp_path/'store');mem=MemoryStore('mirror')
    a=local.put(b['raw']);c=mem.put(b['raw'])
    assert a['logical_root']==c['logical_root']==b['manifest']['logical_root']
    assert a['backend_id']!=c['backend_id']


def test_failed_backend_fallback(b):
    mem=MemoryStore();loc=mem.put(b['raw']);bad={**loc,'backend_id':'missing'}
    raw,r=retrieve([bad,loc],{'memory':mem},expected_root=b['manifest']['logical_root'])
    assert raw==b['raw'] and len(r['attempts'])==2
    assert r['attempts'][0]['code']=='DKN_V02_STORE_BACKEND_UNAVAILABLE'


def test_poisoned_backend_fallback(b):
    good=MemoryStore('good');bad=MemoryStore('bad')
    a=bad.put(b['raw']);c=good.put(b['raw'])
    bad._objects[a['transport_sha256']]=b'not the archive'
    raw,r=retrieve([a,c],{'bad':bad,'good':good},expected_root=b['manifest']['logical_root'])
    assert raw==b['raw'] and r['attempts'][0]['code']=='DKN_V02_STORE_DIGEST_MISMATCH'


def test_transport_digest_cannot_substitute_wrong_logical_identity(b):
    other,_=pack({'other.txt':b'other'})
    store=MemoryStore();loc=store.put(other)
    loc['logical_root']=b['manifest']['logical_root']
    raw,r=retrieve([loc],{'memory':store},expected_root=b['manifest']['logical_root'])
    assert raw is None and r['status']=='INDETERMINATE'
    assert r['attempts'][0]['code']=='DKN_V02_STORE_IDENTITY_MISMATCH'


def test_missing_all_is_not_absence(b):
    raw,r=retrieve([],{},expected_root=b['manifest']['logical_root'])
    assert raw is None and r['global_absence']=='NOT_ESTABLISHED'


def test_store_identity_mismatch(b):
    store=MemoryStore();loc=store.put(b['raw']);store.backend_id='different'
    raw,r=retrieve([loc],{'memory':store},expected_root=b['manifest']['logical_root'])
    assert raw is None and r['attempts'][0]['code']=='DKN_V02_STORE_BACKEND_MISMATCH'


def test_directory_corruption_not_overwritten(b,tmp_path):
    store=DirectoryStore(tmp_path/'store');loc=store.put(b['raw'])
    path=store.root/(loc['transport_sha256']+'.zip');path.write_bytes(b'corrupted')
    with pytest.raises(Refusal,match='DIGEST_MISMATCH'):store.get(loc['transport_sha256'])
    with pytest.raises(Refusal):store.put(b['raw'])
    assert path.read_bytes()==b'corrupted'


def test_directory_missing_normalized(tmp_path):
    with pytest.raises(Refusal,match='IO_ERROR'):DirectoryStore(tmp_path/'missing').get('0'*64)


def test_source_symlink_refused(b,tmp_path):
    root=tmp_path/'real';root.mkdir();link=tmp_path/'link';link.symlink_to(root,target_is_directory=True)
    with pytest.raises(Refusal,match='SYMLINK'):DirectoryStore(link).put(b['raw'])


def test_nested_symlink_refused(b,tmp_path):
    root=tmp_path/'real';root.mkdir();link=tmp_path/'link';link.symlink_to(root,target_is_directory=True)
    with pytest.raises(Refusal,match='SYMLINK'):DirectoryStore(link/'child').put(b['raw'])


def test_leaf_symlink_refused(b,tmp_path):
    store=DirectoryStore(tmp_path/'store');loc=store.put(b['raw'])
    path=store.root/(loc['transport_sha256']+'.zip');path.unlink()
    target=tmp_path/'outside';target.write_bytes(b['raw']);path.symlink_to(target)
    with pytest.raises(Refusal,match='SYMLINK'):store.get(loc['transport_sha256'])


def test_hardlink_alias_refused(b,tmp_path):
    store=DirectoryStore(tmp_path/'store');loc=store.put(b['raw'])
    path=store.root/(loc['transport_sha256']+'.zip');os.link(path,tmp_path/'alias')
    with pytest.raises(Refusal,match='FILE_INVALID'):store.get(loc['transport_sha256'])


def test_nonregular_file_refused(tmp_path):
    if not hasattr(os,'mkfifo'):pytest.skip('POSIX FIFO test')
    root=tmp_path/'store';root.mkdir();os.mkfifo(root/('0'*64+'.zip'))
    with pytest.raises(Refusal,match='FILE_INVALID'):DirectoryStore(root).get('0'*64)


def test_invalid_archive_not_published(tmp_path):
    store=DirectoryStore(tmp_path/'store')
    with pytest.raises(Refusal):store.put(b'garbage')
    assert not store.root.exists()


def test_locator_cannot_inject_path(b):
    store=MemoryStore();loc=store.put(b['raw']);loc['transport_sha256']='../outside'
    with pytest.raises(Refusal):retrieve([loc],{'memory':store},expected_root=b['manifest']['logical_root'])


def test_locator_limit(b):
    store=MemoryStore();loc=store.put(b['raw'])
    with pytest.raises(Refusal,match='LIMIT'):retrieve([loc]*17,{'memory':store},expected_root=b['manifest']['logical_root'])


def test_navigation_joins_verified_material(b):
    r=inspect_with_assurance(b['raw'],**{k:b[k] for k in ('descriptor','contract','evidence','policy','context')})
    assert r['inspection']['integrity']=='PASS' and r['assurance']['status']=='SATISFIES'
    assert r['recognition']=='EXTERNAL_DECISION_REQUIRED'


def test_navigation_refuses_wrong_artifact(b):
    b['contract']['scope']['artifact_root']='0'*64
    with pytest.raises(Refusal,match='SCOPE_MISMATCH'):
        inspect_with_assurance(b['raw'],**{k:b[k] for k in ('descriptor','contract','evidence','policy','context')})


def test_no_implicit_network(monkeypatch):
    def forbidden(*a,**k):raise AssertionError('unexpected network call')
    monkeypatch.setattr(socket,'socket',forbidden)
    monkeypatch.setattr(socket,'create_connection',forbidden)
    assert run()['offline_retrieval']=='RETRIEVED'


def test_abi_eval(b):
    req={'schema':'dkn.sam-request.'+V,'operation':'evaluate',
         'arguments':{k:b[k] for k in ('descriptor','contract','evidence','policy','context')}}
    assert dispatch(req)['status']=='SATISFIES'

@pytest.mark.parametrize('operation,args',[
    ('verify',{'record':None}), ('eval-code',{}), (None,{}),
    ('evaluate',{'assessment':{'status':'PASS'}}), ('compose',{})])
def test_abi_bad_inputs_typed(operation,args):
    with pytest.raises(Refusal):dispatch({'schema':'dkn.sam-request.'+V,'operation':operation,'arguments':args})


def test_cli_example():
    env={**os.environ,'PYTHONPATH':str(ROOT/'src')}
    p=subprocess.run([sys.executable,'-m','dkn_v02.sam_cli',str(ROOT/'examples/v02-sam-request.json')],
                     capture_output=True,env=env,cwd=ROOT,timeout=15)
    assert p.returncode==0
    assert json.loads(p.stdout)['status']=='SATISFIES'

@pytest.mark.parametrize('raw',[b'{}',b'{"schema":1,"schema":2}',b' '+b'{}',b'\xff',b'{"x": NaN}'])
def test_cli_malformed_normalized(tmp_path,raw):
    pth=tmp_path/'request.json';pth.write_bytes(raw)
    env={**os.environ,'PYTHONPATH':str(ROOT/'src')}
    p=subprocess.run([sys.executable,'-m','dkn_v02.sam_cli',str(pth)],capture_output=True,env=env,timeout=15)
    assert p.returncode==2 and json.loads(p.stdout)['status']=='REFUSED'
    assert b'Traceback' not in p.stderr


def test_cli_missing_path_typed(tmp_path):
    env={**os.environ,'PYTHONPATH':str(ROOT/'src')}
    p=subprocess.run([sys.executable,'-m','dkn_v02.sam_cli',str(tmp_path/'absent')],capture_output=True,env=env,timeout=15)
    assert p.returncode==2 and json.loads(p.stdout)['code']=='DKN_V02_SAM_IO_ERROR'
