"""Model-bound evidence is not automatic acceptance of a changed model."""
from pathlib import Path
import hashlib, json, shutil
import pytest
from dkn_v02.core import canonical, Refusal
from tools import check_lifecycle_contract as checker
from tools import build_batch_f_candidate as builder
ROOT=Path(__file__).resolve().parents[1]

def test_extension_model_and_realization_bindings():
    r=checker.check()
    assert r['status']=='PASS_REFERENCE_INTEGRITY' and r['obligations']==12
    assert r['executed_test_binding']=='NOT_CHECKED' and r['authority_effect']=='NONE'

def test_extension_model_mutation_refuses(tmp_path):
    shutil.copytree(ROOT/'model',tmp_path/'model')
    p=tmp_path/'model/lifecycle-f1/CONTRACT.json';v=json.loads(p.read_bytes())
    v['authority_effect']='GRANTED';p.write_bytes(canonical(v))
    with pytest.raises(Refusal,match='DIMENSION_MISMATCH'):checker.check(tmp_path)

def test_extension_source_mutation_detected(tmp_path):
    shutil.copytree(ROOT,tmp_path/'copy',ignore=shutil.ignore_patterns('__pycache__','build','*.egg-info'))
    root=tmp_path/'copy';p=root/'src/dkn_v02/lifecycle.py';p.write_text(p.read_text()+'\n# changed\n')
    assert 'HASH_MISMATCH:src/dkn_v02/lifecycle.py' in checker.check(root)['findings']

def test_extension_foreign_evidence_refused():
    result=checker.check(report={'source_fingerprint':'0'*64,'test_cases':[]})
    assert 'EXECUTED_SOURCE_MISMATCH' in result['findings']
    assert any(v.startswith('TEST_NOT_ESTABLISHED:') for v in result['findings'])

def test_f_package_commits_actual_rc2_predecessor(tmp_path):
    (tmp_path/'file.txt').write_text('fixture')
    raw,m=builder.build(tmp_path)
    assert builder.verify(raw)['status']=='PASS'
    assert m['predecessor_archive_sha256']=='29e8151167c9aedbc62d11ed4f104298f508e65d2a210488feac41e444d534f8'
    assert builder.build(tmp_path)[0]==raw

@pytest.mark.parametrize('value',[None,{},[],42,'','a\x00b'])
def test_vault_path_admission_is_typed(value):
    from dkn_v02.vault import TransactionalVault
    with pytest.raises(Refusal):TransactionalVault(value)
