"""DS-G1 evidence composition, actual cryptography, not canned simulation answers."""
from copy import deepcopy
from itertools import permutations
import pytest
from dkn_v02 import canonical, Refusal, certify, key_hex
from dkn_v02.assurance import seal
from dkn_v02.distributed import assess_view, validate_reader
from dkn_v02.federation import checkpoint_policy_ref
from examples.distributed_fixtures import fixture_bundle, fixture_key

@pytest.fixture
def b():return fixture_bundle()
def view(b,names=('artifact','granted'),reader=None,now=130):
    return assess_view([b['objects'][n] for n in names],reader or b['reader'],now=now)

def test_exact_join_is_not_execution_authority(b):
    r=view(b)
    assert r['status']=='MATCH_FOR_SUPPLIED_VIEW'
    assert r['artifact']['matches'][0]['verification']['certificate']['signature']=='PASS'
    assert not r['execution_authorized'] and r['admission']=='EXTERNAL_DECISION_REQUIRED'
    assert r['global_currentness']==r['consensus_safety']=='NOT_ESTABLISHED'

@pytest.mark.parametrize('names',[(),('artifact',),('granted',),('witness-0',)])
def test_missing_required_material_stays_indeterminate(b,names):
    assert view(b,names)['status']=='INDETERMINATE'

@pytest.mark.parametrize('field,value,expected',[('expected_artifact_root','f'*64,'NO_MATCH'),('expected_head','e'*64,'INDETERMINATE'),('expected_namespace','d'*64,'INDETERMINATE')])
def test_foreign_identity_cannot_match(b,field,value,expected):
    r=deepcopy(b['reader']);r[field]=value
    assert view(b,reader=r)['status']==expected

@pytest.mark.parametrize('kind',['missing','wrong-signer','wrong-namespace','invalid-signature'])
def test_certificate_binds_subject_namespace_and_payload(b,kind):
    a=b['objects']['artifact']['value']
    if kind=='missing':a['certificate']=None
    elif kind=='wrong-signer':a['certificate']=certify(b['manifest'],fixture_key('outsider'),namespace_root=b['genesis']['namespace_root'])
    elif kind=='wrong-namespace':a['certificate']=certify(b['manifest'],b['delegate'],namespace_root='f'*64)
    else:a['certificate']['signature_hex']='0'*128
    r=view(b);assert r['status']=='INDETERMINATE'
    if kind=='invalid-signature':assert r['invalid_objects']

@pytest.mark.parametrize('operation',['install','execute','delete','approve','certify'])
def test_certificate_operation_cannot_be_aliased(b,operation):
    r=deepcopy(b['reader']);r['operation']=operation
    with pytest.raises(Refusal,match='OPERATION_UNSUPPORTED'):view(b,reader=r)

@pytest.mark.parametrize('now',[0,119,181,300,501])
def test_checkpoint_and_time_bounds(b,now):
    assert view(b,now=now)['status']=='INDETERMINATE'

@pytest.mark.parametrize('mask',range(8))
def test_all_three_witness_subsets(b,mask):
    r=deepcopy(b['reader']);r.update(require_witness=True,witness_policy=b['witness_policy'])
    names=['artifact','granted']+['witness-'+str(i) for i in range(3) if mask&(1<<i)]
    result=view(b,names,r)
    assert result['status']==('CONDITIONAL' if mask.bit_count()>=2 else 'INDETERMINATE')

@pytest.mark.parametrize('field,value',[('head_root','e'*64),('sequence',2),('epoch',1)])
def test_witness_exact_head_sequence_epoch_join(b,field,value):
    wp=deepcopy(b['witness_policy'])
    if field=='epoch':wp['epoch']=value
    for i in range(2):
        name='witness-'+str(i);body={**b['objects'][name]['value']['body'],field:value,'policy_ref':checkpoint_policy_ref(wp)}
        b['objects'][name]['value']=seal('checkpoint',body,b['witnesses'][i])
    r=deepcopy(b['reader']);r.update(require_witness=True,witness_policy=wp)
    result=view(b,['artifact','granted','witness-0','witness-1'],r)
    assert result['witness']['assessment']['status']=='CONDITIONAL'
    assert result['status']=='INDETERMINATE' and result['witness']['scope_binding']=='NOT_ESTABLISHED'

def test_known_newer_view_blocks_stale_pin_without_updating_it(b):
    before=canonical(b['reader'])
    r=view(b,['artifact','granted','revoked'],now=150)
    assert r['status']=='INDETERMINATE' and r['lifecycle']['reason']=='PIN_NOT_MAXIMAL_IN_SUPPLIED_VIEW'
    assert canonical(b['reader'])==before

def test_revocation_after_explicit_pin_is_no_match(b):
    r=deepcopy(b['reader']);r['expected_head']=b['revoked'][-1]['event_ref']
    assert view(b,['artifact','granted','revoked'],r,150)['status']=='NO_MATCH'

def test_supplied_recovery_forks_do_not_select_a_winner(b):
    r=view(b,['artifact','granted','recovery-a','recovery-b'],now=150)
    assert r['status']=='CONTRADICTED'
    assert r['lifecycle']['forks']['selected_head'] is None

@pytest.mark.parametrize('floor_field',['minimum','external_minimum'])
def test_exact_floors_reject_rollback_and_same_sequence_fork(b,floor_field):
    r=deepcopy(b['reader']);r[floor_field]={'sequence':2,'head_ref':b['revoked'][-1]['event_ref']}
    out=view(b,reader=r)
    assert out['status']=='INDETERMINATE' and out['lifecycle']['candidates'][0]['refusal']=='DKN_LC_ROLLBACK_OR_FORK'
    r[floor_field]={'sequence':1,'head_ref':'e'*64}
    assert view(b,reader=r)['status']=='INDETERMINATE'

def test_local_floor_cannot_erase_external_floor(b):
    r=deepcopy(b['reader']);r['minimum']={'sequence':1,'head_ref':r['expected_head']}
    r['external_minimum']={'sequence':1,'head_ref':'e'*64}
    assert view(b,reader=r)['status']=='INDETERMINATE'

@pytest.mark.parametrize('perm',list(permutations(['artifact','granted','witness-0'])))
def test_supplied_object_order_not_semantic(b,perm):
    assert canonical(view(b,perm))==canonical(view(b,['artifact','granted','witness-0']))

def test_duplicate_objects_do_not_count_as_distinct_witnesses(b):
    r=deepcopy(b['reader']);r.update(require_witness=True,witness_policy=b['witness_policy'])
    out=view(b,['artifact','granted','witness-0','witness-0'],r)
    assert out['status']=='INDETERMINATE' and out['duplicate_objects']==1

def test_duplicate_envelopes_cannot_count_same_record_twice(b):
    r=deepcopy(b['reader']);r.update(require_witness=True,witness_policy=b['witness_policy'])
    b['objects']['witness-clone']=deepcopy(b['objects']['witness-0'])
    out=view(b,['artifact','granted','witness-0','witness-clone'],r)
    assert out['status']=='INDETERMINATE'

@pytest.mark.parametrize('bad',[{}, {'kind':'execute','value':{}}, {'kind':'artifact','value':{}},
                              {'kind':'journal','value':{}}, {'kind':'evidence','value':{}}])
def test_invalid_candidate_quarantined_not_promoted_or_vetoing_valid(b,bad):
    good=[b['objects']['artifact'],b['objects']['granted']]
    out=assess_view(good+[bad],b['reader'],now=130)
    assert out['status']=='MATCH_FOR_SUPPLIED_VIEW' and len(out['invalid_objects'])==1
    assert assess_view([bad],b['reader'],now=130)['status']=='INDETERMINATE'

@pytest.mark.parametrize('field',['artifact_root','namespace_root','substrate_ref'])
def test_assurance_exact_scope_required(b,field):
    r=deepcopy(b['reader']);r.update(require_assurance=True,assurance=deepcopy(b['assurance']))
    r['assurance']['contract']['scope'][field]='f'*64
    with pytest.raises(Refusal,match='SCOPE_MISMATCH'):view(b,reader=r)

def test_assurance_refutation_is_not_hidden_by_support(b):
    r=deepcopy(b['reader']);r.update(require_assurance=True,assurance=deepcopy(b['assurance']))
    assert view(b,['artifact','granted','enterprise','support'],r)['status']=='MATCH_FOR_SUPPLIED_VIEW'
    assert view(b,['artifact','granted','enterprise','support','refute'],r)['status']=='CONTRADICTED'

def test_valid_outsider_cannot_satisfy_witness_requirement(b):
    b['objects']['witness-0']['value']=seal('checkpoint',b['objects']['witness-0']['value']['body'],fixture_key('outsider'))
    r=deepcopy(b['reader']);r.update(require_witness=True,witness_policy=b['witness_policy'])
    assert view(b,['artifact','granted','witness-0','witness-1'],r)['status']=='INDETERMINATE'

def test_witness_requirement_cannot_be_enabled_without_policy(b):
    r=deepcopy(b['reader']);r['require_witness']=True
    with pytest.raises(Refusal,match='POLICY_MISSING'):view(b,reader=r)

def test_assurance_requirement_cannot_be_enabled_without_policy(b):
    r=deepcopy(b['reader']);r['require_assurance']=True
    with pytest.raises(Refusal,match='POLICY_MISSING'):view(b,reader=r)

@pytest.mark.parametrize('now',[True,-1,2**53,None,1.5])
def test_bad_reader_time_is_typed(b,now):
    with pytest.raises(Refusal):view(b,now=now)

def test_too_many_objects_and_journals_refuse(b):
    with pytest.raises(Refusal,match='LIMIT'):assess_view([b['objects']['artifact']]*65,b['reader'],now=130)
    with pytest.raises(Refusal,match='LIMIT'):assess_view([b['objects']['granted']]*17,b['reader'],now=130)

def test_read_only_evaluator_does_not_mutate_inputs(b):
    before=canonical([b['objects'],b['reader']]);view(b)
    assert canonical([b['objects'],b['reader']])==before


def test_optional_evidence_cannot_hide_known_applicable_conflict(b):
    r=deepcopy(b['reader']);r['witness_policy']=b['witness_policy']
    assert view(b,['artifact','granted'],r)['status']=='MATCH_FOR_SUPPLIED_VIEW'
    assert view(b,['artifact','granted','witness-0','witness-conflict'],r)['status']=='CONTRADICTED'
    r=deepcopy(b['reader']);r['assurance']=b['assurance']
    assert view(b,['artifact','granted','enterprise','refute'],r)['status']=='CONTRADICTED'


def test_nested_malformed_candidates_never_raise_untyped_errors(b):
    # 5 envelope kinds x public first-level field substitutions; invalid evidence may
    # quarantine or typed-refuse but must not become an uncaught Python parser error.
    values=[None,False,0,'',[],{}]
    attempted=0
    for name in ('artifact','granted','witness-0','enterprise','support'):
        original=b['objects'][name]
        for field in list(original['value']):
            for value in values:
                candidate=deepcopy(original);candidate['value'][field]=value
                try:
                    r=assess_view([candidate],b['reader'],now=130)
                    assert r['status']!='MATCH_FOR_SUPPLIED_VIEW'
                except Refusal:
                    pass
                attempted+=1
    assert attempted==144
