from copy import deepcopy
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02.core import Refusal, canonical
from dkn_v02.assurance import seal
from dkn_v02.federation import assess_checkpoints, checkpoint_policy_ref, make_handoff
from examples.v02_assurance import fixture_bundle

@pytest.fixture
def b():return fixture_bundle()

def run(b,at=1000):return assess_checkpoints(b['checkpoints'],b['checkpoint_policy'],at_time=at)

def resign(b):
    for i,w in enumerate(b['witnesses']):
        body=deepcopy(b['checkpoints'][i]['body']);body['policy_ref']=checkpoint_policy_ref(b['checkpoint_policy'])
        b['checkpoints'][i]=seal('checkpoint',body,w)


def test_quorum_is_not_consensus(b):
    r=run(b)
    assert r['status']=='CONDITIONAL' and r['quorum']=='OBSERVED'
    assert r['consensus_safety']==r['global_currentness']=='NOT_ESTABLISHED'


def test_threshold_cannot_be_filled_by_one_signer(b):
    body={**b['checkpoints'][0]['body'],'observed_at':991}
    b['checkpoints']=[b['checkpoints'][0],seal('checkpoint',body,b['witnesses'][0])]
    assert run(b)['status']=='INSUFFICIENT'


def test_shared_administrator(b):
    b['checkpoint_policy']['members'][1]['fault_domains']=deepcopy(b['checkpoint_policy']['members'][0]['fault_domains'])
    resign(b)
    assert run(b)['status']=='INSUFFICIENT'


def test_absent_domain_is_not_independence(b):
    b['checkpoint_policy']['members'][1]['fault_domains']=[];resign(b)
    assert run(b)['status']=='INSUFFICIENT'


def test_conflicting_heads_no_majority_override(b):
    body={**b['checkpoints'][0]['body'],'head_root':'d'*64}
    b['checkpoints'].append(seal('checkpoint',body,b['witnesses'][0]))
    r=run(b)
    assert r['status']=='CONTRADICTED' and len(r['conflicts'])==1
    assert r['quorum']=='NOT_ESTABLISHED'


def test_expiry_does_not_erase_known_equivocation(b):
    body={**b['checkpoints'][0]['body'],'head_root':'d'*64,'valid_until':999}
    b['checkpoints'].append(seal('checkpoint',body,b['witnesses'][0]))
    assert run(b)['status']=='CONTRADICTED'


def test_outsider_not_a_veto(b):
    k=Ed25519PrivateKey.from_private_bytes(bytes([244])*32)
    body={**b['checkpoints'][0]['body'],'head_root':'d'*64}
    b['checkpoints'].append(seal('checkpoint',body,k))
    assert run(b)['status']=='CONDITIONAL'

@pytest.mark.parametrize('field,value',[('namespace_root','e'*64),('substrate_ref','e'*64),('epoch',1),('policy_ref','e'*64)])
def test_wrong_scope(b,field,value):
    b['checkpoints']=[seal('checkpoint',{**r['body'],field:value},w) for r,w in zip(b['checkpoints'],b['witnesses'])]
    assert run(b)['status']=='INSUFFICIENT'


def test_expired_checkpoint(b):assert run(b,at=1100)['status']=='INSUFFICIENT'

def test_future_checkpoint(b):assert run(b,at=989)['status']=='INSUFFICIENT'

def test_maximum_age(b):assert run(b,at=1051)['status']=='INSUFFICIENT'


def test_expired_policy(b):
    b['checkpoint_policy']['valid_until']=1000;resign(b)
    assert run(b)['status']=='INSUFFICIENT'


def test_high_water_mark_rejects_rollback(b):
    b['checkpoint_policy']['minimum_sequence']=3;resign(b)
    r=run(b)
    assert r['status']=='INSUFFICIENT'
    assert all(e['reason']=='BELOW_CALLER_HIGH_WATER_MARK' for e in r['excluded_checkpoints'])


def test_higher_incomplete_sequence_not_hidden_by_old_quorum(b):
    body={**b['checkpoints'][0]['body'],'sequence':3}
    b['checkpoints'].append(seal('checkpoint',body,b['witnesses'][0]))
    r=run(b)
    assert r['status']=='INSUFFICIENT' and r['highest_eligible_sequence']==3


def test_sequence_progression_not_a_fork(b):
    for w in b['witnesses']:
        body={**b['checkpoints'][0]['body'],'sequence':3,'head_root':'e'*64}
        b['checkpoints'].append(seal('checkpoint',body,w))
    r=run(b)
    assert not r['conflicts'] and r['highest_eligible_sequence']==3
    assert r['status']=='CONDITIONAL'


def test_policy_substitution_refused_by_binding(b):
    b['checkpoint_policy']['threshold']=1
    assert run(b)['status']=='INSUFFICIENT'

@pytest.mark.parametrize('consumer',['CHC','CCP'])
def test_handoffs_no_authority(b,consumer):
    r=make_handoff(b['checkpoints'],b['checkpoint_policy'],at_time=1000,consumer=consumer)
    assert not r['execution_authorized'] and r['authority_effect']=='NONE'
    assert r['admission']=='EXTERNAL_DECISION_REQUIRED'


def test_precomputed_assessment_not_accepted(b):
    with pytest.raises(Refusal):assess_checkpoints([run(b)],b['checkpoint_policy'],at_time=1000)


def test_empty_input_is_insufficient(b):
    b['checkpoints']=[]
    assert run(b)['status']=='INSUFFICIENT'


def test_checkpoint_order_deterministic(b):
    r=canonical(run(b));b['checkpoints'].reverse()
    assert canonical(run(b))==r

@pytest.mark.parametrize('threshold',[True,0,17,3])
def test_bad_threshold(b,threshold):
    b['checkpoint_policy']['threshold']=threshold
    with pytest.raises(Refusal):run(b)


def test_duplicate_checkpoint_refused(b):
    b['checkpoints'].append(deepcopy(b['checkpoints'][0]))
    with pytest.raises(Refusal,match='DUPLICATE'):run(b)


def test_high_water_mark_can_advance_without_resigning(b):
    # A local rollback floor changes validation policy, not historical signers' commitments.
    for i,w in enumerate(b['witnesses']):
        body={**b['checkpoints'][i]['body'],'sequence':3}
        b['checkpoints'][i]=seal('checkpoint',body,w)
    original_ref=checkpoint_policy_ref(b['checkpoint_policy'])
    b['checkpoint_policy']['minimum_sequence']=3
    assert checkpoint_policy_ref(b['checkpoint_policy'])==original_ref
    assert run(b)['status']=='CONDITIONAL'
    b['checkpoint_policy']['minimum_sequence']=4
    assert run(b)['status']=='INSUFFICIENT'
    assert all(e['reason']=='BELOW_CALLER_HIGH_WATER_MARK' for e in run(b)['excluded_checkpoints'])


def test_reader_age_limit_can_tighten_without_resigning(b):
    before=run(b)
    b['checkpoint_policy']['max_age_seconds']=5
    after=run(b)
    assert after['membership_policy_ref']==before['membership_policy_ref']
    assert after['policy_ref']!=before['policy_ref']
    assert after['status']=='INSUFFICIENT'
    assert all(e['reason']=='STALE_OBSERVATION' for e in after['excluded_checkpoints'])
