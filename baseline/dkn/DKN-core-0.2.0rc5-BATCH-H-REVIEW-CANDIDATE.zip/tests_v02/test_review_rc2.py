"""Review regressions: source completeness, index integrity, bounded reports, replay binding."""
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path
import random
import stat
import struct
import zipfile
import pytest
from dkn_v02 import core
from dkn_v02 import *
from dkn_v02.navigation import LocalIndex, relation_commitment
from dkn_v02.runtime_schemas import validate_report
from examples.v02_assurance import fixture_bundle
from dkn_v02.assurance import verify_record


def test_source_scan_error_never_becomes_partial_publication(tmp_path, monkeypatch):
    (tmp_path/'visible').write_bytes(b'a'); hidden=tmp_path/'hidden';hidden.mkdir()
    (hidden/'unreadable').write_bytes(b'b')
    original=os.scandir
    def fail(path):
        if os.path.normpath(path)==str(hidden):raise PermissionError('injected scandir failure')
        return original(path)
    monkeypatch.setattr(os,'scandir',fail)
    with pytest.raises(Refusal,match='DKN_V02_IO_ERROR'):load_directory(tmp_path)


def test_empty_source_symlink_ancestor_refused(tmp_path):
    real=tmp_path/'real';real.mkdir();(real/'empty').mkdir()
    link=tmp_path/'link';link.symlink_to(real,target_is_directory=True)
    with pytest.raises(Refusal,match='SYMLINK'):load_directory(link/'empty')


@pytest.mark.parametrize('where',['root','objects','evidence'])
@pytest.mark.parametrize('operation',['add','discover','traverse','resolve'])
def test_invalid_index_container_is_not_empty(tmp_path,where,operation):
    root=tmp_path/'index'
    if where=='root':root.write_bytes(b'wrong kind')
    else:root.mkdir();(root/where).write_bytes(b'wrong kind')
    idx=LocalIndex(root);raw,m=pack({})
    operations={'add':lambda:idx.add(raw),'discover':lambda:idx.discover(semantic_name='fixture'),
                'resolve':lambda:idx.resolve_exact(m['logical_root']),
                'traverse':lambda:idx.traverse(m['logical_root'])}
    with pytest.raises(Refusal,match='NAV_INDEX_INVALID'):operations[operation]()


def test_uncreated_index_is_still_valid_empty_collection(tmp_path):
    r=LocalIndex(tmp_path/'not-created').discover(semantic_name='fixture')
    assert r['matched_locally']==0 and r['global_completeness']=='NOT_ESTABLISHED'


@pytest.mark.parametrize('path',['.dkn','.DKN','.dkn/manifest.json','.DkN/other'])
@pytest.mark.parametrize('entry',['build','pack','validate','certify','verify'])
def test_reserved_payload_paths_refuse_at_every_manifest_boundary(path,entry):
    key=fixture_bundle()['issuer'];files={path:b'x'}
    # Handcraft an otherwise self-consistent manifest to test validators independently of builders.
    body={'schema':'dkn.logical-artifact.v0.2-candidate','metadata_profile':'portable-files-only-v1',
          'inventory':[{'path':path,'type':'file','size':1,'sha256':hashlib.sha256(b'x').hexdigest()}],'dimensions':[]}
    m={**body,'logical_root':core.digest('logical',body)}
    funcs={'build':lambda:build_manifest(files),'pack':lambda:pack(files),'validate':lambda:validate_manifest(m),
           'certify':lambda:certify(m,key),'verify':lambda:verify_manifest(m,files)}
    with pytest.raises(Refusal,match='RESERVED_PATH'):funcs[entry]()


def make_relation(destination,scope='fixture'):
    return {'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':destination,'scope':scope}


def test_real_acyclic_graph_reports_edge_limit(tmp_path,monkeypatch):
    import dkn_v02.navigation as nav
    # Small limit exercises exactly the same real, non-synthetic graph boundary.
    monkeypatch.setattr(nav,'MAX_REPORT_EDGES',16)
    idx=LocalIndex(tmp_path);roots=[]
    for j in range(3):
        rel=[make_relation(f'{100+j*8+k:064x}') for k in range(8)]
        raw,m=pack({'n':str(j).encode()},[relation_commitment(rel)]);idx.add(raw,relations=rel);roots.append(m['logical_root'])
    rel=[make_relation(r) for r in roots];raw,m=pack({},[relation_commitment(rel)]);idx.add(raw,relations=rel)
    report=idx.traverse(m['logical_root'],max_depth=2)
    assert report['truncated'] and report['edge_limited'] and not report['depth_limited']
    assert len(report['edges'])==16 and report['max_edges']==16
    canonical(report)


def test_report_byte_overflow_is_typed_not_noncanonical_success(tmp_path,monkeypatch):
    idx=LocalIndex(tmp_path);raw,m=pack({});idx.add(raw)
    original=core.MAX_META
    monkeypatch.setattr(core,'MAX_META',100)
    with pytest.raises(Refusal,match='NAV_LIMIT'):idx._report({'long':'x'*101})
    monkeypatch.setattr(core,'MAX_META',original)
    assert validate_report('traversal',idx.traverse(m['logical_root']))['max_edges']==4096


def test_archive_metadata_budget_precedes_payload_read(monkeypatch):
    raw,_=pack({'a':b'x'})
    original=zipfile.ZipFile.read;seen=[]
    def tracked(self,name,*a,**kw):
        seen.append(name.filename if isinstance(name,zipfile.ZipInfo) else name)
        return original(self,name,*a,**kw)
    monkeypatch.setattr(zipfile.ZipFile,'read',tracked)
    monkeypatch.setattr(core,'MAX_META',10)
    with pytest.raises(Refusal,match='LIMIT'):verify_archive(raw)
    assert not seen


@pytest.mark.parametrize('field,value',[(1,1),(2,1),(3,5000),(4,5000),(5,0xffffffff),(6,0xffffffff),(7,1)])
def test_eocd_budget_precedes_zip_parser(field,value,monkeypatch):
    raw,_=pack({});header=list(struct.unpack('<4s4H2LH',raw[-22:]));header[field]=value
    bad=raw[:-22]+struct.pack('<4s4H2LH',*header)
    def forbidden(*a,**kw):raise AssertionError('ZIP parser must not be reached')
    monkeypatch.setattr(zipfile,'ZipFile',forbidden)
    with pytest.raises(Refusal):verify_archive(bad)


def test_seeded_archive_mutations_fail_closed():
    raw,_=pack({'a':b'abc','b':bytes(range(64))});rng=random.Random(20261107)
    for _ in range(1000):
        bad=bytearray(raw);i=rng.randrange(len(bad));bad[i]^=rng.randrange(1,256)
        with pytest.raises(Refusal):verify_archive(bytes(bad))


def test_signed_record_field_mutations_never_escape_typed_refusal():
    b=fixture_bundle();records=[b['descriptor'],*b['evidence'],*b['checkpoints']]
    bad_values=[None,True,False,0,-1,2**63,'','bad\n',[],{},['x']]
    n=0
    for original in records:
        for field in original:
            for value in bad_values:
                if type(value) is type(original[field]) and value==original[field]:continue
                bad=deepcopy(original);bad[field]=value;n+=1
                with pytest.raises(Refusal):verify_record(bad)
    assert n==264


def test_fingerprint_covers_legacy_vectors_and_contract(tmp_path,monkeypatch):
    import tools.verify_v02_candidate as runner
    monkeypatch.setattr(runner,'ROOT',tmp_path)
    folders=('src','tests','tests_v02','tools','interop','schemas','examples','vectors','profiles','docs','design-v0.2','model')
    for folder in folders:
        (tmp_path/folder).mkdir();(tmp_path/folder/'fixture').write_bytes(b'a')
    (tmp_path/'pyproject.toml').write_text('')
    initial=runner.source_fingerprint()
    for folder in folders:
        f=tmp_path/folder/'fixture';f.write_bytes(b'b');assert runner.source_fingerprint()!=initial;f.write_bytes(b'a')
    assert runner.source_fingerprint()==initial


def test_no_implicit_namespace_authority_from_valid_signature():
    from dkn_v02.navigation import inspect
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    a=Ed25519PrivateKey.from_private_bytes(b'1'*32);b=Ed25519PrivateKey.from_private_bytes(b'2'*32)
    g=declare_genesis(semantic_name='same-name',purpose='publisher',nonce='test',key=a)
    raw,m=pack({});c=certify(m,b,namespace_root=g['namespace_root'])
    r=inspect(raw,certificate=c,genesis=g)
    assert r['certificate_signature']=='PASS'
    assert r['namespace_authorization']=='NOT_ESTABLISHED' and r['authority_effect']=='NONE'


def test_namespace_comparison_without_genesis_is_canonical(tmp_path):
    b=fixture_bundle();raw,m=pack({});root='a'*64
    idx=LocalIndex(tmp_path);idx.add(raw,certificate=certify(m,b['issuer'],namespace_root=root))
    report=idx.compare_namespace(root)
    assert report['semantic_name_groups']=={}
    assert report['unnamed_candidate_roots']==[m['logical_root']]
    assert report['fork_proven']=='NOT_ESTABLISHED'
    validate_report('namespace-candidates',report)


def test_application_policy_checks_real_payload_semantics():
    from examples.v02_reader_policy import run
    r=run();assert r['status']=='ADMITTED_AS_UTF8_NOTE' and not r['execution_authorized']


@pytest.mark.parametrize('field',['expected_root','pinned_namespace_root','pinned_publisher_key'])
def test_application_pins_are_not_learned_from_bundle(field):
    from examples.v02_reader_policy import make_demo,accept_note
    b,pins,_=make_demo();pins[field]='0'*64
    with pytest.raises(Refusal,match='APP_.*PIN_MISMATCH'):accept_note(**b,**pins)


def test_application_rejects_signed_but_semantically_invalid_payload():
    from examples.v02_reader_policy import make_demo,accept_note,SCHEMA
    b,pins,key=make_demo()
    b['raw'],b['manifest']=pack({'note.txt':b'\xff'},[commit('note-profile',SCHEMA,b['declaration'])])
    pins['expected_root']=b['manifest']['logical_root']
    b['certificate']=certify(b['manifest'],key,namespace_root=b['genesis']['namespace_root'])
    assert verify_archive(b['raw'])['status']=='PASS'
    with pytest.raises(Refusal,match='APP_PAYLOAD_ENCODING_MISMATCH'):accept_note(**b,**pins)


def test_application_requires_dimension_even_when_crypto_verifies():
    from examples.v02_reader_policy import make_demo,accept_note
    b,pins,key=make_demo();b['raw'],b['manifest']=pack({'note.txt':b'valid bytes but missing declaration'})
    pins['expected_root']=b['manifest']['logical_root']
    b['certificate']=certify(b['manifest'],key,namespace_root=b['genesis']['namespace_root'])
    with pytest.raises(Refusal,match='APP_REQUIRED_DIMENSION_MISSING'):accept_note(**b,**pins)


def test_packer_does_not_claim_to_scrub_payload_secrets():
    # The known public fixture is deliberately packable. No actual secret is used.
    raw,m=pack({'fixture-seed.txt':b'PUBLIC NON-PRODUCTION FIXTURE ONLY'})
    assert verify_archive(raw)['status']=='PASS'
    assert m['inventory'][0]['path']=='fixture-seed.txt'


def test_index_scan_io_error_is_typed(tmp_path,monkeypatch):
    idx=LocalIndex(tmp_path);raw,_=pack({});idx.add(raw)
    original=Path.iterdir
    def fail(path):
        if path==idx.metadata:raise PermissionError('injected index scan failure')
        return original(path)
    monkeypatch.setattr(Path,'iterdir',fail)
    with pytest.raises(Refusal,match='DKN_V02_NAV_IO_ERROR'):idx.discover(semantic_name='fixture')


_CORPUS=read_canonical((Path(__file__).resolve().parents[1]/'interop/portable-conformance-rc2.json').read_bytes())
@pytest.mark.parametrize('case',_CORPUS['cases'],ids=lambda c:c['request']['id'])
def test_frozen_portable_conformance_case(case):
    from tools.reference_conformance import execute
    result=execute({'schema':'dkn.conformance-request.v0.2-rc2','cases':[case['request']]})
    assert result['results']==[case['expected']]
