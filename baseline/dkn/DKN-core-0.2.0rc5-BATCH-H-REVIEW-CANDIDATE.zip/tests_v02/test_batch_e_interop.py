"""Cross-language byte/signature agreement; not independent organizational review."""
import base64
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02.core import canonical, DOMAINS, certify, pack, key_hex, declare_genesis

ROOT=Path(__file__).resolve().parents[1]
NODE=shutil.which('node')
pytestmark=pytest.mark.skipif(NODE is None,reason='NODE_NOT_AVAILABLE: cross-language gate not run')

def node(tmp_path,op,args,okay=True):
    p=tmp_path/'request.json';p.write_bytes(canonical({'operation':op,'arguments':args}))
    run=subprocess.run([NODE,str(ROOT/'interop/dkn_v02_verify.mjs'),str(p)],capture_output=True,timeout=15)
    result=json.loads(run.stdout)
    assert run.returncode==(0 if okay else 2),(result,run.stderr.decode())
    assert result['status']==('PASS' if okay else 'REFUSED')
    return result

@pytest.mark.parametrize('value',[
    None,True,False,0,-1,-(2**63),2**63-1,2**53+1,
    {'\ue000':1,'\U00010000':2}, {'z':'é','a':['水',1]},
    {'__proto__':'not-a-prototype','constructor':17}, {'x':'\u2028\u2029\n\t\b\f\r\u0000/"\\'},
    {str(i):i for i in [2,10,1]}, {'empty':{},'list':[]},'😀'])
def test_canonical_python_node(tmp_path,value):
    b64=base64.b64encode(canonical(value)).decode()
    assert node(tmp_path,'canonical',{'raw_base64':b64})['result']['canonical_base64']==b64

@pytest.mark.parametrize('raw',[
    b'{"a":1,"a":2}',b'\xef\xbb\xbf{}',b'1.0',b'NaN',b'1e3',b'-0',
    b'9223372036854775808',b'-9223372036854775809',b'"\\ud800"',b'{}\n',
    b'['*34+b'0'+b']'*34,b'"\xff"',b'{"b":1,"a":2}'])
def test_invalid_canonical_node(tmp_path,raw):
    node(tmp_path,'canonical',{'raw_base64':base64.b64encode(raw).decode()},okay=False)

@pytest.mark.parametrize('domain',list(DOMAINS.values()))
def test_domain_separated_hashes(tmp_path,domain):
    raw=canonical({'\ue000':2**63-1,'\U00010000':-(2**63)})
    result=node(tmp_path,'hash',{'domain_hex':domain.hex(),'canonical_base64':base64.b64encode(raw).decode()})
    assert result['result']['digest']==hashlib.sha256(domain+raw).hexdigest()

@pytest.mark.parametrize('name,kind', [('detached_certificate','certificate'),('genesis','genesis'),('transition_1','transition')])
def test_existing_core_signed_vectors(tmp_path,name,kind):
    v=json.loads((ROOT/'vectors/v02-candidate-vectors.json').read_bytes());record=v[name]
    node(tmp_path,'signed',{'kind':kind,'record':record})
    record['signature_hex']='00'*64
    node(tmp_path,'signed',{'kind':kind,'record':record},okay=False)

@pytest.mark.parametrize('name',['descriptor','evidence','checkpoint'])
def test_existing_sam_signed_vectors(tmp_path,name):
    v=json.loads((ROOT/'vectors/v02-sam-vectors.json').read_bytes());args=v['evaluation_request']['arguments']
    record=args['descriptor'] if name=='descriptor' else (args['evidence'][0] if name=='evidence' else v['checkpoints'][0])
    node(tmp_path,'signed',{'kind':'sam','record':record})

@pytest.mark.parametrize('label,result_name',[
    ('assessment','evaluation_result'),('composition','composition_result'),
    ('checkpoint-report','checkpoint_result'),('handoff','handoff_result')])
def test_existing_report_roots(tmp_path,label,result_name):
    v=json.loads((ROOT/'vectors/v02-sam-vectors.json').read_bytes());record=v[result_name]
    body={k:v for k,v in record.items() if k!='report_hash'}
    domain=b'DKN_V02_SAM_'+label.upper().encode()+b'\0'
    r=node(tmp_path,'hash',{'domain_hex':domain.hex(),'canonical_base64':base64.b64encode(canonical(body)).decode()})
    assert r['result']['digest']==record['report_hash']

@pytest.mark.parametrize('pub',['01'+'00'*31,'00'*32,'ff'*32,'ec'+'ff'*30+'7f'])
def test_weak_keys_refused_by_both(tmp_path,pub):
    from dkn_v02.core import _public,Refusal
    with pytest.raises(Refusal):_public(pub)
    node(tmp_path,'signature',{'public_key_hex':pub,'signature_hex':'01'+'00'*63,'message_hex':''},okay=False)

def test_rfc8032_vector_node(tmp_path):
    node(tmp_path,'signature',{
        'public_key_hex':'d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a',
        'signature_hex':'e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b',
        'message_hex':''})

def test_new_signature_with_i64_unicode_body(tmp_path):
    from dkn_v02.assurance import seal
    from examples.v02_assurance import fixture_bundle
    b=fixture_bundle()['descriptor']['body'];b={**b,'valid_until':2**63-1}
    record=seal('substrate',b,Ed25519PrivateKey.from_private_bytes(b'\x22'*32))
    node(tmp_path,'signed',{'kind':'sam','record':record})

@pytest.mark.parametrize('kind',['state','semantic','governance','manifest'])
def test_original_thr_sha256_vectors(tmp_path,kind):
    v=json.loads((ROOT/'vectors/golden-vectors.json').read_bytes())['accepted']['thr_manifest']
    if kind=='manifest':
        domain=b'DKN_THR_MANIFEST_V0.1\0';body={k:x for k,x in v.items() if k!='thr_manifest_hash'};expected=v['thr_manifest_hash']
    else:
        domain=b'DKN_THR_'+kind.upper().encode()+b'_V0.1\0';body=v['components'][kind];expected=v['commitments'][kind+'_hash']
    raw=canonical(body)
    assert hashlib.sha256(domain+raw).hexdigest()==expected
    r=node(tmp_path,'hash',{'domain_hex':domain.hex(),'canonical_base64':base64.b64encode(raw).decode()})
    assert r['result']['digest']==expected

@pytest.mark.parametrize('kind',['manifest','dimension'])
def test_original_v02_commitment_roots(tmp_path,kind):
    v=json.loads((ROOT/'vectors/v02-candidate-vectors.json').read_bytes())
    if kind=='manifest':
        domain=DOMAINS['logical'];body={k:x for k,x in v['manifest'].items() if k!='logical_root'};expected=v['manifest']['logical_root']
    else:
        domain=DOMAINS['dimension'];body={'schema_id':'example.semantic','value':{'label':'Demo'}};expected=v['dimension']['digest_hex']
    r=node(tmp_path,'hash',{'domain_hex':domain.hex(),'canonical_base64':base64.b64encode(canonical(body)).decode()})
    assert r['result']['digest']==expected
