from copy import deepcopy
import pytest
from dkn_v02.core import canonical, Refusal
from dkn_v02.assurance import seal, compose
from examples.v02_assurance import fixture_bundle

@pytest.fixture
def b():return fixture_bundle()

def descriptor(b,name,domain,**extra):
    body={**b['descriptor']['body'],'substrate_id':name,
          'fault_domains':[{'dimension':'administration','domain_id':domain}],**extra}
    return seal('substrate',body,b['issuer'])


def test_shared_control_not_replica_independence(b):
    d=descriptor(b,'second','fixture-owner')
    r=compose([d,b['descriptor']],roots=[d['record_hash'],b['descriptor']['record_hash']],at_time=1000)
    assert r['status']=='DECLARED_CONFLICTS_DETECTED'
    assert r['pairs'][0]['shared_fault_domains']['administration']==['fixture-owner']
    assert r['independence']=='NOT_ESTABLISHED'


def test_transitive_shared_dependency(b):
    common=descriptor(b,'upstream','shared-idp')
    mid=descriptor(b,'middle','middle-admin',dependencies=[common['record_hash']])
    a=descriptor(b,'first','a',dependencies=[mid['record_hash']])
    c=descriptor(b,'second','c',dependencies=[common['record_hash']])
    r=compose([a,c,mid,common],roots=[a['record_hash'],c['record_hash']],at_time=1000)
    assert common['record_hash'] in r['pairs'][0]['shared_dependencies']
    assert 'shared-idp' in r['pairs'][0]['shared_fault_domains']['administration']


def test_no_overlap_not_proven_independence(b):
    d=descriptor(b,'other','other')
    r=compose([d,b['descriptor']],roots=[d['record_hash'],b['descriptor']['record_hash']],at_time=1000)
    assert r['status']=='NO_DECLARED_CONFLICTS_WITHIN_SCOPE'
    assert r['independence']=='NOT_ESTABLISHED' and 'region' in r['pairs'][0]['incomplete_domain_dimensions']


def test_missing_dependency_remains_unknown(b):
    d=descriptor(b,'dangling','other',dependencies=['0'*64])
    r=compose([d],roots=[d['record_hash']],at_time=1000)
    assert r['status']=='INCOMPLETE' and r['missing_dependencies']==['0'*64]


def test_unknown_shared_dependency_still_overlap(b):
    a=descriptor(b,'one','one',dependencies=['0'*64])
    c=descriptor(b,'two','two',dependencies=['0'*64])
    r=compose([a,c],roots=[a['record_hash'],c['record_hash']],at_time=1000)
    assert r['status']=='DECLARED_CONFLICTS_DETECTED'
    assert r['pairs'][0]['shared_dependencies']==['0'*64]


def test_mutually_exclusive_assumptions(b):
    a=descriptor(b,'one','one',assumptions=[{'id':'public-network','value':True}])
    c=descriptor(b,'two','two',assumptions=[{'id':'public-network','value':False}])
    r=compose([a,c],roots=[a['record_hash'],c['record_hash']],at_time=1000)
    assert 'public-network' in r['conflicting_assumptions']


def test_dependency_public_metadata_leak(b):
    pub=descriptor(b,'public','pub',metadata_visibility='PUBLIC')
    private=descriptor(b,'private','priv',dependencies=[pub['record_hash']])
    r=compose([private,pub],roots=[private['record_hash']],at_time=1000)
    assert r['public_metadata_descriptors']==[pub['record_hash']]


def test_unused_descriptor_does_not_taint_composition(b):
    pub=descriptor(b,'public','pub',metadata_visibility='PUBLIC')
    r=compose([b['descriptor'],pub],roots=[b['descriptor']['record_hash']],at_time=1000)
    assert not r['public_metadata_descriptors']
    assert r['unused_descriptor_refs']==[pub['record_hash']]


def test_expired_descriptor(b):
    r=compose([b['descriptor']],roots=[b['descriptor']['record_hash']],at_time=2000)
    assert r['status']=='INCOMPLETE'


def test_permutation_stable(b):
    d=descriptor(b,'second','second');roots=[d['record_hash'],b['descriptor']['record_hash']]
    x=compose([d,b['descriptor']],roots=roots,at_time=1000)
    y=compose([b['descriptor'],d],roots=list(reversed(roots)),at_time=1000)
    assert canonical(x)==canonical(y)

@pytest.mark.parametrize('roots',[[],['f'*64],[True]])
def test_bad_roots(b,roots):
    with pytest.raises(Refusal):compose([b['descriptor']],roots=roots,at_time=1000)
