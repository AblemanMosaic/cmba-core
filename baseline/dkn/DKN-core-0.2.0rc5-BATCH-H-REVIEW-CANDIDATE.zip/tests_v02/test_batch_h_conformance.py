"""A replacement must match exact typed canonical responses, not Python equality."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import pytest
from dkn_v02 import canonical
from tools import run_conformance as harness

ROOT=Path(__file__).resolve().parents[1]
CORPORA=['portable-conformance-rc2.json','lifecycle-f1-conformance.json','distributed-g1-conformance.json']


def expected(name):
    c=json.loads((ROOT/'interop'/name).read_bytes())
    return {'schema':'dkn.conformance-response.v0.2-rc2','results':[x['expected'] for x in c['cases']],'authority_effect':'NONE'}


def response(monkeypatch,name,raw,code=0):
    monkeypatch.setattr(harness.subprocess,'run',lambda *a,**k:subprocess.CompletedProcess(['public-fixture'],code,raw,b''))
    return harness.run(['public-fixture'],ROOT/'interop'/name)


@pytest.mark.parametrize('name',CORPORA)
def test_exact_reference_response_passes(monkeypatch,name):
    assert response(monkeypatch,name,canonical(expected(name)))['status']=='PASS'


@pytest.mark.parametrize('name',CORPORA)
@pytest.mark.parametrize('raw',[b'null',b'true',b'false',b'0',b'1',b'[]',b'{}',b'"PASS"'])
def test_wrong_envelope_never_passes(monkeypatch,name,raw):
    assert response(monkeypatch,name,raw)['status']=='FAIL'


@pytest.mark.parametrize('name',CORPORA)
@pytest.mark.parametrize('mode',['bool-to-int','int-to-bool'])
def test_boolean_integer_alias_rejected(monkeypatch,name,mode):
    value=expected(name);changed=[]
    def walk(x):
        if mode=='bool-to-int' and type(x) is bool: changed.append(1);return int(x)
        if mode=='int-to-bool' and type(x) is int and x in (0,1):changed.append(1);return bool(x)
        if type(x) is list:return [walk(v) for v in x]
        if type(x) is dict:return {k:walk(v) for k,v in x.items()}
        return x
    mutated=walk(value)
    assert changed, 'fixture must actually change typed fields'
    assert mutated==value, 'witness targets the Python equality alias'
    assert canonical(mutated)!=canonical(value)
    assert response(monkeypatch,name,canonical(mutated))['status']=='FAIL'


@pytest.mark.parametrize('name',CORPORA)
@pytest.mark.parametrize('mode',['empty','missing','duplicate','reordered','extra-envelope','wrong-schema','authority','case-id','wrong-outcome','newline','nonzero-exit'])
def test_faulty_replacement_result_never_passes(monkeypatch,name,mode):
    v=deepcopy(expected(name));code=0
    if mode=='empty':v['results']=[]
    elif mode=='missing':v['results'].pop()
    elif mode=='duplicate':v['results'].append(v['results'][0])
    elif mode=='reordered':v['results'].reverse()
    elif mode=='extra-envelope':v['extra']=True
    elif mode=='wrong-schema':v['schema']='unknown'
    elif mode=='authority':v['authority_effect']='GRANTED'
    elif mode=='case-id':v['results'][0]['id']='foreign-id'
    elif mode=='wrong-outcome':v['results'][0]['outcome']='REFUSED' if v['results'][0]['outcome']=='RETURNED' else 'RETURNED'
    elif mode=='nonzero-exit':code=2
    raw=canonical(v)+(b'\n' if mode=='newline' else b'')
    assert response(monkeypatch,name,raw,code)['status']=='FAIL'
