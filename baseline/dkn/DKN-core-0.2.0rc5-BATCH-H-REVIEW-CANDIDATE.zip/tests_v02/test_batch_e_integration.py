"""Integration/refusal boundary checks and package metadata obligations."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tomllib
import zipfile

import pytest
from dkn_v02 import *
from dkn_v02.core import digest,DOMAINS
from dkn_v02.assurance import verify_record
from dkn_v02.sam_abi import dispatch
from dkn_v02.legacy_entrypoint import main as legacy_main
from tools.build_v02_candidate import build,verify,MANIFEST,PREDECESSOR
from examples.v02_assurance import fixture_bundle,run

ROOT=Path(__file__).resolve().parents[1]
BAD=[None,False,True,0,1,'','x',[],{}, {'x':1}]

@pytest.mark.parametrize('value',BAD)
@pytest.mark.parametrize('entry',['genesis','transition-chain','dimension','manifest','certificate','sam-record','sam-abi'])
def test_public_verification_malformed_inputs_are_typed(value,entry):
    b=fixture_bundle();g=declare_genesis(semantic_name='fixture',purpose='publisher',nonce='init',key=b['issuer'])
    functions={
        'genesis':lambda:verify_genesis(value),
        'transition-chain':lambda:verify_transitions(g,value),
        'dimension':lambda:verify_dimension(value),
        'manifest':lambda:verify_manifest(value,{}),
        'certificate':lambda:verify_certificate(value,b['manifest']),
        'sam-record':lambda:verify_record(value),
        'sam-abi':lambda:dispatch(value)}
    # An empty transition chain is well-formed, not a failure fixture.
    if entry=='transition-chain' and value==[] and type(value) is list:
        assert functions[entry]() ['epoch']==0
    else:
        with pytest.raises(Refusal):functions[entry]()

def test_full_offline_flow_with_socket_access_forbidden(monkeypatch):
    def fail(*a,**k):raise AssertionError('NETWORK_FORBIDDEN')
    monkeypatch.setattr(socket,'socket',fail);monkeypatch.setattr(socket,'create_connection',fail)
    assert run()['offline_retrieval']=='RETRIEVED'

def test_optional_legacy_dependency_explicit(capsys):
    if importlib.util.find_spec('blake3') is not None:pytest.skip('missing-dependency branch only')
    assert legacy_main()==2
    assert json.loads(capsys.readouterr().out)['code']=='DKN_LEGACY_DEPENDENCY_UNAVAILABLE'

def test_packaging_metadata():
    p=tomllib.loads((ROOT/'pyproject.toml').read_text())
    assert p['project']['version']=='0.2.0rc5'
    assert any('blake3' in x for x in p['project']['optional-dependencies']['legacy'])
    assert not any('blake3' in x for x in p['project']['dependencies'])
    assert set(p['project']['scripts'])=={'dkn','dkn-v02','dkn-nav','dkn-sam','dkn-lifecycle','dkn-sim'}

def test_batch_e_predecessor_is_d():
    assert MANIFEST=='BATCH-E-FILE-MANIFEST.json'
    assert PREDECESSOR=='c07838e206dcd7928ff92dc8ab5dd42fdf2e84a5096e914f846a2443d5c2a3a6'

@pytest.mark.parametrize('mutation',['prefix','suffix','comment'])
def test_candidate_transport_exactness(tmp_path,mutation):
    (tmp_path/'x').write_bytes(b'x');raw,_=build(tmp_path)
    if mutation=='prefix':bad=b'x'+raw
    elif mutation=='suffix':bad=raw+b'x'
    else:
        b=io.BytesIO(raw)
        with zipfile.ZipFile(b,'a') as z:z.comment=b'changed'
        bad=b.getvalue()
    with pytest.raises(ValueError):verify(bad)

def test_unchanged_v02_vectors_regenerate_exactly():
    from tools.export_sam_reference import build_vectors
    raw=(ROOT/'vectors/v02-sam-vectors.json').read_bytes()
    assert canonical(build_vectors())==raw

@pytest.mark.parametrize('path',['golden-vectors.json','v02-candidate-vectors.json','v02-sam-vectors.json'])
def test_vector_files_present(path):assert (ROOT/'vectors'/path).is_file()

@pytest.mark.parametrize('algorithm',['SHA-1','BLAKE3','sha256',None,[]])
def test_algorithm_downgrade_refused(algorithm):
    d=commit('state','example.state',{});d['algorithm']=algorithm
    with pytest.raises(Refusal):verify_dimension(d)

def test_typed_dimension_domain_separation():
    a=commit('a','example.a',{});b=commit('a','example.b',{})
    assert a['digest_hex']!=b['digest_hex']
    # Labels are bound at the manifest level; value commitment also binds schema.
    c={**a,'dimension_id':'b'}
    assert build_manifest({},[a])['logical_root']!=build_manifest({},[c])['logical_root']

def test_traversal_cycle_control_flow_is_bounded(tmp_path,monkeypatch):
    # Synthetic graph fixture tests the traversal algorithm, not realizability of
    # a cyclic set of immutable SHA-256 content-addressed manifests.
    from dkn_v02.navigation import LocalIndex
    idx=LocalIndex(tmp_path);a='aa'*32;b='bb'*32
    def record(source,dest):
        return {'relations':[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':dest,'scope':'synthetic-cycle'}],
                'relation_authentication':'NOT_ESTABLISHED'}
    monkeypatch.setattr(idx,'_roots',lambda:[a,b]);monkeypatch.setattr(idx,'_scan_budget',lambda roots:None)
    monkeypatch.setattr(idx,'resolve_exact',lambda root:record(root,b if root==a else a))
    result=idx.traverse(a,max_depth=8)
    assert len(result['nodes'])==2 and len(result['edges'])==2
