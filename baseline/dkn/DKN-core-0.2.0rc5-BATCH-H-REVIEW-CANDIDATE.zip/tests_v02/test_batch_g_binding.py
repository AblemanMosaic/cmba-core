"""Model, realization, predecessor and source-package boundaries."""
from pathlib import Path
import json,shutil
import pytest
from dkn_v02 import canonical,Refusal
from tools import check_distributed_contract as checker
from tools import check_lifecycle_contract,check_semantic_contract
from tools import build_batch_g_candidate as builder
ROOT=Path(__file__).resolve().parents[1]

def test_all_three_semantic_contracts_bound_and_predecessors_unchanged():
    base=check_semantic_contract.check();lc=check_lifecycle_contract.check();ds=checker.check()
    assert base['status']==lc['status']==ds['status']=='PASS_REFERENCE_INTEGRITY'
    assert base['semantic_digest']=='0fbd636ce484dd37e4afc4083f5207d86143ec1de0ee031ce76d1e67137497fb'
    assert lc['semantic_digest']=='cdb44fd68c6e60d5317b889a123837c413aa629c0c77a121c17133b055a63e19'
    assert ds['obligations']==14 and ds['executed_test_binding']=='NOT_CHECKED'

def test_semantic_mutation_refuses(tmp_path):
    shutil.copytree(ROOT/'model',tmp_path/'model')
    p=tmp_path/'model/distributed-g1/CONTRACT.json';v=json.loads(p.read_bytes());v['authority_effect']='GRANTED'
    p.write_bytes(canonical(v))
    with pytest.raises(Refusal,match='DIMENSION_MISMATCH'):checker.check(tmp_path)

def test_source_mutation_detected(tmp_path):
    shutil.copytree(ROOT,tmp_path/'copy',ignore=shutil.ignore_patterns('__pycache__','build','*.egg-info'))
    root=tmp_path/'copy';p=root/'src/dkn_v02/simulation.py';p.write_text(p.read_text()+'\n# changed\n')
    assert 'HASH_MISMATCH:src/dkn_v02/simulation.py' in checker.check(root)['findings']

def test_foreign_test_evidence_not_current():
    r=checker.check(report={'source_fingerprint':'0'*64,'test_cases':[]})
    assert 'EXECUTED_SOURCE_MISMATCH' in r['findings'] and any(x.startswith('TEST_NOT_ESTABLISHED') for x in r['findings'])

def test_exact_batch_f_predecessor_and_closed_package(tmp_path):
    (tmp_path/'fixture.txt').write_text('a fixture, not a published claim')
    raw,m=builder.build(tmp_path)
    assert builder.verify(raw)['status']=='PASS'
    assert m['predecessor_archive_sha256']=='18138c2af53ac18057017a07fdd5e3f5abf72d935a5d88b7701052c6407b247a'
    assert builder.build(tmp_path)[0]==raw

@pytest.mark.parametrize('name',['../escape','/absolute','x\\y'])
def test_package_rejects_unsafe_paths(name):
    import io,zipfile
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w') as z:z.writestr(name,b'bad')
    with pytest.raises(ValueError):builder.verify(data.getvalue())
