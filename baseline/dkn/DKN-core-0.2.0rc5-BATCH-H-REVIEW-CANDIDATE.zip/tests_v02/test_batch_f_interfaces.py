"""Frozen LC-F1 corpus, runtime shapes, primitive interop and installed-surface contracts."""
import base64
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import pytest
from jsonschema import Draft202012Validator
from dkn_v02 import canonical, read_canonical, Refusal, key_hex
from dkn_v02 import lifecycle as lc
from dkn_v02.lifecycle_abi import dispatch
from dkn_v02.lifecycle_schemas import SCHEMAS, validate_shape
from dkn_v02.vault import TransactionalVault
from tools import build_lifecycle_vectors as generator
from tools.reference_lifecycle_conformance import execute
from tests_v02.test_batch_f_lifecycle import setup, grant, event
ROOT=Path(__file__).resolve().parents[1]
CORPUS=read_canonical((ROOT/'interop/lifecycle-f1-conformance.json').read_bytes())
FIXTURE=read_canonical((ROOT/'vectors/v02/lifecycle-f1.json').read_bytes())


@pytest.mark.parametrize('case',CORPUS['cases'],ids=lambda c:c['request']['id'])
def test_frozen_lifecycle_corpus(case):
    result=execute({'schema':'dkn.conformance-request.v0.2-rc2','cases':[case['request']]})
    assert result['results']==[case['expected']]
    assert result['authority_effect']=='NONE'


def test_fixture_regeneration_is_exact():
    fixture,corpus=generator.build()
    assert fixture==FIXTURE and corpus==CORPUS


@pytest.mark.parametrize('name',list(SCHEMAS))
def test_exported_schemas_match_runtime(name):
    Draft202012Validator.check_schema(SCHEMAS[name])
    path=ROOT/'schemas/v02/lifecycle-f1'/(name+'.schema.json')
    assert json.loads(path.read_text())==SCHEMAS[name]


def test_shapes_cover_positive_fixtures_and_vault(tmp_path):
    f=FIXTURE
    validate_shape('policy',f['policy']);validate_shape('checkpoint',f['checkpoint'])
    for name,events in f['chains'].items():
        for e in events:validate_shape('event',e)
        validate_shape('state',f['states'][name])
    from dkn_v02 import pack
    raw,manifest=pack({'x':b'x'})
    vault=TransactionalVault.create(tmp_path/'v.db')
    validate_shape('vault-write',vault.put_artifact(raw))
    validate_shape('vault-query',vault.resolve_exact(manifest['logical_root']))
    validate_shape('vault-query',vault.traverse(manifest['logical_root']))
    validate_shape('vault-query',vault.discover(semantic_name='not-found'))
    validate_shape('vault-pin',vault.advance_namespace(f['genesis'],f['policy'],[],expected_head=None))
    validate_shape('vault-namespace-read',vault.read_namespace(f['genesis']['namespace_root']))


@pytest.mark.parametrize('status',['AUTHORIZED','PASS','GRANTED','APPROVED'])
def test_assessment_cannot_promote_authority(status):
    valid=deepcopy(next(c['expected']['result'] for c in CORPUS['cases'] if c['request']['id']=='exact-scope'))
    valid['status']=status
    with pytest.raises(Refusal,match='SHAPE_INVALID'):validate_shape('assessment',valid)


def test_request_shape_and_runtime_are_separate():
    request=deepcopy(CORPUS['cases'][1]['request'])
    request={k:v for k,v in request.items() if k!='id'}
    request['schema']='dkn.lifecycle-request.v0.2-f1'
    validate_shape('request',request)
    # A schema-valid public-key string is not automatically an admissible Ed25519 point.
    request['arguments']['policy']=deepcopy(request['arguments']['policy'])
    request['arguments']['policy']['recovery_keys']=['01'+'00'*31]
    request['arguments']['policy']['recovery_threshold']=1
    validate_shape('request',request)
    with pytest.raises(Refusal):dispatch(request)


@pytest.mark.parametrize('bad',[None,[],True,0,'bad',{'schema':'unknown','operation':'sign','arguments':{}},
    {'schema':'dkn.lifecycle-request.v0.2-f1','operation':[],'arguments':{}},
    {'schema':'dkn.lifecycle-request.v0.2-f1','operation':'verify-policy','arguments':{'policy':{},'url':'http://example.invalid'}}])
def test_malformed_abi_inputs_typed(bad):
    with pytest.raises(Refusal):dispatch(bad)


def test_readonly_cli_and_refusal(tmp_path):
    request={'schema':'dkn.lifecycle-request.v0.2-f1','operation':'verify-policy','arguments':{'policy':FIXTURE['policy']}}
    path=tmp_path/'request.json';path.write_bytes(canonical(request));before=path.read_bytes()
    process=subprocess.run([sys.executable,'-m','dkn_v02.lifecycle_cli',str(path)],capture_output=True,timeout=10)
    assert process.returncode==0 and json.loads(process.stdout)['authority_effect']=='NONE'
    assert path.read_bytes()==before
    bad=subprocess.run([sys.executable,'-m','dkn_v02.lifecycle_cli','-'],input=b'{}',capture_output=True,timeout=10)
    assert bad.returncode==2 and json.loads(bad.stdout)['status']=='REFUSED'


def test_new_workflow_has_no_network(monkeypatch):
    import socket
    from examples.v02_lifecycle_vault import run
    def forbidden(*args,**kwargs):raise AssertionError('NETWORK_FORBIDDEN')
    monkeypatch.setattr(socket,'socket',forbidden)
    monkeypatch.setattr(socket,'create_connection',forbidden)
    assert run()['status']=='PASS'


def test_epoch_instance_stable_within_epoch_changes_on_rotation(setup):
    owner,_,successor,_,policy,genesis,_,_=setup
    initial=lc.verify_journal(genesis,policy,[])
    a=grant(setup);delegated=lc.verify_journal(genesis,policy,[a])
    b=event(setup,[a],'rotate',{'successor_public_key_hex':key_hex(successor)},keys=[owner,successor])
    rotated=lc.verify_journal(genesis,policy,[a,b])
    assert initial['epoch_instance_ref']==delegated['epoch_instance_ref']
    assert rotated['epoch_instance_ref']!=initial['epoch_instance_ref']
    assert initial['namespace_root']==rotated['namespace_root']


def _unique_events():
    return {e['event_ref']:e for chain in FIXTURE['chains'].values() for e in chain}


@pytest.mark.parametrize('event',list(_unique_events().values()),ids=lambda e:e['body']['kind'])
def test_node_checks_new_domain_hash_and_every_signature(tmp_path,event):
    node=shutil.which('node')
    if not node:pytest.skip('Node is not available; no interop PASS may be claimed')
    def run(arguments,operation):
        request={'operation':operation,'arguments':arguments}
        file=tmp_path/'node-request.json';file.write_bytes(canonical(request))
        p=subprocess.run([node,str(ROOT/'interop/dkn_v02_verify.mjs'),str(file)],capture_output=True,timeout=10)
        assert p.returncode==0,p.stdout+p.stderr
        return json.loads(p.stdout)['result']
    body=canonical(event['body'])
    hashed=run({'domain_hex':b'DKN_LC_F1\x00event\x00'.hex(),
                'canonical_base64':base64.b64encode(body).decode()},'hash')
    assert hashed['digest']==event['event_ref']
    for signature in event['signatures']:
        verified=run({'public_key_hex':signature['public_key_hex'],'signature_hex':signature['signature_hex'],
            'message_hex':(b'DKN_LC_F1\x00event-signature\x00'+body).hex()},'signature')
        assert verified['signature']=='PASS'


def test_protocol_view_input_is_not_mutated():
    f=deepcopy(FIXTURE);before=canonical(f)
    lc.verify_journal(f['genesis'],f['policy'],f['chains']['recovered'])
    assert canonical(f)==before
