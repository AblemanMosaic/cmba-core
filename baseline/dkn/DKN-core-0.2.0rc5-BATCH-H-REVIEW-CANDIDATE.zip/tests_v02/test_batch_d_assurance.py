"""Batch D: evidence contracts are not operational guarantees."""
from copy import deepcopy
from pathlib import Path
import json
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02.core import Refusal, canonical, read_canonical, key_hex
from dkn_v02.assurance import seal, verify_record, validate, evaluate, sam_hash
from dkn_v02.reference_profiles import reference_profile
from dkn_v02.sam_schemas import SCHEMAS, PROFILES
from examples.v02_assurance import fixture_bundle

ROOT = Path(__file__).resolve().parents[1]

@pytest.fixture
def b(): return fixture_bundle()

def run(b):
    return evaluate(**{k:b[k] for k in ('descriptor','contract','evidence','policy','context')})

def set_evidence(b, **changes):
    body = {**b['evidence'][0]['body'], **changes}
    b['evidence'] = [seal('evidence', body, b['witnesses'][0])]

def set_descriptor(b, **changes):
    b['descriptor'] = seal('substrate', {**b['descriptor']['body'], **changes}, b['issuer'])
    scope = {**b['contract']['scope'], 'substrate_ref': b['descriptor']['record_hash']}
    b['contract']['scope'] = scope
    set_evidence(b, scope=scope)

def add_second(b):
    b['evidence'].append(seal('evidence', b['evidence'][0]['body'], b['witnesses'][1]))


def test_evidence_satisfaction_has_claim_ceiling(b):
    r=run(b)
    assert r['status']=='SATISFIES' and r['authority_effect']=='NONE'
    assert r['operational_guarantee']=='NOT_ESTABLISHED_BY_THIS_EVALUATOR'
    assert r['conclusion_scope']=='SUPPLIED_EVIDENCE_OBLIGATIONS_UNDER_CALLER_POLICY'
    assert r['report_hash']==sam_hash('assessment',{k:v for k,v in r.items() if k!='report_hash'})


def test_signature_is_not_truth(b):
    r=verify_record(b['evidence'][0])
    assert r['signature']=='PASS' and r['asserted_fact']=='NOT_ESTABLISHED'

@pytest.mark.parametrize('change', ['body','hash','signature','extra','kind'])
def test_record_tamper_refuses(b,change):
    e=deepcopy(b['evidence'][0])
    if change=='body': e['body']['outcome']='REFUTES'
    elif change=='hash': e['record_hash']='0'*64
    elif change=='signature': e['signature_hex']='0'*128
    elif change=='extra': e['trusted']=True
    elif change=='kind': e['kind']='substrate'
    with pytest.raises(Refusal): verify_record(e)


def test_seal_freezes_caller_data(b):
    body=deepcopy(b['evidence'][0]['body']);e=seal('evidence',body,b['witnesses'][0])
    body['scope']['artifact_root']='0'*64
    assert e['body']['scope']['artifact_root']!='0'*64
    verify_record(e)

@pytest.mark.parametrize('name', PROFILES)
def test_profiles_never_establish_assurance(b,name):
    body=reference_profile(name)
    set_descriptor(b,**{k:v for k,v in body.items() if k!='schema'})
    assert run(b)['status']=='INSUFFICIENT'
    assert read_canonical((ROOT/'profiles/v02'/(name.lower()+'.json')).read_bytes())==body

@pytest.mark.parametrize('name', list(SCHEMAS))
def test_exported_schemas_match_runtime(name):
    assert json.loads((ROOT/'schemas/v02'/('sam-'+name+'.schema.json')).read_text())==SCHEMAS[name]


def test_no_evidence_no_promotion(b):
    b['evidence']=[]
    assert run(b)['status']=='INSUFFICIENT'


def test_declared_replica_count_is_not_observed(b):
    b['contract']['dimension']='availability'
    b['contract']['requirements'][0]['predicate']='replica.present'
    set_evidence(b,predicate='replica.present',method='DECLARATION')
    b['policy']['observers'][0]['predicates']=['replica.present']
    assert run(b)['status']=='INSUFFICIENT'


def test_unrecognized_observer_ignored(b):
    other=Ed25519PrivateKey.from_private_bytes(bytes([211])*32)
    b['evidence']=[seal('evidence',b['evidence'][0]['body'],other)]
    r=run(b)
    assert r['status']=='INSUFFICIENT'
    assert r['excluded_evidence'][0]['reason']=='OBSERVER_NOT_RECOGNIZED_FOR_PREDICATE'


def test_observer_predicate_pin_is_enforced(b):
    b['policy']['observers'][0]['predicates']=['other.predicate']
    assert run(b)['status']=='INSUFFICIENT'


def test_descriptor_signer_must_be_recognized(b):
    b['policy']['descriptor_signers']=['0'*64]
    assert run(b)['status']=='INSUFFICIENT'

@pytest.mark.parametrize('field', ['substrate_ref','artifact_root','namespace_root'])
def test_cross_scope_evidence_not_reused(b,field):
    set_evidence(b,scope={**b['evidence'][0]['body']['scope'],field:'d'*64})
    assert run(b)['status']=='INSUFFICIENT'


def test_contract_descriptor_binding_strict(b):
    b['contract']['scope']['substrate_ref']='1'*64
    with pytest.raises(Refusal,match='SCOPE_MISMATCH'):run(b)

@pytest.mark.parametrize('at,expected', [(989,'INSUFFICIENT'),(990,'SATISFIES'),(1050,'SATISFIES'),(1051,'INSUFFICIENT'),(1100,'INSUFFICIENT')])
def test_time_boundaries(b,at,expected):
    b['context']['at_time']=at
    assert run(b)['status']==expected


def test_contract_expiry(b):
    b['contract']['valid_until']=1000
    assert run(b)['status']=='INSUFFICIENT'


def test_descriptor_expiry(b):
    set_descriptor(b,valid_until=1000)
    assert run(b)['status']=='INSUFFICIENT'


def test_refutation_dominates_positive(b):
    b['evidence'].append(seal('evidence',{**b['evidence'][0]['body'],'outcome':'REFUTES'},b['witnesses'][1]))
    assert run(b)['status']=='CONTRADICTED'


def test_indeterminate_not_support(b):
    set_evidence(b,outcome='INDETERMINATE')
    assert run(b)['status']=='INSUFFICIENT'


def test_untrusted_refutation_not_a_veto(b):
    unknown=Ed25519PrivateKey.from_private_bytes(bytes([212])*32)
    b['evidence'].append(seal('evidence',{**b['evidence'][0]['body'],'outcome':'REFUTES'},unknown))
    assert run(b)['status']=='SATISFIES'


def test_stale_refutation_not_current_evidence(b):
    b['evidence'].append(seal('evidence',{**b['evidence'][0]['body'],'outcome':'REFUTES','valid_until':999},b['witnesses'][1]))
    assert run(b)['status']=='SATISFIES'


def test_same_signer_cannot_fill_quorum(b):
    b['contract']['requirements'][0]['min_signers']=2
    b['evidence'].append(seal('evidence',{**b['evidence'][0]['body'],'note':'different statement'},b['witnesses'][0]))
    assert run(b)['status']=='INSUFFICIENT'


def test_duplicate_evidence_refused(b):
    b['evidence']*=2
    with pytest.raises(Refusal,match='DUPLICATE'):run(b)


def test_common_administrator_not_independent(b):
    add_second(b)
    b['contract']['requirements'][0].update(min_signers=2,independence_dimensions=['administration'])
    b['policy']['observers'][1]['fault_domains']=deepcopy(b['policy']['observers'][0]['fault_domains'])
    assert run(b)['status']=='INSUFFICIENT'


def test_different_labels_remain_conditional(b):
    add_second(b)
    b['contract']['requirements'][0].update(min_signers=2,independence_dimensions=['administration'])
    r=run(b)
    assert r['status']=='CONDITIONAL'
    assert any(p['id']=='policy-fault-domains-accurate' for p in r['premises'])


def test_missing_domain_not_independent(b):
    add_second(b)
    b['contract']['requirements'][0].update(min_signers=2,independence_dimensions=['administration','provider'])
    assert run(b)['status']=='INSUFFICIENT'


def test_independent_subset_not_all_or_nothing(b):
    add_second(b)
    third=Ed25519PrivateKey.from_private_bytes(bytes([213])*32)
    b['policy']['observers'].append({'public_key_hex':key_hex(third),'predicates':['retrieval.verified'],
                                    'fault_domains':deepcopy(b['policy']['observers'][0]['fault_domains'])})
    b['evidence'].append(seal('evidence',b['evidence'][0]['body'],third))
    b['contract']['requirements'][0].update(min_signers=2,independence_dimensions=['administration'])
    r=run(b)
    assert r['status']=='CONDITIONAL' and len(r['checks'][0]['selected_signers'])==2

@pytest.mark.parametrize('accepted',[False,True])
def test_assumptions_never_become_proof(b,accepted):
    b['contract']['assumptions']=[{'id':'observer-honest','value':True}]
    if accepted:b['context']['accepted_premises']=[{'id':'observer-honest','value':True}]
    assert run(b)['status']=='CONDITIONAL'


def test_rejected_premise_contradicts(b):
    b['contract']['assumptions']=[{'id':'network-online','value':True}]
    b['context']['accepted_premises']=[{'id':'network-online','value':False}]
    assert run(b)['status']=='CONTRADICTED'


def test_conflicting_contract_and_descriptor_assumptions(b):
    set_descriptor(b,assumptions=[{'id':'network-online','value':True}])
    b['contract']['assumptions']=[{'id':'network-online','value':False}]
    assert run(b)['status']=='CONTRADICTED'


def test_public_metadata_flagged(b):
    set_descriptor(b,metadata_visibility='PUBLIC')
    assert 'PUBLIC_METADATA_EXPOSURE' in run(b)['limitations']

@pytest.mark.parametrize('rule',['consensus-safety-v1','global-freshness-v1','future-availability-v1','python-eval'])
def test_unsupported_guarantees_refuse(b,rule):
    b['contract']['decision_rule']=rule
    with pytest.raises(Refusal,match='RULE_UNSUPPORTED'):run(b)


def test_evidence_permutation_deterministic(b):
    add_second(b);before=canonical(run(b));b['evidence'].reverse()
    assert canonical(run(b))==before

@pytest.mark.parametrize('value',[True,-1,2**63,1.5,'1000',None])
def test_bad_evaluation_times_typed(b,value):
    b['context']['at_time']=value
    with pytest.raises(Refusal):run(b)

@pytest.mark.parametrize('mutation',['extra','empty','zero','duplicate-observer','duplicate-premise','newline-token'])
def test_closed_schemas(b,mutation):
    if mutation=='extra':b['contract']['implies_authority']=True
    elif mutation=='empty':b['contract']['requirements']=[]
    elif mutation=='zero':b['contract']['requirements'][0]['min_signers']=0
    elif mutation=='duplicate-observer':b['policy']['observers'].append(deepcopy(b['policy']['observers'][0]))
    elif mutation=='duplicate-premise':b['context']['accepted_premises']=[{'id':'x','value':True},{'id':'x','value':False}]
    elif mutation=='newline-token':b['contract']['contract_id']='valid\n'
    with pytest.raises(Refusal):run(b)


def test_bundle_resource_limit(b):
    b['evidence']=[deepcopy(b['evidence'][0]) for _ in range(129)]
    with pytest.raises(Refusal,match='LIMIT'):run(b)


def test_golden_vectors_replay():
    from tools.export_sam_reference import build_vectors
    assert canonical(build_vectors())==(ROOT/'vectors/v02-sam-vectors.json').read_bytes()
