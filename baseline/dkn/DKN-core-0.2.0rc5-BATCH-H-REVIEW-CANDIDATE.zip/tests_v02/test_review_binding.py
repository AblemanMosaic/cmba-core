"""Review-artifact integrity is traceability, not approval or a proof of semantics."""
import hashlib,json,shutil
from pathlib import Path
import pytest
from dkn_v02.core import canonical,Refusal
from tools import check_semantic_contract as checker
from tools import verify_v02_candidate as runner
from tools import build_review_candidate as builder
ROOT=Path(__file__).resolve().parents[1]


def test_current_semantic_realization_binding():
    r=checker.check()
    assert r['status']=='PASS_REFERENCE_INTEGRITY' and r['obligations']==16
    assert r['executed_test_binding']=='NOT_CHECKED'


def test_semantic_body_mutation_refuses(tmp_path):
    shutil.copytree(ROOT/'model',tmp_path/'model')
    p=tmp_path/'model/v02/SEMANTIC-CONTRACT.json';value=json.loads(p.read_bytes())
    value['authority_effect']='GRANTED';p.write_bytes(canonical(value))
    with pytest.raises(Refusal,match='DIMENSION_MISMATCH'):checker.check(tmp_path)


def test_realization_binding_detects_source_change(tmp_path):
    shutil.copytree(ROOT,tmp_path/'copy',ignore=shutil.ignore_patterns('__pycache__','build','*.egg-info'))
    root=tmp_path/'copy';p=root/'src/dkn_v02/core.py';p.write_text(p.read_text()+'\n# mutation\n')
    r=checker.check(root)
    assert 'HASH_MISMATCH:src/dkn_v02/core.py' in r['findings']


def test_model_rejects_foreign_run_as_current_evidence():
    r=checker.check(report={'source_fingerprint':'0'*64,'test_cases':[]})
    assert 'EXECUTED_SOURCE_MISMATCH' in r['findings']
    assert any(x.startswith('TEST_NOT_ESTABLISHED') for x in r['findings'])


def setup_stage(out,monkeypatch):
    out.mkdir();fp='fixed';monkeypatch.setattr(runner,'source_fingerprint',lambda:fp)
    xml=b'<testsuites><testsuite><testcase classname="fixture" name="example"/></testsuite></testsuites>'
    (out/'v02-tests.xml').write_bytes(xml)
    h=lambda b:hashlib.sha256(b).hexdigest()
    for stream in ('stdout','stderr'):(out/('v02-tests.'+stream+'.txt')).write_bytes(b'')
    test={'source_fingerprint':fp,'exit_code':0,'xml_sha256':h(xml),'stdout_sha256':h(b''),'stderr_sha256':h(b'')}
    examples=[]
    for name in runner.EXAMPLES:
        for stream in ('stdout','stderr'):(out/(name+'.'+stream+'.txt')).write_bytes(b'')
        examples.append({'path':'examples/'+name,'exit_code':0,'status':'PASS','stdout_sha256':h(b''),'stderr_sha256':h(b'')})
    ex={'source_fingerprint':fp,'examples':examples,'legacy_runtime':{'status':'BLOCKED'}}
    (out/'TEST-STAGE.json').write_text(json.dumps(test));(out/'EXAMPLE-STAGE.json').write_text(json.dumps(ex))
    return ex


def test_replay_assembly_rejects_changed_stdout(tmp_path,monkeypatch):
    out=tmp_path/'run';setup_stage(out,monkeypatch)
    (out/'v02-tests.stdout.txt').write_bytes(b'modified')
    with pytest.raises(ValueError,match='TEST_LOG_CHANGED'):runner.execute(out,phase='assemble')


def test_replay_assembly_requires_all_examples(tmp_path,monkeypatch):
    out=tmp_path/'run';ex=setup_stage(out,monkeypatch);ex['examples']=[]
    (out/'EXAMPLE-STAGE.json').write_text(json.dumps(ex))
    with pytest.raises(ValueError,match='EXAMPLE_STAGE_INCOMPLETE'):runner.execute(out,phase='assemble')


def test_rc2_source_archive_binds_exact_e_predecessor(tmp_path):
    (tmp_path/'example.txt').write_text('source')
    raw,m=builder.build(tmp_path);r=builder.verify(raw)
    assert r['status']=='PASS' and r['member_count']==2
    assert m['predecessor_archive_sha256']=='b775c6296d86b8586e38369bba1e1e458daa9a676e0f49adbbd0e9a499b4acbd'
    assert builder.MANIFEST=='REVIEW-RC2-FILE-MANIFEST.json'
    assert builder.build(tmp_path)[0]==raw

@pytest.mark.parametrize('raw',[b'{"results":null}',b'[]',b'invalid-json'])
def test_conformance_harness_records_malformed_replacement(raw,monkeypatch):
    from tools import run_conformance as harness
    import subprocess
    monkeypatch.setattr(harness.subprocess,'run',lambda *a,**k:subprocess.CompletedProcess(['fixture'],0,raw,b''))
    r=harness.run(['fixture'],ROOT/'interop/portable-conformance-rc2.json')
    assert r['status']=='FAIL' and r['failures']


def test_conformance_harness_records_unavailable_replacement(monkeypatch):
    from tools import run_conformance as harness
    def missing(*a,**k):raise FileNotFoundError('fixture')
    monkeypatch.setattr(harness.subprocess,'run',missing)
    r=harness.run(['fixture'],ROOT/'interop/portable-conformance-rc2.json')
    assert r['status']=='FAIL' and r['exit_code']==127


def test_replay_fingerprint_ignores_generated_build_metadata(tmp_path,monkeypatch):
    (tmp_path/'src').mkdir();(tmp_path/'src'/'actual.py').write_text('value=1')
    monkeypatch.setattr(runner,'ROOT',tmp_path)
    before=runner.source_fingerprint()
    build=tmp_path/'src'/'dkn_core.egg-info';build.mkdir();(build/'PKG-INFO').write_text('generated build metadata')
    assert runner.source_fingerprint()==before
    (tmp_path/'src'/'actual.py').write_text('value=2')
    assert runner.source_fingerprint()!=before
