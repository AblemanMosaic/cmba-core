import io
import json
import hashlib
import zipfile
from pathlib import Path
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import *

@pytest.fixture
def keys():return Ed25519PrivateKey.from_private_bytes(b'\x11'*32),Ed25519PrivateKey.from_private_bytes(b'\x22'*32)

def test_canonical_roundtrip():
    b=canonical({'β':'ok','a':[0,True,None]})
    assert read_canonical(b)=={'β':'ok','a':[0,True,None]}
    with pytest.raises(Refusal):read_canonical(b'{"x":1,"x":2}')
    with pytest.raises(Refusal):read_canonical(b'{"x":1.2}')
    with pytest.raises(Refusal):read_canonical(b'{ "x":1}')

def test_dimension():
    d=commit('state','example.state',{'hello':'world'})
    assert verify_dimension(d,{'hello':'world'},supplied=True)['commitment']=='PASS'
    with pytest.raises(Refusal):verify_dimension(d,{'hello':'evil'}, supplied=True)
    with pytest.raises(Refusal):verify_dimension(d,supported_schemas={'other'})
    nc=commit('custom','example.unknown',{},critical=False)
    assert verify_dimension(nc,supported_schemas=set())['semantics']=='UNSUPPORTED'

def test_pack_verify():
    files={'README.md':b'hello\n','bin/tool':b'abc'}
    d=commit('semantics','example.semantics',{'purpose':'example'})
    blob,m=pack(files,[d]);assert pack(files,[d])[0]==blob
    assert verify_archive(blob)['status']=='PASS'
    assert verify_manifest(m,files)['integrity']=='PASS'
    assert hashlib.sha256(blob).hexdigest()==verify_archive(blob)['transport_sha256']
    with pytest.raises(Refusal):verify_manifest(m,{**files,'README.md':b'evil'})
    with pytest.raises(Refusal):verify_archive(blob+b'garbage')

def test_empty_archive():
    blob,m=pack({})
    assert verify_archive(blob)['logical_root']==m['logical_root']

def test_certification(keys):
    k,_=keys
    blob,m=pack({'a':b'1'})
    certificate=certify(m,k)
    assert verify_certificate(certificate,m)['signature']=='PASS'
    changed={**certificate,'claim':'AUTHORITY_GRANTED'}
    with pytest.raises(Refusal):verify_certificate(changed,m)
    changed={**certificate,'signature_hex':'00'*64}
    with pytest.raises(Refusal):verify_certificate(changed,m)

def test_namespace_lineage(keys):
    k1,k2=keys
    instance='dkn:v0.1:b3:'+'ab'*32
    genesis=declare_genesis(semantic_name='example.app',purpose='publisher',nonce='init',legacy_instance=instance,key=k1)
    assert verify_genesis(genesis)['signature']=='PASS'
    tr=transition(genesis,k1,key_hex(k2),epoch=1)
    assert verify_transitions(genesis,[tr])['active_key']==key_hex(k2)
    other=declare_genesis(semantic_name='example.app',purpose='publisher',nonce='init',legacy_instance=instance,key=k2)
    assert other['namespace_root'] != genesis['namespace_root']
    with pytest.raises(Refusal):verify_transitions(genesis,[{**tr,'epoch':2}])
    with pytest.raises(Refusal):verify_transitions(genesis,[tr,tr])
    with pytest.raises(Refusal):verify_genesis({**genesis,'semantic_name':'bad.name'})

def test_path_limits():
    for p in ['../x','/x','a//b','a/./b','a/../b','a\\b','x/']:
        with pytest.raises(Refusal):pack({p:b'x'})
    with pytest.raises(Refusal):pack({'A':b'1','a':b'2'})
    with pytest.raises(Refusal):pack({'.dkn/manifest.json':b'evil'})

def test_critical_namespace_distinction():
    base={'x':b'y'}
    d=commit('policy','example.policy',{'allow':True})
    m=build_manifest(base,[d])
    assert m['logical_root'] != build_manifest(base)['logical_root']
    assert verify_manifest(m,base)['dimension_semantics']=='NOT_CHECKED'

def test_archive_zip_mutation():
    blob,_=pack({'x':b'hello'})
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        entries={n:z.read(n) for n in z.namelist()}
    entries['x']=b'wrong'
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w') as z:
        for n,v in sorted(entries.items()):z.writestr(n,v)
    with pytest.raises(Refusal):verify_archive(buf.getvalue())

def test_legacy_anchor_not_automatically_authenticated(keys):
    k,_=keys
    # A genesis statement that mentions a legacy ID cannot prove the r002 ID derivation.
    g=declare_genesis(semantic_name='example.app',purpose='publisher',nonce='anchor',legacy_instance='dkn:v0.1:b3:'+'00'*32,key=k)
    assert verify_genesis(g)['human_name_exclusive'] is False

def test_noncritical_dimension_not_semantically_verified():
    d=commit('unrecognized','example.unrecognized',{'x':1},critical=False)
    result=verify_dimension(d,{'x':1},supplied=True,supported_schemas=set())
    assert result == {'commitment':'PASS','semantics':'UNSUPPORTED'}

def test_distinct_keys_distinct_signatures(keys):
    a,b=keys
    _,m=pack({'file':b'payload'})
    assert certify(m,a)['signer_public_key_hex'] != certify(m,b)['signer_public_key_hex']

def test_malformed_manifest_refuses():
    b,m=pack({'x':b'1'})
    with pytest.raises(Refusal): verify_manifest({**m,'unexpected':True},{'x':b'1'})
    with pytest.raises(Refusal): build_manifest({'x':b'1'},[commit('x','example.foo',1),commit('x','example.foo',2)])
