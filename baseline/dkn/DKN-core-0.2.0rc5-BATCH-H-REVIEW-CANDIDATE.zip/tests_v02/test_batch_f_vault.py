"""Actual on-disk transactions, concurrent clients, injected failure and process exit."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import threading
import pytest
from dkn_v02 import pack, certify, LocalIndex, Refusal, canonical, key_hex
from dkn_v02 import vault as mod
from dkn_v02.vault import TransactionalVault
from dkn_v02 import lifecycle as lc
from tests_v02.test_batch_f_lifecycle import setup, grant, event


@pytest.fixture
def vault(tmp_path):
    return TransactionalVault.create(tmp_path / 'vault.db')


def test_create_open_and_verified_read(vault, setup):
    owner, _, _, _, _, genesis, raw, manifest = setup
    cert = certify(manifest, owner, namespace_root=genesis['namespace_root'])
    receipt = vault.put_artifact(raw, certificate=cert, genesis=genesis)
    assert receipt['revision'] == 1 and receipt['authority_effect'] == 'NONE'
    read = TransactionalVault(vault.path).resolve_exact(manifest['logical_root'])
    assert read['result']['integrity'] == 'PASS' and read['snapshot_revision'] == 1
    assert vault.discover(semantic_name='test.lifecycle')['result']['returned'] == 1
    assert vault.traverse(manifest['logical_root'])['result']['root'] == manifest['logical_root']
    assert vault.read_artifact(manifest['logical_root'])[0] == raw


def test_exact_write_idempotence_not_overwrite(vault, setup):
    owner, _, _, _, _, genesis, raw, manifest = setup
    assert vault.put_artifact(raw)['status'] == 'STORED'
    assert vault.put_artifact(raw)['status'] == 'ALREADY_PRESENT'
    assert vault.resolve_exact(manifest['logical_root'])['snapshot_revision'] == 1
    with pytest.raises(Refusal, match='EXISTS'):
        vault.put_artifact(raw, certificate=certify(manifest, owner))


def test_open_never_creates_missing_file(tmp_path):
    target = tmp_path / 'missing.db'
    with pytest.raises(Refusal, match='NOT_FOUND'): TransactionalVault(target)
    assert not target.exists()


def test_create_never_overwrites(vault):
    before = vault.path.read_bytes()
    with pytest.raises(Refusal, match='EXISTS'): TransactionalVault.create(vault.path)
    assert before == vault.path.read_bytes()


def test_transaction_rollback_no_partial_revision(vault, setup, monkeypatch):
    def fail(connection): raise RuntimeError('injected failure after insert before commit')
    with monkeypatch.context() as patch:
        patch.setattr(vault, '_before_commit', fail)
        with pytest.raises(RuntimeError): vault.put_artifact(setup[-2])
    with pytest.raises(Refusal, match='NOT_FOUND'): vault.resolve_exact(setup[-1]['logical_root'])
    assert vault.put_artifact(setup[-2])['revision'] == 1


def test_reader_sees_old_snapshot_until_commit(vault, setup):
    old, old_manifest = pack({'old.txt': b'old'})
    vault.put_artifact(old)
    written, release = threading.Event(), threading.Event()
    def pause(connection):
        written.set()
        if not release.wait(5): raise RuntimeError('test synchronization timeout')
    writer = TransactionalVault(vault.path)
    writer._before_commit = pause
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(writer.put_artifact, setup[-2])
        try:
            assert written.wait(5)
            assert vault.resolve_exact(old_manifest['logical_root'])['snapshot_revision'] == 1
            with pytest.raises(Refusal, match='NOT_FOUND'): vault.resolve_exact(setup[-1]['logical_root'])
        finally: release.set()
        assert future.result(timeout=5)['revision'] == 2
    assert vault.resolve_exact(setup[-1]['logical_root'])['snapshot_revision'] == 2


def test_competing_writers_serialize(vault):
    payloads = [pack({f'{i}.txt': str(i).encode()}) for i in range(8)]
    def put(item): return TransactionalVault(vault.path, busy_timeout_ms=5000).put_artifact(item[0])
    with ThreadPoolExecutor(max_workers=4) as pool:
        result = list(pool.map(put, payloads))
    assert sorted(r['revision'] for r in result) == list(range(1,9))
    for _, manifest in payloads: assert vault.resolve_exact(manifest['logical_root'])['result']['integrity'] == 'PASS'


def test_competing_duplicate_writers_are_idempotent(vault, setup):
    def put(_): return TransactionalVault(vault.path, busy_timeout_ms=5000).put_artifact(setup[-2])
    with ThreadPoolExecutor(max_workers=4) as pool: results = list(pool.map(put, range(8)))
    assert sum(r['status']=='STORED' for r in results) == 1
    assert {r['revision'] for r in results} == {1}


def test_busy_refuses_without_corruption(vault, setup):
    connection = sqlite3.connect(vault.path, isolation_level=None)
    connection.execute('BEGIN IMMEDIATE')
    try:
        with pytest.raises(Refusal, match='BUSY'):
            TransactionalVault(vault.path, busy_timeout_ms=0).put_artifact(setup[-2])
    finally: connection.close()
    assert vault.put_artifact(setup[-2])['revision'] == 1


@pytest.mark.parametrize('size',[32,3*1024*1024])
def test_process_exit_before_commit_recovers(vault, setup, size):
    raw, manifest = pack({'blob.bin': b'x'*size})
    raw_path = vault.path.parent/'artifact.zip'; raw_path.write_bytes(raw)
    code = '''import os,sys
from pathlib import Path
from dkn_v02.vault import TransactionalVault
v=TransactionalVault(sys.argv[1])
v._before_commit=lambda connection: os._exit(73)
v.put_artifact(Path(sys.argv[2]).read_bytes())
'''
    process = subprocess.run([sys.executable,'-c',code,str(vault.path),str(raw_path)],
                             capture_output=True,timeout=10)
    assert process.returncode == 73, process.stderr
    with pytest.raises(Refusal, match='NOT_FOUND'): vault.resolve_exact(manifest['logical_root'])
    assert vault.put_artifact(raw)['revision'] == 1


def test_process_commit_survives_exit(vault, setup):
    raw_path=vault.path.parent/'artifact.zip';raw_path.write_bytes(setup[-2])
    code='''import os,sys
from pathlib import Path
from dkn_v02.vault import TransactionalVault
TransactionalVault(sys.argv[1]).put_artifact(Path(sys.argv[2]).read_bytes())
os._exit(0)
'''
    process=subprocess.run([sys.executable,'-c',code,str(vault.path),str(raw_path)],capture_output=True,timeout=10)
    assert process.returncode==0,process.stderr
    assert vault.resolve_exact(setup[-1]['logical_root'])['snapshot_revision']==1


@pytest.mark.parametrize('mutation', ['archive', 'envelope', 'root', 'type'])
def test_corrupt_record_not_empty_or_verified(vault, setup, mutation):
    vault.put_artifact(setup[-2]); root=setup[-1]['logical_root']
    with sqlite3.connect(vault.path) as connection:
        if mutation=='archive': connection.execute('UPDATE artifacts SET archive=?',(b'invalid',))
        if mutation=='envelope': connection.execute('UPDATE artifacts SET envelope=?',(b'{}',))
        if mutation=='root': connection.execute('UPDATE artifacts SET root=?',('f'*64,))
        if mutation=='type': connection.execute('UPDATE artifacts SET archive=?',('text not bytes',))
    with pytest.raises(Refusal): vault.discover(semantic_name='notfound')


@pytest.mark.parametrize('mutation', ['version', 'application', 'table', 'trigger', 'prefix_table', 'meta'])
def test_schema_corruption_refuses(vault, mutation):
    with sqlite3.connect(vault.path) as connection:
        if mutation=='version':connection.execute('PRAGMA user_version=99')
        if mutation=='application':connection.execute('PRAGMA application_id=0')
        if mutation=='table':connection.execute('CREATE TABLE unexpected (x)')
        if mutation=='prefix_table':connection.execute('CREATE TABLE sqliteXhidden (x)')
        if mutation=='trigger':connection.execute('CREATE TRIGGER changed AFTER INSERT ON artifacts BEGIN DELETE FROM meta; END')
        if mutation=='meta':connection.execute('DELETE FROM meta')
    with pytest.raises(Refusal):vault.discover(semantic_name='x')


def test_file_damage_refuses(vault):
    vault.path.write_bytes(b'not a sqlite database')
    with pytest.raises(Refusal):vault.discover(semantic_name='x')


@pytest.mark.parametrize('kind',['db_symlink','parent_symlink','sidecar_symlink','hardlink'])
def test_static_alias_refused(vault, tmp_path, kind):
    if kind=='db_symlink':
        target=tmp_path/'alias.db';target.symlink_to(vault.path)
    elif kind=='parent_symlink':
        parent=tmp_path/'alias';parent.symlink_to(tmp_path,target_is_directory=True);target=parent/vault.path.name
    elif kind=='sidecar_symlink':
        Path(str(vault.path)+'-journal').symlink_to(tmp_path/'elsewhere');target=vault.path
    else:
        target=tmp_path/'alias.db';os.link(vault.path,target)
    with pytest.raises(Refusal):TransactionalVault(target)


def test_group_writable_database_refused(vault):
    if os.name!='posix':pytest.skip('POSIX permission semantics unavailable')
    vault.path.chmod(0o666)
    with pytest.raises(Refusal, match='CUSTODY'):TransactionalVault(vault.path)


def test_namespace_cas_and_ancestry(vault, setup):
    policy,genesis=setup[4:6];anchor=lc.lifecycle_anchor(genesis,policy)
    assert vault.advance_namespace(genesis,policy,[],expected_head=None)['revision']==1
    assert vault.advance_namespace(genesis,policy,[],expected_head=anchor)['status']=='ALREADY_PINNED'
    first=grant(setup)
    assert vault.advance_namespace(genesis,policy,[first],expected_head=anchor)['sequence']==1
    with pytest.raises(Refusal,match='CAS_CONFLICT'):
        vault.advance_namespace(genesis,policy,[first],expected_head=anchor)
    with pytest.raises(Refusal,match='ROLLBACK_OR_FORK'):
        vault.advance_namespace(genesis,policy,[],expected_head=first['event_ref'])
    alternate=event(setup,[],'suspend',{'reason':'alternative'})
    later=event(setup,[alternate],'resume',{'reason':'alternative'})
    with pytest.raises(Refusal,match='ROLLBACK_OR_FORK'):
        vault.advance_namespace(genesis,policy,[alternate,later],expected_head=first['event_ref'])
    read=vault.read_namespace(genesis['namespace_root'])
    assert read['state']['head_ref']==first['event_ref'] and read['snapshot_revision']==2


def test_two_namespace_writers_only_one_wins(vault,setup):
    policy,genesis=setup[4:6];anchor=lc.lifecycle_anchor(genesis,policy)
    vault.advance_namespace(genesis,policy,[],expected_head=None)
    branches=[event(setup,[],'suspend',{'reason':label}) for label in ('a','b')]
    def update(e):
        try:return TransactionalVault(vault.path).advance_namespace(genesis,policy,[e],expected_head=anchor)['status']
        except Refusal as exc:return exc.code
    with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(update,branches))
    assert sorted(result)==['DKN_VAULT_CAS_CONFLICT','PIN_ADVANCED']


def test_namespace_transaction_rollback(vault,setup,monkeypatch):
    policy,genesis=setup[4:6]
    def fail(connection):raise RuntimeError('injected pin failure')
    monkeypatch.setattr(vault,'_before_commit',fail)
    with pytest.raises(RuntimeError):vault.advance_namespace(genesis,policy,[],expected_head=None)
    with pytest.raises(Refusal,match='NOT_FOUND'):vault.read_namespace(genesis['namespace_root'])


def test_namespace_storage_tampering_reverified(vault,setup):
    policy,genesis=setup[4:6]
    vault.advance_namespace(genesis,policy,[grant(setup)],expected_head=None)
    bundle=vault.read_namespace(genesis['namespace_root'])['bundle']
    bundle['events'][0]['signatures'][0]['signature_hex']='00'*64
    with sqlite3.connect(vault.path) as con:con.execute('UPDATE namespaces SET bundle=?',(canonical(bundle),))
    with pytest.raises(Refusal):vault.read_namespace(genesis['namespace_root'])


def test_directory_import_atomic_and_non_destructive(vault,tmp_path,setup):
    source=tmp_path/'source';index=LocalIndex(source);index.add(setup[-2])
    before={p.relative_to(source).as_posix():p.read_bytes() for p in source.rglob('*') if p.is_file()}
    result=vault.import_local_index(source)
    assert result['artifacts']==1 and not result['source_modified']
    assert vault.resolve_exact(setup[-1]['logical_root'])['result']['integrity']=='PASS'
    after={p.relative_to(source).as_posix():p.read_bytes() for p in source.rglob('*') if p.is_file()}
    assert before==after
    with pytest.raises(Refusal,match='NOT_EMPTY'):vault.import_local_index(source)


@pytest.mark.parametrize('case',['orphan','missing_payload','unknown_entry','malformed_metadata','missing_source'])
def test_incomplete_import_refuses_without_rows(vault,tmp_path,setup,case):
    source=tmp_path/'source';index=LocalIndex(source)
    if case!='missing_source':index.add(setup[-2])
    if case=='orphan':(index.objects/('a'*64+'.zip')).write_bytes(b'orphan')
    if case=='missing_payload':(index.objects/(setup[-1]['logical_root']+'.zip')).unlink()
    if case=='unknown_entry':(index.metadata/'ignored.txt').write_bytes(b'ignore?')
    if case=='malformed_metadata':(index.metadata/(setup[-1]['logical_root']+'.json')).write_bytes(b'{}')
    with pytest.raises(Refusal):vault.import_local_index(source)
    assert vault.discover(semantic_name='x')['snapshot_revision']==0


def test_import_rolls_back_all_entries(vault,tmp_path,setup,monkeypatch):
    source=tmp_path/'source';index=LocalIndex(source);index.add(setup[-2]);index.add(pack({'b':b'b'})[0])
    def fail(connection):raise RuntimeError('all-or-nothing import')
    with monkeypatch.context() as p:
        p.setattr(vault,'_before_commit',fail)
        with pytest.raises(RuntimeError):vault.import_local_index(source)
    assert vault.discover(semantic_name='x')['snapshot_revision']==0
    assert vault.import_local_index(source)['artifacts']==2


def test_read_does_not_advance_namespace_pin(vault,setup):
    policy,genesis=setup[4:6]
    vault.advance_namespace(genesis,policy,[],expected_head=None)
    for _ in range(3):assert vault.read_namespace(genesis['namespace_root'])['snapshot_revision']==1


def test_local_snapshot_not_global_freshness(vault,setup):
    policy,genesis=setup[4:6]
    vault.advance_namespace(genesis,policy,[],expected_head=None)
    read=vault.read_namespace(genesis['namespace_root'])
    assert read['state']['global_currentness']=='NOT_ESTABLISHED'
    assert read['authority_effect']=='NONE'


def test_bounded_snapshot_and_storage(vault,setup,monkeypatch):
    vault.put_artifact(setup[-2])
    monkeypatch.setattr(mod,'MAX_SCAN_BYTES',8)
    with pytest.raises(Refusal,match='LIMIT'):vault.discover(semantic_name='x')
    with pytest.raises(Refusal,match='LIMIT'):vault.put_artifact(pack({'b':b'b'})[0])


def test_source_mutation_is_detected(vault,tmp_path,setup,monkeypatch):
    source=tmp_path/'source';index=LocalIndex(source);index.add(setup[-2])
    original=mod.read_bounded_file;count=[0]
    def changing(path, maximum):
        count[0]+=1
        raw=original(path,maximum)
        return raw+b'changed' if count[0]==3 else raw
    monkeypatch.setattr(mod,'read_bounded_file',changing)
    with pytest.raises(Refusal,match='SOURCE_CHANGED'):vault.import_local_index(source)
    assert vault.discover(semantic_name='x')['snapshot_revision']==0
