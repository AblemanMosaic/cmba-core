"""Regression probes found in Batch E. Keys below are public test fixtures only."""
import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import core as c
from dkn_v02.core import *
from dkn_v02.navigation import LocalIndex, validate_relations
from dkn_v02.assurance import verify_record, DOMAIN, SIGN_DOMAIN
from examples.v02_assurance import fixture_bundle

KEY=Ed25519PrivateKey.from_private_bytes(b'\x17'*32)
SECOND=Ed25519PrivateKey.from_private_bytes(b'\x18'*32)
IDENTITY='01'+'00'*31
FAKE_SIGNATURE='01'+'00'*63

def genesis():
    return declare_genesis(semantic_name='e.fixture',purpose='publisher',nonce='genesis',
                           legacy_instance='dkn:v0.1:b3:'+'17'*32,key=KEY)

def resign_genesis(changes):
    g=genesis();body={k:v for k,v in g.items() if k not in ('namespace_root','signature_hex')}
    body.update(changes)
    return {**body,'namespace_root':digest('namespace',body),
            'signature_hex':KEY.sign(DOMAINS['namespace']+canonical(body)).hex()}

def resign_transition(changes):
    g=genesis();event=transition(g,KEY,key_hex(SECOND),epoch=1)
    body={k:v for k,v in event.items() if k not in ('transition_hash','signature_hex')}
    body.update(changes)
    return g,{**body,'transition_hash':digest('transition',body),
              'signature_hex':KEY.sign(DOMAINS['transition']+canonical(body)).hex()}

@pytest.mark.parametrize('kind',['certificate','genesis','sam'])
def test_identity_key_forgery_rejected(kind):
    _,m=pack({'a':b'x'})
    if kind=='certificate':
        record=certify(m,KEY);record.update(signer_public_key_hex=IDENTITY,signature_hex=FAKE_SIGNATURE)
        fn=lambda:verify_certificate(record,m)
    elif kind=='genesis':
        record=genesis();record['founder_public_key_hex']=IDENTITY
        body={k:v for k,v in record.items() if k not in ('namespace_root','signature_hex')}
        record.update(namespace_root=digest('namespace',body),signature_hex=FAKE_SIGNATURE)
        fn=lambda:verify_genesis(record)
    else:
        record=copy.deepcopy(fixture_bundle()['descriptor']);record['signer_public_key_hex']=IDENTITY
        unsigned={k:v for k,v in record.items() if k not in ('record_hash','signature_hex')}
        record.update(record_hash=hashlib.sha256(DOMAIN+canonical(unsigned)).hexdigest(),signature_hex=FAKE_SIGNATURE)
        fn=lambda:verify_record(record)
    with pytest.raises(Refusal,match='PUBLIC_KEY_INVALID'):fn()

@pytest.mark.parametrize('pub',[IDENTITY,'00'*32,'ff'*32, 'ed'+'ff'*30+'7f', 'ec'+'ff'*30+'7f'])
def test_invalid_public_key_admission(pub):
    with pytest.raises(Refusal):c._public(pub)

@pytest.mark.parametrize('field,value',[
    ('semantic_name',[]),('semantic_name','Alpha'),('semantic_name','a\nb'),
    ('semantic_name','аpp'),('purpose',None),('nonce',False),('nonce','bad space'),
    ('legacy_instance','dkn:v0.1:b3:'+'zz'*32),('legacy_instance',[]),
    ('recovery_policy_ref',42),('recovery_policy_ref','x'*257)])
def test_signed_genesis_schema_checked(field,value):
    with pytest.raises(Refusal):verify_genesis(resign_genesis({field:value}))

@pytest.mark.parametrize('value',['not-a-key',None,False,[],IDENTITY,'00'*32])
def test_final_successor_admission(value):
    g,event=resign_transition({'successor_public_key_hex':value})
    with pytest.raises(Refusal):verify_transitions(g,[event])

@pytest.mark.parametrize('value',[None,False,True,'1',[],{},0,-1,2**63])
def test_transition_epoch_typed_refusal(value):
    with pytest.raises(Refusal):transition(genesis(),KEY,key_hex(SECOND),epoch=value)

def test_transition_creation_checks_first_predecessor():
    with pytest.raises(Refusal):transition(genesis(),SECOND,key_hex(KEY),epoch=1)

def test_transition_creation_checks_previous_link():
    with pytest.raises(Refusal):transition(genesis(),KEY,key_hex(KEY),epoch=1,previous_transition_hash='00'*32)
    with pytest.raises(Refusal):transition(genesis(),KEY,key_hex(KEY),epoch=2)

@pytest.mark.parametrize('value',[None,False,[],{},0])
def test_relation_type_typed_refusal(value):
    with pytest.raises(Refusal):validate_relations([{'schema':'dkn.relations.v0.2-candidate','relation_type':value,'destination':'00'*32,'scope':'x'}])

@pytest.mark.parametrize('path',['C:/x','C:x','CON','CON.txt','dir/NUL','aux','COM1','LPT9.txt','COM¹',
    'a:b','a.','a ','a\n','a\t','a\x7f','x?','x*','x|','x<','x>','x"','x\\y','../x','/x','x//y','x/./y','x/../y','x/','e\u0301','\ud800'])
def test_portable_path_refusals(path):
    with pytest.raises(Refusal):pack({path:b'x'})

@pytest.mark.parametrize('files',[
    {'A/x':b'x','a':b'z'}, {'A':b'x','a/x':b'z'},
    {'Straße':b'x','STRASSE':b'z'}, {'a/É':b'x','A/é':b'z'}])
def test_casefold_alias_and_prefix(files):
    with pytest.raises(Refusal,match='COLLISION'):pack(files)

@pytest.mark.parametrize('path',['.dkn','.DKN/x','.DKN/manifest.json','.dkn/x'])
def test_reserved_metadata_subtree(path):
    with pytest.raises(Refusal,match='RESERVED_PATH'):pack({path:b'x'})

@pytest.mark.parametrize('path',['é.txt','nested/水.txt','folder/name','COM10','application.txt'])
def test_valid_portable_paths(path):
    raw,m=pack({path:b'x'});assert verify_archive(raw)['logical_root']==m['logical_root']

@pytest.mark.parametrize('value',[True,False,-1,'1',[],64*1024*1024+1])
def test_manifest_size_types(value):
    _,m=pack({'a':b'x'});m['inventory'][0]['size']=value
    m['logical_root']=digest('logical',{k:v for k,v in m.items() if k!='logical_root'})
    with pytest.raises(Refusal):validate_manifest(m)
    with pytest.raises(Refusal):certify(m,KEY)

def test_manifest_nested_metadata_is_detached():
    d=commit('foo','example.foo',{})
    m=build_manifest({},[d]);root=m['logical_root'];d['critical']=False
    validate_manifest(m);assert m['logical_root']==root and m['dimensions'][0]['critical'] is True

@pytest.mark.parametrize('operation',['manifest','archive'])
def test_unknown_critical_with_explicit_support_policy(operation):
    raw,m=pack({'a':b'x'},[commit('foo','unknown.foo',{},critical=True)])
    with pytest.raises(Refusal,match='CRITICAL_UNSUPPORTED'):
        if operation=='archive':verify_archive(raw,supported_schemas=set())
        else:verify_manifest(m,{'a':b'x'},supported_schemas=set())
    # Structural verification remains honest about semantics when no policy is supplied.
    assert verify_archive(raw)['dimension_semantics']=='NOT_CHECKED'

@pytest.mark.parametrize('raw',[
    b'{"a":1,"a":2}',b'\xef\xbb\xbf{}',b'1.0',b'NaN',b'1e3',b'-0',
    b'9223372036854775808',b'-9223372036854775809',b'"\\ud800"',b'{}\n',
    b'['*34+b'0'+b']'*34,b'"\xff"'])
def test_canonical_invalid_inputs(raw):
    with pytest.raises(Refusal):read_canonical(raw)

@pytest.mark.parametrize('value',[ -(2**63),2**63-1,2**53+1,{'\ue000':1,'\U00010000':2}, {'x':'\u2028\n\b\u0000/"\\'}])
def test_canonical_edge_roundtrip(value):assert read_canonical(canonical(value))==value

def test_manifest_without_files_does_not_claim_payload_integrity():
    _,m=pack({'a':b'x'})
    assert validate_manifest(m)['content_integrity']=='NOT_CHECKED'

@pytest.mark.parametrize('change',['extra','missing','mutation'])
def test_archive_closure_mutations(change):
    raw,_=pack({'a':b'x','b':b'y'})
    with zipfile.ZipFile(io.BytesIO(raw)) as z:items=[(i,z.read(i)) for i in z.infolist()]
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w') as z:
        for i,b in items:
            if change=='missing' and i.filename=='a':continue
            if change=='mutation' and i.filename=='a':b=b'z'
            z.writestr(i,b)
        if change=='extra':
            i=copy.copy(items[-1][0]);i.filename='extra';z.writestr(i,b'x')
    with pytest.raises(Refusal):verify_archive(out.getvalue())

def test_raw_read_is_bounded(tmp_path):
    p=tmp_path/'large';p.write_bytes(b'x'*64)
    with pytest.raises(Refusal,match='LIMIT'):read_bounded_file(p,32)
    assert read_bounded_file(p,64)==b'x'*64

def test_directory_total_budget_checked_before_retaining(tmp_path,monkeypatch):
    (tmp_path/'a').write_bytes(b'x'*6);(tmp_path/'b').write_bytes(b'x'*6)
    monkeypatch.setattr(c,'MAX_TOTAL',10)
    with pytest.raises(Refusal,match='LIMIT'):load_directory(tmp_path)

@pytest.mark.parametrize('where',['root','objects','evidence'])
def test_index_ancestor_symlink(tmp_path,where):
    target=tmp_path/'target';target.mkdir()
    root=tmp_path/'vault'
    if where=='root':root.symlink_to(target,target_is_directory=True)
    else:
        root.mkdir();(root/where).symlink_to(target,target_is_directory=True)
    raw,m=pack({'a':b'x'});idx=LocalIndex(root)
    with pytest.raises(Refusal,match='SYMLINK'):idx.add(raw)
    with pytest.raises(Refusal,match='SYMLINK'):idx.discover(semantic_name='x')

def test_depth_bound_is_explicit(tmp_path):
    from dkn_v02.navigation import relation_commitment
    rel=[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':'11'*32,'scope':'fixture'}]
    raw,m=pack({},[relation_commitment(rel)]);idx=LocalIndex(tmp_path);idx.add(raw,relations=rel)
    r=idx.traverse(m['logical_root'],max_depth=0)
    assert r['truncated'] and r['depth_limited']

def test_discovery_scan_budget(tmp_path,monkeypatch):
    import dkn_v02.navigation as nav
    idx=LocalIndex(tmp_path);raw,_=pack({'x':b'x'});idx.add(raw)
    monkeypatch.setattr(nav,'MAX_SCAN_BYTES',10)
    with pytest.raises(Refusal,match='LIMIT'):idx.discover(semantic_name='x')

def test_rfc8032_vector1_and_malleability():
    # RFC 8032 section 7.1, TEST 1; published test key, not an operational secret.
    seed=bytes.fromhex('9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60')
    key=Ed25519PrivateKey.from_private_bytes(seed)
    pub='d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a'
    sig='e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b'
    assert key_hex(key)==pub and key.sign(b'').hex()==sig
    c._verify_sig(pub,b'',sig)
    order=2**252+27742317777372353535851937790883648493
    mutated=bytes.fromhex(sig[:64])+(int.from_bytes(bytes.fromhex(sig[64:]),'little')+order).to_bytes(32,'little')
    with pytest.raises(Refusal):c._verify_sig(pub,b'',mutated.hex())
