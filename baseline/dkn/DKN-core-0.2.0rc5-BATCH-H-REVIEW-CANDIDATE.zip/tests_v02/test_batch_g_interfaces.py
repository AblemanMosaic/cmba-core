"""Frozen DS-G1 corpus, shape contracts, CLI, byte-domain cross-language checks."""
from pathlib import Path
from copy import deepcopy
import json, shutil, subprocess, sys
import pytest
from jsonschema import Draft202012Validator
from dkn_v02 import canonical, read_canonical, Refusal
from dkn_v02.distributed_abi import dispatch
from dkn_v02.distributed_schemas import export_schemas,validate_shape
from dkn_v02.simulation import run_scenario
from tools.reference_distributed_conformance import execute
from examples.distributed_fixtures import extended_scenarios
ROOT=Path(__file__).resolve().parents[1]
CORPUS=read_canonical((ROOT/'interop/distributed-g1-conformance.json').read_bytes())

@pytest.mark.parametrize('case',CORPUS['cases'],ids=lambda c:c['request']['id'])
def test_frozen_distributed_corpus(case):
    response=execute({'schema':'dkn.conformance-request.v0.2-rc2','cases':[case['request']]})
    assert response['results']==[case['expected']]

@pytest.mark.parametrize('name',list(export_schemas()))
def test_runtime_schema_exports_exact(name):
    schema=export_schemas()[name];Draft202012Validator.check_schema(schema)
    assert read_canonical((ROOT/'schemas/v02/distributed-g1'/(name+'.schema.json')).read_bytes())==schema

@pytest.mark.parametrize('field,value',[('authority_effect','GRANTED'),('execution_authorized',True),
                                        ('global_currentness','PROVEN'),('status','APPROVED')])
def test_view_schema_refuses_promoted_claims(field,value):
    result=deepcopy(next(c['expected']['result'] for c in CORPUS['cases'] if c['request']['id']=='view-normal'))
    result[field]=value
    with pytest.raises(Refusal):validate_shape('view',result)

def test_schema_shape_does_not_certify_result_truth():
    result=deepcopy(next(c['expected']['result'] for c in CORPUS['cases'] if c['request']['id']=='view-normal'))
    result['status']='NO_MATCH'
    validate_shape('view',result) # Structurally admitted, not authenticated or semantically checked.
    request=next(c['request'] for c in CORPUS['cases'] if c['request']['id']=='view-normal')
    actual=dispatch({'schema':'dkn.distributed-request.v0.2-g1','operation':'assess','arguments':request['arguments']})
    assert actual!=result

@pytest.mark.parametrize('bad',[None,[],True,{},
    {'schema':'dkn.distributed-request.v0.2-g1','operation':'publish','arguments':{}},
    {'schema':'dkn.distributed-request.v0.2-g1','operation':'assess','arguments':{'url':'https://example.invalid'}}])
def test_closed_abi_typed_refusals(bad):
    with pytest.raises(Refusal):dispatch(bad)

def test_cli_read_only_returns_nonacceptance_with_exit_zero(tmp_path):
    r=next(c['request'] for c in CORPUS['cases'] if c['request']['id']=='view-empty')
    request={'schema':'dkn.distributed-request.v0.2-g1',**{k:v for k,v in r.items() if k!='id'}}
    path=tmp_path/'request.json';path.write_bytes(canonical(request));before=path.read_bytes()
    p=subprocess.run([sys.executable,'-m','dkn_v02.distributed_cli',str(path)],capture_output=True,timeout=10)
    assert p.returncode==0 and json.loads(p.stdout)['status']=='INDETERMINATE'
    assert path.read_bytes()==before
    bad=subprocess.run([sys.executable,'-m','dkn_v02.distributed_cli','-'],input=b'{}',capture_output=True,timeout=10)
    assert bad.returncode==2 and json.loads(bad.stdout)['status']=='REFUSED'

@pytest.mark.parametrize('name',['normal','partition-heal','recovery-fork','external-floor-rollback','witness-equivocation','transitive-shared-dependency'])
def test_node_trace_domain_and_linkage(tmp_path,name):
    node=shutil.which('node')
    if not node:pytest.skip('Node not available; interoperability remains unestablished')
    s=extended_scenarios()[name];r=run_scenario(s);p=tmp_path/'request.json'
    p.write_bytes(canonical({'scenario':s,'transcript':r}))
    cp=subprocess.run([node,str(ROOT/'interop/distributed_trace_check.mjs'),str(p)],capture_output=True,timeout=10)
    assert cp.returncode==0,cp.stdout+cp.stderr
    assert json.loads(cp.stdout)['trace_root']==r['trace_root']
    r['trace'][0]['details']['forged']=True;p.write_bytes(canonical({'scenario':s,'transcript':r}))
    bad=subprocess.run([node,str(ROOT/'interop/distributed_trace_check.mjs'),str(p)],capture_output=True,timeout=10)
    assert bad.returncode==2


def test_reference_vectors_and_scenarios_rebuild_exactly():
    from tools.build_distributed_vectors import build
    scenarios,vector,corpus=build()
    assert corpus==CORPUS
    assert vector==read_canonical((ROOT/'vectors/v02/distributed-g1.json').read_bytes())
    for name,s in scenarios.items():
        assert canonical(s)==(ROOT/'profiles/distributed-g1/scenarios'/(name+'.json')).read_bytes()


def test_frozen_process_conformance_runner():
    from tools.run_conformance import run
    r=run([sys.executable,str(ROOT/'tools/reference_distributed_conformance.py')],ROOT/'interop/distributed-g1-conformance.json')
    assert r['status']=='PASS' and r['cases']==28
