"""Review gates refuse mixed/partial evidence without granting independent approval."""
from pathlib import Path
from copy import deepcopy
import json
import pytest
from tools import release_gate as gate
from tools import verify_batch_h as runner
from tools import build_batch_h_candidate as builder

ROOT=Path(__file__).resolve().parents[1]

def xml(tmp_path,body='<testcase classname="fixture" name="one"/>',tests=1,failures=0,errors=0,skipped=0):
    p=tmp_path/'test.xml';p.write_text(f'<testsuites><testsuite tests="{tests}" failures="{failures}" errors="{errors}" skipped="{skipped}">{body}</testsuite></testsuites>')
    return p


def report():
    return {'source_fingerprint':'frozen','test_cases':[{'id':'fixture::one','result':'PASS'}],
            'v02_tests':1,'v02_passed':1,'v02_test_exit_code':0,
            'examples':[{'path':'examples/demo.py','status':'PASS','exit_code':0}],
            'authority_effect':'NONE','public_release_gate':'NOT_CLEARED','independent_review':'NOT_PERFORMED'}


def test_local_report_has_no_independent_authority(tmp_path):
    assert gate.check_run(report(),xml(tmp_path),'frozen',('demo.py',))['status']=='PASS'


@pytest.mark.parametrize('field,value',[
 ('source_fingerprint','foreign'),('test_cases',[]),('v02_tests',True),('v02_passed',True),
 ('v02_tests',2),('v02_passed',0),('v02_test_exit_code',False),('v02_test_exit_code',2),
 ('examples',[]),('authority_effect','GRANTED'),('public_release_gate','CLEARED'),
 ('independent_review','APPROVED')])
def test_report_drift_or_promotion_refused(tmp_path,field,value):
    r=report();r[field]=value
    assert gate.check_run(r,xml(tmp_path),'frozen',('demo.py',))['status']=='FAIL'


@pytest.mark.parametrize('field',['tests','failures','errors','skipped'])
def test_junit_unrepresented_counts_refuse(tmp_path,field):
    args={'tests':1,'failures':0,'errors':0,'skipped':0};args[field]+=1
    with pytest.raises(ValueError,match='COUNT_MISMATCH'):gate.junit_cases(xml(tmp_path,**args))


@pytest.mark.parametrize('body,kwargs,code',[
 ('',{'tests':0},'EMPTY_TEST_RUN'),
 ('<testcase classname="fixture" name="one"/><testcase classname="fixture" name="one"/>',{'tests':2},'DUPLICATE_TEST_ID'),
 ('<testcase name="one"/>',{},'TEST_ID_MISSING'),
 ('<testcase classname="fixture" name="one"><error/><failure/></testcase>',{},'AMBIGUOUS_TEST_RESULT'),
 ])
def test_invalid_test_identity_set(tmp_path,body,kwargs,code):
    with pytest.raises(ValueError,match=code):gate.junit_cases(xml(tmp_path,body,**kwargs))


@pytest.mark.parametrize('tag,result,count',[('skipped','SKIP','skipped'),('error','ERROR','errors'),('failure','FAIL','failures')])
def test_nonpass_is_not_reclassified(tmp_path,tag,result,count):
    p=xml(tmp_path,f'<testcase classname="fixture" name="one"><{tag}/></testcase>',**{count:1})
    assert gate.junit_cases(p)[0]['result']==result
    assert gate.check_run(report(),p,'frozen',('demo.py',))['status']=='FAIL'


def test_stage_contexts_must_be_exact():
    assert gate.contexts_match([{'version':'a'}]*3)
    assert not gate.contexts_match([{'n':1},{'n':True},{'n':1}])
    assert not gate.contexts_match([{'os':'linux'},{'os':'windows'},{'os':'linux'}])
    assert not gate.contexts_match([{}]*3)
    assert not gate.contexts_match([{'os':'linux'}]*2)


def test_stage_hashes_are_rechecked(tmp_path,monkeypatch):
    monkeypatch.setattr(runner.runner,'source_fingerprint',lambda:'frozen')
    monkeypatch.setattr(runner,'context',lambda:{'runner':'fixture'})
    (tmp_path/'out.json').write_text('{}')
    runner.seal_stage(tmp_path,'audit','frozen',{'runner':'fixture'},True,['out.json'])
    assert runner.read_stage(tmp_path,'audit','frozen')['status']=='PASS'
    (tmp_path/'out.json').write_text('{"changed":true}')
    with pytest.raises(ValueError,match='OUTPUT_CHANGED'):runner.read_stage(tmp_path,'audit','frozen')


def test_source_change_during_stage_refuses(tmp_path,monkeypatch):
    monkeypatch.setattr(runner.runner,'source_fingerprint',lambda:'changed')
    with pytest.raises(ValueError,match='SOURCE_CHANGED'):runner.seal_stage(tmp_path,'audit','frozen',{},True,[])


def test_context_change_during_stage_refuses(tmp_path,monkeypatch):
    monkeypatch.setattr(runner.runner,'source_fingerprint',lambda:'frozen')
    monkeypatch.setattr(runner,'context',lambda:{'runner':'changed'})
    with pytest.raises(ValueError,match='CONTEXT_CHANGED'):runner.seal_stage(tmp_path,'audit','frozen',{'runner':'original'},True,[])


def test_release_json_duplicate_keys_refused(tmp_path):
    p=tmp_path/'bad.json';p.write_text('{"status":"FAIL","status":"PASS"}')
    with pytest.raises(ValueError,match='DUPLICATE_JSON_KEY'):gate.read_json(p)


def test_current_runtime_and_semantics_preserved():
    result=gate.audit_static()
    assert result['status']=='PASS',result
    assert result['runtime_files']==43 and result['semantic_files']==6 and result['corpora']==3


def test_review_baseline_release_metadata_bound_by_fingerprint(tmp_path,monkeypatch):
    (tmp_path/'release').mkdir();p=tmp_path/'release/REVIEW-BASELINE.json';p.write_text('{}')
    monkeypatch.setattr(runner.runner,'ROOT',tmp_path);before=runner.runner.source_fingerprint()
    p.write_text('{"changed":true}');assert runner.runner.source_fingerprint()!=before


def test_h_archive_exact_predecessor_and_closure(tmp_path):
    (tmp_path/'file.txt').write_bytes(b'fixture')
    raw,m=builder.build(tmp_path)
    assert builder.verify(raw)['status']=='PASS'
    assert m['predecessor_archive_sha256']=='cb659af507734796c8b69602449b7fe93efb31a3c66407b997f6e2d882994e97'
    assert builder.MANIFEST=='BATCH-H-FILE-MANIFEST.json'
    assert builder.build(tmp_path)[0]==raw
