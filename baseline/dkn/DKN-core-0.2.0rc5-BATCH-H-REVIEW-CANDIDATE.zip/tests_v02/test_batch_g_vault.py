"""Actual SQLite behavior contrasted with the simulation's external-floor assumption."""
from copy import deepcopy
import shutil
import pytest
from dkn_v02 import Refusal
from dkn_v02.distributed import assess_view
from dkn_v02.vault import TransactionalVault
from examples.distributed_fixtures import fixture_bundle


def test_whole_database_restore_loses_local_floor_but_external_pin_detects(tmp_path):
    b=fixture_bundle();path=tmp_path/'vault.db';saved=tmp_path/'saved.db'
    v=TransactionalVault.create(path)
    old=v.advance_namespace(b['genesis'],b['policy'],b['events'],expected_head=None)
    shutil.copy2(path,saved) # No open transaction; cooperative local test only.
    new=v.advance_namespace(b['genesis'],b['policy'],b['revoked'],expected_head=old['head_ref'])
    external={'sequence':new['sequence'],'head_ref':new['head_ref']}
    assert v.read_namespace(b['genesis']['namespace_root'])['state']['sequence']==2
    shutil.copy2(saved,path)
    restored=TransactionalVault(path).read_namespace(b['genesis']['namespace_root'])
    assert restored['state']['sequence']==1
    journal={'kind':'journal','value':{**restored['bundle'],'checkpoint':b['objects']['granted']['value']['checkpoint']}}
    journal['value'].pop('schema')
    reader=deepcopy(b['reader']);objects=[b['objects']['artifact'],journal]
    assert assess_view(objects,reader,now=150)['status']=='MATCH_FOR_SUPPLIED_VIEW'
    reader['external_minimum']=external
    rejected=assess_view(objects,reader,now=150)
    assert rejected['status']=='INDETERMINATE'
    assert rejected['lifecycle']['candidates'][0]['refusal']=='DKN_LC_ROLLBACK_OR_FORK'


def test_valid_recovery_fork_does_not_overwrite_local_selection(tmp_path):
    b=fixture_bundle();v=TransactionalVault.create(tmp_path/'vault.db')
    before=v.advance_namespace(b['genesis'],b['policy'],b['events'],expected_head=None)
    selected=v.advance_namespace(b['genesis'],b['policy'],b['recovery'][0],expected_head=before['head_ref'])
    with pytest.raises(Refusal):
        v.advance_namespace(b['genesis'],b['policy'],b['recovery'][1],expected_head=selected['head_ref'])
    assert v.read_namespace(b['genesis']['namespace_root'])['state']['head_ref']==selected['head_ref']
