"""All exported runtime schemas exercised with actual implementation outputs."""
import copy
import json
from pathlib import Path
import pytest
from jsonschema import Draft202012Validator
from dkn_v02 import *
from dkn_v02.runtime_schemas import SCHEMAS, validate_report
from dkn_v02.assurance import verify_record,evaluate,compose
from dkn_v02.federation import assess_checkpoints,make_handoff
from dkn_v02.assured_navigation import inspect_with_assurance
from dkn_v02.storage import MemoryStore,retrieve
from examples.v02_assurance import fixture_bundle

ROOT=Path(__file__).resolve().parents[1]

def samples(tmp_path):
    b=fixture_bundle();raw,m=b['raw'],b['manifest'];key=b['issuer']
    g=declare_genesis(semantic_name='schema.demo',purpose='publisher',nonce='initial',key=key)
    t=transition(g,key,key_hex(b['witnesses'][0]),epoch=1)
    cert=certify(m,key,namespace_root=g['namespace_root'])
    idx=LocalIndex(tmp_path/'index');idx.add(raw,certificate=cert,genesis=g)
    args={k:b[k] for k in ('descriptor','contract','evidence','policy','context')}
    store=MemoryStore();loc=store.put(raw)
    return {
        'dimension':commit('state','example.state',{}),'manifest':m,'certificate':cert,'genesis':g,'transition':t,
        'relation':{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':'00'*32,'scope':'fixture'},
        'inspection':inspect(raw,certificate=cert,genesis=g),'query':idx.discover(semantic_name='schema.demo'),
        'traversal':idx.traverse(m['logical_root']),'namespace-candidates':idx.compare_namespace(g['namespace_root']),
        'lineage-analysis':analyze_lineage(g,[[t]]),'manifest-structure':validate_manifest(m),
        'manifest-verification':verify_manifest(m,{'hello.txt':b'DKN Batch D offline fixture\n'}),
        'archive-verification':verify_archive(raw),'certificate-verification':verify_certificate(cert,m),
        'dimension-verification':verify_dimension(commit('state','example.state',{})),
        'genesis-verification':verify_genesis(g),'lineage-verification':verify_transitions(g,[t]),
        'record-verification':verify_record(b['descriptor']),'assessment':evaluate(**args),
        'composition':compose([b['descriptor']],roots=[b['descriptor']['record_hash']],at_time=1000),
        'checkpoint-assessment':assess_checkpoints(b['checkpoints'],b['checkpoint_policy'],at_time=1000),
        'handoff':make_handoff(b['checkpoints'],b['checkpoint_policy'],at_time=1000,consumer='CCP'),
        'assured-inspection':inspect_with_assurance(raw,**args),
        'retrieval':retrieve([loc],{'memory':store},expected_root=m['logical_root'])[1],
        'refusal':{'status':'REFUSED','code':'FIXTURE','authority_effect':'NONE'},
        'sam-request':{'schema':'dkn.sam-request.v0.2-candidate','operation':'evaluate','arguments':args}}

@pytest.fixture(scope='module')
def example_reports(tmp_path_factory):return samples(tmp_path_factory.mktemp('schema-reports'))

@pytest.mark.parametrize('name',sorted(SCHEMAS))
def test_exported_schema_matches_source(name):
    p=ROOT/'schemas/v02/runtime'/(name+'.schema.json')
    assert json.loads(p.read_text())==SCHEMAS[name]
    Draft202012Validator.check_schema(SCHEMAS[name])

@pytest.mark.parametrize('name',sorted(SCHEMAS))
def test_actual_reports_fit_closed_schema(name,example_reports):
    assert validate_report(name,example_reports[name])==example_reports[name]

@pytest.mark.parametrize('name',sorted(SCHEMAS))
def test_unknown_report_field_refused(name,example_reports):
    r=copy.deepcopy(example_reports[name]);r['unexpected-authority-grant']=True
    with pytest.raises(Refusal):validate_report(name,r)

@pytest.mark.parametrize('name',['assessment','composition','checkpoint-assessment','handoff','assured-inspection','retrieval'])
def test_authority_promotion_refused(name,example_reports):
    r=copy.deepcopy(example_reports[name]);r['authority_effect']='GRANT'
    with pytest.raises(Refusal):validate_report(name,r)

def test_indeterminate_retrieval_shape():
    r=retrieve([],{},expected_root='00'*32)[1]
    validate_report('retrieval',r)

def test_insufficient_assessment_shape():
    b=fixture_bundle();r=evaluate(b['descriptor'],b['contract'],[],b['policy'],b['context'])
    assert r['status']=='INSUFFICIENT';validate_report('assessment',r)

def test_all_sam_request_shapes():
    b=fixture_bundle()
    requests={
        'verify':{'record':b['descriptor']},
        'compose':{'descriptors':[b['descriptor']],'roots':[b['descriptor']['record_hash']],'at_time':1000},
        'checkpoints':{'checkpoints':b['checkpoints'],'policy':b['checkpoint_policy'],'at_time':1000},
        'handoff':{'checkpoints':b['checkpoints'],'policy':b['checkpoint_policy'],'at_time':1000,'consumer':'CHC'}}
    for op,args in requests.items():validate_report('sam-request',{'schema':'dkn.sam-request.v0.2-candidate','operation':op,'arguments':args})
