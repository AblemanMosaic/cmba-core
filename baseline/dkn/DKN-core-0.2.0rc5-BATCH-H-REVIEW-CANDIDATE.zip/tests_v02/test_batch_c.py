import json
from pathlib import Path
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import (LocalIndex,Refusal,pack,certify,commit,declare_genesis,key_hex,
                     relation_commitment,validate_relations,inspect,transition)

@pytest.fixture
def key(): return Ed25519PrivateKey.from_private_bytes(b'\x63'*32)

@pytest.fixture
def vault(tmp_path):return LocalIndex(tmp_path/'vault')

def rel(dest,kind='depends_on',scope='candidate dependency'):
    return {'schema':'dkn.relations.v0.2-candidate','relation_type':kind,'destination':dest,'scope':scope}

def prepared(key, name='a', relations=None):
    dims=[relation_commitment(relations)] if relations is not None else []
    blob,manifest=pack({name+'.txt':name.encode()},dims)
    return blob,manifest,certify(manifest,key)

def test_exact_and_discovery(vault,key):
    g=declare_genesis(semantic_name='team.app',purpose='publisher',nonce='v',legacy_instance='dkn:v0.1:b3:'+'12'*32,key=key)
    raw,m,cert=prepared(key)
    cert=certify(m,key,namespace_root=g['namespace_root'])
    rid=m['logical_root']
    vault.add(raw,certificate=cert,genesis=g)
    got=vault.resolve_exact(rid)
    assert got['namespace_authorization']=='PASS_FOR_SUPPLIED_CHAIN_ONLY'
    assert got['freshness']=='NOT_ESTABLISHED'
    res=vault.discover(semantic_name='team.app')
    assert res['results'][0]['logical_root']==rid
    assert res['global_completeness']=='NOT_ESTABLISHED'
    with pytest.raises(Refusal): vault.resolve_exact('00'*32)
    with pytest.raises(Refusal):vault.add(raw,certificate=cert,genesis=g)

def test_relation_traversal(vault,key):
    raw_b,m_b,c_b=prepared(key,'b')
    vault.add(raw_b,certificate=c_b)
    edges=[rel(m_b['logical_root'])]
    raw_a,m_a,c_a=prepared(key,'a',edges)
    vault.add(raw_a,certificate=c_a,relations=edges)
    forward=vault.traverse(m_a['logical_root'])
    assert len(forward['nodes'])==2 and forward['edges'][0]['relation_authentication']=='PASS'
    reverse=vault.traverse(m_b['logical_root'],direction='incoming')
    assert len(reverse['nodes'])==2
    assert reverse['global_completeness']=='NOT_ESTABLISHED'
    assert vault.traverse(m_a['logical_root'],max_nodes=1)['truncated']

def test_unsigned_binding_is_not_authenticated(vault,key):
    edges=[rel('de'*32)]
    raw,m,_=prepared(key,'a',edges)
    vault.add(raw,relations=edges)
    r=vault.resolve_exact(m['logical_root'])
    assert r['relation_binding']=='PASS' and r['relation_authentication']=='NOT_ESTABLISHED'
    trav=vault.traverse(m['logical_root'])
    assert trav['unresolved'][0]['logical_root']=='de'*32

def test_unbound_relation_refused(vault,key):
    raw,m,c=prepared(key)
    with pytest.raises(Refusal,match='RELATION_UNBOUND'):
        vault.add(raw,certificate=c,relations=[rel('00'*32)])

def test_tampering_fails_closed(vault,key):
    raw,m,c=prepared(key)
    vault.add(raw,certificate=c)
    p=vault.objects/(m['logical_root']+'.zip')
    p.write_bytes(p.read_bytes()+b'evil')
    with pytest.raises(Refusal,match='TRANSPORT_MISMATCH'):
        vault.resolve_exact(m['logical_root'])
    with pytest.raises(Refusal):vault.discover(signer_public_key_hex=key_hex(key))

def test_evidence_substitution_refused(vault,key):
    raw,m,c=prepared(key)
    vault.add(raw,certificate=c)
    ep=vault.metadata/(m['logical_root']+'.json')
    item=json.loads(ep.read_text());item['certificate']['signer_public_key_hex']='00'*32
    ep.write_text(json.dumps(item,sort_keys=True,separators=(',',':')))
    with pytest.raises(Refusal):vault.resolve_exact(m['logical_root'])

def test_relation_mutation_refused(vault,key):
    raw,m,c=prepared(key,'a',[rel('00'*32)])
    with pytest.raises(Refusal,match='DIMENSION_MISMATCH'):
        vault.add(raw,certificate=c,relations=[rel('11'*32)])
    with pytest.raises(Refusal):validate_relations([rel('ab'*32),rel('ab'*32)])
    with pytest.raises(Refusal):validate_relations([rel('00'*32,'unknown')])

def test_limits_and_malformed(vault,key):
    raw,m,c=prepared(key)
    vault.add(raw,certificate=c)
    with pytest.raises(Refusal):vault.traverse(m['logical_root'],max_depth=9)
    with pytest.raises(Refusal):vault.discover()
    with pytest.raises(Refusal):vault.discover(signer_public_key_hex='xyz')
    with pytest.raises(Refusal):vault.discover(signer_public_key_hex=key_hex(key),limit=0)

def test_symlink_attack(vault,key,tmp_path):
    raw,m,c=prepared(key)
    vault.add(raw,certificate=c)
    ep=vault.metadata/(m['logical_root']+'.json')
    ep.unlink();ep.symlink_to(tmp_path/'missing')
    with pytest.raises(Refusal,match='SYMLINK'):vault.resolve_exact(m['logical_root'])

def test_namespace_nonexclusive(vault,key):
    k2=Ed25519PrivateKey.from_private_bytes(b'\x54'*32)
    g1=declare_genesis(semantic_name='same.app',purpose='publisher',nonce='x',legacy_instance='dkn:v0.1:b3:'+'11'*32,key=key)
    g2=declare_genesis(semantic_name='same.app',purpose='publisher',nonce='x',legacy_instance='dkn:v0.1:b3:'+'22'*32,key=k2)
    for n,k,g in [('a',key,g1),('b',k2,g2)]:
        raw,m,_=prepared(k,n);vault.add(raw,certificate=certify(m,k,namespace_root=g['namespace_root']),genesis=g)
    got=vault.discover(semantic_name='same.app')
    assert len(got['results'])==2
    assert got['results'][0]['namespace_root'] != got['results'][1]['namespace_root']
    assert vault.compare_namespace(g1['namespace_root'])['fork_proven']=='NOT_ESTABLISHED'

def test_namespace_signer_mismatch(vault,key):
    k2=Ed25519PrivateKey.from_private_bytes(b'\x42'*32)
    g=declare_genesis(semantic_name='x.app',purpose='publisher',nonce='x',legacy_instance='dkn:v0.1:b3:'+'11'*32,key=key)
    raw,m,_=prepared(k2)
    vault.add(raw,certificate=certify(m,k2,namespace_root=g['namespace_root']),genesis=g)
    r=vault.resolve_exact(m['logical_root'])
    assert r['namespace_authorization']=='NOT_ESTABLISHED'

def test_transitions_scoped(vault,key):
    k2=Ed25519PrivateKey.from_private_bytes(b'\x42'*32)
    g=declare_genesis(semantic_name='x.app',purpose='publisher',nonce='x',legacy_instance='dkn:v0.1:b3:'+'11'*32,key=key)
    tr=transition(g,key,key_hex(k2),epoch=1)
    raw,m,_=prepared(k2)
    vault.add(raw,certificate=certify(m,k2,namespace_root=g['namespace_root']),genesis=g,transitions=[tr])
    r=vault.resolve_exact(m['logical_root'])
    assert r['namespace_authorization']=='PASS_FOR_SUPPLIED_CHAIN_ONLY'
    assert r['lineage_scope']=='SUPPLIED_CHAIN_ONLY'
    assert r['freshness']=='NOT_ESTABLISHED'

def test_bounded_discovery_is_not_completeness(vault,key):
    for i in range(3):
        raw,m,c=prepared(key,str(i));vault.add(raw,certificate=c)
    r=vault.discover(signer_public_key_hex=key_hex(key),limit=1)
    assert r['returned']==1 and r['matched_locally']==3 and r['truncated']
    assert r['global_completeness']=='NOT_ESTABLISHED'

def test_noncanonical_stored_metadata_refused(vault,key):
    raw,m,c=prepared(key)
    vault.add(raw,certificate=c)
    p=vault.metadata/(m['logical_root']+'.json')
    p.write_bytes(b' '+p.read_bytes())
    with pytest.raises(Refusal,match='JSON_NOT_CANONICAL'):vault.resolve_exact(m['logical_root'])
