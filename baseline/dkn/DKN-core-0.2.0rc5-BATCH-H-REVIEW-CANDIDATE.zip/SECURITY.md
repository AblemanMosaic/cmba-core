# Security boundary — current candidate 0.2.0rc5 / Batch H

**NOT independently approved; public-release gate NOT_CLEARED.** The current inventory is
`BATCH-H-FILE-MANIFEST.json`. All predecessor inventories/certificates are historical.
The full predecessor security text is preserved in `docs/history/SECURITY-RC4.md`.

## Current guarantees and exclusions

Cryptographic checks bind exact admitted bytes, signing keys and supplied histories. They
do not prove truth, intended publisher recognition, global freshness, witness independence,
consensus, availability, or execution authority. Recognized keys, roots, time, policies and
rollback floors are caller-controlled trust inputs; protect them outside untrusted bundles.

The base library handles bounded canonical metadata and portable regular files. It accepts
its canonical ZIP transport, not arbitrary equivalent ZIP/tar encodings or filesystem
permission/symlink semantics. Payload credentials are NOT scrubbed; plaintext vault contents
are NOT encrypted by DKN. Public test fixtures are never production identities.

LC-F1 direct delegations are exact artifact/subject/operation, finite and nondelegable.
Recovery requires a genesis-bound threshold policy and successor proof of possession.
Distinct guardian keys are not proof of independent people or honest custodians. Journals
are capped at 256 events; live revocation discovery and policy amendments are not implemented.

The SQLite vault is explicit and local: cooperating clients, trusted local filesystem.
It is not a hostile-host sandbox, remote database service, or unqualified physical-power-loss
proof. Whole-file rollback restores internal floors; independently retained floors require
an actual external mechanism. The older LocalIndex remains a single-writer directory index.

DS-G1 is a finite deterministic model using supplied evidence. No network, consensus,
automatic reader-pin advancement or operational capability grant follows from simulation.
The evaluator checks certify_artifact evidence, never permission to execute or install.

## Findings and review history

Batch E repaired inadmissible-key acceptance; RC2 repaired inventory and report boundaries.
Batch H repairs two conformance-test oracle errors: Python bool/int equality and a JSON null
response that could bypass mismatch reporting. No new runtime cryptographic bypass was
established by these findings. See `docs/release/FINDINGS.md` and retained pre-repair witnesses.

A conformance PASS is finite corpus agreement, not semantic equivalence. The reviewed runner
records stage context and exact evidence hashes but is not tamper-proof against someone who
controls the runner and all unsigned records. Test executables are host-authorized code.
An external reviewer must independently pin inputs and reproduce checks.

## Responsible reporting and deployment

Report suspected defects privately to the maintainer with exact artifact hashes and a bounded
reproducer. Do not send production private keys, credentials, personal archives, or live tokens.
Do not deploy as an unattended production trust root on the strength of this self-review.
Open gates and the independent review checklist are in `docs/release/REVIEW-HANDOFF.md`.
