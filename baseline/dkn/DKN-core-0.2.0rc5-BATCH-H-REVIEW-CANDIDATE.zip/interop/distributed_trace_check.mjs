// Separately written DS-G1 commitment/trace checker. NOT a simulator or policy verifier.
import {readFileSync} from 'node:fs';
import {canonical,parseCanonical,hash} from './dkn_v02_verify.mjs';
const h=(kind,value)=>hash(Buffer.from('DKN_DS_G1\0'+kind+'\0','ascii'),value);
function requireValue(value,reason){if(!value)throw new Error(reason);}
try{
 const request=parseCanonical(readFileSync(process.argv[2]));
 const {scenario,transcript:t}=request;
 requireValue(t.schema==='dkn.distributed-transcript.v0.2-g1','SCHEMA');
 requireValue(t.simulation_only===true && t.production_evidence===false && t.authority_effect==='NONE','BOUNDARY');
 const sr=h('scenario',scenario);requireValue(t.scenario_ref===sr,'SCENARIO');
 let previous=h('trace-start',{scenario_ref:sr}),i=0n,last=0n;
 const assessments=[];
 for(const entry of t.trace){
   requireValue(entry.index===i && entry.time>=last && entry.previous_hash===previous,'ORDER');
   const {entry_hash,...body}=entry;
   requireValue(h('trace-entry',body)===entry_hash,'HASH');
   if(entry.type==='assessment')assessments.push(entry.details);
   i++;last=entry.time;previous=entry_hash;
 }
 requireValue(t.trace_root===previous,'ROOT');
 requireValue(canonical(assessments)===canonical(t.assessments),'ASSESSMENT_LINK');
 process.stdout.write(canonical({status:'PASS',scenario_ref:sr,trace_root:previous,entries:i,
   scope:'COMMITMENT_TRACE_LINKAGE_ONLY_NOT_SCENARIO_SEMANTICS',authority_effect:'NONE'})+'\n');
}catch(error){process.stdout.write(canonical({status:'REFUSED',code:error.message,authority_effect:'NONE'})+'\n');process.exitCode=2;}
