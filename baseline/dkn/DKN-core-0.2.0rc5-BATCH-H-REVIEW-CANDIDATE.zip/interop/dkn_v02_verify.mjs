#!/usr/bin/env node
/** Independently written DKN candidate byte/signature checker. Node built-ins only.
 * This checks specified cryptographic primitives, not all DKN policy/schema rules.
 * Python and Node may share OpenSSL ancestry: not independent crypto or human review.
 */
import {readFileSync} from 'node:fs';
import {createHash,createPublicKey,verify} from 'node:crypto';
import {fileURLToPath} from 'node:url';

export class Refusal extends Error {}
function check(ok,code){if(!ok)throw new Refusal(code);}
const MAX=4*1024*1024;
const I64MIN=-(1n<<63n),I64MAX=(1n<<63n)-1n;
const object=v=>v!==null && typeof v==='object' && !Array.isArray(v);
function scalarString(s){
  check(typeof s==='string','STRING');
  for(const c of s){const cp=c.codePointAt(0);check(cp<0xd800 || cp>0xdfff,'SURROGATE');}
}
function compareCodepoints(a,b){
 const aa=Array.from(a,c=>c.codePointAt(0)),bb=Array.from(b,c=>c.codePointAt(0));
 for(let i=0;i<Math.min(aa.length,bb.length);i++)if(aa[i]!==bb[i])return aa[i]-bb[i];
 return aa.length-bb.length;
}
export function canonical(value,depth=0){
 check(depth<=32,'DEPTH');
 let result;
 if(value===null || typeof value==='boolean')result=String(value);
 else if(typeof value==='bigint'){
   check(value>=I64MIN && value<=I64MAX,'INTEGER_RANGE');result=value.toString();
 }else if(typeof value==='number'){
   check(Number.isSafeInteger(value) && !Object.is(value,-0),'NUMBER_UNSAFE');result=String(value);
 }else if(typeof value==='string'){scalarString(value);result=JSON.stringify(value);}
 else if(Array.isArray(value)){
   check(value.length<=4096,'MEMBER_LIMIT');result='['+value.map(v=>canonical(v,depth+1)).join(',')+']';
 }else if(object(value)){
   const keys=Object.keys(value).sort(compareCodepoints);check(keys.length<=4096,'MEMBER_LIMIT');
   result='{'+keys.map(k=>{scalarString(k);return JSON.stringify(k)+':'+canonical(value[k],depth+1);}).join(',')+'}';
 }else throw new Refusal('TYPE');
 check(Buffer.byteLength(result)<=MAX,'BYTE_LIMIT');return result;
}
/** Lossless parser: integer tokens become BigInt. Duplicate keys are refused.
 * Canonical reserialization refuses BOM, insignificant whitespace, -0 and escapes.
 */
export function parseCanonical(raw){
 check(Buffer.isBuffer(raw) && raw.length<=MAX,'BYTE_LIMIT');
 let text;try{text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw);}catch{throw new Refusal('UTF8');}
 let pos=0;
 function string(){
   check(text[pos]==='"','STRING');const start=pos++;
   while(pos<text.length){
     const ch=text[pos++];
     if(ch==='"'){
       let s;try{s=JSON.parse(text.slice(start,pos));}catch{throw new Refusal('STRING');}
       scalarString(s);return s;
     }
     if(ch==='\\'){check(pos<text.length,'STRING');pos++;}
   }
   throw new Refusal('STRING');
 }
 function value(depth=0){
   check(depth<=32,'DEPTH');const ch=text[pos];
   if(ch==='"')return string();
   if(ch==='{'){
     pos++;const out=Object.create(null);if(text[pos]==='}'){pos++;return out;}
     let n=0;while(true){
       check(++n<=4096,'MEMBER_LIMIT');const key=string();check(!Object.hasOwn(out,key),'DUPLICATE_KEY');
       check(text[pos++]===':','COLON');out[key]=value(depth+1);
       const end=text[pos++];if(end==='}')return out;check(end===',','OBJECT');
     }
   }
   if(ch==='['){
     pos++;const out=[];if(text[pos]===']'){pos++;return out;}
     while(true){check(out.length<4096,'MEMBER_LIMIT');out.push(value(depth+1));const end=text[pos++];if(end===']')return out;check(end===',','ARRAY');}
   }
   for(const [token,out] of [['null',null],['true',true],['false',false]])if(text.startsWith(token,pos)){pos+=token.length;return out;}
   const m=/^-?(?:0|[1-9][0-9]*)/.exec(text.slice(pos));check(m!==null,'JSON');
   pos+=m[0].length;const n=BigInt(m[0]);check(n>=I64MIN&&n<=I64MAX,'INTEGER_RANGE');return n;
 }
 const out=value();check(pos===text.length && canonical(out)===text,'NONCANONICAL');return out;
}
export function hash(domain,value){return createHash('sha256').update(domain).update(Buffer.from(canonical(value),'utf8')).digest('hex');}
const P=(1n<<255n)-19n,L=(1n<<252n)+27742317777372353535851937790883648493n;
const mod=x=>((x%P)+P)%P;
function pow(x,n){let r=1n;x=mod(x);while(n){if(n&1n)r=mod(r*x);x=mod(x*x);n>>=1n;}return r;}
const D=mod(-121665n*pow(121666n,P-2n)),SQRTM1=pow(2n,(P-1n)/4n);
const le=b=>BigInt('0x'+Buffer.from(b).reverse().toString('hex'));
function decodePoint(b){
 const packed=le(b),sign=packed>>255n,y=packed&((1n<<255n)-1n);check(y<P,'POINT_CANONICAL');
 const y2=mod(y*y),den=mod(D*y2+1n);check(den!==0n,'POINT');const x2=mod((y2-1n)*pow(den,P-2n));
 let x=pow(x2,(P+3n)/8n);if(mod(x*x)!==x2)x=mod(x*SQRTM1);
 check(mod(x*x)===x2 && !(x===0n&&sign===1n),'POINT');if((x&1n)!==sign)x=P-x;
 return [x,y,1n,mod(x*y)];
}
function add(a,b){ // Extended Edwards coordinates; public data only.
 const [x1,y1,z1,t1]=a,[x2,y2,z2,t2]=b;
 const A=mod((y1-x1)*(y2-x2)),B=mod((y1+x1)*(y2+x2)),C=mod(2n*D*t1*t2),DD=mod(2n*z1*z2);
 const E=mod(B-A),F=mod(DD-C),G=mod(DD+C),H=mod(B+A);
 return [mod(E*F),mod(G*H),mod(F*G),mod(E*H)];
}
function mul(p,n){let out=[0n,1n,1n,0n];while(n){if(n&1n)out=add(out,p);p=add(p,p);n>>=1n;}return out;}
const identity=p=>p[0]===0n && mod(p[1]-p[2])===0n && p[2]!==0n;
const keys=new Map();
export function admitKey(hex){
 check(typeof hex==='string' && /^[0-9a-f]{64}$/.test(hex),'KEY_ENCODING');
 if(keys.has(hex))return keys.get(hex);
 const raw=Buffer.from(hex,'hex'),point=decodePoint(raw);check(!identity(point)&&identity(mul(point,L)),'KEY_SUBGROUP');
 const key=createPublicKey({key:Buffer.concat([Buffer.from('302a300506032b6570032100','hex'),raw]),format:'der',type:'spki'});
 if(keys.size>=512)keys.clear();keys.set(hex,key);return key;
}
export function verifySignature(pub,signature,msg){
 check(typeof signature==='string' && /^[0-9a-f]{128}$/.test(signature),'SIGNATURE_ENCODING');
 const raw=Buffer.from(signature,'hex');check(le(raw.subarray(32))<L,'SIGNATURE_SCALAR');
 const key=admitKey(pub);check(verify(null,msg,key,raw),'SIGNATURE');return true;
}
const without=(obj,fields)=>Object.fromEntries(Object.entries(obj).filter(([k])=>!fields.includes(k)));
export function verifySigned(kind,record){
 let body,domain,pub;
 if(kind==='certificate'){
   body=without(record,['signature_hex']);domain='DKN_V02_CERTIFICATE\0';pub=record.signer_public_key_hex;
 }else if(kind==='genesis'){
   body=without(record,['signature_hex','namespace_root']);domain='DKN_V02_NAMESPACE_GENESIS\0';pub=record.founder_public_key_hex;
   check(hash(domain,body)===record.namespace_root,'ROOT');
 }else if(kind==='transition'){
   body=without(record,['signature_hex','transition_hash']);domain='DKN_V02_NAMESPACE_TRANSITION\0';pub=record.predecessor_public_key_hex;
   admitKey(record.successor_public_key_hex);check(hash(domain,body)===record.transition_hash,'ROOT');
 }else if(kind==='sam'){
   body=without(record,['signature_hex','record_hash']);domain='DKN_V02_SAM_SIGNATURE\0';pub=record.signer_public_key_hex;
   check(hash('DKN_V02_SAM_RECORD\0',body)===record.record_hash,'ROOT');
 }else throw new Refusal('KIND');
 return verifySignature(pub,record.signature_hex,Buffer.from(domain+canonical(body),'utf8'));
}
export function dispatch(request){
 const a=request.arguments;
 switch(request.operation){
   case 'canonical':return {canonical_base64:Buffer.from(canonical(parseCanonical(Buffer.from(a.raw_base64,'base64')))).toString('base64')};
   case 'hash':return {digest:hash(Buffer.from(a.domain_hex,'hex'),parseCanonical(Buffer.from(a.canonical_base64,'base64')))};
   case 'signature':verifySignature(a.public_key_hex,a.signature_hex,Buffer.from(a.message_hex,'hex'));return {signature:'PASS'};
   case 'signed':verifySigned(a.kind,a.record);return {signature:'PASS'};
   default:throw new Refusal('OPERATION');
 }
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 try{
   const raw=readFileSync(process.argv[2]);const request=parseCanonical(raw);
   const result=dispatch(request);process.stdout.write(canonical({status:'PASS',result,scope:'BYTE_AND_CRYPTO_PRIMITIVES_ONLY'})+'\n');
 }catch(error){process.stdout.write(canonical({status:'REFUSED',code:error instanceof Refusal?error.message:'INPUT_ERROR'})+'\n');process.exitCode=2;}
}
