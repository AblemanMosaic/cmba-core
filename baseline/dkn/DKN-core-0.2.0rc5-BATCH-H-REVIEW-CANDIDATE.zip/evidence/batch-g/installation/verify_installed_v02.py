"""Installed-wheel smoke probe. Run from outside the source tree with no PYTHONPATH.

This script does not prove dependency installation independence or target-OS parity.
All keys and files it creates are temporary local demonstration material.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def run():
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    import dkn_v02
    from dkn_v02 import pack,certify,declare_genesis,verify_archive,inspect,LocalIndex,analyze_lineage
    from dkn_v02.storage import DirectoryStore,retrieve
    from dkn_v02.reference_profiles import reference_profile
    from dkn_v02.assurance import seal
    from dkn_v02.sam_abi import dispatch
    from dkn_v02.runtime_schemas import validate_report
    module=Path(dkn_v02.__file__).resolve()
    assert Path(sys.prefix).resolve() in module.parents, 'IMPORT_IS_NOT_FROM_TEST_ENVIRONMENT'
    with tempfile.TemporaryDirectory(prefix='dkn-wheel-smoke-') as tmp:
        root=Path(tmp);key=Ed25519PrivateKey.generate()
        raw,m=pack({'README.txt':b'Installed DKN candidate\n'})
        g=declare_genesis(semantic_name='installed.demo',purpose='publisher',nonce='temp',key=key)
        cert=certify(m,key,namespace_root=g['namespace_root'])
        store=DirectoryStore(root/'store');loc=store.put(raw)
        got,observation=retrieve([loc],{'local':store},expected_root=m['logical_root'])
        report=inspect(got,certificate=cert,genesis=g);validate_report('inspection',report)
        idx=LocalIndex(root/'index');idx.add(got,certificate=cert,genesis=g)
        assert idx.discover(semantic_name='installed.demo')['returned']==1
        assert analyze_lineage(g,[[]])['selected_head'] is None
        descriptor=seal('substrate',reference_profile('LOCAL_VAULT'),key)
        result=dispatch({'schema':'dkn.sam-request.v0.2-candidate','operation':'verify','arguments':{'record':descriptor}})
        assert result['signature']=='PASS' and result['asserted_fact']=='NOT_ESTABLISHED'
        archive=root/'artifact.zip';archive.write_bytes(raw)
        commands=[]
        for module_name,args in [('dkn_v02',['verify',str(archive)]),('dkn_v02.nav_cli',['inspect',str(archive)])]:
            p=subprocess.run([sys.executable,'-m',module_name,*args],capture_output=True,text=True,timeout=20)
            assert p.returncode==0,p.stderr;commands.append({'module':module_name,'exit_code':p.returncode})
    return {'schema':'dkn.installed-wheel-smoke.v0.2-rc2','status':'PASS',
            'module_path':str(module),'prefix':sys.prefix,'python':sys.version,
            'checks':['installed-module-custody','pack-verify','namespace-signature','directory-retrieval',
                      'index-discovery','lineage-analysis','sam-abi','report-schema','module-clis'],
            'commands':commands,'dependency_source':'COPIED_PREINSTALLED_HOST_DEPENDENCIES_NOT_FRESH_RESOLUTION',
            'cross_platform':'NOT_ESTABLISHED','authority_effect':'NONE'}

if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))
