"""Probe the installed DS-G1 wheel outside the source tree; no dependency download claim."""
from __future__ import annotations
import argparse,hashlib,importlib.metadata,json,os,subprocess,sys,zipfile
from pathlib import Path

def run(wheel:Path,scenario_path:Path):
    import dkn_v02
    from dkn_v02 import canonical,read_canonical
    from dkn_v02.simulation import run_scenario,verify_replay
    from dkn_v02.distributed_abi import dispatch
    prefix=Path(sys.prefix).resolve();module=Path(dkn_v02.__file__).resolve()
    assert prefix in module.parents,'SOURCE_IMPORT_NOT_INSTALLED'
    site=module.parent.parent;count=0
    with zipfile.ZipFile(wheel) as z:
        for name in z.namelist():
            if name.startswith(('dkn_v02/','dkn_core/')) and not name.endswith('/'):
                assert (site/name).read_bytes()==z.read(name),name;count+=1
    scenario=read_canonical(scenario_path.read_bytes())
    result=run_scenario(scenario);assert verify_replay(scenario,result)['status']=='MATCH_EXACT_SIMULATION_REPLAY'
    assert [r['report']['status'] for r in result['assessments']]==['INDETERMINATE','MATCH_FOR_SUPPLIED_VIEW']
    request={'schema':'dkn.distributed-request.v0.2-g1','operation':'simulate','arguments':{'scenario':scenario}}
    assert dispatch(request)==result
    executable=prefix/('Scripts/dkn-sim.exe' if os.name=='nt' else 'bin/dkn-sim')
    p=subprocess.run([str(executable),'-'],input=canonical(request),capture_output=True,timeout=20)
    assert p.returncode==0,(p.stdout,p.stderr)
    assert p.stdout==canonical(result)+b'\n'
    return {'schema':'dkn.installed-wheel-smoke.v0.2-rc4','status':'PASS',
        'version':importlib.metadata.version('dkn-core'),'module_path':str(module),'prefix':str(prefix),
        'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
        'scenario_sha256':hashlib.sha256(scenario_path.read_bytes()).hexdigest(),
        'installed_payload_files_compared':count,'checks':['file-identity','installed-import','simulation','full-replay','read-only-abi','installed-cli'],
        'dependency_source':'EXACT_COPIES_OF_GENUINE_PREINSTALLED_HOST_DISTRIBUTIONS',
        'fresh_dependency_resolution':'NOT_ESTABLISHED','cross_platform':'NOT_ESTABLISHED','authority_effect':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--wheel',type=Path,required=True);p.add_argument('--scenario',type=Path,required=True);p.add_argument('--out',type=Path)
    a=p.parse_args();r=run(a.wheel.resolve(),a.scenario.resolve());text=json.dumps(r,indent=2,sort_keys=True)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text)
if __name__=='__main__':main()
