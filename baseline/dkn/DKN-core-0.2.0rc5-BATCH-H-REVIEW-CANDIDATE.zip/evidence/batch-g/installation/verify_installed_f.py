"""Installed Batch F smoke probe; run outside source without PYTHONPATH.

Dependencies are exact copies of genuine host distributions in the isolated test venv.
That is explicitly not a fresh dependency resolution or cross-platform test.
"""
from __future__ import annotations
import argparse,hashlib,importlib.metadata,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path

def run(wheel: Path):
    import dkn_v02
    from dkn_v02 import canonical,pack,certify,key_hex,declare_genesis
    from dkn_v02 import lifecycle as lc
    from dkn_v02.vault import TransactionalVault
    from dkn_v02.lifecycle_schemas import validate_shape
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    module=Path(dkn_v02.__file__).resolve();prefix=Path(sys.prefix).resolve()
    assert prefix in module.parents,'SOURCE_IMPORT_NOT_INSTALLED'
    site=module.parent.parent
    matched=[]
    with zipfile.ZipFile(wheel) as archive:
        for name in archive.namelist():
            if name.startswith(('dkn_v02/','dkn_core/')) and not name.endswith('/'):
                assert (site/name).read_bytes()==archive.read(name),name
                matched.append(name)
    owner,delegate,guardian,new=[Ed25519PrivateKey.generate() for _ in range(4)]
    policy=lc.lifecycle_policy(recovery_keys=[key_hex(guardian)],recovery_threshold=1,
        allowed_operations=['certify_artifact'])
    genesis=declare_genesis(semantic_name='installed.batch-f',purpose='publisher',nonce='fixture',
        key=owner,recovery_policy_ref=lc.policy_reference(policy))
    raw,manifest=pack({'README.txt':b'Installed F smoke fixture\n'})
    event=lc.make_event(genesis,policy,[],kind='delegate',issued_at=10,
        payload={'subject_public_key_hex':key_hex(delegate),'artifact_root':manifest['logical_root'],
                 'operations':['certify_artifact'],'not_before':10,'expires_at':100},signing_keys=[owner])
    events=[event];certificate=certify(manifest,delegate,namespace_root=genesis['namespace_root'])
    checkpoint=lc.make_checkpoint(genesis,policy,events,issued_at=11,expires_at=90,key=owner)
    result=lc.inspect_with_lifecycle(raw,certificate,genesis,policy,events,
        expected_namespace=genesis['namespace_root'],expected_head=event['event_ref'],now=20,max_checkpoint_age=30,
        checkpoint=checkpoint)
    assert result['lifecycle']['status']=='MATCH_FOR_SUPPLIED_VIEW'
    validate_shape('inspection',result)
    with tempfile.TemporaryDirectory(prefix='dkn-f-installed-') as directory:
        vault=TransactionalVault.create(Path(directory)/'vault.db')
        vault.put_artifact(raw,certificate=certificate,genesis=genesis)
        pin=vault.advance_namespace(genesis,policy,events,expected_head=None)
        assert vault.resolve_exact(manifest['logical_root'])['result']['integrity']=='PASS'
        proposal=lc.prepare_event(genesis,policy,events,kind='recover',issued_at=30,
            payload={'successor_public_key_hex':key_hex(new)})
        proofs=[lc.endorse_event(genesis,policy,events,proposal,key) for key in (guardian,new)]
        recovered=lc.assemble_event(genesis,policy,events,proposal,proofs)
        vault.advance_namespace(genesis,policy,events+[recovered],expected_head=pin['head_ref'])
        assert vault.read_namespace(genesis['namespace_root'])['state']['active_key']==key_hex(new)
    request={'schema':'dkn.lifecycle-request.v0.2-f1','operation':'verify-policy','arguments':{'policy':policy}}
    executable=prefix/('Scripts/dkn-lifecycle.exe' if os.name=='nt' else 'bin/dkn-lifecycle')
    p=subprocess.run([str(executable),'-'],input=canonical(request),capture_output=True,timeout=20)
    assert p.returncode==0,(p.stdout,p.stderr)
    assert json.loads(p.stdout)['policy_ref']==lc.policy_reference(policy)
    return {'schema':'dkn.installed-wheel-smoke.v0.2-rc3','status':'PASS','version':importlib.metadata.version('dkn-core'),
        'module_path':str(module),'prefix':str(prefix),'python':sys.version,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
        'installed_payload_files_compared':len(matched),'checks':['wheel-file-identity','installed-import','artifact-lifecycle-join',
        'transactional-vault','detached-guardian-recovery','installed-console-entrypoint','report-schema'],
        'dependency_source':'EXACT_COPIES_OF_GENUINE_PREINSTALLED_HOST_DISTRIBUTIONS',
        'fresh_dependency_resolution':'NOT_ESTABLISHED','cross_platform':'NOT_ESTABLISHED','authority_effect':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--wheel',type=Path,required=True);p.add_argument('--out',type=Path);a=p.parse_args()
    result=run(a.wheel.resolve());text=json.dumps(result,sort_keys=True,indent=2)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text)
if __name__=='__main__':main()
