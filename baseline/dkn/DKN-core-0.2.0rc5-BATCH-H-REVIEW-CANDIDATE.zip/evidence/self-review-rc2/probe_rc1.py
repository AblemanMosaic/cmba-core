import sys, json, tempfile, pathlib, os, copy
sys.path[:0]=['/mnt/data/dkn_review_rc2/src','/mnt/data/dkn_review_rc2']
from unittest.mock import patch
from dkn_v02 import *
from dkn_v02 import core
from dkn_v02.navigation import LocalIndex, relation_commitment
from dkn_v02.runtime_schemas import validate_report
results=[]
def record(id,fn):
 try: results.append({'id':id, 'observed':fn()})
 except Exception as e:results.append({'id':id,'exception':type(e).__name__,'code':str(e)})
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td)/'src';p.mkdir();(p/'visible').write_bytes(b'a');(p/'hidden').mkdir();(p/'hidden'/'secret').write_bytes(b'b')
 original=os.scandir
 def scan(path):
  if os.fspath(path)==os.fspath(p/'hidden'):raise PermissionError('fixture inaccessible subtree')
  return original(path)
 def source():
  with patch('os.scandir',scan):return {'returned_paths':sorted(load_directory(p)), 'expected_file_count':2}
 record('R001_PARTIAL_SCAN',source)
 q=pathlib.Path(td)/'idx';q.mkdir();(q/'evidence').write_bytes(b'not a directory')
 record('R002_INDEX_LAYOUT',lambda:LocalIndex(q).discover(semantic_name='fixture'))
record('R004_RESERVED_MANIFEST',lambda:validate_manifest(build_manifest({'.dkn/manifest.json':b'x'})))
with tempfile.TemporaryDirectory() as td:
 idx=LocalIndex(td);roots=[]
 # Real acyclic content-addressed leaves; each carries 128 unresolved claims.
 for j in range(33):
  rel=[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':f'{j*128+k+1:064x}','scope':'review-fixture'} for k in range(128)]
  raw,m=pack({'leaf':str(j).encode()},[relation_commitment(rel)]);idx.add(raw,relations=rel);roots.append(m['logical_root'])
 rel=[{'schema':'dkn.relations.v0.2-candidate','relation_type':'depends_on','destination':r,'scope':'review-fixture'} for r in roots]
 raw,m=pack({},[relation_commitment(rel)]);idx.add(raw,relations=rel)
 report=idx.traverse(m['logical_root'],max_depth=2,max_nodes=64)
 record('R003_TRAVERSAL_REPORT',lambda:{'edges':len(report['edges']),'canonical_bytes':len(canonical(report))})
 results.append({'id':'R003_TRAVERSAL_DETAILS','edges':len(report['edges']),'unresolved':len(report['unresolved']),'truncated':report['truncated'],'node_count':len(report['nodes'])})
print(json.dumps(results,indent=2,sort_keys=True))
