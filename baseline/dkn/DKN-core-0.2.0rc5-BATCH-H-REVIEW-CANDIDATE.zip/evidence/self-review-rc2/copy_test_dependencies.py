"""Offline test-environment repair using exact genuine installed distribution files."""
import importlib.metadata as m,hashlib,json,shutil
from pathlib import Path
E=Path('/mnt/data/dkn_review_evidence');target=Path('/mnt/data/dkn_rc2_install_env/lib/python3.13/site-packages')
rows=[]
for name in ['cryptography','jsonschema','attrs','jsonschema-specifications','referencing','rpds-py','typing_extensions','cffi','pycparser']:
 d=m.distribution(name);files=[]
 for f in d.files or []:
  p=Path(str(f))
  if p.is_absolute() or '..' in p.parts or '__pycache__' in p.parts or p.suffix=='.pyc':continue
  src=Path(d.locate_file(f))
  if not src.is_file():continue
  dst=target/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  before=hashlib.sha256(src.read_bytes()).hexdigest();assert before==hashlib.sha256(dst.read_bytes()).hexdigest()
  files.append({'path':str(f),'sha256':before})
 rows.append({'distribution':name,'version':d.version,'origin':str(d.locate_file('')),'copied_file_count':len(files),'files':files})
r={'schema':'dkn.install-dependency-custody.v0.2-rc2','status':'PASS_EXACT_LOCAL_COPY',
 'reason':'Nested venv system-site-packages did not inherit the active /opt/pyvenv packages; jsonschema missing at first smoke.',
 'source':'GENUINE_PREINSTALLED_HOST_DISTRIBUTIONS','dependency_downloads':'NOT_PERFORMED',
 'fresh_resolution':'NOT_ESTABLISHED','distributions':rows}
(E/'INSTALL-DEPENDENCIES.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
(E/'INSTALL-FIRST-ATTEMPT.json').write_text(json.dumps({'status':'FAILED_ENVIRONMENT','error':"ModuleNotFoundError: No module named 'jsonschema'",'context':'Nested venv --system-site-packages, isolated -I installed-wheel smoke','repair':'Exact copies of genuine preinstalled distributions; no mocked dependencies.'},indent=2)+'\n')
