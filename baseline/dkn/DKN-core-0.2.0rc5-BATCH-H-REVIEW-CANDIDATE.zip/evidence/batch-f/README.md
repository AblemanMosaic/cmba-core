# Batch F local engineering evidence

`final/LOCAL-RUN.json` is the completed current-source assembled test/example report.
`base-model-check.json`, `lifecycle-model-check.json` and `acceptance-audit.json` bind/check
that report. Baseline, initial failures, intermediate runs, dependency attempts and an
interrupted combined runner are retained as historical construction evidence, not substituted
for final results. The timeout happened after the completed test stage; examples and assembly
were rerun against the identical source fingerprint. Installed-wheel evidence uses exact
copied genuine host dependencies. Fresh network dependency resolution remains unestablished.

All records are unsigned same-author engineering evidence. Fresh extraction of the FINAL
ZIP is replayed outside this tree and reported separately, avoiding a self-hash cycle.
