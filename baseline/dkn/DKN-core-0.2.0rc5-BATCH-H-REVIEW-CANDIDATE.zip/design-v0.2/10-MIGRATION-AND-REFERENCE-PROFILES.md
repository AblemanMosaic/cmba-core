# Migration and reference deployment models

## Backward compatibility
Retain original `src/dkn_core`, `docs`, schemas, tests and vectors unmodified in Batch A. A v0.1 namespace identity includes epoch and cannot be rewritten as a stable root. A new genesis root, if implemented, is a distinct object bound to an exact legacy instance through evidence; it does not rename that instance. Legacy THR hashes remain SHA-256 domain-separated. MosaicID formula unchanged. Neither public v0.2 text nor an adapter upgrades old certificates.

## Interop preservation
A migration table records legacy schema/ID and proposed successor schema/ID, precise computation, signer evidence and explicit external adoption decision. Old clients reject unsupported new versions rather than guess. New clients must treat old facts under original semantics and mark new unsupported properties NOT_CHECKED. Signed upgrade statement authenticates authorship; does not confer permission.

## Example deployment profiles, not automatic guarantees
1. Personal local vault: content commitments, local key custody, offline snapshot verification; loss/recovery and external freshness unspecified.
2. Enterprise managed: PKI and signed release heads with audited access; administrator/witness independence unresolved without proof.
3. Public Git/HTTP mirror: external transport addresses plus exact digest; availability/revocation not asserted.
4. Content-addressed P2P: retrieval by logical content ID with independent peers possible; continuous pinning not implied.
5. CCP federation: external membership/constitutional recognition, quorum conditions and separate witness protocols; consensus safety not implied by signatures.
6. Hybrid: multiple backend observations, common-fault analysis and scoped commitments; no scalar aggregate security score.

## Reference developer journeys
Local developer: pack → detached certify → inspect offline → publish explicitly to a store → independent verify. Institution: declare governance model → attest controlled release head → third-party retrieval/witness → scoped policy acceptance. Reader: pin namespace root → discover candidates → verify signed lineage/relations → choose recognized head by external policy → retrieve bytes → verify closure and transport.
