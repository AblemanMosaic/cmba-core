# Batch D — Substrate assurance and federation evidence

**Status:** EXPERIMENTAL IMPLEMENTATION CANDIDATE. **Authority effect:** NONE.
**Input:** the exact Batch C archive, SHA-256
`971f86103c14ce2f4d934b1309aae9e3947e75145593eb1e95a082b495bfc613`.

## What this batch delivers

Batch D extends the existing repository rather than replacing its kernel. The original
`src/dkn_core`, the Batch B `dkn_v02.core`, and Batch C navigation implementation remain
unchanged. New modules are imported explicitly; ordinary `import dkn_v02` does not load
SAM or its JSON Schema validator. Public package metadata remains v0.1.0; every new
wire object is explicitly a v0.2 candidate.

| Component | Implementation | Scope |
|---|---|---|
| Signed substrate/evidence records | `assurance.seal`, `verify_record` | Ed25519 signatures and typed, domain-separated commitments |
| Assurance contracts | `assurance.evaluate` | Bounded evidence requirements under explicit caller policy |
| Composition | `assurance.compose` | Transitive declared dependencies, shared control, incompatible assumptions, metadata exposure |
| Six reference models | `reference_profiles.reference_profile` | Templates, never automatically accepted deployment evidence |
| Federation observations | `federation.assess_checkpoints` | Caller-pinned members, threshold, epoch, age, rollback floor, observed conflicts |
| CHC/CCP handoff | `federation.make_handoff` | Evidence export with external admission still required |
| Storage | `storage.MemoryStore`, `DirectoryStore`, `retrieve` | Explicit local publication, verified retrieval, bounded fallback |
| Navigation join | `assured_navigation.inspect_with_assurance` | Rechecks artifact plus exact assurance scope |
| Read-only ABI/CLI | `sam_abi.dispatch`, `python -m dkn_v02.sam_cli` | Closed operations; no dynamic execution, ambient trust, or network access |
| Language-neutral material | `schemas/v02`, `profiles/v02`, `vectors/v02-sam-vectors.json` | Nine executable input schemas, six templates, deterministic signed fixtures |

## The central ceiling

`SATISFIES` means **the specified evidence obligations were satisfied by the supplied
records, at the supplied time, under the supplied policy**. It never means the evaluator
has established an operator's real-world security promise. Every assessment carries
`conclusion_scope=SUPPLIED_EVIDENCE_OBLIGATIONS_UNDER_CALLER_POLICY` and
`operational_guarantee=NOT_ESTABLISHED_BY_THIS_EVALUATOR`.

This is deliberately weaker than a general assurance theorem prover. A signature from
an approved observer can satisfy an attestation requirement; it cannot turn an untested
replication claim into demonstrated availability. Independent measurement, logs, and
protocol-specific proof checkers remain distinct integrations.

## What is not delivered

No live IPFS/P2P, HTTP, Git, corporate identity, or distributed federation service is
implemented or contacted by the runtime. The enterprise, P2P, and CCP artifacts model
those environments; they are not operational deployments. No consensus engine, log
inclusion/consistency proof checker, retention SLA verifier, automated revocation client,
key custody service, or ratification engine is included. Local storage is single-writer
and is not certified crash-safe or hostile-local-writer-safe.

No independent implementation or independent review occurred. A clean extraction rerun
in the same Linux environment is repeatability evidence, not independence or Windows
validation. The original r002 test suite remains blocked by the absent `blake3` package;
an installation attempt failed and its log is retained.

## Repository continuity

Inherited r002 manifest and self-certificate files are historical snapshots, NOT a
certificate over the upgraded repository. Batch D uses `BATCH-D-FILE-MANIFEST.json` for
its own closed file inventory and an external SHA-256 for the final ZIP. See
`META/V02-CANDIDATE-BOUNDARY.json`. Do not use the r002 `tools/verify_release.py` to claim
v0.2 certification: that historical tool embeds Windows-specific environment labels.
The new `tools/verify_v02_candidate.py` records the actual host.

## Reading order

Start with 15 for the wire/evaluation rules; 16 for the six security models; 17 for
checkpoint and governance boundaries; 18 for runnable developer workflows; 19 for
threats and tests; 20 for the consolidated Batch E worklist. Exact local evidence is in
`evidence/batch-d/`, and cumulative implementation status is in `BATCH-D-STATUS.json`.
