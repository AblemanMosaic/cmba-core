# Batch C: Offline verified navigation and discovery — implementation candidate

## Scope and authority

This implementation is **not** an authoritative registry, globally complete index, online freshness oracle, P2P resolver, independent witness, or policy admission engine. Every result declares `authority_effect: NONE`. Discovery identifies locally present candidates. Exact resolution verifies the stored archive, its canonical manifest, transport hash, and any supplied certificate/relations/namespace evidence *on each read*.

## Operations and API

`dkn_v02.navigation.inspect(raw, certificate=None, relations=None, genesis=None, transitions=None)` returns typed statuses for transport/content integrity, signature, bound relation values, relation attestation, genesis signature, namespace authorization against supplied lineage, and expressly unproven freshness/completeness.

`LocalIndex(path).add(raw, certificate=..., relations=..., genesis=..., transitions=...)` stores the deterministic archive bytes under `objects/<logical_root>.zip` and a canonical evidence envelope under `evidence/<logical_root>.json`. This is a **single-writer demonstration store**, not a transactional or concurrency-safe vault. Existing roots refuse overwrite. The index does not implicitly download anything.

`resolve_exact(root)` finds one local candidate and re-verifies evidence. `discover(semantic_name=..., namespace_root=..., signer_public_key_hex=..., limit=...)` scans the local store and returns verified matching candidates. A result with `local_scan_complete=true` refers solely to this bounded local evidence directory, not the world or a remote network. Discovery performs a full local scan before returning `matched_locally`, even when output is truncated. `traverse(root, direction='outgoing'|'incoming', max_depth=3, max_nodes=128)` follows declared relationship edges. Incoming edges rely on a bounded scan over local evidence, never a global completeness claim. `compare_namespace(root)` identifies locally known release candidates for the same namespace; multiple candidates are *not* necessarily a fork.

CLI: `PYTHONPATH=src python -m dkn_v02.nav_cli inspect ARCHIVE [--certificate CERT] [--relations JSON] [--genesis GENESIS] [--transitions JSON]`; `index VAULT ARCHIVE [options]`; `resolve VAULT LOGICAL_ROOT`; `discover VAULT --name NAME [--limit N]`; `traverse VAULT LOGICAL_ROOT [--direction incoming|outgoing --depth N --nodes N]`; `compare VAULT NAMESPACE_ROOT`.

## Relationship evidence profile

Accepted relation records (canonicalized as a sorted list before commitment):

```json
{"schema":"dkn.relations.v0.2-candidate","relation_type":"depends_on","destination":"<64 lowercase hex logical artifact root>","scope":"declared dependency"}
```

The source is the artifact whose manifest commits to the relation set. The relation dimension is `dimension_id=relations`, `schema_id=dkn.relations.v0.2-candidate`, produced by `relation_commitment(relations)`. The verifier checks the canonical committed value against the manifest. If a valid detached publisher certificate is supplied, the claim is authenticated as a *publisher assertion*. It is not proof of actual dependency, legal authority, consent of the destination, or completeness. Unknown relation types, duplicate edges, unbound relation values, or changed values fail closed.

## Namespace recognition

A verified genesis identifies a *claimed semantic name*. Namespace authorization reaches `PASS_FOR_SUPPLIED_CHAIN_ONLY` only when the provided certificate binds the same namespace root and its signer is the founder or verified active successor in the provided transition chain. This does not establish ownership of a human-readable name, completeness of the transition history, legacy r002 namespace derivation, contemporaneous signing authority, global freshness, or absence of undiscovered branches. Since certificates have no signed epoch/time designation, a supplied chain can test key correspondence but **cannot prove the key was authorized at the time of historical signing**. Do not treat this field as temporal authorization.

## Security and operational limits

- Input archive canonicality is enforced by inherited v0.2 `verify_archive`; detached certificate and namespace chain are inherited cryptographic checks.
- 4096 local metadata entries, 128 edges per supplied relation set, 8 traversal hops, 256 returned/mapped nodes, 4 MiB metadata size limit, 300 MiB archive read limit, finite query output limits.
- Existing index object overwrites refused. On local disk the paired files are not atomic together; if interrupted, a verifier will refuse corrupted/incomplete entries. No concurrent-writer guarantee and no filesystem adversary boundary.
- All local index entries are reverified rather than trusted, and corrupt/missing entries cause typed refusals, **not silent skipping**.
- No wall-clock or network work; no cursor, distributed ordering, proof of absent artifacts, storage availability, global head or online retrieval.
- Index symlink entries and requested object/evidence symlinks are refused. This prototype is not hardened against concurrent replacement or malicious modification of parent directories. Use a trusted dedicated local path; later storage hardening must include descriptor-safe opens, ownership/mode checks, and atomic journaling.

## Batch D handoff

Define substrate assurance descriptors and evidence contracts for local, enterprise, HTTP/Git, P2P, and federated environments. Bind claim scope to deployment threat models, demonstrate missing/contradictory evidence, and *do not* upgrade local discovery to a freshness or authority guarantee. Add a transactional storage adapter and externally witnessed snapshot proofs separately.
