# Namespace declaration, lineage and near-unsquattable identity

## Three concepts
- **Root/genesis:** a stable cryptographic anchor established by a unique signed genesis commitment (does not assert exclusive human-name ownership).
- **Instance:** a time/key/purpose/epoch-scoped operation identity. Existing `dkn:v0.1:b3:...` namespace is precisely an instance; preserve it.
- **Head:** a signed assertion of currently preferred or successor instance and state at a given scoped checkpoint, not a universal fact.

## Threat boundary
Cryptographic impersonation of a fixed identity should fail without key or break of algorithms. Human-readable names remain adversarially duplicable, visually confusable and index-rankable. Resolver MUST show claimant, root fingerprint, name-match type, provenance and recognition policy when present. Name-only resolution returns candidates, never one blessed identity without an explicit selector.

## Suggested lineage events
Genesis, transition, key rotation, controlled delegation, revocation, supersession, recovery, witness checkpoint, fork indication. Each binds the exact predecessor, intended successor(s), epoch, signers, witness context and scope; no mutation of predecessor evidence. Forks must remain visible. Replay protection may require stateful consumers or witnessed monotonic checkpoints: signatures alone do not establish exclusivity or latest state.

## Recovery
Lost or compromised founder keys may require precommitted recovery keys, quorum authorization or external dispute mechanisms. No universal recovery authority is imposed. If no validated recovery path exists, continuity is NOT_ESTABLISHED; do not manufacture succession from matching semantic name.

## Selection policies
`PINNED_ROOT`, `PINNED_INSTANCE`, `POLICY_RECOGNIZED_ROOT`, `CHECKPOINT_SCOPED_HEAD` are candidate external selectors; they must identify which policy decided. Monotonicity/equivocation claims must name signed log or consensus protocol, witness assumptions and checkpoints.
