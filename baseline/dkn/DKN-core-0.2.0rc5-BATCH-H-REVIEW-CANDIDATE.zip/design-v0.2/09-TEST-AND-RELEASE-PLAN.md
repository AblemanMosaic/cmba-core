# Verification, implementation sequence and release gates

## Batch gates
**A SPECIFIED:** Audit existing source; freeze inherited hash identities; design draft schemas, invariants, threat assumptions, test matrix. No new runtime capabilities claimed.
**B IMPLEMENTED:** Canonical dimensions, logical artifact inventory, detached certificate and namespace root/epoch candidate, noninterference with v0.1. Verify golden vectors, mutation tests, memory/time bounds.
**C IMPLEMENTED:** Offline inspect, exact resolution, typed graph traversal, discovery index, forks and scoped completeness; malicious index and partial retrieval tests.
**D IMPLEMENTED:** Substrate descriptors, contract evaluator, composition and side-effect adapters; threat-model and fault-domain tests, CHC/CCP neutral interfaces. Do not claim deployment guarantees from simulation.
**E TESTED / CANDIDATE:** Repeat deterministic release, independent runner(s), Python/Rust parity if actually built, network simulation and real environment claims clearly segregated; archive receipts, changelog, migration, external review package. Only a separate authorization can ratify public v0.2.

## Evidence tiers
`DESIGNED`, `IMPLEMENTED`, `UNIT_TESTED`, `INTEGRATION_TESTED`, `INDEPENDENTLY_REVIEWED`, `DEPLOYMENT_OBSERVED`, `RATIFIED`. No promotion based on plan text or synthetic evidence. Separate results for Windows/WSL/Linux/macOS; where unavailable NOT_RUN.

## Stop conditions
Unexpected change in legacy source/test/vector bytes; v0.1 vector divergence; unversioned semantics; authority effect beyond NONE; index claim of global completeness; freshness without checkpoint; contradictory assurance conclusion; publishing without explicit grant; plaintext secret in public release; unbounded network traversal. Fail closed and document root cause.

## Release attachments
Source archive, manifest/inventory and SHA-256, per-commit test evidence, golden/negative vectors, environment and dependencies, unresolved defects, audit deltas, protocol draft and case matrix, exact release claim ceiling, independent reviewer instructions. No authority or A5 effect.
