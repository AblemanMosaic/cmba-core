# Batch D threat model and acceptance dossier

## Trust boundaries

Untrusted: descriptors, evidence, checkpoint records, discovery/locator metadata,
provider-returned bytes, claimed fault domains, and the mutable local index.
Explicit caller inputs: recognized keys/roles, membership, fault-domain labels, accepted
premises, fixed evaluation time, artifact root, selected stores, and rollback floor.
Trusted implementation assumptions: correct verifier execution, cryptographic primitives,
and adequate local resources. A compromised verifier can falsify its own report.

A compromised recognized observer can lie. The library verifies what was signed, not
whether the world matched it. A compromised reader policy can recognize hostile keys.
No decentralization label can repair that policy by itself.

## Acceptance coverage mapped to the original Batch A SAM cases

| ID | Original requirement | Direct Batch D evidence |
|---|---|---|
| A-SAM-01 | No profile-implied assurance | `test_profiles_never_establish_assurance` (all six templates) |
| A-SAM-02 | Fault-domain overlap | `test_common_administrator_not_independent`, `test_transitive_shared_dependency` |
| A-SAM-03 | Quorum without protocol | `test_quorum_is_not_consensus`, `test_unsupported_guarantees_refuse` |
| A-SAM-04 | Expiry | `test_time_boundaries`, `test_descriptor_expiry`, `test_expired_checkpoint` |
| A-SAM-05 | Replica-count claim | `test_declared_replica_count_is_not_observed` |
| A-SAM-06 | CHC stale evidence | `test_maximum_age`, `test_high_water_mark_rejects_rollback`, `test_handoffs_no_authority` |
| A-SAM-07 | CCP admission boundary | `test_handoffs_no_authority`, `test_precomputed_assessment_not_accepted` |
| A-SAM-08 | Metadata confidentiality | `test_public_metadata_flagged`, `test_dependency_public_metadata_leak` |
| A-SAM-09 | Contradictory evidence | `test_refutation_dominates_positive`, `test_conflicting_heads_no_majority_override` |
| A-SAM-10 | Composition incompatibility | `test_mutually_exclusive_assumptions`, `test_conflicting_contract_and_descriptor_assumptions` |

Additional tests cover tampered hashes/signatures, wrong namespace/descriptor/artifact
scope, unknown keys and predicates, duplicate signers, missing domains, explicit method
filters, accepted assumptions not becoming proofs, malformed canonical JSON, boolean
numeric confusion, excessive collections, deterministic permutation handling, poisoned
storage fallback, no global absence inference, symlinks/hardlinks/nonregular files,
local idempotent publication, unchanged logical roots across backends, ABI refusal,
fixture-vector replay, source-package closure, and serialization repeatability.

These are executable examples, not exhaustive adversarial coverage or formal proofs.
Parametrized cases are counted as separate pytest cases, and exact test IDs and outcomes
are retained in `evidence/batch-d/LOCAL-RUN.json` and the XML report. Earlier B/C tests
are rerun unchanged. Legacy v0.1 runtime testing is separately blocked, not counted as
passing. Every reported platform claim is specific to the actual runner.

## Findings and repairs during construction

**D-F001 — Reader bounds accidentally part of signed membership identity.** Initial
checkpoint code bound the entire policy, so advancing a local high-water mark or
changing maximum age invalidated otherwise legitimate historical signatures. Fixed by
separating `checkpoint-membership` and complete `checkpoint-policy` commitments. Two
regressions confirm floors/age can change without re-signing observations, while
membership/threshold substitution still cannot reuse them. No intermediate candidate
was released as a completed Batch D.

**D-F002 — Historical release metadata could be misread as current.** The inherited
r002 manifest and self-certificate remain in the cumulative source tree, but do not
cover new files or modified top-level guides. Added a v0.2 candidate boundary, an
independent closed file inventory, and explicit README/documentation warnings. Retained
historical bytes rather than minting misleading replacement v0.1 certificates.

**D-F003 — Historical verifier hardcodes Windows host labels.**
`tools/verify_release.py` contains a Windows-native result block. It is preserved as
legacy source, not executed to assess the new candidate. The new v0.2 runner records
actual `platform` and Python information and separates blocked legacy tests. This is
an explicit containment, not a claim that the historical tool was repaired.

**D-F004 — Legacy dependency unavailable.** `blake3` is not installed. A bounded pip
attempt returned no matching distribution in this environment. No fallback hash or
substitute cryptographic primitive was used. The legacy gate remains open.

## Open engineering limitations

- Caller-supplied clocks and policy storage are not authenticated by this library.
- Observer independence is caller-declared, not physically or institutionally proven.
- `basis_ref` is a commitment, not an executed proof or fetched test report.
- No network, retention, durability, confidentiality, consensus, or revocation protocol
  has received operational validation here.
- Local path checks are not race-free under hostile concurrent directory mutation.
- No multiwriter/crash/recovery vault protocol, persisted antirollback state, or protected
  signer custody is implemented.
- Real Windows/WSL/macOS, a second implementation, clean full dependency installation,
  and independent review remain pending.
- Batch B/C limitations remain inherited. No independent audit of their entire protocol
  was substituted by the new passing tests.

## Test execution and publication boundaries

All new attack cases use synthetic local fixtures and temporary storage. No production
keys, institutional memberships, peers, or public network targets are tested. `make_handoff`
creates local evidence data only. It does not invoke CHC/CCP, a Courthouse, or a custodian.
Dependency installation and primary-source documentation lookup were construction
activities, not runtime publication. No external artifact publication occurred.
