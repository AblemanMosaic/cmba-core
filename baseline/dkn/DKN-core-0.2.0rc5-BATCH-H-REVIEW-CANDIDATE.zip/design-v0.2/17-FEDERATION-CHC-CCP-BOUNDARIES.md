# Federation observations and CHC/CCP interfaces

## Purpose

The federation component is an offline witness-set evaluator. It checks supplied signed
head observations against explicitly pinned membership. It is NOT a distributed ledger,
leader election algorithm, Byzantine agreement protocol, constitutional membership
ceremony, or network service.

A member statement commits to a substrate descriptor, namespace root, epoch, sequence,
head root, observation time, expiry, and membership-policy reference. It says that the
signer attests this head observation. It does not prove that no other head exists.

## Two policy references: stable membership versus changing reader bounds

`checkpoint_policy_ref(policy)` hashes the checkpoint policy **excluding**
`minimum_sequence` and `max_age_seconds`, under domain label `checkpoint-membership`.
The signed record's `body.policy_ref` uses this reference. The membership-bound fields
include policy ID, protocol, namespace/substrate scope, epoch, members, threshold,
independence dimensions, and policy validity interval.

`assess_checkpoints` separately hashes the *entire* supplied policy under
`checkpoint-policy` in the output `policy_ref`. The output also includes
`membership_policy_ref`.

This separation is essential: advancing a local rollback floor or tightening a reader's
maximum age must not require historical observations to be signed again. Changing
membership, scope, epoch, threshold, or the signed policy interval does change the
membership reference and requires appropriately bound evidence. Batch D does not
implement a membership-transition or authorization ceremony.

## Evaluation sequence

Validate every envelope and signature first. Unrecognized member keys and mismatched
policy/scope records are excluded and cannot veto. Retain compatible signed statements
for observed-conflict reporting. Then filter usable observations by minimum sequence,
validity interval, and maximum age at the fixed reader time.

Only the highest eligible sequence is considered for a current bounded observation.
If that sequence lacks a threshold, do not silently fall back to a lower sequence with
more signatures. Count unique signers and apply caller-declared fault-domain separation.
An unavailable/partitioned member supplies no observation; its absence is not a vote.

Different declared heads at the same sequence are reported as conflicts. A threshold
supporting one head does not hide another compatible member's conflicting assertion.
A change of head at a higher sequence is not itself a fork. Historic conflicting signed
assertions are not erased by their expiry, although expired observations do not count
as current evidence. This is conservative conflict visibility, not proof of which actor
or branch should be recognized.

## Output interpretation

A qualifying witness set yields `status=CONDITIONAL`, `quorum=OBSERVED`, and
`freshness=BOUNDED_OBSERVATION_ONLY`. Global currentness, consensus safety, and revocation
status remain unestablished/not checked. Missing evidence yields `INSUFFICIENT`.
Conflicts yield `CONTRADICTED`. Invalid signatures/schema produce typed refusal.

Caller policy labels are the only basis for independence checks. Even matching the
threshold does not establish that declared institutions are truly independent, that
clocks are honest, or that the supplied evidence set is complete.

## CHC and CCP handoffs

```python
from dkn_v02.federation import make_handoff
handoff = make_handoff(checkpoints, policy, at_time=now, consumer='CHC')
```

`consumer` is exactly `CHC` or `CCP`. The function recomputes the checkpoint assessment;
it does not accept a caller-supplied `PASS` report. Each handoff contains:

```text
admission = EXTERNAL_DECISION_REQUIRED
execution_authorized = false
recognition = NOT_EVALUATED
authority_effect = NONE
standing = INFORMATION_ONLY
real_a5 = false
g0 = CLOSED
```

CHC must supply its own admissibility, freshness, revocation, and failure policy. CCP
must supply its own constitutional recognition and decision policy. These are integration
envelopes only: no existing CHC or CCP service was invoked or independently tested.

## Persistent high-water state

Batch D takes `minimum_sequence` as input; it does not persist or protect that value.
A consumer needing rollback resistance across restarts must maintain trustworthy,
namespace/epoch-scoped state and specify recovery/reset rules. Copying a sequence from
untrusted discovery into that state is not a valid substitute for an acceptance policy.
New epochs require a separate authorized transition policy; no counter reset is inferred.

## Future proof plugins

A future proof checker must name its exact protocol, input commitment, membership and
fault assumptions, safety/liveness property, freshness interval, and evidence format.
Unknown rule IDs are currently refused. Multiple signatures do not activate a generic
consensus verifier, and a descriptor's `mechanisms` list cannot install code.
