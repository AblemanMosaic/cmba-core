# Batch B implementation and limits (2026-11-07)

## Scope
A new separate `src/dkn_v02` Python package implements the **experimental, not ratified** v0.2 SHA-256 / Ed25519 profile. The `src/dkn_core`, `tests`, `vectors` and all other inherited r002 content is unchanged. No v0.1 hash domain or identifier is reinterpreted. This is a sibling package inside the original repository, not a replacement for the original `dkn_core` API.

## Implemented calls
- `canonical`, `read_canonical`: bounded DKN-CJSON-like canonical JSON (same structural rules for supported types; independently versioned usage).
- `commit`, `verify_dimension`: SHA-256, exact typed dimension commitment; 'committed' does NOT mean 'semantically verified'. Unknown critical schemas refuse when a supported schema set is passed.
- `build_manifest`, `verify_manifest`, `load_directory`: regular files only, NFC POSIX-style relative paths, casefold collision refusal, symlink refusal, exact inventory SHA-256 and length, file-size and count caps. Directory timestamps, empty dirs, execute permission, ownership, alternate data streams and extended attributes are NOT preserved by this profile. Do not use it as a general-purpose faithful filesystem backup or package for executable mode preservation.
- `pack`, `verify_archive`: deterministic ZIP_STORED, fixed timestamp/permission, embedded canonical logical manifest and independent exact transport hash. Reject non-canonical zip repackaging, duplicate members, and payload substitution. Output file is local-only. No network publication.
- `certify`, `verify_certificate`: detached Ed25519 signature over logical root, declared namespace root, publisher key and exact claim. Signing is statement attestation ONLY, NOT publisher authorization or namespace admission. Public key authorization to operate namespace must be established separately.
- `declare_genesis`, `verify_genesis`: stable candidate genesis root, signed by founder, semantic human-readable name is not exclusive.
- `transition`, `verify_transitions`: minimal linear signed key-transition chain, epoch 1..N. No delegation, recovery, competing-branch discovery, revocation or global head. Those belong to later scope.
- `python -m dkn_v02 pack SOURCE OUT`, `verify ARCHIVE`, and `verify-certificate CERT MANIFEST` provide bounded local CLI paths.

## Important refusal/claim ceilings
- **Unverified legacy-instance binding:** The v0.2 genesis body includes a legacy namespace ID as a *signed reference* but its correspondence to the public key / semantic name / epoch via the BLAKE3 v0.1 derivation is NOT independently verified by `verify_genesis`. Until a separate v0.1 verifier is attached, report `legacy_instance_binding=NOT_CHECKED`; no migration authority follows.
- **Freshness:** no global-current, unique successor or non-equivocation claim. The deterministic chain verifier establishes only that a supplied, fully known sequence is internally consistent; missing or withheld sibling branches are not detectable without witnesses/indexes.
- **Filesystem TOCTOU:** `load_directory` checks size and symlinks, but malicious concurrent mutation requires a stronger OS-specific snapshot/handle custody scheme. Local packaging is NOT claimed secure against a hostile concurrent writer.
- **No key ceremony or durable secret store** in new API. The caller supplies an in-memory Ed25519 private key; a production integration must provide protected key management and explicit side-effect authorization.
- **Cross-language / cross-platform parity:** NOT_ESTABLISHED. Python tests run under Linux in this session; r002 regression tests are BLOCKED due to missing `blake3`, not reported as PASS.
- **Draft schemas in Batch A** remain proposal sketches and are not yet exact implementation-conformance JSON Schemas. Batch B exact shapes and octets are described by code and generated fixtures. Ratification will require synchronized normative schema updates and independent vectors.
- **No UCM/CHC/CCP authority effects** are implemented; `NONE` throughout.

## Developer mini-example
```python
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from dkn_v02 import commit, pack, certify, verify_archive, verify_certificate
key = Ed25519PrivateKey.generate()
d = commit('semantics', 'example.description', {'purpose':'demo'})
archive, manifest = pack({'README.md':b'DKN demo\n'}, [d])
certificate = certify(manifest, key)
assert verify_archive(archive)['status']=='PASS'
assert verify_certificate(certificate,manifest)['signature']=='PASS'
```

## Batch C integration handoff
Build an independent navigation index over these exact logical roots, expose discover/resolve/inspect/traverse with scoped completeness and explicit conflicts; preserve the distinction between a candidate discovered from an index and a commitment verified against locally obtained bytes. Before public deployment, address the unverified v0.1 anchor, unknown critical dimension policy, richer metadata profiles, namespace fork resolution, and signer authorization to namespaces.
