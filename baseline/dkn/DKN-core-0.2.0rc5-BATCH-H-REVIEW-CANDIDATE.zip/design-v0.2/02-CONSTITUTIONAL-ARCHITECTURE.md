# DKN constitutional architecture

## Mission
A reusable, application-neutral protocol for authenticated identity, deterministic artifacts, multidimensional commitments, verifiable relations, substrate descriptions and conditional assurance evidence. It neither grants trust nor dictates a global naming registry.

## Layering
1. `dkn.core` (offline): canonical serialization, key subjects, typed domains, content inventory, cryptographic verification, typed evidentiary results.
2. `dkn.navigation` (offline index with optional resolvers): manifests, typed outgoing edges, candidate discovery, provenance, bounded traversal and result evidence.
3. `dkn.substrates` (offline assessments): descriptions, threat assumptions, evidence obligations, contracts, conflict/fault domain composition.
4. `dkn.adapters` (side-effectful): filesystem, HTTP, Git, optional P2P, enterprise and witness transports; never autonomously authorized by parse/verify.
5. External consumers: CHC freshness/admissibility policies, CCP recognition/custody/federation, UCM, Courts, arbitrary applications.

## Invariants / design obligations
**INV-01** Existing v0.1 namespace / identity / THR hashes and certificates retain exact meaning and bytes.
**INV-02** Unknown version, codec, hash, signature, critical extension or relation semantics yield typed refusal, never an inferred fallback.
**INV-03** Every object commitment binds schema ID, canonical byte form, algorithm and domain; identical input across different domains must not alias.
**INV-04** Logical artifact digest binds a complete normalized entry inventory; archive-container byte digest is separately computed.
**INV-05** Signed witness or publisher testimony asserts only its precise scope; acceptance and operational authority remain external.
**INV-06** No trust is gained by traversal: edges preserve claimant, proof, query scope and provenance; no unsigned claim silently becomes authenticated.
**INV-07** Index search, name matching and inbound discovery never imply exhaustiveness without a specified snapshot/coverage proof.
**INV-08** Freshness is relative to source, checkpoint, observation interval and policy; a disconnected client does not assert global currentness.
**INV-09** Revocation, rotation, delegation and successor selection are separate signed claims and external choice; forks are represented, not hidden.
**INV-10** Substrate guarantees must state assumptions, fault thresholds, evidence and expiry; profile labels alone grant nothing.
**INV-11** Replica/witness independence is an evidence question; overlapping control makes additive availability or Byzantine assumptions invalid.
**INV-12** Verification of read-only material may not install, execute, publish, mutate trust state or fetch secrets.
**INV-13** Bounded reads, recursion, graph fan-out, zip expansion, decompression, time and remote I/O are explicit; no unbounded traversal.
**INV-14** Invalid or incomplete objects do not return partial VERIFIED state; typed outcomes distinguish missing/unsupported/conflicting/failed evidence.
**INV-15** Custody of private keys is separate from public manifests; no plaintext key material in published artifact.
**INV-16** Representation is agnostic about philosophical truth: content claims and empirical assertion correctness remain outside cryptographic integrity.

## Jurisdiction partitions
`CRYPTOGRAPHIC` hash/signature/byte statements; `OBSERVATIONAL` reader/liveness/evidence; `POLICY` local recognizer outcomes; `AUTHORITY` externally conferred rights. No upward automatic promotion. Evidence may inform decisions but cannot itself confer capability.

## Acceptance vocabulary
- Execution state: `PASS`, `FAIL`, `NOT_CHECKED`, `UNSUPPORTED`, `INDETERMINATE`.
- Contract conclusion: `SATISFIES`, `CONDITIONAL`, `INSUFFICIENT`, `CONTRADICTED`, `NOT_EVALUATED`.
- Freshness: `CHECKPOINT_VERIFIED`, `SOURCE_HEAD_VERIFIED`, `UNBOUNDED_UNKNOWN` (do not label global current).
- Capability effect: `NONE` in DKN; any permitted effect belongs to a named external decision record.
All conclusions carry evidence references and bounded evaluation scope, or are `NOT_EVALUATED`.
