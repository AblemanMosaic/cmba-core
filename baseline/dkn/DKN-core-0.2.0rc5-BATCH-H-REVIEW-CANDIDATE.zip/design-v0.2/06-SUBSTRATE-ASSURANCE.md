# Substrate Assurance Model (SAM) — draft

## Entities
`SubstrateDescriptor`: who asserts architecture mechanisms, configuration and provider endpoints; `ThreatModel`: actor capabilities, controlled domains, faults and exclusions; `AssuranceContract`: property, assumptions, validity interval, evidence obligations and decision rule; `EvidenceRecord`: signed/observed/measured artifact, observer, time, scope, method; `Assessment`: deterministic conclusion for exact contract and evidence set. Descriptors are signed declarative statements, not operational truths.

## Dimensions
Integrity, authenticity, availability, durability, freshness, consistency, equivocation-detection, censorship resistance, custody, confidentiality, recovery, jurisdiction. Each can have multiple bounded assertions. Time/coverage matter: verified archival integrity today is not proof of future availability.

## Reference model characteristics (NOT guarantees)
- `LOCAL_VAULT`: local control and possible offline access; single-site destruction and insider/key compromise concerns.
- `ENTERPRISE_DISTRIBUTED`: centralized policy and operator accountability; shared administrator/root/backup failures.
- `PUBLIC_HOSTING`: external accessibility and simple mirroring; takedown, credentials and provider policy risk.
- `P2P_CAS`: multi-path retrieval can exist; pinning, provider discovery, sybil resistance and indefinite storage not inherent.
- `FEDERATED_CCP`: multi-institution recognition possible; membership and independent-fault assumptions need evidence and specific agreement protocol.
- `HYBRID`: compositional potential; shared fault domains, inconsistent heads and metadata leakage must be accounted for.

## Conditional inference rules
Claim SATISFIES only if required evidence, validity windows and explicit assumptions are met under evaluator semantics. CONDITIONALLY SATISFIES is `CONDITIONAL` with named unsupported premises. `INSUFFICIENT` means missing evidence; `CONTRADICTED` means conflicting/negative evidence; `NOT_EVALUATED` is absence of a run. Strong consistency/freshness requires an actual scoped protocol or log proof, not majority signatures alone. Availability numbers require defined stochastic models and failure independence; without evidence do not compute numerically.

## Composition
Describe dependencies across custody, administrators, network transit, identity providers, regions, witnesses and software supply chain. Shared root administrative access collapses apparent multi-party independence. Compose claims only when assumptions are mutually compatible and evidence covers the combination. Never rank all substrates on one score. Clearly report counterexamples and gaps.

## Threat model constraints
Adversaries include publisher impersonator, storage malicious operator, collaborating witnesses, compromised endpoint, malicious index, active network attacker, unavailable network, sybil swarm, coercive censor. External policy recognition cannot be inferred from cryptographic properties.

## CHC/CCP boundary
CHC may consume scoped freshness checkpoints; CCP may consume signed constitutional topology/decision records. Both must issue their own acceptance/admission results. DKN `authority_effect=NONE` irrespective of favorable SAM assessment.
