# Read path and evidence-aware navigation

## Operations
`inspect` parse and verify supplied bytes, offline; `resolve_exact` fetch/verify a specified digest or ID; `discover` obtain untrusted name/metadata candidates; `traverse` follow typed links subject to limits; `compare` assess competing lineage/evidence; `evaluate` apply explicitly passed policy. No hidden network activity inside `inspect`/offline core.

## Edge format and semantics
Typed relation: source object digest, destination identifier, relation type, declaring identity, signed statement reference or proof type, claim scope, optional observed index origin. Candidate relation types: `depends_on`, `derived_from`, `supersedes`, `attests`, `governed_by`, `published_at`, `witnesses`; enum extensibility requires version/criticality. The claim that an object lists an edge can be verified separately from the truth of the relation. Every traversal result carries per-edge evidence state.

## Incoming vs outgoing
Outgoing relation directly anchored in the signed source (where signed). Incoming edge discovered through indexes is a candidate until its source and signature verify. An index's absence of results never proves nonexistence. Complete-snapshot claims require explicit bounded domain, root, index coverage model, checkpoint and proof; do not say globally exhaustive.

## Query result
Query echo; normalized selector; named source(s) with retrieval observations; verifications for each hit; applied limits; unresolved references; version/algorithm support; exact snapshot or observation time; fork candidates; any omitted edges and why. Malicious result order, alias injection and misleading names must not turn discovery results into identity proof.

## Boundedness
Maximum depth, result count, nodes, fetched bytes, walltime and retrieval hops configurable and default finite. Cycles handled by exact identity dedupe, but aliases may be distinct. Resume cursors are tamper-evident or bound to exact snapshot/query; unresolved network failures should report INDETERMINATE, not no-results.
