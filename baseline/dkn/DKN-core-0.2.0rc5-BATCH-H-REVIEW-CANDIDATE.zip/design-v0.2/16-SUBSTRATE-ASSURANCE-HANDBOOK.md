# Security-model handbook: six composable reference profiles

The profile library describes architectural options without ranking them on a single
ladder. Each returned descriptor is marked `deployment_status=TEMPLATE`; even signing
it does not turn it into measured deployment evidence. All mechanism/domain fields
are declarations. A developer must instantiate the actual deployment, bind evidence,
and choose independent reader policy.

## Comparison by control and failure model

| Profile | Declared mechanism examples | Security questions to answer | Evidence still required |
|---|---|---|---|
| Local vault | Local files, content checks | Who can read/write the host? Where are recovery copies? Is key custody separate? | Actual access/custody checks, recovery exercises, off-device copies if required |
| Enterprise distributed | Organizational identity, access control, replicas | Are replicas under one administrator, identity provider, region, provider, or backup root? | Effective control-domain inventory, observation records, recovery/access tests |
| Public hosting | Mirrors, digest verification | Can a provider remove or roll back content? Who controls account recovery? | Retrieval observations, pinned roots, explicit release/head policies |
| P2P CAS | Content addressing, peer discovery, declared pinning | Who retains content? Can peers be eclipsed or sybils? Are bootstrap paths shared? | Retention/retrieval observations and peer-domain evidence, not merely replica counts |
| Federated CCP | Pinned membership, signed observations, external recognition | Who defines membership? Which failures/collusions are excluded? What happens under partition? | Membership decision, per-member observations, a specified protocol before any consensus claim |
| Hybrid | Local copy, alternate retrieval paths, optional witnesses | What shared dependencies remain? Does a public component expose private metadata? | Evidence for each component and their composition, not added-up marketing guarantees |

## Independent assurance dimensions

Integrity concerns committed bytes. Authenticity concerns signatures and attribution.
Availability concerns retrieval under a specified time/failure model. Durability concerns
retention and recovery over an interval. Freshness concerns what can be established
about updates relative to a checkpoint and clock. Consistency and equivocation detection
concern compatible histories and visible conflicts. Censorship resistance concerns
control over publication/retrieval paths. Custody concerns who controls bytes and keys.
Confidentiality includes metadata as well as payload. Recovery concerns restoration
procedures. Jurisdiction concerns whose rules recognize a claim.

A substrate may be strong along one dimension and unestablished along another. Nothing
in the evaluator infers all twelve from one successful signature or content check.

## Worked composition: local + enterprise + P2P

Suppose a local copy and corporate mirror both rely on one account-recovery identity
provider. Their apparent administrative diversity does not remove that common cause.
Declare the shared identity provider as a dependency, and identify its administration
and identity domains. The transitive composition report exposes the overlap.

Adding a public peer may improve the set of possible retrieval paths, but the template
alone does not establish that the peer holds the bytes, will retain them, is independent,
or can be discovered. A successful retrieval supports one observation at one time, not
a perpetual availability promise. A public peer or index may expose publication metadata
regardless of payload encryption; the model reports public metadata explicitly.

The application chooses whether these properties suffice. DKN does not automatically
replace a private root's policy with that of the most numerous or fastest peers.

## Declaration versus evidence versus acceptance

`seal('substrate', ...)` establishes a signed declaration. `seal('evidence', ...)`
establishes a signed statement about a condition. `evaluate(...)` establishes that a
specified record collection meets exact requirements under a caller's policy. These
steps do not audit the actual deployment or delegate authority.

To require measured evidence rather than self-description, exclude `DECLARATION` from
a contract requirement and pin recognized observer keys and predicates. That prevents
syntactically declared evidence from satisfying the wrong method, but an observer can
still lie about its method or result. Independent measurement is a separate trust
obligation. The report states this ceiling even when all requirements are satisfied.

## Boundaries not represented as numeric scores

No replica-count-to-uptime formula, Byzantine safety proof, insurance-like guarantee,
censorship score, cryptographic key-custody proof, or regulatory/compliance certification
is implemented. Administrative labels are not automatically independent institutions.
A mixed deployment requires an explicitly scoped contract; it cannot inherit the union
of every component's optimistic assertions.

## Supplemental primary references

These are external design context, not claims that DKN implements these protocols or
that the user's earlier repository contained them. Consulted 2026-11-07.

1. The Update Framework specification, v1.0.37, sections 5.4–5.6:
   https://theupdateframework.github.io/specification/latest/
   Its client workflow separates role signatures, metadata versions, expiration, and
   snapshot binding. DKN uses distinct reader policies and age/sequence checks but is
   not a TUF client and does not claim TUF compliance.
2. IPFS documentation, Persistence, permanence, and pinning:
   https://docs.ipfs.tech/concepts/persistence/
   Pinning protects content from node garbage collection; content addressing by itself
   does not establish indefinite retention. DKN's P2P profile remains declarative.
3. IPFS documentation, Privacy and encryption:
   https://docs.ipfs.tech/concepts/privacy-and-encryption/
   Public content identifiers and peer visibility are reasons to model metadata exposure
   separately from payload confidentiality. No IPFS encryption or transport is implemented.
4. RFC 9162, Certificate Transparency v2, sections 2.1 and 11:
   https://www.rfc-editor.org/rfc/rfc9162.html
   Inclusion, consistency, and cross-observer comparison are distinct evidence problems.
   DKN Batch D supplies no CT log, CT proof verifier, or gossip protocol.
