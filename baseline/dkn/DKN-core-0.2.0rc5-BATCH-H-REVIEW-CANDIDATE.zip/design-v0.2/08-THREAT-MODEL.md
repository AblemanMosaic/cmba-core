# Extended adversarial threat model

## Attacker capabilities
Duplicate namespace spelling and Unicode homoglyphs; substitute key/passport/manifest; exploit case or symlink behavior; mutate archive bytes; replay valid signed records; fork namespace and selectively reveal branches; censor or withhold checkpoints; inject fake inbound edges into indexes; sybil-fill P2P routing; collude across nominal witnesses; steal or recover key; steal storage credentials; deny service by cycles/huge graph/decompression; assert false uptime/replica counts; exploit inconsistent policy or stale clocks.

## Required controls
Canonical versioned domains and explicit algorithms; exact artifact and transport digests; full inventory closure; secret scan; no implicit symbolic-link follow; signed lineage plus fork visibility; receipts with scope, actor and observed time; bounded traversal and no exhaustive discovery claim; external witness/protocol evidence for freshness; fault-domain mapping; evidence expiration and typed NOT_CHECKED; independent cross-language negative vectors; no publishing or execution in core.

## Residual limitations
Hashes do not guarantee availability, provenance truth, malware-freedom, security of keys, unique human names, global latest state, witness independence or jurisdiction. Any algorithm/key compromise changes the assumptions; claims must identify affected epochs. Public graph index may reveal private relationships even where payload is encrypted; confidentiality threat modeling applies to metadata.

## Safety acceptance
Every adversarial case must specify setup, attack, expected refusal/status, actual observed status, evidence artifact and limitations. Unit-only fixture PASS is not proof of deployment-level resilience. No actual remote penetration tests or external authority changes authorized by Batch A.
