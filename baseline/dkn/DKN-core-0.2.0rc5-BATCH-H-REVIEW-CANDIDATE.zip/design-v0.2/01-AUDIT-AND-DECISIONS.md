# Source audit and compatibility boundary

## Observed in r002 source
- Public protocol `v0.1`, engineering revision `r002`, package `dkn-core` 0.1.0; Python >=3.12; `blake3`, `cryptography`, `jsonschema` dependencies.
- `src/dkn_core/canonical.py`: max JSON input 4 MiB, max depth 32, signed 64-bit integers, duplicate-key/float/BOM restrictions, canonical UTF-8 JSON; these inherited limits are not to be retroactively changed.
- `src/dkn_core/namespace.py`: exact/terminal-wildcard grammar and public-key/purpose/nonce/epoch-bound BLAKE3 namespace identifiers; epoch is inside the v0.1 namespace derivation.
- `src/dkn_core/crypto.py`: Ed25519 key validation, BLAKE3 subject identity and MosaicID compatibility.
- `src/dkn_core/thr.py`: separate SHA-256 state/semantic/governance domain hashes.
- `src/dkn_core/records.py`: signed lifecycle records, publication/retrieval, revocation, epoch statements and storage locators; signatures do not confer rights.
- `src/dkn_core/archive.py`: bounded canonical ZIP with manifest, THR, binding, self-certificate; exact ZIP SHA-256 is external; archive self-certification needs publisher key.
- `src/dkn_core/abi.py`: v0.1 dispatch; no v0.2 graph/substrate implementation detected.
- `tests/`: seven test modules plus helpers, baseline local receipt reports 28 passing units; independent result not established by receipt.

## Evidence and scope
Source ZIP SHA-256: `3b3355b2db7bc9d7be1dae1968832819aa8a717ccf2a49c70bf70e7196f267f2`. The supplied local verification receipt reports 28 PASS, byte-identical two builds, Windows native PASS, independent review NOT_PERFORMED, cross-platform NOT_ESTABLISHED, publication NOT_PERFORMED, authority NONE. This Batch A does not promote any status.

## Decisions
- A-001 PRESERVE: v0.1 data, identifiers, vectors, domain prefixes, envelopes and refusal semantics remain unchanged; new formats use explicitly distinct draft namespaces and domain tags.
- A-002 SPLIT: artifact logical root != container transport digest != deployment location; no self-hash cycle.
- A-003 SPLIT: stable namespace root lineage distinct from v0.1 epoch-specific namespace instance. No implicit upgrade or alias.
- A-004 EVIDENCE: signed descriptive claim != validated property != selected policy acceptance != capability grant.
- A-005 NAVIGATION: publisher-signed outgoing edges distinguishable from index-discovered inbound edges; completeness is scoped, never presumed.
- A-006 SUBSTRATE: profile names make no unconditional security guarantees; clauses reference mechanisms, assumptions, tests, independent fault domains and time.
- A-007 RUNTIME: core offline; networking, indexing, policy and adapter layers optional, never required for exact verification.
- A-008 STATUS: fail-closed version/algorithm/codec negotiation; no automatic downgrade or hidden silent inference.
- A-009 GOVERNANCE: external recognizer may authorize; DKN verification never does.
- A-010 RELEASE: Batch A design candidate is not v0.2 ratification, production assurance or implementation.

## Critical open design questions for falsification
Key rotation versus permanent root takeover; equivocation without external witnessing; accidental cross-platform path equivalence; link-graph completeness; time-based freshness with offline readers; correlation and shared control across federated witnesses; cryptographic multihash agility and downgrade; private metadata disclosure through indexes. No claim can be lifted until tests and, where relevant, independent protocol analysis.
