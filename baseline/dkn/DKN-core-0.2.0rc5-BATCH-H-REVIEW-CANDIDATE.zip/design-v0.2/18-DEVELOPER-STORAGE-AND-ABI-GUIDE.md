# Developer guide: assurance, local publishing, reading, and handoffs

## Run the cumulative examples

Use the repository source tree; this is an experimental module track, not a newly
published package version. Existing pyproject dependencies are unchanged. Batch D ran
on Linux/Python 3.13.5 with cryptography 46.0.4, jsonschema 4.26.0, and pytest 9.0.2.
`requirements-v02-dev.txt` records those versions, not a verified installation recipe
for every operating system or a transitive lock. Legacy v0.1 additionally needs blake3.

POSIX shell:

```sh
export PYTHONPATH="src:."
python examples/v02_publish_verify.py
python examples/v02_navigate.py
python examples/v02_assurance.py
python -m dkn_v02.sam_cli examples/v02-sam-request.json
python tools/verify_v02_candidate.py --out /tmp/dkn-evidence
```

PowerShell syntax (provided, NOT executed in Batch D):

```powershell
$env:PYTHONPATH = "src;."
py -3.12 examples/v02_assurance.py
py -3.12 -m dkn_v02.sam_cli examples/v02-sam-request.json
py -3.12 tools/verify_v02_candidate.py --out "$env:TEMP\dkn-evidence"
```

All deterministic keys in examples/tests are public fixtures. Never use them for an
actual publisher, observer, witness, or custodian. The demonstration times near epoch
1000 are synthetic; no current deployment observation is implied.

## Storage-neutral publication and retrieval

```python
from dkn_v02.core import pack
from dkn_v02.storage import DirectoryStore, MemoryStore, retrieve

raw, manifest = pack({'readme.txt': b'hello'})
local = DirectoryStore('./my-vault', backend_id='local')
mirror = MemoryStore('fixture-mirror')
a = local.put(raw)  # Explicit local write, creates only the content-addressed file.
b = mirror.put(raw)
received, observation = retrieve(
    [a, b], {'local': local, 'fixture-mirror': mirror},
    expected_root=manifest['logical_root'],
)
assert received == raw
```

A locator binds backend ID, exact transport SHA-256, and logical artifact root. It is
not part of the artifact identity. Moving identical bytes between backends preserves
the root. `retrieve` checks the expected logical root and transport digest itself,
regardless of what a provider asserts. A poisoned/unavailable first provider can be
followed by another explicitly supplied provider. Exhausting the list returns
`INDETERMINATE`, not global absence.

The interface is a Python `Store` protocol with `backend_id`, `put(raw)`, and
`get(transport_sha256)`. `get` returns untrusted bytes until the reader checks them.
Only `MemoryStore` and `DirectoryStore` are implemented. There is no URL dereferencing,
HTTP fetch, P2P discovery, corporate login, or backend auto-installation. Third-party
adapters are explicit caller code and must supply their own timeouts, isolation,
credential handling, destination allowlists, and request/byte budgets.

## Local store threat boundary

The directory store rejects detected symlinks in the root/ancestor/leaf chain, rejects
nonregular or multiply linked read targets, bounds reads, checks file snapshots, uses
no-follow flags where available, and verifies hashes/archives. Creates use exclusive
open, flush, and fsync; existing valid content is reused, never overwritten.

These checks do not establish race-free directory custody. An active local process
able to rename ancestors can race path-based checks. There is no hostile multi-tenant
filesystem proof, directory-descriptor-relative traversal across platforms, transaction
log, crash recovery protocol, multiwriter coordinator, or protected key storage. A
partial write may remain after interruption and will be refused on read. Backups,
retention, deletion, permissions administration, and secrets management are external.

`MemoryStore` is ephemeral. A retrieval result is an observation of this invocation,
not an SLA or a proof that a remote replica remains available.

## Creating assurance records

Obtain a fresh template from `reference_profile`. Fill actual deployment data; replace
`TEMPLATE` with `DECLARED_DEPLOYMENT` only as an explicit declaration, not as proof.
Use `seal('substrate', body, key)` to bind it. Author a contract referencing that exact
`record_hash`. Sign observer statements with their own keys using `seal('evidence',...)`.
The reader supplies its policy and fixed context independently.

```python
from dkn_v02.assurance import evaluate
assessment = evaluate(descriptor, contract, evidence, reader_policy, context)
# Inspect status, scope, excluded evidence, unresolved premises, and limitations.
# Do not translate status=SATISFIES into execute=true.
```

Full, executable field construction is in `examples/v02_assurance.py`. The example's
synthetic signed observation is deliberately labelled as a fixture. A `basis_ref`
can bind actual observation material; this evaluator does not inspect that material.

## Joining assurance to navigation

`inspect_with_assurance(raw, descriptor=..., contract=..., evidence=..., policy=...,
context=..., certificate=...)` executes Batch C inspection and Batch D evaluation,
then checks that the contract refers to the inspected artifact/namespace. It returns
both reports and `recognition=EXTERNAL_DECISION_REQUIRED`. Descriptor changes remain
separate from immutable artifact contents. Discovery never silently chooses a security
policy for the reader.

## Closed JSON ABI

A request has exactly `schema`, `operation`, and `arguments`.
`schema=dkn.sam-request.v0.2-candidate`.

| Operation | Exact argument fields |
|---|---|
| `verify` | `record` |
| `evaluate` | `descriptor`, `contract`, `evidence`, `policy`, `context` |
| `compose` | `descriptors`, `roots`, `at_time` |
| `checkpoints` | `checkpoints`, `policy`, `at_time` |
| `handoff` | `checkpoints`, `policy`, `at_time`, `consumer` |

No argument contains executable expressions, dynamically imported names, or local file
paths. The CLI itself takes one explicitly selected canonical JSON file. It reads at
most the metadata byte budget and writes one JSON result. Exit 0 means the request was
processed; the result may be `INSUFFICIENT` or `CONTRADICTED`. Exit 2 denotes typed refusal.
Consumers must inspect the result, not use exit 0 as a policy approval.

## Source package verification

```sh
python tools/verify_v02_candidate.py --out /tmp/dkn-v02-check
python tools/build_v02_candidate.py --out /tmp/dkn-candidate.zip
```

Add `--require-legacy` to make missing legacy dependencies a gating failure. The
candidate builder inventories every file except its own inventory, serializes a frozen
tree twice, and writes an external SHA-256. The inherited v0.1 release tooling is not
the v0.2 candidate builder. A checksum confirms content relative to a chosen digest;
it does not establish who authorized the release.
