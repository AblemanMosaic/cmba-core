# SAM candidate protocol and deterministic evaluator

## 1. Separation of responsibilities

A substrate descriptor declares a deployment model. A signed evidence record declares
an observation or result. A contract specifies which records are required. Caller policy
pins recognized descriptor signers and observer roles. A context supplies a fixed time
and accepted premises. None of these is an execution grant.

No descriptor may add its own observer to the reader's policy. Evidence cannot declare
its signer independent: observer control-domain labels come only from the caller's
policy. They remain unproven premises even there.

The candidate retains Batch A terminology: `SubstrateDescriptor`, `AssuranceContract`,
`EvidenceRecord`, `Assessment`, and explicit threat-model assumptions. Runtime schemas
under `schemas/v02/sam-*.schema.json` are distinct from the historical design-only
schemas under `design-v0.2/schemas`. Do not silently substitute one for the other.

## 2. Serialization and signed envelope

Canonical bytes use the existing Batch B `canonical` implementation, not a new JSON
standard: UTF-8, Unicode code-point key ordering, compact separators, no floating point,
no NaN/infinity, no surrogate code points, signed 64-bit integers. No Unicode
normalization is added. Strict wire reads reject duplicate keys and noncanonical bytes.
This is not a claim of RFC 8785/JCS conformance.

All schemas are closed (`additionalProperties=false`). IDs use lowercase ASCII token
syntax; digest and public-key fields are 64 lowercase hexadecimal characters. Signature
fields are 128 lowercase hexadecimal characters. Time is an integer UTC Unix second.
An interval is `[valid_from, valid_until)` or `[observed_at, valid_until)`; an inclusive
maximum-age bound adds `at_time - observed_at <= max_age_seconds`.

A signed record has exactly these fields:

```text
schema = dkn.sam-signed.v0.2-candidate
kind = substrate | evidence | checkpoint
body = a closed typed object for that kind
signer_public_key_hex
record_hash
signature_hex
```

Let `U` be the four-field object excluding `record_hash` and `signature_hex`.

```text
record_hash = SHA256(ASCII("DKN_V02_SAM_RECORD") || 0x00 || canonical(U))
signature_hex = Ed25519.sign(private_key,
    ASCII("DKN_V02_SAM_SIGNATURE") || 0x00 || canonical(U)).hex()
```

Record identity binds the exact body, kind, schema, and signer, not a human name or
network endpoint. Signature verification is separate from recognizing a signer.

Other SAM commitments use `SHA256(ASCII("DKN_V02_SAM_") || ASCII(label.upper()) ||
0x00 || canonical(value))` for a closed label set in `sam_hash`. Labels include
`contract`, `policy`, `context`, `assessment`, `composition`, `checkpoint-policy`,
`checkpoint-membership`, `checkpoint-report`, and `handoff`. Hyphens in labels are
literal. Result `report_hash` excludes only that result's own `report_hash` field.

## 3. Exact scope

An evidence/contract scope contains three fields:

```json
{"substrate_ref":"<signed descriptor record_hash>","artifact_root":"<64 hex or null>","namespace_root":"<64 hex or null>"}
```

Evidence is reusable only when all three fields match exactly. `null` means the scoped
field is intentionally unspecified; it is not a wildcard matching every artifact.
Contracts bind the descriptor hash, not only its mutable display ID. Changes to a
descriptor therefore require a new scope and cannot inherit old evidence silently.

`inspect_with_assurance` additionally checks that the contract's artifact root equals
the freshly verified archive root. A non-null namespace must equal the inspected
certificate namespace. This join never mutates the archive or treats an assurance
record as namespace authorization.

## 4. Contract evaluation

Only `decision_rule=evidence-obligations-v1` is implemented. Arbitrary expressions,
plugins named by untrusted input, consensus rules, and global-freshness rules are refused.
The twelve dimension labels organize contracts; they do not invoke implicit validators.

Evaluation performs these steps:

1. Bound and validate the complete input, then verify descriptor and every supplied
   signed evidence record. Malformed records and bad signatures produce typed refusal.
2. Match the descriptor hash to contract scope; pin descriptor authorship through caller
   policy. A valid but unrecognized descriptor cannot satisfy the contract.
3. Filter evidence by exact scope, recognized observer/predicate, and validity interval.
   Record exclusion reasons. A wrong-scope or unrecognized record cannot satisfy or veto.
4. For each requirement, retain allowed methods and maximum-age-compliant observations.
   `DECLARATION`, `OBSERVATION`, and `TEST_RESULT` are signed classifications, not proofs
   that an observation or test actually occurred. `basis_ref` binds supporting material
   when provided; this evaluator does not fetch or inspect that material.
5. Any eligible `REFUTES` for a requirement produces `CONTRADICTED`, even alongside
   support. `INDETERMINATE` is not support. Count each supporting signer at most once.
6. Find a threshold-sized signer subset satisfying each required independence dimension
   under policy labels. Missing labels are unknown, not independent. Multiple keys
   sharing a named administration/provider/etc. domain do not form an independent subset.
7. Reconcile descriptor, contract, and caller premises. Conflicting required premises
   produce `CONTRADICTED`. Accepted premises remain assumptions, not proofs.
8. Apply status precedence and emit a content-bound assessment.

### Status meanings and precedence

| Status | Precise meaning |
|---|---|
| `CONTRADICTED` | Eligible negative evidence or mutually incompatible required premises |
| `INSUFFICIENT` | Missing evidence/quorum, invalid time, template-only deployment, or unrecognized descriptor signer |
| `CONDITIONAL` | Evidence requirements met, but named assumptions or policy-declared independence remain unproven |
| `SATISFIES` | Evidence requirements met with no additional declared premises; still not a real-world security proof |
| `NOT_EVALUATED` | Vocabulary for a model with no run; a successful evaluator invocation never returns this placeholder |
| typed `REFUSED` | Malformed, unsupported, over-budget, wrongly bound, or cryptographically invalid request |

Precedence is contradiction, insufficiency, conditional, satisfaction. A contradiction
may be reported even where another requirement is incomplete; it cannot yield admission.
`SAM_RULE_UNSUPPORTED` is a refusal, not a weak pass.

## 5. Composition

`compose(descriptors, roots=[...], at_time=...)` examines an explicitly all-of deployment.
It traverses signed descriptor dependency hashes, reports missing dependencies and
expired declarations, and compares effective domain sets including transitive ancestors.
A shared dependency remains visible even when its document is missing.

The report identifies shared control, incompatible boolean premises, incomplete domain
coverage, unused supplied descriptors, and public metadata along selected dependency
paths. It never computes failure probabilities or a scalar security score. An unused
public descriptor does not taint a private root's selected dependency closure.

`NO_DECLARED_CONFLICTS_WITHIN_SCOPE` means precisely that. It does not prove actual
independence, inventory completeness, operational configuration, or availability.
Composition checks declaration signatures but does not recognize their authors; it is
an inspection operation. Policy acceptance is a separate step.

## 6. Python entry points

| Function | Result |
|---|---|
| `seal(kind, body, key)` | New detached signed record; freezes nested caller data |
| `verify_record(record, expected_kind=None)` | Signature report with fact/recognition unestablished |
| `evaluate(descriptor, contract, evidence, policy, context)` | Deterministic assurance assessment |
| `compose(descriptors, roots=..., at_time=...)` | Bounded declared-composition report |
| `reference_profile(name)` | Fresh independent template dictionary |
| `validate(kind, value)` | Strict schema/semantic validation or typed refusal |

These functions are exposed in their modules, not eagerly imported by `dkn_v02`.

## 7. Resource and determinism contract

The complete evaluation, composition, or checkpoint request is bounded to the inherited
4 MiB canonical metadata cap and depth 32. Maximum signed records: 128; descriptor
records in composition: 64; composition roots: 16; requirements: 16; recognized
observers/members: 16; fault-domain labels per actor: 32. Signer subset search is finite
(at most 12,870 subsets for any one 16-member threshold). No untrusted code is evaluated.

Results are independent of evidence/descriptor/checkpoint list arrival order; references
and diagnostic sets are sorted. Policy/contract array order remains part of those
objects' identity. Time is caller-supplied; there is no clock read inside evaluation.
Repeated evaluation of the same inputs produces the same report hash. These are local
algorithmic properties, not distributed agreement.

## 8. Refusal families

`DKN_V02_SAM_SCHEMA_INVALID`, `SCHEMA_UNSUPPORTED`, `KIND_MISMATCH`,
`COMMITMENT_MISMATCH`, `RULE_UNSUPPORTED`, `SCOPE_MISMATCH`, `TIME_INVALID`,
`THRESHOLD_INVALID`, `DUPLICATE`, `LIMIT`, `ROOT_MISSING`, `OPERATION_UNSUPPORTED`,
`PROFILE_UNSUPPORTED`, `CONSUMER_UNSUPPORTED`, and `IO_ERROR` use the SAM prefix.
Signature and canonicalization failures retain existing `DKN_V02_*` codes. No raw
traceback is emitted for the tested invalid CLI requests.
