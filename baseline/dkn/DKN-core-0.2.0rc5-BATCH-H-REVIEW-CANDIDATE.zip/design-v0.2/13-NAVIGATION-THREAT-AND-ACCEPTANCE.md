# Batch C threat model and falsification ledger

## Adversaries and expected handling

1. A local index can invent names and references: name discovery is never identity proof; only verified genesis/certificate evidence is exposed.
2. A publisher can claim a relation to any artifact: signed claims are not a proof of truth or destination authorization.
3. An index can omit incoming edges: all results state global completeness NOT_ESTABLISHED.
4. A local operator can mutate an archive after indexing: fresh transport and logical verification must fail.
5. A local operator can replace a certificate: signature verification must fail.
6. A local operator can replace the submitted relation value: dimension digest check must fail.
7. A local operator can create a symlink at an object/evidence entry: refuse.
8. A publisher can sign namespace genesis with a false reference to a legacy instance: do not claim the legacy binding is proven.
9. Two publishers can create identically spelled semantic names: expose both cryptographically distinct roots; neither gains exclusivity.
10. Multiple artifacts can share a namespace root: expose competing candidates, not a cryptographically established fork.
11. Missing or incomplete transitions: cannot prove global head, signing-time key authorization or current epoch.
12. Cycles and deep graphs: bounded breadth-first traversal with exact-root deduplication and explicit truncation.

## Evidence statuses

`PASS` means a particular listed test/check passed. `NOT_CHECKED` means no verification requested or supplied. `NOT_ESTABLISHED` means the available evidence is insufficient for the stronger claim. `PASS_FOR_SUPPLIED_CHAIN_ONLY` is explicitly scoped and does not assert global or temporal authorization. `REFUSED` is a typed cryptographic/structural failure. `authority_effect=NONE` is invariant.

## Tests

`tests_v02/test_batch_c.py` verifies exact resolution, local discovery, outgoing/incoming traversal, unsigned relation semantics, unbound relation refusal, archive/evidence tampering, duplicate/malformed edges, bounded execution, symlink refusal, namespace homonyms, incorrect signer, supplied transition scopes, truncated outputs, and noncanonical stored metadata.

`examples/v02_navigate.py` exercises deterministic signed publisher-claim traversal. All tests are locally executed, but no independent cross-language verification or network security evaluation is claimed.
