# Proposed developer surfaces — no implementation in Batch A

## Runtime modules
`dkn_core` v0.1 remains untouched. Proposed separate namespaces: `dkn_v02.core`, `.navigation`, `.substrates`, `.adapters` until protocol/semver decision; no import-time networking. Core has no dependency on CCP/UCM/CHC. JSON ABI shared with Rust/other verifiers.

## Operations and contract
- `identity` / `namespace`: derive and verify exact typed identity or candidate lineage.
- `commit`: canonical typed data to domain-separated digest; no semantic truth evaluation.
- `pack`: close a logical manifest and optionally deterministic transport; no network side effect.
- `certify`: sign specifically identified committed statement with authorized private material; signature validity != admission.
- `verify`: accept bytes and selected profile; return per-property evidence/status, never broad boolean.
- `inspect`: bounded offline parse and verification.
- `resolve_exact`: require an exact pinned digest or namespace instance and adapter explicit; verify fetched bytes.
- `discover`: return potentially incomplete candidate set and origin (not verified identities by name).
- `traverse`: verified graph edges with provenance, bounded depth/limits, no authority escalation.
- `assess_substrate`: contract + descriptor + evidence + assumptions => conditional, typed conclusion.
- `publish`: adapter-specific side-effect operation requiring explicit caller invocation and policy; NEVER implicit from validation.

## JSON ABI envelope
Request contains `schema`, `operation`, `arguments`, `limits`, `critical_extensions`; response contains `ok`, `evaluation`, `evidence`, `refusal`, `authority_effect`. Invalid input uses a stable typed refusal and MUST NOT partially endorse. Non-applicable checks return `NOT_CHECKED`; unsupported critical schema returns `UNSUPPORTED` with refusal code. No sensitive private key bytes in public JSON responses.

## Command-line sketches
`dkn v02 inspect path`; `dkn v02 pack DIR --profile basic`; `dkn v02 verify FILE --certificate CERT`; `dkn v02 discover NAME --index DIR`; `dkn v02 traverse ID --depth 2 --index DIR`; `dkn v02 substrates assess DESCRIPTOR CONTRACT EVIDENCE`. All illustrative, NOT available in r002.

## Interoperability
Normative CJSON octets, hash/signature vectors, reject vectors, sorting/path rules, key canonicality, length bounds, case-folding and Unicode behavior; implementations must reproduce accepted values and rejection classes. Cross-platform compatibility remains NOT_ESTABLISHED pending actual independent runners.
