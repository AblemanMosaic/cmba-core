# Draft cryptographic and artifact commitment protocol

## Existing v0.1 immutability
DKN-CJSON-1, SHA-256 THR domains, BLAKE3 namespace/subject domains and Ed25519 signatures stay exactly as `docs/PROTOCOL.md` defines. No new digest computed under those legacy domains. A v0.2 candidate is not backward reinterpretation.

## Draft independent domains (unratified)
`DKN_V02_DIMENSION\x00`, `DKN_V02_LOGICAL_ARTIFACT\x00`, `DKN_V02_NAMESPACE_GENESIS\x00`, `DKN_V02_RELATION\x00`, `DKN_V02_SUBSTRATE_DESCRIPTOR\x00`, `DKN_V02_ASSURANCE_EVIDENCE\x00`, `DKN_V02_SNAPSHOT\x00`. Prefixes shown as symbolic printable escapes, pending cross-language normative octet vectors. These are reserved candidate identifiers only.

## Logical artifact model
Canonical inventory contains each path (portable NFC question pending explicit policy), entry type (regular file, directory, symlink, or deny), content digest, length, metadata profile, deterministic path order; the candidate must choose and test exact interpretation of executable bits, symlinks and case-insensitive aliases before implementation. The outer identity is the digest of the complete typed inventory and declared critical metadata. No mutable locator is an identity input. Transport digests bind the exact ZIP/tar/delivery bytes and may differ for one logical artifact. A declared transport-to-logical association MUST be independently verified by opening and validating every entry; association by hash text alone is not proof.

## Typed dimension object
Required: `dimension_id`, `schema_id`, `hash_algorithm`, `digest_hex`, `critical` and optional `meaning_ref`. Domains distinguish dimension and root. Exact canonical object structure, byte limits and hash choices must be locked in a public candidate before vectors. Dimension absence is not success. Unknown critical dimension refuses; unknown noncritical dimension can be preserved as unassessed, never verified semantically. THR remains a named profile requiring all three dimensions and their legacy exact SHA-256 roots.

## Commitment statements
Declarations may say a dimension's *bytes were committed*, not that its semantic claims are correct. Multidimensional root binds ordered, unique, typed dimension records; sorting order normative after code-point/byte policies locked. Multiproofs and Merkle optimization are optional future features; no Merkle-specific property is promised by a flat SHA-256 canonical manifest.

## Certificate stages
`DETERMINISTIC_PACKAGED` (closed inventory), `EXTERNAL_ATTESTATION_REQUIRED`, `SIGNED_STATEMENT_VALID`, `POLICY_ACCEPTED` (external only). Never call a v0.1 READY_FOR_EXTERNAL certificate self-signed. Detached signature binds schema, logical root, claim type, namespace-instance reference, and signer passport or key identity. External exact archive checksum still required for exact transport identity.

## Algorithm agility
Mandatory explicit algorithm identifiers and allowed profiles; no accept-any hash, no autodetect, no silent fallback. Cross-language negative vectors for unsupported algorithms, misleading encodings, digest length, nulls and extension ambiguities required before enabling v0.2.
