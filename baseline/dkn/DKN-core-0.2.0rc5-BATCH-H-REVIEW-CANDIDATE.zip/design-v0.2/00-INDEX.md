# Current implementation manual

See `../docs/v02/README.md` and `21-BATCH-E-INTEGRATION.md`. Earlier numbered files retain the design trail.

# DKN v0.2 — Batch A architectural baseline

**Status:** SPECIFICATION_CANDIDATE; not v0.2 protocol ratification or implementation. **Authority:** NONE. **Source:** DKN Core v0.1 r002 unmodified. **Scope:** Batch A audit, contract definitions, schemas, and proposed acceptance gates.

## Reading order
1. `01-AUDIT-AND-DECISIONS.md` — bounded assessment of inherited repository and change rules.
2. `02-CONSTITUTIONAL-ARCHITECTURE.md` — jurisdiction, layers, invariants, assumptions, and boundary cases.
3. `03-CRYPTO-AND-MANIFEST-PROTOCOL.md` — canonical logical identity and dimensions, versioning.
4. `04-NAMESPACE-AND-LINEAGE.md` — root versus instance, forks, key recovery, naming.
5. `05-NAVIGATION-AND-QUERY.md` — graph links, resolution/discovery, query proofs.
6. `06-SUBSTRATE-ASSURANCE.md` — security models, conditional contracts, composition.
7. `07-API-AND-INTEROPERABILITY.md` — Python/CLI/JSON ABI, cross-language behavior.
8. `08-THREAT-MODEL.md` — actors, threats, mitigations, and residual risks.
9. `09-TEST-AND-RELEASE-PLAN.md` — gates, falsification cases, responsibility.
10. `10-MIGRATION-AND-REFERENCE-PROFILES.md` — preservation, profiles, protocol transition.
11. `DECISIONS.json`, `acceptance/MATRIX.json`, `schemas/*.schema.json`, `BATCH-A-STATUS.json`.

The draft schemas only validate document structure. No schema validation proves that hashes, signatures, promises, network behavior, or jurisdiction are true. Do not use draft IDs as public protocol IDs.


## Cumulative implementation addenda

Historical Batch A text above remains a design snapshot. Implemented candidate tracks:
11 — Batch B kernel; 12–13 — Batch C navigation; 14 — Batch D implementation;
15 — exact SAM protocol and API; 16 — security-model handbook; 17 — federation/CHC/CCP;
18 — developer/storage/ABI guide; 19 — threat and acceptance dossier;
20 — consolidated Batch E handoff. `BATCH-D-STATUS.json` and `evidence/batch-d/` record
current scoped evidence. `schemas/v02/` contains executable SAM input schemas;
`design-v0.2/schemas/` remains the earlier draft schema vocabulary.
