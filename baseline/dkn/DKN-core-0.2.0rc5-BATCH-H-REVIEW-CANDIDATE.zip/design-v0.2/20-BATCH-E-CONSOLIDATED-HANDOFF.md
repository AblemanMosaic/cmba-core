# Batch E — consolidated integration and release worklist

## Starting point

Use the complete Batch D candidate, its exact external SHA-256, and verification
receipt. Do not start from r002 alone or regenerate a parallel replacement repository.
Keep legacy files and all candidate vectors under explicit byte-diff review.

Batch D implements the bounded substrate-modeling/evidence path. It does not clear a
public v0.2 release gate. A successful build/test run is not ratification or independent
review. Real deployment and authority remain outside the candidate.

## Maximum-batched final engineering turn

1. Audit the complete B/C/D integration: typed input failures, identities/epochs,
   unknown critical dimensions, resource exhaustion, retrieval/navigation boundaries,
   evidence substitution, assumption composition, and report interpretation. Read actual
   implementation and test results rather than promoting checklist rows wholesale.
2. Reconcile every original acceptance-matrix row with an executable case, a bounded
   proof obligation, or a named deferred limitation. Particular inherited gaps include
   legacy namespace binding, revocation freshness, key recovery, display-confusable
   names, cursor semantics, and strong transactional vault claims.
3. Exercise candidate vectors with an independently written verifier where feasible.
   Rust/interoperability is NOT_STARTED, not assumed from JSON portability. A second
   Python implementation is also not the same as independent human/institutional review.
4. Run legacy tests in an environment with the declared `blake3` dependency. Run actual
   Windows and other target environments only when available; otherwise retain NOT_RUN.
   The supplied PowerShell commands are documentation, not Windows evidence.
5. Consolidate schemas, API/reference documentation, packaging metadata, install/runtime
   requirements, failure codes, examples, source inventory, and migration claims. Runtime
   output formats currently have precise code/docs but no complete exported JSON Schema
   set; add that surface or explicitly defer it before asserting full ABI-schema closure.
6. Build twice from a frozen tree; verify exact closure and external transport hashes;
   extract afresh and rerun. Retain logs, defect dispositions, and claim ceilings.
7. Produce one review-ready handoff with a genuinely bounded release recommendation.
   External ratification remains a separate decision. Do not hide blocked gates behind
   `PASS_SCOPED_LOCAL_ENGINEERING`.

## Extensions that must not silently expand this gate

Live HTTP/Git/P2P adapters, corporate SSO or PKI, actual CCP federation deployment,
transparency proofs, authenticated time, revocation channels, crash-safe/multiwriter
vault storage, and proof-generating custody infrastructure are separate implementation
and operational-validation tracks. Their security models are represented in Batch D;
their operation is not. No scheduler, automatic upload, or remote execution is needed
for the final local engineering turn.

## Local checks

```sh
export PYTHONPATH="src:."
python tools/verify_v02_candidate.py --out /tmp/dkn-evidence
# Gate legacy runtime too when its real dependency is installed:
python tools/verify_v02_candidate.py --out /tmp/dkn-full-evidence --require-legacy
python tools/build_v02_candidate.py --out /tmp/dkn-candidate.zip
```

The candidate builder currently emits the Batch D boundary. A later release must
version its boundary explicitly; do not keep claiming Batch C as direct predecessor
after importing additional changes.
