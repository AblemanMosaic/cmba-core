"""Offline canonical request file or stdin; no signing or state mutation."""
import argparse
from pathlib import Path
import sys
from .core import canonical, read_canonical, read_bounded_file, MAX_META, Refusal
from .lifecycle_abi import dispatch


def main(argv=None):
    parser=argparse.ArgumentParser(prog='dkn-lifecycle')
    parser.add_argument('request',help='Canonical LC-F1 JSON request, or - for stdin')
    args=parser.parse_args(argv)
    try:
        raw=sys.stdin.buffer.read(MAX_META+1) if args.request=='-' else read_bounded_file(Path(args.request),MAX_META)
        result=dispatch(read_canonical(raw));code=0
    except (Refusal,OSError) as exc:
        result={'status':'REFUSED','code':exc.code if isinstance(exc,Refusal) else 'DKN_LC_IO_ERROR','authority_effect':'NONE'}
        code=2
    sys.stdout.buffer.write(canonical(result)+b'\n')
    return code

if __name__=='__main__':raise SystemExit(main())
