"""Closed, read-only JSON ABI for SAM. No caller-supplied code or file paths."""
from .core import canonical, check, exact
from .assurance import evaluate, compose, verify_record
from .federation import assess_checkpoints, make_handoff
from .sam_schemas import V
from .runtime_schemas import validate_report


def dispatch(request: dict) -> dict:
    canonical(request)
    exact(request, {'schema', 'operation', 'arguments'})
    check(request['schema'] == 'dkn.sam-request.'+V, 'DKN_V02_SAM_SCHEMA_INVALID')
    check(type(request['operation']) is str, 'DKN_V02_SAM_OPERATION_UNSUPPORTED')
    op, a = request['operation'], request['arguments']
    if op == 'verify':
        exact(a, {'record'})
        return validate_report('record-verification',verify_record(a['record']))
    if op == 'evaluate':
        exact(a, {'descriptor', 'contract', 'evidence', 'policy', 'context'})
        return validate_report('assessment',evaluate(**a))
    if op == 'compose':
        exact(a, {'descriptors', 'roots', 'at_time'})
        return validate_report('composition',compose(**a))
    if op == 'checkpoints':
        exact(a, {'checkpoints', 'policy', 'at_time'})
        return validate_report('checkpoint-assessment',assess_checkpoints(**a))
    if op == 'handoff':
        exact(a, {'checkpoints', 'policy', 'at_time', 'consumer'})
        return validate_report('handoff',make_handoff(**a))
    from .core import Refusal
    raise Refusal('DKN_V02_SAM_OPERATION_UNSUPPORTED')
