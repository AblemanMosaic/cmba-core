"""Closed read-only DS-G1 JSON ABI. No URL, key, arbitrary path or executable."""
from .core import check, exact, canonical
from .distributed_schemas import validate_shape
from .distributed import assess_view
from .simulation import run_scenario, verify_replay

def dispatch(request):
    validate_shape('request',request);args=request['arguments'];op=request['operation']
    if op=='assess':
        exact(args,{'objects','reader','now'},'DKN_DS_ARGUMENT_INVALID')
        result=assess_view(args['objects'],args['reader'],now=args['now'])
    elif op=='simulate':
        exact(args,{'scenario'},'DKN_DS_ARGUMENT_INVALID');result=run_scenario(args['scenario'])
    else:
        exact(args,{'scenario','transcript'},'DKN_DS_ARGUMENT_INVALID')
        result=verify_replay(args['scenario'],args['transcript'])
    canonical(result)
    return result
