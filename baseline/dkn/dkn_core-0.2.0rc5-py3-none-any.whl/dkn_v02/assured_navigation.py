"""Join Batch C artifact inspection to a separately versioned assurance envelope."""
from .core import check
from .navigation import inspect
from .assurance import evaluate, BOUNDARY
from .sam_schemas import V


def inspect_with_assurance(raw: bytes, *, descriptor: dict, contract: dict,
                           evidence: list[dict], policy: dict, context: dict,
                           certificate=None, relations=None, genesis=None, transitions=None) -> dict:
    inspection = inspect(raw, certificate=certificate, relations=relations,
                         genesis=genesis, transitions=transitions)
    # Evaluate schemas before field use; no precomputed assessment may be injected.
    result = evaluate(descriptor, contract, evidence, policy, context)
    check(contract['scope']['artifact_root'] == inspection['logical_root'], 'DKN_V02_SAM_SCOPE_MISMATCH')
    if contract['scope']['namespace_root'] is not None:
        check(contract['scope']['namespace_root'] == inspection['namespace_root'], 'DKN_V02_SAM_SCOPE_MISMATCH')
    return {'schema': 'dkn.assured-inspection.'+V, 'inspection': inspection,
            'assurance': result, 'recognition': 'EXTERNAL_DECISION_REQUIRED', **BOUNDARY}
