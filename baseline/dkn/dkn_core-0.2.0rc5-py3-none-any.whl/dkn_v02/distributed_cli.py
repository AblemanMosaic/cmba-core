"""Explicit local-file/stdin read only. Process exit 0 is not an authority grant."""
from __future__ import annotations
import argparse, sys
from .core import Refusal, MAX_META, canonical, read_canonical, read_bounded_file, check
from .distributed_abi import dispatch

def main():
    parser=argparse.ArgumentParser(description='DKN DS-G1 offline evidence model; not a live network client')
    parser.add_argument('request',help='Canonical DS-G1 request JSON, or - for stdin')
    args=parser.parse_args()
    try:
        raw=sys.stdin.buffer.read(MAX_META+1) if args.request=='-' else read_bounded_file(args.request,MAX_META)
        result=dispatch(read_canonical(raw))
        sys.stdout.buffer.write(canonical(result)+b'\n');return 0
    except Refusal as exc:
        sys.stdout.buffer.write(canonical({'status':'REFUSED','code':exc.code,'authority_effect':'NONE'})+b'\n');return 2
    except OSError:
        sys.stdout.buffer.write(canonical({'status':'REFUSED','code':'DKN_DS_IO_ERROR','authority_effect':'NONE'})+b'\n');return 2
if __name__=='__main__':raise SystemExit(main())
