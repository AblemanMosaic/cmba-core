"""Bounded, deterministic substrate assurance; no networking or authority effects.

SATISFIES means exact evidence obligations under explicit caller policy, not the
truth of attestations. Independence labels are policy premises, not measurements.
"""
from __future__ import annotations
from itertools import combinations
from typing import Any
import hashlib

from jsonschema import Draft202012Validator
from .core import Refusal, canonical, check, key_hex, _verify_sig
from .sam_schemas import SCHEMAS, FAULT_DIMENSIONS, V

BOUNDARY = {'standing': 'INFORMATION_ONLY', 'authority_effect': 'NONE',
            'real_a5': False, 'g0': 'CLOSED'}
MAX_RECORDS = 128
DOMAIN = b'DKN_V02_SAM_RECORD\x00'
SIGN_DOMAIN = b'DKN_V02_SAM_SIGNATURE\x00'
VALIDATORS = {name: Draft202012Validator(schema) for name, schema in SCHEMAS.items()}


def validate(kind: str, value: Any) -> Any:
    """Strict schemas and bounded canonical values; return input without mutation."""
    check(type(kind) is str and kind in VALIDATORS, 'DKN_V02_SAM_SCHEMA_UNSUPPORTED')
    canonical(value)  # byte, integer, depth, and member limits before validation
    check(VALIDATORS[kind].is_valid(value), 'DKN_V02_SAM_SCHEMA_INVALID')
    if kind in ('substrate', 'contract', 'checkpoint-policy'):
        check(value['valid_from'] < value['valid_until'], 'DKN_V02_SAM_TIME_INVALID')
    if kind in ('evidence', 'checkpoint'):
        check(value['observed_at'] < value['valid_until'], 'DKN_V02_SAM_TIME_INVALID')
    for field, unique in (('requirements', 'id'), ('observers', 'public_key_hex'),
                          ('members', 'public_key_hex'), ('assumptions', 'id'),
                          ('accepted_premises', 'id')):
        if field in value:
            rows = value[field]
            check(len({r[unique] for r in rows}) == len(rows), 'DKN_V02_SAM_DUPLICATE')
    if kind == 'checkpoint-policy':
        check(value['threshold'] <= len(value['members']), 'DKN_V02_SAM_THRESHOLD_INVALID')
    return value


def sam_hash(label: str, value: Any) -> str:
    """Commitments for a closed set of record classes, not arbitrary algorithms."""
    check(label in ('record', 'contract', 'policy', 'context', 'assessment',
                    'composition', 'checkpoint-policy', 'checkpoint-membership', 'checkpoint-report', 'handoff'),
          'DKN_V02_SAM_DOMAIN_UNSUPPORTED')
    return hashlib.sha256(b'DKN_V02_SAM_' + label.upper().encode('ascii') + b'\x00' + canonical(value)).hexdigest()


def seal(kind: str, body: dict, key) -> dict:
    """Sign a declaration/observation. This does not validate the asserted fact."""
    check(kind in ('substrate', 'evidence', 'checkpoint'), 'DKN_V02_SAM_SCHEMA_UNSUPPORTED')
    validate(kind, body)
    unsigned = {'schema': 'dkn.sam-signed.'+V, 'kind': kind,
                'body': body, 'signer_public_key_hex': key_hex(key)}
    encoded = canonical(unsigned)
    result = {**unsigned, 'record_hash': hashlib.sha256(DOMAIN + encoded).hexdigest(),
              'signature_hex': key.sign(SIGN_DOMAIN + encoded).hex()}
    # Freeze nested caller-owned data through canonical roundtrip.
    from .core import read_canonical
    return read_canonical(canonical(result))


def verify_record(record: dict, *, expected_kind: str | None = None) -> dict:
    validate('signed', record)
    if expected_kind is not None:
        check(record['kind'] == expected_kind, 'DKN_V02_SAM_KIND_MISMATCH')
    validate(record['kind'], record['body'])
    unsigned = {k: v for k, v in record.items() if k not in ('record_hash', 'signature_hex')}
    encoded = canonical(unsigned)
    check(hashlib.sha256(DOMAIN + encoded).hexdigest() == record['record_hash'],
          'DKN_V02_SAM_COMMITMENT_MISMATCH')
    _verify_sig(record['signer_public_key_hex'], SIGN_DOMAIN + encoded, record['signature_hex'])
    return {'record_hash': record['record_hash'], 'kind': record['kind'], 'signature': 'PASS',
            'asserted_fact': 'NOT_ESTABLISHED', 'recognition': 'NOT_EVALUATED', **BOUNDARY}


def _records(records: list, kind: str, *, maximum=MAX_RECORDS) -> list:
    check(type(records) is list and len(records) <= maximum, 'DKN_V02_SAM_LIMIT')
    canonical(records)
    ids = set()
    for record in records:
        verify_record(record, expected_kind=kind)
        check(record['record_hash'] not in ids, 'DKN_V02_SAM_DUPLICATE')
        ids.add(record['record_hash'])
    return sorted(records, key=lambda r: r['record_hash'])


def _time(at_time: int) -> None:
    check(type(at_time) is int and 0 <= at_time < 2**63, 'DKN_V02_SAM_TIME_INVALID')


def _domains(rows: list[dict], dimension: str) -> set[str]:
    return {r['domain_id'] for r in rows if r['dimension'] == dimension}


def independent_subset(keys: list[str], actors: dict, count: int, dimensions: list[str]) -> list[str] | None:
    """At most 16 choose 8 trials. Only caller policy declares actor domains."""
    if len(keys) < count:
        return None
    for selected in combinations(sorted(set(keys)), count):
        good = True
        for dimension in dimensions:
            groups = [_domains(actors[k]['fault_domains'], dimension) for k in selected]
            if any(not g for g in groups) or any(a & b for a, b in combinations(groups, 2)):
                good = False
                break
        if good:
            return list(selected)
    return None


def _finish(result: dict, label='assessment') -> dict:
    return {**result, 'report_hash': sam_hash(label, result)}


def evaluate(descriptor: dict, contract: dict, evidence: list[dict],
             policy: dict, context: dict) -> dict:
    """Evaluate finite signed-evidence obligations against a caller-pinned policy.

    Entire input is bounded to canonical MAX_META. Unknown decision rules refuse.
    Invalid signatures refuse, unrecognized signers cannot satisfy requirements.
    Evidence and time are explicit; no implicit clock, network, or trust store.
    """
    canonical([descriptor, contract, evidence, policy, context])
    verify_record(descriptor, expected_kind='substrate')
    validate('contract', contract); validate('policy', policy); validate('context', context)
    check(contract['decision_rule'] == 'evidence-obligations-v1', 'DKN_V02_SAM_RULE_UNSUPPORTED')
    check(contract['scope']['substrate_ref'] == descriptor['record_hash'], 'DKN_V02_SAM_SCOPE_MISMATCH')
    records = _records(evidence, 'evidence')
    at = context['at_time']; body = descriptor['body']
    actors = {r['public_key_hex']: r for r in policy['observers']}
    recognized = descriptor['signer_public_key_hex'] in policy['descriptor_signers']
    intervals = (body, contract)
    expired = [name for name, value in zip(('descriptor', 'contract'), intervals)
               if not value['valid_from'] <= at < value['valid_until']]
    eligible = []
    excluded = []
    for record in records:
        b = record['body']; signer = record['signer_public_key_hex']
        if b['scope'] != contract['scope']:
            reason = 'SCOPE_MISMATCH'
        elif signer not in actors or b['predicate'] not in actors[signer]['predicates']:
            reason = 'OBSERVER_NOT_RECOGNIZED_FOR_PREDICATE'
        elif not b['observed_at'] <= at < b['valid_until']:
            reason = 'OUTSIDE_VALIDITY'
        else:
            eligible.append(record)
            continue
        excluded.append({'evidence_ref': record['record_hash'], 'reason': reason})
    checks = []
    any_negative = False
    independence_used = False
    for requirement in sorted(contract['requirements'], key=lambda r: r['id']):
        relevant = [r for r in eligible if r['body']['predicate'] == requirement['predicate']
                    and r['body']['method'] in requirement['methods']
                    and at-r['body']['observed_at'] <= requirement['max_age_seconds']]
        supports = [r for r in relevant if r['body']['outcome'] == 'SUPPORTS']
        refutes = [r for r in relevant if r['body']['outcome'] == 'REFUTES']
        keys = sorted({r['signer_public_key_hex'] for r in supports})
        subset = independent_subset(keys, actors, requirement['min_signers'], requirement['independence_dimensions'])
        status = 'CONTRADICTED' if refutes else ('SATISFIES' if subset is not None else 'INSUFFICIENT')
        any_negative |= bool(refutes)
        if subset is not None and requirement['independence_dimensions']:
            independence_used = True
        checks.append({'id': requirement['id'], 'status': status,
                       'eligible_supporting_signers': keys, 'selected_signers': subset or [],
                       'support_refs': sorted(r['record_hash'] for r in supports),
                       'refutation_refs': sorted(r['record_hash'] for r in refutes),
                       'independence_basis': 'CALLER_POLICY_LABELS_ONLY' if requirement['independence_dimensions'] else 'NOT_REQUIRED',
                       'max_age_seconds': requirement['max_age_seconds']})
    requested = {}
    conflicts = []
    accepted = {r['id']: r['value'] for r in context['accepted_premises']}
    for source in (body, contract):
        for p in source['assumptions']:
            if p['id'] in requested and requested[p['id']] != p['value']:
                conflicts.append(p['id'])
            requested[p['id']] = p['value']
    for name, value in requested.items():
        if name in accepted and accepted[name] != value:
            conflicts.append(name)
    premises = [{'id': name, 'expected': value,
                 'basis': 'CALLER_ACCEPTED_NOT_PROVEN' if accepted.get(name) == value and name in accepted else 'UNRESOLVED'}
                for name, value in sorted(requested.items())]
    if independence_used:
        premises.append({'id': 'policy-fault-domains-accurate', 'expected': True, 'basis': 'NOT_PROVEN'})
    limitations = ['SIGNED_ASSERTIONS_ARE_NOT_PROOFS_OF_THEIR_TRUTH',
                   'NO_GLOBAL_FRESHNESS_OR_COMPLETENESS', 'NO_FUTURE_AVAILABILITY_GUARANTEE',
                   'NO_CONSENSUS_PROTOCOL_VERIFIED', 'CALLER_SUPPLIED_CLOCK']
    if body['metadata_visibility'] == 'PUBLIC':
        limitations.append('PUBLIC_METADATA_EXPOSURE')
    if any_negative or conflicts:
        status = 'CONTRADICTED'
    elif expired or not recognized or body['deployment_status'] == 'TEMPLATE' or any(c['status'] == 'INSUFFICIENT' for c in checks):
        status = 'INSUFFICIENT'
    elif premises:
        status = 'CONDITIONAL'
    else:
        status = 'SATISFIES'
    return _finish({'schema': 'dkn.assurance-assessment.'+V, 'status': status,
                    'conclusion_scope': 'SUPPLIED_EVIDENCE_OBLIGATIONS_UNDER_CALLER_POLICY',
                    'operational_guarantee': 'NOT_ESTABLISHED_BY_THIS_EVALUATOR',
                    'descriptor_ref': descriptor['record_hash'],
                    'contract_ref': sam_hash('contract', contract), 'policy_ref': sam_hash('policy', policy),
                    'context_ref': sam_hash('context', context), 'at_time': at,
                    'descriptor_recognized_under_policy': recognized,
                    'invalid_time_scopes': expired, 'checks': checks,
                    'evidence_refs': sorted(r['record_hash'] for r in records),
                    'excluded_evidence': excluded, 'premises': premises,
                    'conflicting_premises': sorted(set(conflicts)), 'limitations': limitations, **BOUNDARY})


def compose(descriptors: list[dict], *, roots: list[str], at_time: int) -> dict:
    """All-of composition of *declared* deployments; not an availability calculator.

    Transitive dependency overlap is retained even where domain labels are absent.
    Missing domain dimensions never imply independence.
    """
    canonical([descriptors, roots, at_time]); _time(at_time)
    records = _records(descriptors, 'substrate', maximum=64)
    check(type(roots) is list and 1 <= len(roots) <= 16 and all(type(r) is str for r in roots), 'DKN_V02_SAM_LIMIT')
    check(len(set(roots)) == len(roots), 'DKN_V02_SAM_DUPLICATE')
    by_id = {r['record_hash']: r for r in records}
    check(all(r in by_id for r in roots), 'DKN_V02_SAM_ROOT_MISSING')
    closures = {}; missing = set()
    for root in sorted(roots):
        seen = set(); pending = [root]
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            seen.add(current)
            if current not in by_id:
                missing.add(current)
                continue
            pending.extend(by_id[current]['body']['dependencies'])
        closures[root] = seen
    used = set().union(*closures.values()) & by_id.keys()
    pairs = []
    for left, right in combinations(sorted(roots), 2):
        domains = {}
        unknown = []
        for dimension in FAULT_DIMENSIONS:
            def collect(root):
                return set().union(*[_domains(by_id[r]['body']['fault_domains'], dimension)
                                     for r in closures[root] if r in by_id])
            a, b = collect(left), collect(right)
            if a & b:
                domains[dimension] = sorted(a & b)
            if any(r not in by_id or not _domains(by_id[r]['body']['fault_domains'], dimension)
                   for r in closures[left] | closures[right]):
                unknown.append(dimension)
        pairs.append({'left': left, 'right': right, 'shared_fault_domains': domains,
                      'shared_dependencies': sorted(closures[left] & closures[right]),
                      'incomplete_domain_dimensions': unknown})
    assumptions = {}
    for ref in sorted(used):
        for p in by_id[ref]['body']['assumptions']:
            assumptions.setdefault(p['id'], {}).setdefault(str(p['value']).lower(), []).append(ref)
    conflicts = {name: values for name, values in assumptions.items() if len(values) > 1}
    invalid_time = sorted(ref for ref in used if not by_id[ref]['body']['valid_from'] <= at_time < by_id[ref]['body']['valid_until'])
    exposures = sorted(ref for ref in used if by_id[ref]['body']['metadata_visibility'] == 'PUBLIC')
    known_overlap = any(p['shared_fault_domains'] or p['shared_dependencies'] for p in pairs)
    state = 'DECLARED_CONFLICTS_DETECTED' if conflicts or known_overlap else ('INCOMPLETE' if missing or invalid_time else 'NO_DECLARED_CONFLICTS_WITHIN_SCOPE')
    return _finish({'schema': 'dkn.substrate-composition.'+V, 'status': state, 'mode': 'ALL_OF',
                    'at_time': at_time, 'roots': sorted(roots), 'descriptor_refs': sorted(by_id),
                    'unused_descriptor_refs': sorted(set(by_id)-used),
                    'closures': {r: sorted(v) for r, v in closures.items()},
                    'missing_dependencies': sorted(missing), 'invalid_time_scopes': invalid_time,
                    'pairs': pairs, 'conflicting_assumptions': conflicts,
                    'public_metadata_descriptors': exposures,
                    'independence': 'NOT_ESTABLISHED', 'availability': 'NOT_COMPUTED',
                    'descriptor_signature_scope': 'DECLARATIONS_ONLY', **BOUNDARY}, 'composition')
