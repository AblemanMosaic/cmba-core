"""Closed read-only lifecycle ABI. No keys to sign with, paths, plugins or network."""
from .core import canonical, check, exact, Refusal
from . import lifecycle as lc
from .lifecycle_schemas import validate_shape


def dispatch(request: dict) -> dict:
    canonical(request)
    exact(request, {'schema','operation','arguments'}, 'DKN_LC_REQUEST_INVALID')
    check(request['schema']=='dkn.lifecycle-request.v0.2-f1','DKN_LC_REQUEST_INVALID')
    operation,arguments=request['operation'],request['arguments']
    check(type(operation) is str, 'DKN_LC_OPERATION_UNSUPPORTED')
    journal={'genesis','policy','events'}
    reader={'expected_namespace','expected_head','now','max_checkpoint_age','checkpoint','minimum'}
    if operation=='verify-policy':
        exact(arguments,{'policy'},'DKN_LC_ARGUMENT_INVALID')
        result=lc.validate_policy(**arguments);kind='policy-verification'
    elif operation=='verify-journal':
        exact(arguments,journal,'DKN_LC_ARGUMENT_INVALID')
        result=lc.verify_journal(**arguments);kind='state'
    elif operation=='analyze-journals':
        exact(arguments,{'genesis','policy','chains'},'DKN_LC_ARGUMENT_INVALID')
        result=lc.analyze_journals(**arguments);kind='forks'
    elif operation=='assess-delegation':
        exact(arguments,journal|reader|{'subject_public_key_hex','artifact_root','operation'},'DKN_LC_ARGUMENT_INVALID')
        result=lc.assess_delegation(**arguments);kind='assessment'
    elif operation=='assess-certificate':
        exact(arguments,journal|reader|{'certificate','manifest'},'DKN_LC_ARGUMENT_INVALID')
        result=lc.assess_certificate(**arguments);kind='assessment'
    else:
        raise Refusal('DKN_LC_OPERATION_UNSUPPORTED')
    return validate_shape(kind,result)
