"""Transactional local vault for cooperating clients on a trusted local filesystem.

SQLite is the serialization/crash-recovery mechanism, not an authentication authority.
Every exposed artifact/namespace is reverified. Host/root compromise, old whole-database
restores, hostile filesystem races, NFS locking and power-loss durability are not proven.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import sqlite3
import stat
from contextlib import contextmanager
from typing import Any, Iterator

from .core import (Refusal, canonical, read_canonical, check, exact, hex32,
                   read_bounded_file, MAX_META, MAX_TRANSPORT)
from .navigation import (LocalIndex, inspect, _envelope, MAX_SCAN, MAX_SCAN_BYTES)
from .lifecycle import verify_journal, MAX_EVENTS

APP_ID = 0x444B4E46
FORMAT_VERSION = 1
MAX_DB_BYTES = 1024 * 1024 * 1024
MAX_NAMESPACES = 1024
MAX_IMPORT = 256
SQL = {
    'meta': 'CREATE TABLE meta (singleton INTEGER PRIMARY KEY CHECK(singleton=1), revision INTEGER NOT NULL CHECK(revision>=0))',
    'artifacts': 'CREATE TABLE artifacts (root TEXT PRIMARY KEY NOT NULL, archive BLOB NOT NULL, envelope BLOB NOT NULL)',
    'namespaces': 'CREATE TABLE namespaces (root TEXT PRIMARY KEY NOT NULL, bundle BLOB NOT NULL)'
}
BUNDLE_KEYS = {'schema', 'logical_root', 'transport_sha256', 'certificate', 'relations', 'genesis', 'transitions'}


def _local_path(value: str | Path) -> Path:
    check(isinstance(value, (str, Path)), 'DKN_VAULT_PATH_INVALID')
    text = str(value)
    check(0 < len(text) <= 4096 and '\x00' not in text, 'DKN_VAULT_PATH_INVALID')
    try:
        return Path(os.path.abspath(text))
    except (OSError, ValueError) as error:
        raise Refusal('DKN_VAULT_PATH_INVALID') from error


def _database_error(error: sqlite3.Error) -> Refusal:
    code = getattr(error, 'sqlite_errorcode', 0) & 255
    if code in (sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED):
        return Refusal('DKN_VAULT_BUSY')
    if code in (sqlite3.SQLITE_CORRUPT, sqlite3.SQLITE_NOTADB, sqlite3.SQLITE_SCHEMA, sqlite3.SQLITE_ERROR):
        return Refusal('DKN_VAULT_INVALID')
    if code in (sqlite3.SQLITE_TOOBIG, sqlite3.SQLITE_FULL, sqlite3.SQLITE_INTERRUPT):
        return Refusal('DKN_VAULT_LIMIT')
    return Refusal('DKN_VAULT_IO_ERROR')


def _verified(root: str, raw: bytes, encoded: bytes) -> tuple[dict, dict]:
    hex32(root)
    check(type(raw) is bytes and len(raw) <= MAX_TRANSPORT and type(encoded) is bytes and
          len(encoded) <= MAX_META, 'DKN_VAULT_LIMIT')
    bundle = read_canonical(encoded)
    exact(bundle, BUNDLE_KEYS, 'DKN_VAULT_INVALID')
    check(bundle['schema'] == 'dkn.nav-bundle.v0.2-candidate' and bundle['logical_root'] == root,
          'DKN_VAULT_IDENTITY_MISMATCH')
    check(hashlib.sha256(raw).hexdigest() == bundle['transport_sha256'], 'DKN_VAULT_TRANSPORT_MISMATCH')
    report = inspect(raw, certificate=bundle['certificate'], relations=bundle['relations'],
                     genesis=bundle['genesis'], transitions=bundle['transitions'])
    check(report['logical_root'] == root, 'DKN_VAULT_IDENTITY_MISMATCH')
    return bundle, report


def _namespace_bundle(encoded: bytes, root: str) -> tuple[dict, dict]:
    bundle = read_canonical(encoded)
    exact(bundle, {'schema', 'genesis', 'policy', 'events'}, 'DKN_VAULT_NAMESPACE_INVALID')
    check(bundle['schema'] == 'dkn.vault-namespace.v0.2-f1', 'DKN_VAULT_NAMESPACE_INVALID')
    report = verify_journal(bundle['genesis'], bundle['policy'], bundle['events'])
    check(report['namespace_root'] == root, 'DKN_VAULT_IDENTITY_MISMATCH')
    return bundle, report


class _Snapshot(LocalIndex):
    """Reuse bounded navigation over a detached, already verified SQLite snapshot."""
    def __init__(self, records: dict[str, dict]):
        self.records = records

    def _roots(self):
        return sorted(self.records)

    def _scan_budget(self, roots):
        # Enforced from stored lengths before blob retrieval, in one read transaction.
        return None

    def resolve_exact(self, logical_root):
        hex32(logical_root)
        check(logical_root in self.records, 'DKN_V02_NAV_NOT_FOUND')
        return self.records[logical_root]


class TransactionalVault:
    """Explicit create/write APIs; read calls do not advance namespace recognition.

    Open is deliberately not create. Concurrent writers use BEGIN IMMEDIATE; readers
    materialize one committed snapshot. No SQL or filesystem paths from metadata execute.
    """
    def __init__(self, path: str | Path, *, busy_timeout_ms: int = 1000):
        check(isinstance(path, (str, Path)), 'DKN_VAULT_PATH_INVALID')
        check(type(busy_timeout_ms) is int and 0 <= busy_timeout_ms <= 30000, 'DKN_VAULT_LIMIT')
        self.path = _local_path(path)
        self.busy_timeout_ms = busy_timeout_ms
        self._guard()

    @classmethod
    def create(cls, path: str | Path, *, busy_timeout_ms: int = 1000) -> 'TransactionalVault':
        check(isinstance(path, (str, Path)), 'DKN_VAULT_PATH_INVALID')
        check(type(busy_timeout_ms) is int and 0 <= busy_timeout_ms <= 30000, 'DKN_VAULT_LIMIT')
        target = _local_path(path)
        # Caller creates/chooses the parent; do not invent a custody hierarchy.
        cls._guard_path(target, allow_missing=True)
        connection = None
        created = False
        try:
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            os.close(fd); created = True
            connection = sqlite3.connect(str(target), isolation_level=None, timeout=busy_timeout_ms / 1000)
            connection.execute('PRAGMA journal_mode=DELETE')
            connection.execute('PRAGMA synchronous=FULL')
            connection.execute('BEGIN IMMEDIATE')
            for statement in SQL.values():
                connection.execute(statement)
            connection.execute('INSERT INTO meta VALUES (1,0)')
            connection.execute(f'PRAGMA application_id={APP_ID}')
            connection.execute(f'PRAGMA user_version={FORMAT_VERSION}')
            connection.execute('COMMIT')
        except FileExistsError as error:
            raise Refusal('DKN_VAULT_EXISTS') from error
        except sqlite3.Error as error:
            raise _database_error(error) from error
        except OSError as error:
            raise Refusal('DKN_VAULT_IO_ERROR') from error
        finally:
            if connection is not None:
                connection.close()
        # On a failed creation, an owned incomplete file may remain. Never silently
        # delete it or another client's file. Open will refuse its missing schema.
        check(created, 'DKN_VAULT_IO_ERROR')
        return cls(target, busy_timeout_ms=busy_timeout_ms)

    @staticmethod
    def _guard_path(path: Path, *, allow_missing=False):
        try:
            for parent in path.parents:
                check(not parent.is_symlink() and parent.is_dir(), 'DKN_VAULT_PATH_INVALID')
            for candidate in (path, Path(str(path) + '-journal'), Path(str(path) + '-wal'), Path(str(path) + '-shm')):
                check(not candidate.is_symlink(), 'DKN_VAULT_PATH_INVALID')
                try:
                    info = candidate.stat(follow_symlinks=False)
                except FileNotFoundError:
                    if candidate == path and not allow_missing:
                        raise Refusal('DKN_VAULT_NOT_FOUND')
                    continue
                check(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'DKN_VAULT_PATH_INVALID')
                check(info.st_size <= MAX_DB_BYTES, 'DKN_VAULT_LIMIT')
                if os.name == 'posix':
                    check(info.st_uid == os.geteuid() and not info.st_mode & 0o022, 'DKN_VAULT_CUSTODY_INVALID')
        except OSError as error:
            raise Refusal('DKN_VAULT_IO_ERROR') from error

    def _guard(self):
        self._guard_path(self.path)

    @contextmanager
    def _transaction(self, *, write: bool = False) -> Iterator[sqlite3.Connection]:
        self._guard()
        connection = None
        try:
            # mode=rw prevents missing-file auto-creation. Reads use query_only below;
            # SQLite may itself recover a hot journal, without advancing application state.
            connection = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True,
                                         isolation_level=None, timeout=self.busy_timeout_ms / 1000)
            connection.execute('PRAGMA trusted_schema=OFF')
            connection.execute('PRAGMA synchronous=FULL')
            connection.execute('PRAGMA foreign_keys=ON')
            connection.execute('PRAGMA read_uncommitted=OFF')
            connection.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, MAX_TRANSPORT + MAX_META + 65536)
            connection.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
            connection.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 16384)
            connection.execute('PRAGMA max_page_count=262144')
            steps = [0]
            def budget():
                steps[0] += 1000
                return int(steps[0] > 1000000)
            connection.set_progress_handler(budget, 1000)
            if not write:
                connection.execute('PRAGMA query_only=ON')
            connection.execute('BEGIN IMMEDIATE' if write else 'BEGIN')
            self._validate_database(connection)
            yield connection
            if write:
                self._before_commit(connection)
            connection.execute('COMMIT')
        except sqlite3.Error as error:
            raise _database_error(error) from error
        finally:
            if connection is not None:
                # close() rolls back an uncommitted transaction on every exception,
                # including test fault injection, interrupts and application refusals.
                connection.close()

    def _before_commit(self, connection):
        """Private fault-injection seam, not a public plugin or execution interface."""
        return None

    @staticmethod
    def _validate_database(connection):
        check(connection.execute('PRAGMA application_id').fetchone()[0] == APP_ID and
              connection.execute('PRAGMA user_version').fetchone()[0] == FORMAT_VERSION,
              'DKN_VAULT_VERSION_UNSUPPORTED')
        check(connection.execute('PRAGMA journal_mode').fetchone()[0] == 'delete', 'DKN_VAULT_JOURNAL_UNSUPPORTED')
        all_schema = connection.execute("SELECT type,name,sql FROM sqlite_master").fetchall()
        schema = []
        for kind, name, sql in all_schema:
            if name in ('sqlite_autoindex_artifacts_1', 'sqlite_autoindex_namespaces_1'):
                check(kind == 'index' and sql is None, 'DKN_VAULT_SCHEMA_INVALID')
            else:
                schema.append((kind, name, sql))
        check(len(schema) == len(SQL) and all(kind == 'table' and name in SQL and sql == SQL[name]
                                            for kind, name, sql in schema), 'DKN_VAULT_SCHEMA_INVALID')
        meta = connection.execute('SELECT singleton,revision FROM meta').fetchmany(2)
        check(len(meta) == 1 and meta[0][0] == 1 and type(meta[0][1]) is int and 0 <= meta[0][1] < 2**63-1,
              'DKN_VAULT_INVALID')

    @staticmethod
    def _revision(connection) -> int:
        return connection.execute('SELECT revision FROM meta WHERE singleton=1').fetchone()[0]

    @staticmethod
    def _bump(connection) -> int:
        connection.execute('UPDATE meta SET revision=revision+1 WHERE singleton=1')
        return TransactionalVault._revision(connection)

    def put_artifact(self, raw: bytes, *, certificate=None, relations=None, genesis=None, transitions=None) -> dict:
        bundle = _envelope(raw, certificate, relations, genesis, transitions)
        encoded = canonical(bundle); root = bundle['logical_root']
        with self._transaction(write=True) as connection:
            existing = connection.execute('SELECT length(archive),length(envelope) FROM artifacts WHERE root=?', (root,)).fetchone()
            if existing is not None:
                check(existing == (len(raw), len(encoded)), 'DKN_VAULT_EXISTS')
                stored = connection.execute('SELECT archive,envelope FROM artifacts WHERE root=?', (root,)).fetchone()
                check(stored == (raw, encoded), 'DKN_VAULT_EXISTS')
                revision = self._revision(connection); status = 'ALREADY_PRESENT'
            else:
                count, total = connection.execute('SELECT count(*),coalesce(sum(length(archive)+length(envelope)),0) FROM artifacts').fetchone()
                check(count < MAX_SCAN and total + len(raw) + len(encoded) <= MAX_SCAN_BYTES, 'DKN_VAULT_LIMIT')
                connection.execute('INSERT INTO artifacts VALUES (?,?,?)', (root, raw, encoded))
                revision = self._bump(connection); status = 'STORED'
        return {'schema': 'dkn.vault-write.v0.2-f1', 'status': status, 'logical_root': root,
                'revision': revision, 'authority_effect': 'NONE'}

    def _snapshot(self, only_root: str | None = None):
        if only_root is not None:
            hex32(only_root)
        with self._transaction() as connection:
            revision = self._revision(connection)
            where, params = ('', ()) if only_root is None else (' WHERE root=?', (only_root,))
            count, total, largest, metadata = connection.execute(
                'SELECT count(*),coalesce(sum(length(archive)+length(envelope)),0),'
                'coalesce(max(length(archive)),0),coalesce(max(length(envelope)),0) FROM artifacts' + where, params).fetchone()
            check(count <= MAX_SCAN and total <= MAX_SCAN_BYTES and largest <= MAX_TRANSPORT and metadata <= MAX_META,
                  'DKN_VAULT_LIMIT')
            rows = connection.execute('SELECT root,archive,envelope FROM artifacts' + where + ' ORDER BY root', params).fetchall()
        # Detached immutable bytes come from a single SQLite snapshot; signatures,
        # content roots and relation bindings are never trusted from SQL columns.
        records = {}
        for root, raw, encoded in rows:
            _, records[root] = _verified(root, raw, encoded)
        return revision, records, rows

    def _query(self, operation: str, arguments: dict) -> dict:
        only = arguments['logical_root'] if operation == 'resolve_exact' else None
        revision, records, _ = self._snapshot(only)
        result = getattr(_Snapshot(records), operation)(**arguments)
        output = {'schema': 'dkn.vault-query.v0.2-f1', 'snapshot_revision': revision,
                  'snapshot_scope': 'ONE_LOCAL_COMMITTED_DATABASE_VIEW', 'result': result,
                  'authority_effect': 'NONE'}
        canonical(output)
        return output

    def resolve_exact(self, logical_root: str) -> dict:
        return self._query('resolve_exact', {'logical_root': logical_root})

    def discover(self, *, semantic_name=None, namespace_root=None, signer_public_key_hex=None, limit=64) -> dict:
        return self._query('discover', dict(semantic_name=semantic_name, namespace_root=namespace_root,
                                           signer_public_key_hex=signer_public_key_hex, limit=limit))

    def traverse(self, logical_root: str, *, direction='outgoing', max_depth=3, max_nodes=128) -> dict:
        return self._query('traverse', dict(logical_root=logical_root, direction=direction,
                                           max_depth=max_depth, max_nodes=max_nodes))

    def read_artifact(self, logical_root: str) -> tuple[bytes, dict]:
        _, records, rows = self._snapshot(logical_root)
        check(logical_root in records, 'DKN_V02_NAV_NOT_FOUND')
        return rows[0][1], read_canonical(rows[0][2])

    def advance_namespace(self, genesis: dict, policy: dict, events: list[dict], *, expected_head: str | None) -> dict:
        """Explicit caller-selected local continuity pin, compare-and-swap plus ancestry.

        The caller chooses the initial branch. No automatic fork resolution or grant.
        """
        encoded = canonical({'schema': 'dkn.vault-namespace.v0.2-f1', 'genesis': genesis,
                             'policy': policy, 'events': events})
        bundle = read_canonical(encoded)
        report = verify_journal(bundle['genesis'], bundle['policy'], bundle['events'])
        root = report['namespace_root']
        if expected_head is not None:
            hex32(expected_head)
        with self._transaction(write=True) as connection:
            length = connection.execute('SELECT length(bundle) FROM namespaces WHERE root=?', (root,)).fetchone()
            previous = None
            if length is not None:
                check(length[0] <= MAX_META, 'DKN_VAULT_LIMIT')
                previous, prior = _namespace_bundle(connection.execute('SELECT bundle FROM namespaces WHERE root=?', (root,)).fetchone()[0], root)
                check(expected_head == prior['head_ref'], 'DKN_VAULT_CAS_CONFLICT')
                check(bundle['genesis'] == previous['genesis'] and bundle['policy'] == previous['policy'], 'DKN_VAULT_IDENTITY_MISMATCH')
                refs = [report['anchor_ref']] + [event['event_ref'] for event in bundle['events']]
                check(prior['sequence'] <= report['sequence'] and refs[prior['sequence']] == prior['head_ref'], 'DKN_VAULT_ROLLBACK_OR_FORK')
                if report['head_ref'] == prior['head_ref']:
                    return {'schema': 'dkn.vault-pin.v0.2-f1', 'status': 'ALREADY_PINNED', 'namespace_root': root,
                            'head_ref': prior['head_ref'], 'sequence': prior['sequence'],
                            'revision': self._revision(connection), 'authority_effect': 'NONE'}
                total = connection.execute('SELECT coalesce(sum(length(bundle)),0) FROM namespaces').fetchone()[0]
                check(total - length[0] + len(encoded) <= MAX_SCAN_BYTES, 'DKN_VAULT_LIMIT')
                connection.execute('UPDATE namespaces SET bundle=? WHERE root=?', (encoded, root))
            else:
                check(expected_head is None, 'DKN_VAULT_CAS_CONFLICT')
                count, total = connection.execute('SELECT count(*),coalesce(sum(length(bundle)),0) FROM namespaces').fetchone()
                check(count < MAX_NAMESPACES and total + len(encoded) <= MAX_SCAN_BYTES, 'DKN_VAULT_LIMIT')
                connection.execute('INSERT INTO namespaces VALUES (?,?)', (root, encoded))
            revision = self._bump(connection)
        return {'schema': 'dkn.vault-pin.v0.2-f1', 'status': 'PIN_ADVANCED', 'namespace_root': root,
                'head_ref': report['head_ref'], 'sequence': report['sequence'], 'revision': revision,
                'authority_effect': 'NONE'}

    def read_namespace(self, namespace_root: str) -> dict:
        hex32(namespace_root)
        with self._transaction() as connection:
            revision = self._revision(connection)
            row = connection.execute('SELECT length(bundle) FROM namespaces WHERE root=?', (namespace_root,)).fetchone()
            check(row is not None, 'DKN_VAULT_NOT_FOUND'); check(row[0] <= MAX_META, 'DKN_VAULT_LIMIT')
            encoded = connection.execute('SELECT bundle FROM namespaces WHERE root=?', (namespace_root,)).fetchone()[0]
        bundle, report = _namespace_bundle(encoded, namespace_root)
        output = {'schema': 'dkn.vault-namespace-read.v0.2-f1', 'snapshot_revision': revision,
                  'bundle': bundle, 'state': report, 'authority_effect': 'NONE'}
        canonical(output)
        return output

    def import_local_index(self, source: str | Path) -> dict:
        """Explicit all-or-nothing import into an empty artifact table. Source must be quiescent."""
        index = LocalIndex(_local_path(source))
        index._guard()
        check(index.root.is_dir(), 'DKN_VAULT_IMPORT_INCOMPLETE')
        roots = index._roots()
        check(len(roots) <= MAX_IMPORT, 'DKN_VAULT_LIMIT')
        index._scan_budget(roots)
        expected_objects = {root + '.zip' for root in roots}
        expected_metadata = {root + '.json' for root in roots}
        try:
            for directory, expected in ((index.objects, expected_objects), (index.metadata, expected_metadata)):
                present = set()
                if directory.exists():
                    for number, entry in enumerate(directory.iterdir(), 1):
                        check(number <= MAX_IMPORT, 'DKN_VAULT_LIMIT')
                        check(not entry.is_symlink() and entry.is_file(), 'DKN_VAULT_IMPORT_INCOMPLETE')
                        present.add(entry.name)
                check(present == expected, 'DKN_VAULT_IMPORT_INCOMPLETE')
            rows = []
            for root in roots:
                raw = read_bounded_file(index.objects / (root + '.zip'), MAX_TRANSPORT)
                encoded = read_bounded_file(index.metadata / (root + '.json'), MAX_META)
                _verified(root, raw, encoded)
                rows.append((root, raw, encoded))
            check(index._roots() == roots, 'DKN_VAULT_SOURCE_CHANGED')
            # A second exact read detects observed source mutation, not a hostile-writer-proof snapshot.
            for root, raw, encoded in rows:
                check(read_bounded_file(index.objects / (root + '.zip'), MAX_TRANSPORT) == raw and
                      read_bounded_file(index.metadata / (root + '.json'), MAX_META) == encoded,
                      'DKN_VAULT_SOURCE_CHANGED')
        except OSError as error:
            raise Refusal('DKN_VAULT_IO_ERROR') from error
        check(sum(len(raw)+len(encoded) for _,raw,encoded in rows) <= MAX_SCAN_BYTES, 'DKN_VAULT_LIMIT')
        with self._transaction(write=True) as connection:
            check(connection.execute('SELECT count(*) FROM artifacts').fetchone()[0] == 0, 'DKN_VAULT_IMPORT_DESTINATION_NOT_EMPTY')
            connection.executemany('INSERT INTO artifacts VALUES (?,?,?)', rows)
            revision = self._bump(connection) if rows else self._revision(connection)
        return {'schema': 'dkn.vault-import.v0.2-f1', 'status': 'IMPORTED', 'artifacts': len(rows),
                'revision': revision, 'source_modified': False, 'source_snapshot': 'QUIESCENT_SOURCE_REQUIRED',
                'authority_effect': 'NONE'}
