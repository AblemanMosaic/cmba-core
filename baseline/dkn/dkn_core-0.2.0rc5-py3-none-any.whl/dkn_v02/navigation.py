"""DKN v0.2 candidate: bounded offline navigation over independently verified archives.

Indexes are discovery aids, not authorities. No networking, global freshness, or
completeness claims. Relations are signed *claims*, never established truths.
"""
from __future__ import annotations
import hashlib
import io
import os
import re
import stat
import zipfile
from collections import deque
from pathlib import Path
from typing import Any

from .core import (Refusal, canonical, read_canonical, check, exact, hex32,
                   verify_archive, verify_certificate, verify_dimension,
                   verify_genesis, verify_transitions, digest, read_bounded_file, MAX_META, MAX_TRANSPORT)

RELATION_SCHEMA = 'dkn.relations.v0.2-candidate'
RELATION_TYPES = frozenset(('depends_on', 'derived_from', 'supersedes', 'attests',
                            'governed_by', 'published_at', 'witnesses'))
MAX_EDGES = 128
MAX_RESULTS = 256
MAX_HOPS = 8
MAX_SCAN = 4096
MAX_SCAN_BYTES = 512 * 1024 * 1024
MAX_REPORT_EDGES = 4096


def validate_relations(relations: Any) -> list[dict]:
    check(type(relations) is list and len(relations) <= MAX_EDGES, 'DKN_V02_NAV_LIMIT')
    canonical(relations)
    seen = set()
    for e in relations:
        exact(e, {'schema','relation_type','destination','scope'})
        check(e['schema'] == RELATION_SCHEMA and type(e['relation_type']) is str and e['relation_type'] in RELATION_TYPES,
              'DKN_V02_RELATION_UNSUPPORTED')
        hex32(e['destination'])
        check(type(e['scope']) is str and 0 < len(e['scope']) <= 256,
              'DKN_V02_RELATION_INVALID')
        key = (e['relation_type'],e['destination'],e['scope'])
        check(key not in seen, 'DKN_V02_RELATION_DUPLICATE')
        seen.add(key)
    return sorted(relations, key=lambda e: (e['relation_type'],e['destination'],e['scope']))


def relation_commitment(relations: list[dict]) -> dict:
    from .core import commit
    return commit('relations', RELATION_SCHEMA, validate_relations(relations))


def _unpack_checked(raw: bytes) -> tuple[dict, dict]:
    report = verify_archive(raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        manifest = read_canonical(z.read('.dkn/manifest.json'))
    return report, manifest


def inspect(raw: bytes, *, certificate: dict | None = None,
            relations: list[dict] | None = None, genesis: dict | None = None,
            transitions: list[dict] | None = None) -> dict:
    """Evaluate a complete supplied evidence bundle. Fail closed on invalid evidence."""
    archive_result, manifest = _unpack_checked(raw)
    signature = 'NOT_CHECKED'
    signer = None
    namespace_root = None
    if certificate is not None:
        verify_certificate(certificate,manifest)
        signature = 'PASS'
        signer = certificate['signer_public_key_hex']
        namespace_root = certificate['namespace_root']
    rels = []
    relation_binding = 'NOT_CHECKED'
    relation_authentication = 'NOT_ESTABLISHED'
    if relations is not None:
        rels = validate_relations(relations)
        commitments = [d for d in manifest['dimensions'] if d['dimension_id']=='relations']
        check(len(commitments)==1 and commitments[0]['schema_id']==RELATION_SCHEMA,
              'DKN_V02_RELATION_UNBOUND')
        verify_dimension(commitments[0],rels,supplied=True)
        relation_binding = 'PASS'
        relation_authentication = 'PASS' if signature=='PASS' else 'NOT_ESTABLISHED'
    namespace_signature = 'NOT_CHECKED'
    namespace_authorization = 'NOT_ESTABLISHED'
    semantic_name = None
    fork_scope = 'NOT_CHECKED'
    if transitions is not None and genesis is None:
        raise Refusal('DKN_V02_NAV_LINEAGE_MISSING')
    if genesis is not None:
        verify_genesis(genesis)
        namespace_signature = 'PASS'
        semantic_name = genesis['semantic_name']
        check(namespace_root is None or namespace_root == genesis['namespace_root'],
              'DKN_V02_NAV_NAMESPACE_MISMATCH')
        if transitions is not None:
            lineage = verify_transitions(genesis,transitions)
            active = lineage['active_key']
            fork_scope = 'SUPPLIED_CHAIN_ONLY'
        else:
            active = genesis['founder_public_key_hex']
        if signer is not None and namespace_root == genesis['namespace_root'] and signer == active:
            namespace_authorization = 'PASS_FOR_SUPPLIED_CHAIN_ONLY'
    return {
        'schema':'dkn.navigation-inspection.v0.2-candidate',
        'logical_root':archive_result['logical_root'],
        'transport_sha256':archive_result['transport_sha256'],
        'integrity':'PASS','certificate_signature':signature,
        'relation_binding':relation_binding,
        'relation_authentication':relation_authentication,
        'relations':rels,'namespace_root':namespace_root,
        'namespace_signature':namespace_signature,
        'namespace_authorization':namespace_authorization,
        'semantic_name':semantic_name,'signer_public_key_hex':signer,
        'lineage_scope':fork_scope,
        'freshness':'NOT_ESTABLISHED','global_completeness':'NOT_ESTABLISHED',
        'authority_effect':'NONE',
    }


def _envelope(raw: bytes, certificate=None, relations=None, genesis=None, transitions=None) -> dict:
    # Only serializable evidence. Files are stored by exact logical root.
    report=inspect(raw,certificate=certificate,relations=relations,genesis=genesis,transitions=transitions)
    return {'schema':'dkn.nav-bundle.v0.2-candidate','logical_root':report['logical_root'],
            'transport_sha256':report['transport_sha256'], 'certificate':certificate,
            'relations':relations,'genesis':genesis,'transitions':transitions}


class LocalIndex:
    """Read-only verified views over a local mutable evidence directory.

    add() is a convenience single-writer operation, not a transactional or
    concurrency-safe store. Every read re-verifies archive and attached claims.
    """
    def __init__(self, root: str | Path):
        self.root = Path(os.path.abspath(root))
        self.objects = self.root / 'objects'
        self.metadata = self.root / 'evidence'

    def _guard(self) -> None:
        try:
            for path in (self.root, self.objects, self.metadata, *self.root.parents):
                check(not path.is_symlink(), 'DKN_V02_NAV_SYMLINK')
                try:
                    mode = path.stat(follow_symlinks=False).st_mode
                except FileNotFoundError:
                    continue  # an uncreated index is a valid empty local collection
                check(stat.S_ISDIR(mode), 'DKN_V02_NAV_INDEX_INVALID')
        except OSError as exc:
            raise Refusal('DKN_V02_NAV_IO_ERROR') from exc

    @staticmethod
    def _report(value: dict) -> dict:
        # All returned navigation reports must fit the protocol's canonical envelope.
        # Byte overflow refuses; finite edge-count truncation is explicit below.
        try:
            canonical(value)
        except Refusal as exc:
            if exc.code in ('DKN_V02_LIMIT', 'DKN_V02_DEPTH_LIMIT'):
                raise Refusal('DKN_V02_NAV_LIMIT') from exc
            raise
        return value

    def _scan_budget(self, roots) -> None:
        total=0
        for root in roots:
            for path in (self.objects/(root+'.zip'),self.metadata/(root+'.json')):
                try: total+=path.stat().st_size
                except OSError as exc:raise Refusal('DKN_V02_NAV_IO_ERROR') from exc
                check(total<=MAX_SCAN_BYTES,'DKN_V02_NAV_LIMIT')

    def add(self, raw: bytes, *, certificate: dict | None=None,
            relations: list[dict] | None=None, genesis: dict | None=None,
            transitions: list[dict] | None=None) -> dict:
        self._guard()
        bundle = _envelope(raw,certificate,relations,genesis,transitions)
        root = bundle['logical_root']
        try:
            self.objects.mkdir(parents=True,exist_ok=True)
            self.metadata.mkdir(parents=True,exist_ok=True)
            archive_path = self.objects / (root + '.zip')
            evidence_path = self.metadata / (root + '.json')
            # No overwrites: a different transport or evidence set requires explicit removal.
            check(not archive_path.exists() and not archive_path.is_symlink() and
                  not evidence_path.exists() and not evidence_path.is_symlink(), 'DKN_V02_NAV_EXISTS')
            # single-writer reference: interrupted writes can leave partial candidates;
            # readers fail closed on incomplete or corrupt content.
            with archive_path.open('xb') as f: f.write(raw)
            try:
                with evidence_path.open('xb') as f: f.write(canonical(bundle))
            except BaseException:
                archive_path.unlink(missing_ok=True)
                raise
        except OSError as exc:
            raise Refusal('DKN_V02_NAV_IO_ERROR') from exc
        return {'status':'INDEXED','logical_root':root,'authority_effect':'NONE'}

    def _roots(self) -> list[str]:
        self._guard()
        try:
            if not self.metadata.is_dir(): return []
            names=[]
            for count,p in enumerate(self.metadata.iterdir(),1):
                check(count<=MAX_SCAN,'DKN_V02_NAV_LIMIT')
                if p.is_symlink(): raise Refusal('DKN_V02_NAV_SYMLINK')
                if p.suffix == '.json':
                    check(re.fullmatch('[0-9a-f]{64}',p.stem) is not None,'DKN_V02_NAV_INDEX_INVALID')
                    names.append(p.stem)
            check(len(names)<=MAX_SCAN,'DKN_V02_NAV_LIMIT')
            return sorted(names)
        except OSError as exc:
            raise Refusal('DKN_V02_NAV_IO_ERROR') from exc

    def resolve_exact(self, logical_root: str) -> dict:
        hex32(logical_root)
        self._guard()
        try:
            ep=self.metadata/(logical_root+'.json')
            op=self.objects/(logical_root+'.zip')
            check(not ep.is_symlink() and not op.is_symlink(), 'DKN_V02_NAV_SYMLINK')
            check(ep.is_file() and op.is_file(),'DKN_V02_NAV_NOT_FOUND')
            check(ep.stat().st_size<=4*1024*1024 and op.stat().st_size<=300*1024*1024,
                  'DKN_V02_NAV_LIMIT')
            bundle=read_canonical(read_bounded_file(ep,MAX_META))
            exact(bundle,{'schema','logical_root','transport_sha256','certificate','relations','genesis','transitions'})
            check(bundle['schema']=='dkn.nav-bundle.v0.2-candidate' and
                  bundle['logical_root']==logical_root,'DKN_V02_NAV_INDEX_INVALID')
            raw=read_bounded_file(op,MAX_TRANSPORT)
            check(hashlib.sha256(raw).hexdigest()==bundle['transport_sha256'],
                  'DKN_V02_NAV_TRANSPORT_MISMATCH')
            report=inspect(raw,certificate=bundle['certificate'],relations=bundle['relations'],
                           genesis=bundle['genesis'],transitions=bundle['transitions'])
            check(report['logical_root']==logical_root,'DKN_V02_NAV_IDENTITY_MISMATCH')
            return report
        except OSError as exc:
            raise Refusal('DKN_V02_NAV_IO_ERROR') from exc

    def discover(self, *, semantic_name: str | None=None,
                 namespace_root: str | None=None,
                 signer_public_key_hex: str | None=None,
                 limit: int=64) -> dict:
        check(type(limit) is int and 1<=limit<=MAX_RESULTS,'DKN_V02_NAV_LIMIT')
        check(any(x is not None for x in (semantic_name,namespace_root,signer_public_key_hex)),
              'DKN_V02_NAV_QUERY_REQUIRED')
        if namespace_root is not None: hex32(namespace_root)
        if signer_public_key_hex is not None: hex32(signer_public_key_hex)
        check(semantic_name is None or (type(semantic_name) is str and 0<len(semantic_name)<=255),
              'DKN_V02_NAV_QUERY_INVALID')
        roots=self._roots()
        self._scan_budget(roots)
        result=[];matching=0
        for root in roots:
            record=self.resolve_exact(root)
            if ((semantic_name is None or record['semantic_name']==semantic_name) and
                (namespace_root is None or record['namespace_root']==namespace_root) and
                (signer_public_key_hex is None or record['signer_public_key_hex']==signer_public_key_hex)):
                matching += 1
                if len(result)<limit: result.append(record)
        return self._report({'schema':'dkn.navigation-query.v0.2-candidate',
                'query':{'semantic_name':semantic_name,'namespace_root':namespace_root,
                         'signer_public_key_hex':signer_public_key_hex},
                'results':result,'returned':len(result),'matched_locally':matching,
                'truncated':matching>limit,'local_scan_complete':True,
                'global_completeness':'NOT_ESTABLISHED',
                'source':'LOCAL_UNTRUSTED_INDEX','authority_effect':'NONE'})

    def traverse(self, logical_root: str, *, direction: str='outgoing',
                 max_depth: int=3, max_nodes: int=128) -> dict:
        hex32(logical_root)
        check(direction in ('outgoing','incoming') and type(max_depth) is int and 0<=max_depth<=MAX_HOPS
              and type(max_nodes) is int and 1<=max_nodes<=MAX_RESULTS,'DKN_V02_NAV_LIMIT')
        roots=self._roots()
        self._scan_budget(roots)
        check(logical_root in roots,'DKN_V02_NAV_NOT_FOUND')
        verified={r:self.resolve_exact(r) for r in roots}
        outgoing={r:[{**e,'source':r, 'relation_authentication':v['relation_authentication']}
                     for e in v['relations']] for r,v in verified.items()}
        incoming={}
        for edges in outgoing.values():
            for edge in edges:incoming.setdefault(edge['destination'],[]).append(edge)
        queue=deque([(logical_root,0)])
        visited={logical_root};nodes=[];edges=[];unresolved=[];truncated=False;depth_limited=False;edge_limited=False
        while queue:
            current,depth=queue.popleft()
            nodes.append({'logical_root':current,'depth':depth,
                          'inspection':verified[current]})
            selected=outgoing[current] if direction=='outgoing' else incoming.get(current,[])
            if depth>=max_depth:
                if selected:depth_limited=True;truncated=True
                continue
            for edge in sorted(selected,key=lambda e:(e['source'],e['relation_type'],e['destination'],e['scope'])):
                if len(edges) >= MAX_REPORT_EDGES:
                    edge_limited=True;truncated=True;break
                target=edge['destination'] if direction=='outgoing' else edge['source']
                edges.append(edge)
                if target not in verified:
                    unresolved.append({'logical_root':target,'reason':'NOT_PRESENT_IN_LOCAL_INDEX'})
                    continue
                if target not in visited:
                    if len(visited)>=max_nodes:
                        truncated=True;continue
                    visited.add(target);queue.append((target,depth+1))
        return self._report({'schema':'dkn.navigation-traversal.v0.2-candidate','root':logical_root,
                'direction':direction,'max_depth':max_depth,'max_nodes':max_nodes,
                'nodes':nodes,'edges':edges,'unresolved':unresolved,'truncated':truncated,
                'depth_limited':depth_limited,'edge_limited':edge_limited,'max_edges':MAX_REPORT_EDGES,
                'local_scan_complete':True,'global_completeness':'NOT_ESTABLISHED',
                'authority_effect':'NONE'})

    def compare_namespace(self, namespace_root: str) -> dict:
        hex32(namespace_root)
        records=self.discover(namespace_root=namespace_root,limit=MAX_RESULTS)
        groups={};unnamed=[]
        for item in records['results']:
            if item['semantic_name'] is None:
                unnamed.append(item['logical_root'])
            else:
                groups.setdefault(item['semantic_name'],[]).append(item['logical_root'])
        return self._report({'schema':'dkn.namespace-candidates.v0.2-candidate',
                'namespace_root':namespace_root,'candidate_roots':sorted(r['logical_root'] for r in records['results']),
                'semantic_name_groups':groups,'unnamed_candidate_roots':sorted(unnamed),
                'potential_competing_heads':len(records['results'])>1,
                'fork_proven':'NOT_ESTABLISHED', 'global_head':'NOT_ESTABLISHED',
                'truncated':records['truncated'],'authority_effect':'NONE'})
