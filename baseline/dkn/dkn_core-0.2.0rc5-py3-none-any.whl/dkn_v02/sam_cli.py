"""Explicit canonical JSON request file -> canonical JSON result; offline only."""
import argparse
from pathlib import Path
import sys
from .core import Refusal, canonical, read_canonical, check, MAX_META, read_bounded_file
from .assurance import BOUNDARY
from .sam_abi import dispatch


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m dkn_v02.sam_cli')
    parser.add_argument('request', type=Path, help='Canonical JSON SAM request; no networking')
    args = parser.parse_args(argv)
    try:
        raw = read_bounded_file(args.request, MAX_META)
        check(len(raw) <= MAX_META, 'DKN_V02_SAM_LIMIT')
        result = dispatch(read_canonical(raw))
        code = 0  # well-formed assessment, not an approval; inspect result.status
    except (Refusal, OSError) as exc:
        result = {'status': 'REFUSED', 'code': exc.code if isinstance(exc, Refusal) and exc.code != 'DKN_V02_IO_ERROR' else 'DKN_V02_SAM_IO_ERROR', **BOUNDARY}
        code = 2
    sys.stdout.buffer.write(canonical(result)+b'\n')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
