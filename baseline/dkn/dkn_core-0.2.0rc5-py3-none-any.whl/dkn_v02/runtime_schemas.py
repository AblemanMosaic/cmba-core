"""Closed runtime input/report schemas for the candidate. No remote resolution.

These describe shape only. Canonical bytes, cryptographic checks, policy predicates,
uniqueness, resource budgets and evidence-to-result binding remain runtime duties.
"""
from copy import deepcopy
from jsonschema import Draft202012Validator
from .sam_schemas import obj, array, enum, document, HEX, TIME, TOKEN, V, SCHEMAS as INPUTS
from .core import canonical, check

BOOL={'type':'boolean'}
NULL={'type':'null'}
STRING={'type':'string'}
INT={'type':'integer','minimum':0,'maximum':2**63-1}
SIG={'type':'string','pattern':'^[0-9a-f]{128}$','minLength':128,'maxLength':128}
def const(v):return {'const':v}
def maybe(v):return {'anyOf':[v,NULL]}
def mapping(values):return {'type':'object','additionalProperties':values}
def row(props):return obj(props)
A={'authority_effect':const('NONE')}
B={**A,'standing':const('INFORMATION_ONLY'),'real_a5':const(False),'g0':const('CLOSED')}
HS=array(HEX,4096)
STRS=array(STRING,4096)

DIMENSION=document('dimension',{'dimension_id':TOKEN,'schema_id':TOKEN,'algorithm':const('SHA-256'),
                                'digest_hex':HEX,'critical':BOOL})
MANIFEST=document('logical-artifact',{'metadata_profile':const('portable-files-only-v1'),
    'inventory':array(row({'path':STRING,'type':const('file'),'size':{'type':'integer','minimum':0,'maximum':64*1024*1024},'sha256':HEX}),4096),
    'dimensions':array(DIMENSION,128),'logical_root':HEX})
CERTIFICATE=document('detached-certificate',{'logical_root':HEX,'namespace_root':maybe(HEX),
    'claim':const('PUBLISHER_ATTESTS_COMMITMENT'),'signer_public_key_hex':HEX,'signature_hex':SIG})
GENESIS=document('namespace-genesis',{'semantic_name':{'type':'string','pattern':'^[a-z0-9][a-z0-9._-]{0,254}$'},
    'purpose':TOKEN,'nonce':TOKEN,'legacy_instance':maybe({'type':'string','pattern':'^dkn:v0.1:b3:[0-9a-f]{64}$'}),
    'founder_public_key_hex':HEX,'recovery_policy_ref':maybe({'type':'string','maxLength':256}),
    'namespace_root':HEX,'signature_hex':SIG})
TRANSITION=document('namespace-transition',{'namespace_root':HEX,'predecessor_public_key_hex':HEX,
    'successor_public_key_hex':HEX,'epoch':{'type':'integer','minimum':1,'maximum':2**63-1},
    'previous_transition_hash':maybe(HEX),'transition_hash':HEX,'signature_hex':SIG})
RELATION=document('relations',{'relation_type':enum(('depends_on','derived_from','supersedes','attests','governed_by','published_at','witnesses')),
    'destination':HEX,'scope':{'type':'string','minLength':1,'maxLength':256}})
INSPECTION=document('navigation-inspection',{
    'logical_root':HEX,'transport_sha256':HEX,'integrity':const('PASS'),
    'certificate_signature':enum(('PASS','NOT_CHECKED')),'relation_binding':enum(('PASS','NOT_CHECKED')),
    'relation_authentication':enum(('PASS','NOT_ESTABLISHED')),'relations':array(RELATION,128),
    'namespace_root':maybe(HEX),'namespace_signature':enum(('PASS','NOT_CHECKED')),
    'namespace_authorization':enum(('NOT_ESTABLISHED','PASS_FOR_SUPPLIED_CHAIN_ONLY')),
    'semantic_name':maybe(STRING),'signer_public_key_hex':maybe(HEX),
    'lineage_scope':enum(('NOT_CHECKED','SUPPLIED_CHAIN_ONLY')),'freshness':const('NOT_ESTABLISHED'),
    'global_completeness':const('NOT_ESTABLISHED'),**A})
QUERY=document('navigation-query',{
    'query':row({'semantic_name':maybe(STRING),'namespace_root':maybe(HEX),'signer_public_key_hex':maybe(HEX)}),
    'results':array(INSPECTION,256),'returned':INT,'matched_locally':INT,'truncated':BOOL,
    'local_scan_complete':const(True),'global_completeness':const('NOT_ESTABLISHED'),
    'source':const('LOCAL_UNTRUSTED_INDEX'),**A})
EDGE=row({**RELATION['properties'],'source':HEX,'relation_authentication':enum(('PASS','NOT_ESTABLISHED'))})
TRAVERSAL=document('navigation-traversal',{
    'root':HEX,'direction':enum(('outgoing','incoming')),'max_depth':INT,'max_nodes':INT,
    'nodes':array(row({'logical_root':HEX,'depth':INT,'inspection':INSPECTION}),256),
    'edges':array(EDGE,4096),'unresolved':array(row({'logical_root':HEX,'reason':const('NOT_PRESENT_IN_LOCAL_INDEX')}),4096),
    'truncated':BOOL,'depth_limited':BOOL,'edge_limited':BOOL,'max_edges':const(4096),'local_scan_complete':const(True),
    'global_completeness':const('NOT_ESTABLISHED'),**A})
CHECK=row({'id':TOKEN,'status':enum(('SATISFIES','INSUFFICIENT','CONTRADICTED')),
    'eligible_supporting_signers':HS,'selected_signers':HS,'support_refs':HS,'refutation_refs':HS,
    'independence_basis':enum(('CALLER_POLICY_LABELS_ONLY','NOT_REQUIRED')),'max_age_seconds':TIME})
ASSESSMENT=document('assurance-assessment',{
    'status':enum(('SATISFIES','CONDITIONAL','INSUFFICIENT','CONTRADICTED')),
    'conclusion_scope':const('SUPPLIED_EVIDENCE_OBLIGATIONS_UNDER_CALLER_POLICY'),
    'operational_guarantee':const('NOT_ESTABLISHED_BY_THIS_EVALUATOR'),
    'descriptor_ref':HEX,'contract_ref':HEX,'policy_ref':HEX,'context_ref':HEX,'at_time':TIME,
    'descriptor_recognized_under_policy':BOOL,'invalid_time_scopes':STRS,'checks':array(CHECK,16),
    'evidence_refs':HS,'excluded_evidence':array(row({'evidence_ref':HEX,'reason':enum(('SCOPE_MISMATCH','OBSERVER_NOT_RECOGNIZED_FOR_PREDICATE','OUTSIDE_VALIDITY'))})),
    'premises':array(row({'id':TOKEN,'expected':BOOL,'basis':enum(('CALLER_ACCEPTED_NOT_PROVEN','UNRESOLVED','NOT_PROVEN'))}),129),
    'conflicting_premises':STRS,'limitations':STRS,'report_hash':HEX,**B})
COMPOSITION=document('substrate-composition',{
    'status':enum(('DECLARED_CONFLICTS_DETECTED','INCOMPLETE','NO_DECLARED_CONFLICTS_WITHIN_SCOPE')),
    'mode':const('ALL_OF'),'at_time':TIME,'roots':HS,'descriptor_refs':HS,'unused_descriptor_refs':HS,
    'closures':mapping(HS),'missing_dependencies':HS,'invalid_time_scopes':HS,
    'pairs':array(row({'left':HEX,'right':HEX,'shared_fault_domains':mapping(STRS),'shared_dependencies':HS,'incomplete_domain_dimensions':STRS}),120),
    'conflicting_assumptions':mapping(mapping(HS)),'public_metadata_descriptors':HS,
    'independence':const('NOT_ESTABLISHED'),'availability':const('NOT_COMPUTED'),
    'descriptor_signature_scope':const('DECLARATIONS_ONLY'),'report_hash':HEX,**B})
CHECKPOINT=document('checkpoint-assessment',{
    'status':enum(('CONTRADICTED','CONDITIONAL','INSUFFICIENT')),
    'policy_ref':HEX,'membership_policy_ref':HEX,'at_time':TIME,'policy_time_valid':BOOL,
    'substrate_ref':HEX,'namespace_root':HEX,'epoch':TIME,'minimum_sequence':TIME,
    'highest_eligible_sequence':maybe(TIME),'candidate_heads':HS,'observed_head':maybe(HEX),
    'selected_signers':HS,'quorum':enum(('OBSERVED','NOT_ESTABLISHED')),
    'conflicts':array(row({'sequence':TIME,'heads':mapping(HS)})),
    'excluded_checkpoints':array(row({'checkpoint_ref':HEX,'reason':enum(('NOT_IN_CALLER_MEMBERSHIP','POLICY_OR_SCOPE_MISMATCH','BELOW_CALLER_HIGH_WATER_MARK','OUTSIDE_VALIDITY','STALE_OBSERVATION'))})),
    'checkpoint_refs':HS,'freshness':enum(('BOUNDED_OBSERVATION_ONLY','NOT_ESTABLISHED')),
    'global_currentness':const('NOT_ESTABLISHED'),'consensus_safety':const('NOT_ESTABLISHED'),
    'independence':const('CALLER_POLICY_LABELS_ONLY'),'revocation_status':const('NOT_CHECKED'),
    'clock_source':const('CALLER_SUPPLIED'),'coverage':const('SUPPLIED_CHECKPOINTS_ONLY'),'report_hash':HEX,**B})
HANDOFF=document('governance-evidence-handoff',{
    'consumer':enum(('CHC','CCP')),'assessment':CHECKPOINT,'admission':const('EXTERNAL_DECISION_REQUIRED'),
    'execution_authorized':const(False),'recognition':const('NOT_EVALUATED'),
    'required_inputs':const(['CALLER_RECOGNITION_POLICY','REVOCATION_POLICY','FRESHNESS_POLICY','CAPABILITY_GRANT_IF_NEEDED']),
    'report_hash':HEX,**B})
ATTEMPT={'oneOf':[
    row({'locator':INPUTS['locator'],'status':const('RETRIEVED')}),
    row({'locator':INPUTS['locator'],'status':const('REFUSED'),'code':STRING})]}
RETRIEVAL={'oneOf':[
    document('retrieval-observation',{'status':const('RETRIEVED'),'logical_root':HEX,'attempts':array(ATTEMPT,16),
        'availability_scope':const('THIS_INVOCATION_ONLY'),'freshness':const('NOT_ESTABLISHED'),'future_availability':const('NOT_ESTABLISHED'),**B}),
    document('retrieval-observation',{'status':const('INDETERMINATE'),'logical_root':HEX,'attempts':array(ATTEMPT,16),
        'reason':const('SUPPLIED_SOURCES_EXHAUSTED'),'global_absence':const('NOT_ESTABLISHED'),**B})]}

SCHEMAS={
    'dimension':DIMENSION,'manifest':MANIFEST,'certificate':CERTIFICATE,'genesis':GENESIS,'transition':TRANSITION,
    'relation':RELATION,'inspection':INSPECTION,'query':QUERY,'traversal':TRAVERSAL,
    'namespace-candidates':document('namespace-candidates',{
        'namespace_root':HEX,'candidate_roots':HS,'semantic_name_groups':mapping(HS),'unnamed_candidate_roots':HS,
        'potential_competing_heads':BOOL,'fork_proven':const('NOT_ESTABLISHED'),
        'global_head':const('NOT_ESTABLISHED'),'truncated':BOOL,**A}),
    'lineage-analysis':document('lineage-analysis',{
        'namespace_root':HEX,'supplied_chains':INT,'unique_transitions':INT,'supplied_chain_tips':HS,
        'forks':array(row({'predecessor_ref':HEX,'successors':array(row({'transition_hash':HEX,'epoch':TIME,'successor_public_key_hex':HEX}),512)}),512),
        'fork_evidence':enum(('OBSERVED','NOT_OBSERVED_IN_SUPPLIED_CHAINS')),'signature_chains':const('PASS'),
        'selected_head':NULL,'global_head':const('NOT_ESTABLISHED'),'revocation':const('NOT_CHECKED'),
        'coverage':const('SUPPLIED_CHAINS_ONLY'),**A}),
    'manifest-structure':row({'manifest_structure':const('PASS'),'content_integrity':const('NOT_CHECKED'),'dimension_semantics':const('NOT_CHECKED'),**A}),
    'manifest-verification':row({'integrity':const('PASS'),'dimensions_committed':const('PASS'),
        'dimension_semantics':const('NOT_CHECKED'),'logical_root':HEX,**A}),
    'archive-verification':row({'status':const('PASS'),'logical_root':HEX,'transport_sha256':HEX,'files':INT,'dimension_semantics':const('NOT_CHECKED'),**A}),
    'certificate-verification':row({'signature':const('PASS'),'publisher_statement':const('PASS'),'authorization':const('NOT_CHECKED'),**A}),
    'dimension-verification':row({'commitment':enum(('PASS','NOT_CHECKED')),'semantics':enum(('UNSUPPORTED','NOT_CHECKED'))}),
    'genesis-verification':row({'namespace_root':HEX,'signature':const('PASS'),'human_name_exclusive':const(False),
        'legacy_binding':enum(('NOT_ESTABLISHED','NOT_APPLICABLE')),**A}),
    'lineage-verification':row({'signature_chain':const('PASS'),'epoch':INT,'active_key':HEX,'global_head':const('NOT_ESTABLISHED'),**A}),
    'record-verification':row({'record_hash':HEX,'kind':enum(('substrate','evidence','checkpoint')),'signature':const('PASS'),
        'asserted_fact':const('NOT_ESTABLISHED'),'recognition':const('NOT_EVALUATED'),**B}),
    'assessment':ASSESSMENT,'composition':COMPOSITION,'checkpoint-assessment':CHECKPOINT,'handoff':HANDOFF,
    'assured-inspection':document('assured-inspection',{'inspection':INSPECTION,'assurance':ASSESSMENT,'recognition':const('EXTERNAL_DECISION_REQUIRED'),**B}),
    'retrieval':RETRIEVAL,
    'refusal':{'oneOf':[row({'status':const('REFUSED'),'code':STRING,**A}),row({'status':const('REFUSED'),'code':STRING,**B})]},
}
REQUEST_ARGUMENTS={
    'verify':row({'record':INPUTS['signed']}),
    'evaluate':row({'descriptor':INPUTS['signed'],'contract':INPUTS['contract'],'evidence':array(INPUTS['signed']),
                    'policy':INPUTS['policy'],'context':INPUTS['context']}),
    'compose':row({'descriptors':array(INPUTS['signed'],64),'roots':array(HEX,16,1),'at_time':TIME}),
    'checkpoints':row({'checkpoints':array(INPUTS['signed']),'policy':INPUTS['checkpoint-policy'],'at_time':TIME}),
    'handoff':row({'checkpoints':array(INPUTS['signed']),'policy':INPUTS['checkpoint-policy'],'at_time':TIME,'consumer':enum(('CHC','CCP'))})}
SCHEMAS['sam-request']={'oneOf':[row({'schema':const('dkn.sam-request.'+V),'operation':const(op),'arguments':args}) for op,args in REQUEST_ARGUMENTS.items()]}
VALIDATORS={name:Draft202012Validator(schema) for name,schema in SCHEMAS.items()}

def validate_report(kind: str, value):
    check(type(kind) is str and kind in VALIDATORS,'DKN_V02_REPORT_KIND_UNSUPPORTED')
    # Reports can be larger than an input envelope but remain bounded to serialized limits.
    canonical(value)
    check(VALIDATORS[kind].is_valid(value),'DKN_V02_REPORT_SCHEMA_INVALID')
    return value
