"""Closed Batch D candidate schemas. Runtime source of truth; exports are tested.

No schema downloads or external $ref resolution occur. Integer time values are
UTC Unix seconds. These schemas are NOT the Batch A design-only schemas.
"""
from __future__ import annotations

V = 'v0.2-candidate'
SCHEMA_URI = 'https://json-schema.org/draft/2020-12/schema'
PROFILES = ('LOCAL_VAULT', 'ENTERPRISE_DISTRIBUTED', 'PUBLIC_HOSTING',
            'P2P_CAS', 'FEDERATED_CCP', 'HYBRID')
DIMENSIONS = ('integrity', 'authenticity', 'availability', 'durability', 'freshness',
              'consistency', 'equivocation_detection', 'censorship_resistance',
              'custody', 'confidentiality', 'recovery', 'jurisdiction')
FAULT_DIMENSIONS = ('administration', 'identity', 'provider', 'region', 'network',
                    'software', 'power', 'custody')
METHODS = ('DECLARATION', 'OBSERVATION', 'TEST_RESULT')
HEX = {'type': 'string', 'pattern': '^[0-9a-f]{64}$', 'minLength': 64, 'maxLength': 64}
TOKEN = {'type': 'string', 'pattern': '^[a-z][a-z0-9._-]{0,127}$', 'not': {'pattern': '[\\r\\n]'}}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 512}
TIME = {'type': 'integer', 'minimum': 0, 'maximum': 2**63-1}


def enum(values):
    return {'type': 'string', 'enum': list(values)}


def array(item, maximum=128, minimum=0, unique=False):
    return {'type': 'array', 'items': item, 'minItems': minimum,
            'maxItems': maximum, 'uniqueItems': unique}


def obj(properties):
    return {'type': 'object', 'additionalProperties': False,
            'properties': properties, 'required': list(properties)}


def document(name, properties):
    return {'$schema': SCHEMA_URI, 'title': name,
            **obj({'schema': {'const': 'dkn.'+name+'.'+V}, **properties})}


DOMAIN = obj({'dimension': enum(FAULT_DIMENSIONS), 'domain_id': TOKEN})
DOMAINS = array(DOMAIN, 32, unique=True)
PREMISE = obj({'id': TOKEN, 'value': {'type': 'boolean'}})
PREMISES = array(PREMISE, 64, unique=True)
SCOPE = obj({'substrate_ref': HEX, 'artifact_root': {'anyOf': [HEX, {'type': 'null'}]},
             'namespace_root': {'anyOf': [HEX, {'type': 'null'}]}})
OBSERVER = obj({'public_key_hex': HEX, 'predicates': array(TOKEN, 64, 1, True),
                'fault_domains': DOMAINS})
MEMBER = obj({'public_key_hex': HEX, 'fault_domains': DOMAINS})
REQUIREMENT = obj({'id': TOKEN, 'predicate': TOKEN,
                   'methods': array(enum(METHODS), 3, 1, True),
                   'min_signers': {'type': 'integer', 'minimum': 1, 'maximum': 16},
                   'independence_dimensions': array(enum(FAULT_DIMENSIONS), 8, 0, True),
                   'max_age_seconds': TIME})

SCHEMAS = {
    'substrate': document('substrate', {
        'substrate_id': TOKEN, 'profile': enum(PROFILES),
        'deployment_status': enum(('TEMPLATE', 'DECLARED_DEPLOYMENT')),
        'mechanisms': array(TOKEN, 64, 0, True),
        'fault_domains': DOMAINS, 'assumptions': PREMISES,
        'dependencies': array(HEX, 64, 0, True),
        'metadata_visibility': enum(('LOCAL_ONLY', 'ACCESS_CONTROLLED', 'PUBLIC', 'UNSPECIFIED')),
        'threat_model': obj({'adversaries': array(TOKEN, 32, 1, True),
                             'exclusions': array(TEXT, 32, 0, True),
                             'network_assumptions': array(TEXT, 32, 0, True)}),
        'valid_from': TIME, 'valid_until': TIME,
    }),
    'contract': document('assurance-contract', {
        'contract_id': TOKEN, 'scope': SCOPE, 'dimension': enum(DIMENSIONS),
        # An unknown token is well-formed but is refused by the evaluator.
        'decision_rule': TOKEN, 'requirements': array(REQUIREMENT, 16, 1),
        'assumptions': PREMISES, 'valid_from': TIME, 'valid_until': TIME,
    }),
    'evidence': document('assurance-evidence', {
        'scope': SCOPE, 'predicate': TOKEN, 'method': enum(METHODS),
        'outcome': enum(('SUPPORTS', 'REFUTES', 'INDETERMINATE')),
        'observed_at': TIME, 'valid_until': TIME,
        'basis_ref': {'anyOf': [HEX, {'type': 'null'}]},
        'note': {'type': 'string', 'maxLength': 512},
    }),
    'policy': document('assurance-policy', {
        'policy_id': TOKEN, 'descriptor_signers': array(HEX, 16, 1, True),
        'observers': array(OBSERVER, 16),
    }),
    'context': document('assurance-context', {
        'at_time': TIME, 'accepted_premises': PREMISES,
    }),
    'checkpoint-policy': document('checkpoint-policy', {
        'policy_id': TOKEN, 'protocol': {'const': 'signed-head-observation-v1'},
        'substrate_ref': HEX, 'namespace_root': HEX, 'epoch': TIME,
        'members': array(MEMBER, 16, 1),
        'threshold': {'type': 'integer', 'minimum': 1, 'maximum': 16},
        'independence_dimensions': array(enum(FAULT_DIMENSIONS), 8, 0, True),
        'max_age_seconds': TIME, 'minimum_sequence': TIME,
        'valid_from': TIME, 'valid_until': TIME,
    }),
    'checkpoint': document('head-observation', {
        'policy_ref': HEX, 'substrate_ref': HEX, 'namespace_root': HEX,
        'epoch': TIME, 'sequence': TIME, 'head_root': HEX,
        'observed_at': TIME, 'valid_until': TIME,
    }),
    'signed': document('sam-signed', {
        'kind': enum(('substrate', 'evidence', 'checkpoint')),
        'body': {'type': 'object'}, 'signer_public_key_hex': HEX,
        'record_hash': HEX,
        'signature_hex': {'type': 'string', 'pattern': '^[0-9a-f]{128}$', 'minLength': 128, 'maxLength': 128},
    }),
    'locator': document('storage-locator', {
        'backend_id': TOKEN, 'logical_root': HEX, 'transport_sha256': HEX,
    }),
}
