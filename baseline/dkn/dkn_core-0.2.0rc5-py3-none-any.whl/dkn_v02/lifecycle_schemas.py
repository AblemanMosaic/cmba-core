"""LC-F1 and vault report shapes, not cryptographic or semantic validation."""
from copy import deepcopy
from jsonschema import Draft202012Validator
from .core import canonical, check
from .runtime_schemas import SCHEMAS as BASE

HEX={'type':'string','pattern':'^[0-9a-f]{64}$','minLength':64,'maxLength':64}
SIG={'type':'string','pattern':'^[0-9a-f]{128}$','minLength':128,'maxLength':128}
TOKEN={'type':'string','pattern':'^[a-z][a-z0-9._-]{0,127}$','maxLength':128}
TIME={'type':'integer','minimum':0,'maximum':2**63-1}
SEQ={'type':'integer','minimum':0,'maximum':256}
REF={'type':'string','pattern':'^dkn:lc-f1:sha256:[0-9a-f]{64}$'}

def obj(fields):return {'type':'object','properties':fields,'required':list(fields),'additionalProperties':False}
def const(value):return {'const':value}
def arr(item, maximum, minimum=0):return {'type':'array','items':item,'minItems':minimum,'maxItems':maximum}
def doc(schema,fields):return obj({'schema':const(schema),**fields})
def nullable(item):return {'anyOf':[item,{'type':'null'}]}
A={'authority_effect':const('NONE')}
OPS={**arr(TOKEN,16,1),'uniqueItems':True}
POLICY=doc('dkn.lifecycle-policy.v0.2-f1',{
    'recovery_keys':{**arr(HEX,16),'uniqueItems':True},'recovery_threshold':{'type':'integer','minimum':0,'maximum':16},
    'allowed_operations':OPS,'max_grant_seconds':{'type':'integer','minimum':1,'maximum':31622400}})
PAYLOADS={
    'delegate':obj({'subject_public_key_hex':HEX,'artifact_root':HEX,'operations':OPS,'not_before':TIME,'expires_at':TIME}),
    'rotate':obj({'successor_public_key_hex':HEX}),'recover':obj({'successor_public_key_hex':HEX}),
    'revoke_grant':obj({'grant_ref':HEX}),'revoke_key':obj({'public_key_hex':HEX}),
    'suspend':obj({'reason':{'type':'string','minLength':1,'maxLength':256}}),
    'resume':obj({'reason':{'type':'string','minLength':1,'maxLength':256}})}
EVENT=obj({'body':{'oneOf':[doc('dkn.lifecycle-event.v0.2-f1',{
    'namespace_root':HEX,'policy_ref':REF,'sequence':{'type':'integer','minimum':1,'maximum':256},
    'previous_ref':HEX,'issued_at':TIME,'kind':const(kind),'payload':payload}) for kind,payload in PAYLOADS.items()]},
    'event_ref':HEX,'signatures':arr(obj({'public_key_hex':HEX,'signature_hex':SIG}),18,1)})
CHECKPOINT=doc('dkn.lifecycle-checkpoint.v0.2-f1',{
    'namespace_root':HEX,'policy_ref':REF,'head_ref':HEX,'sequence':SEQ,'issued_at':TIME,'expires_at':TIME,
    'signer_public_key_hex':HEX,'signature_hex':SIG})
STATE=doc('dkn.lifecycle-state.v0.2-f1',{
    'namespace_root':HEX,'policy_ref':REF,'anchor_ref':HEX,'head_ref':HEX,'sequence':SEQ,'epoch':SEQ,
    'epoch_instance_ref':HEX,'active_key':HEX,'suspended':{'type':'boolean'},'last_declared_time':TIME,
    'grant_count':SEQ,'revoked_grant_count':SEQ,'revoked_keys':arr(HEX,256),
    'signature_chain':const('PASS'),'coverage':const('SUPPLIED_JOURNAL_ONLY'),
    'global_currentness':const('NOT_ESTABLISHED'),**A})
ASSESSMENT=doc('dkn.lifecycle-assessment.v0.2-f1',{
    'status':{'enum':['MATCH_FOR_SUPPLIED_VIEW','NO_MATCH','INDETERMINATE']},
    'reason':{'enum':['NO_ACTIVE_EXACT_GRANT','CHECKPOINT_MISSING','NAMESPACE_SUSPENDED',
       'OPERATION_OUTSIDE_POLICY','CONTROLLER_FOR_SUPPLIED_VIEW','KEY_REVOKED_IN_SUPPLIED_VIEW',
       'EXACT_DELEGATION_FOR_SUPPLIED_VIEW']},
    'namespace_root':HEX,'head_ref':HEX,'sequence':SEQ,'subject_public_key_hex':HEX,
    'artifact_root':HEX,'operation':TOKEN,'evaluated_at':TIME,'matching_grants':arr(HEX,256),
    'checkpoint':{'enum':['NOT_CHECKED','PASS_READER_TIME_BOUND']},
    'subject_possession':{'enum':['NOT_CHECKED','SIGNATURE_VERIFIED']},
    'revocation':const('SUPPLIED_PINNED_VIEW_ONLY'),'global_currentness':const('NOT_ESTABLISHED'),
    'acceptance':const('EXTERNAL_DECISION_REQUIRED'),**A})
FORKS=doc('dkn.lifecycle-forks.v0.2-f1',{
    'namespace_root':HEX,'supplied_chain_tips':arr(HEX,32),
    'forks':arr(obj({'predecessor_ref':HEX,'successors':arr(obj({'event_ref':HEX,'kind':{'enum':list(PAYLOADS)},'sequence':SEQ}),32)}),512),
    'selected_head':const(None),'fork_evidence':{'enum':['OBSERVED','NOT_OBSERVED_IN_SUPPLIED_JOURNALS']},
    'coverage':const('SUPPLIED_JOURNALS_ONLY'),**A})
JOURNAL_ARGS={'genesis':BASE['genesis'],'policy':POLICY,'events':arr(EVENT,256)}
READER_ARGS={'expected_namespace':HEX,'expected_head':HEX,'now':TIME,
    'max_checkpoint_age':{'type':'integer','minimum':1,'maximum':2**63-1},'checkpoint':nullable(CHECKPOINT),
    'minimum':nullable(obj({'sequence':SEQ,'head_ref':HEX}))}
REQUEST_ARGS={
    'verify-policy':obj({'policy':POLICY}), 'verify-journal':obj(JOURNAL_ARGS),
    'analyze-journals':obj({'genesis':BASE['genesis'],'policy':POLICY,'chains':arr(arr(EVENT,256),32,1)}),
    'assess-delegation':obj({**JOURNAL_ARGS,**READER_ARGS,'subject_public_key_hex':HEX,'artifact_root':HEX,'operation':TOKEN}),
    'assess-certificate':obj({**JOURNAL_ARGS,**READER_ARGS,'certificate':BASE['certificate'],'manifest':BASE['manifest']})}
SCHEMAS={
    'policy':POLICY,'event':EVENT,'checkpoint':CHECKPOINT,'state':STATE,'assessment':ASSESSMENT,'forks':FORKS,
    'policy-verification':obj({'policy_ref':REF,**A}),
    'inspection':doc('dkn.lifecycle-inspection.v0.2-f1',{'artifact':BASE['archive-verification'],'lifecycle':ASSESSMENT,**A}),
    'request':{'oneOf':[doc('dkn.lifecycle-request.v0.2-f1',{'operation':const(operation),'arguments':args}) for operation,args in REQUEST_ARGS.items()]},
    'vault-write':doc('dkn.vault-write.v0.2-f1',{'status':{'enum':['STORED','ALREADY_PRESENT']},'logical_root':HEX,'revision':TIME,**A}),
    'vault-query':doc('dkn.vault-query.v0.2-f1',{'snapshot_revision':TIME,'snapshot_scope':const('ONE_LOCAL_COMMITTED_DATABASE_VIEW'),
                        'result':{'oneOf':[BASE['inspection'],BASE['query'],BASE['traversal']]},**A}),
    'vault-pin':doc('dkn.vault-pin.v0.2-f1',{'status':{'enum':['PIN_ADVANCED','ALREADY_PINNED']},'namespace_root':HEX,
                        'head_ref':HEX,'sequence':SEQ,'revision':TIME,**A}),
    'vault-import':doc('dkn.vault-import.v0.2-f1',{'status':const('IMPORTED'),'artifacts':{'type':'integer','minimum':0,'maximum':256},
                        'revision':TIME,'source_modified':const(False),'source_snapshot':const('QUIESCENT_SOURCE_REQUIRED'),**A}),
    'vault-namespace':doc('dkn.vault-namespace.v0.2-f1',JOURNAL_ARGS),
}
SCHEMAS['vault-namespace-read']=doc('dkn.vault-namespace-read.v0.2-f1',{
    'snapshot_revision':TIME,'bundle':SCHEMAS['vault-namespace'],'state':STATE,**A})
SCHEMAS['proposal']=obj({'body':EVENT['properties']['body'],'event_ref':HEX})
SCHEMAS['endorsement']=obj({'public_key_hex':HEX,'signature_hex':SIG})
VALIDATORS={kind:Draft202012Validator(value) for kind,value in SCHEMAS.items()}

def validate_shape(kind: str, value):
    check(type(kind) is str and kind in VALIDATORS,'DKN_LC_SCHEMA_KIND_UNSUPPORTED')
    canonical(value)
    check(VALIDATORS[kind].is_valid(value),'DKN_LC_SHAPE_INVALID')
    return value
