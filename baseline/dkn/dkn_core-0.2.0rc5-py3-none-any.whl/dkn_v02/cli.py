"""Prototype CLI: no publication or key persistence side effects."""
import argparse
import json
from pathlib import Path
from .core import Refusal,pack,load_directory,verify_archive,read_canonical,verify_certificate,read_bounded_file,MAX_META,MAX_TRANSPORT

def main(argv=None):
    parser=argparse.ArgumentParser(prog='python -m dkn_v02')
    sub=parser.add_subparsers(dest='op',required=True)
    a=sub.add_parser('pack');a.add_argument('source');a.add_argument('output')
    b=sub.add_parser('verify');b.add_argument('archive')
    c=sub.add_parser('verify-certificate');c.add_argument('certificate');c.add_argument('manifest')
    args=parser.parse_args(argv)
    try:
        if args.op=='pack':
            archive,manifest=pack(load_directory(Path(args.source)))
            output=Path(args.output)
            if output.exists(): raise Refusal('DKN_V02_OUTPUT_EXISTS')
            with output.open('xb') as f:f.write(archive)
            result={'status':'PACKAGED','logical_root':manifest['logical_root'],'output':str(output),'authority_effect':'NONE'}
        elif args.op=='verify':result=verify_archive(read_bounded_file(args.archive,MAX_TRANSPORT))
        else:result=verify_certificate(read_canonical(read_bounded_file(args.certificate,MAX_META)),read_canonical(read_bounded_file(args.manifest,MAX_META)))
        print(json.dumps(result,sort_keys=True));return 0
    except (Refusal, OSError) as e:
        print(json.dumps({'status':'REFUSED','code':e.code if isinstance(e,Refusal) else 'DKN_V02_IO_ERROR','authority_effect':'NONE'}));return 2
if __name__=='__main__':raise SystemExit(main())
