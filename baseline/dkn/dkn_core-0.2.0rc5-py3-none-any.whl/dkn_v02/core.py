"""DKN v0.2 EXPERIMENTAL: offline, SHA-256 / Ed25519 reference binding.

All v0.2 domains are independent of dkn_core v0.1. No authority grants.
"""
from __future__ import annotations
import hashlib
import io
import json
import re
import stat
import os
import unicodedata
import zipfile
import struct
from pathlib import Path, PurePosixPath
from typing import Any
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

MAX_FILES = 4096
MAX_FILE = 64 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024
MAX_META = 4 * 1024 * 1024
MAX_DEPTH = 32
MAX_TRANSPORT = MAX_TOTAL + MAX_META + (MAX_FILES + 1) * 2304
DOMAINS = {
    'dimension': b'DKN_V02_DIMENSION\x00',
    'logical': b'DKN_V02_LOGICAL_ARTIFACT\x00',
    'namespace': b'DKN_V02_NAMESPACE_GENESIS\x00',
    'transition': b'DKN_V02_NAMESPACE_TRANSITION\x00',
    'certificate': b'DKN_V02_CERTIFICATE\x00',
}
class Refusal(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)

def check(value: bool, code: str):
    if not value: raise Refusal(code)

def _validate(obj: Any, depth: int = 0) -> None:
    check(depth <= MAX_DEPTH, 'DKN_V02_DEPTH_LIMIT')
    if obj is None or type(obj) is bool: return
    if type(obj) is int:
        check(-(2**63) <= obj < 2**63, 'DKN_V02_NUMBER_INVALID'); return
    if type(obj) is str:
        check(not any(0xD800 <= ord(x) <= 0xDFFF for x in obj), 'DKN_V02_STRING_INVALID');return
    if type(obj) is list:
        check(len(obj) <= MAX_FILES, 'DKN_V02_LIMIT')
        for x in obj: _validate(x, depth+1)
        return
    if type(obj) is dict:
        check(len(obj) <= MAX_FILES and all(type(k) is str for k in obj), 'DKN_V02_TYPE_INVALID')
        for k,v in obj.items(): _validate(k, depth+1); _validate(v, depth+1)
        return
    raise Refusal('DKN_V02_TYPE_INVALID')

def canonical(obj: Any) -> bytes:
    _validate(obj)
    b = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    check(len(b) <= MAX_META, 'DKN_V02_LIMIT')
    return b

def read_canonical(b: bytes) -> Any:
    check(type(b) is bytes and len(b) <= MAX_META, 'DKN_V02_LIMIT')
    def pairs(xs):
        d={}
        for k,v in xs:
            check(k not in d, 'DKN_V02_DUPLICATE_KEY');d[k]=v
        return d
    def refuse_float(_): raise Refusal('DKN_V02_NUMBER_INVALID')
    try: obj = json.loads(b.decode('utf-8'), object_pairs_hook=pairs, parse_float=refuse_float, parse_constant=refuse_float)
    except Refusal: raise
    except (ValueError, UnicodeError, RecursionError) as e: raise Refusal('DKN_V02_JSON_INVALID') from e
    check(canonical(obj) == b, 'DKN_V02_JSON_NOT_CANONICAL')
    return obj

def exact(obj: Any, keys: set[str], code='DKN_V02_SCHEMA_INVALID') -> None:
    check(type(obj) is dict and set(obj) == keys, code)

def digest(domain: str, obj: Any) -> str:
    check(type(domain) is str and domain in DOMAINS, 'DKN_V02_DOMAIN_UNKNOWN')
    return hashlib.sha256(DOMAINS[domain] + canonical(obj)).hexdigest()

def hex32(value: Any):
    check(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, 'DKN_V02_DIGEST_INVALID')
    return value

def _token(v: Any):
    check(type(v) is str and re.fullmatch('[a-z][a-z0-9._-]{0,127}',v) is not None, 'DKN_V02_TOKEN_INVALID')
    return v

def commit(dimension_id: str, schema_id: str, value: Any, *, critical=True) -> dict:
    _token(dimension_id); _token(schema_id)
    check(type(critical) is bool, 'DKN_V02_SCHEMA_INVALID')
    item={'schema':'dkn.dimension.v0.2-candidate', 'dimension_id':dimension_id, 'schema_id':schema_id,
          'algorithm':'SHA-256', 'digest_hex':digest('dimension',{'schema_id':schema_id,'value':value}), 'critical':critical}
    return item

def verify_dimension(item: Any, value: Any=None, *, supplied=False, supported_schemas: set[str] | None=None) -> dict:
    exact(item, {'schema','dimension_id','schema_id','algorithm','digest_hex','critical'})
    check(item['schema']=='dkn.dimension.v0.2-candidate' and item['algorithm']=='SHA-256', 'DKN_V02_ALGORITHM_UNSUPPORTED')
    _token(item['dimension_id']); _token(item['schema_id']);hex32(item['digest_hex'])
    check(type(item['critical']) is bool, 'DKN_V02_SCHEMA_INVALID')
    check(type(supplied) is bool, 'DKN_V02_SCHEMA_INVALID')
    check(supported_schemas is None or (type(supported_schemas) in (set, frozenset) and all(type(s) is str for s in supported_schemas)), 'DKN_V02_SCHEMA_INVALID')
    supported = supported_schemas is None or item['schema_id'] in supported_schemas
    check(supported or not item['critical'], 'DKN_V02_CRITICAL_UNSUPPORTED')
    if supplied:
        check(digest('dimension', {'schema_id':item['schema_id'], 'value':value}) == item['digest_hex'], 'DKN_V02_DIMENSION_MISMATCH')
    return {'commitment':'PASS' if supplied else 'NOT_CHECKED', 'semantics':'NOT_CHECKED' if supported else 'UNSUPPORTED'}

def _path(path: str) -> str:
    check(type(path) is str and bool(path), 'DKN_V02_PATH_INVALID')
    check(not any(ord(c) < 32 or ord(c) == 127 or 0xD800 <= ord(c) <= 0xDFFF for c in path), 'DKN_V02_PATH_INVALID')
    check(path == unicodedata.normalize('NFC', path) and not any(c in path for c in '\\<>:"|?*'), 'DKN_V02_PATH_INVALID')
    parts=path.split('/')
    check(all(p not in ('.','..','') and not p.endswith((' ','.')) for p in parts), 'DKN_V02_PATH_INVALID')
    check(all(len(p.encode('utf-8')) <= 255 for p in parts) and len(path.encode('utf-8')) <= 1024, 'DKN_V02_PATH_INVALID')
    # DOS device aliases remain reserved even with an extension and under directories.
    reserved={'CON','PRN','AUX','NUL','CONIN$','CONOUT$'}
    for p in parts:
        base=p.split('.')[0].upper()
        check(base not in reserved and re.fullmatch(r'(COM|LPT)[1-9¹²³]',base) is None, 'DKN_V02_PATH_INVALID')
    return path


def _check_paths(paths: list[str]) -> None:
    folded=set()
    for path in paths:
        _path(path)
        f=path.casefold()
        check(f not in folded, 'DKN_V02_PATH_COLLISION')
        folded.add(f)
    for f in folded:
        parts=f.split('/')
        check(not any('/'.join(parts[:i]) in folded for i in range(1,len(parts))), 'DKN_V02_PATH_COLLISION')


def _payload_path(path: str) -> str:
    _path(path)
    folded = path.casefold()
    check(folded != '.dkn' and not folded.startswith('.dkn/'), 'DKN_V02_RESERVED_PATH')
    return path


def _inventory(files: dict[str, bytes]) -> list:
    check(type(files) is dict and len(files) <= MAX_FILES, 'DKN_V02_LIMIT')
    _check_paths(list(files))
    for path in files: _payload_path(path)
    total=0
    for b in files.values():
        check(type(b) is bytes and len(b) <= MAX_FILE, 'DKN_V02_LIMIT')
        total += len(b)
        check(total <= MAX_TOTAL, 'DKN_V02_LIMIT')
    return [{'path':p,'type':'file','size':len(files[p]),'sha256':hashlib.sha256(files[p]).hexdigest()} for p in sorted(files)]


def validate_manifest(manifest: dict, *, supported_schemas=None) -> dict:
    """Check a commitment's complete structure, never claim its payload is present."""
    canonical(manifest)
    exact(manifest,{'schema','metadata_profile','inventory','dimensions','logical_root'})
    check(manifest['schema']=='dkn.logical-artifact.v0.2-candidate' and manifest['metadata_profile']=='portable-files-only-v1', 'DKN_V02_SCHEMA_INVALID')
    hex32(manifest['logical_root'])
    rows=manifest['inventory'];dims=manifest['dimensions']
    check(type(rows) is list and len(rows)<=MAX_FILES and type(dims) is list and len(dims)<=128, 'DKN_V02_LIMIT')
    paths=[];total=0
    for row in rows:
        exact(row,{'path','type','size','sha256'})
        check(row['type']=='file' and type(row['size']) is int and 0<=row['size']<=MAX_FILE, 'DKN_V02_SCHEMA_INVALID')
        _payload_path(row['path']);hex32(row['sha256']);paths.append(row['path']);total+=row['size']
    check(total<=MAX_TOTAL, 'DKN_V02_LIMIT');_check_paths(paths)
    check(paths==sorted(paths), 'DKN_V02_MANIFEST_MISMATCH')
    for d in dims:verify_dimension(d,supported_schemas=supported_schemas)
    names=[d['dimension_id'] for d in dims]
    check(len(set(names))==len(names), 'DKN_V02_DIMENSION_DUPLICATE')
    check(names==sorted(names), 'DKN_V02_MANIFEST_MISMATCH')
    body={k:v for k,v in manifest.items() if k!='logical_root'}
    check(digest('logical',body)==manifest['logical_root'], 'DKN_V02_MANIFEST_MISMATCH')
    return {'manifest_structure':'PASS','content_integrity':'NOT_CHECKED','dimension_semantics':'NOT_CHECKED','authority_effect':'NONE'}


def build_manifest(files: dict[str,bytes], dimensions: list[dict] | None=None) -> dict:
    dims = [] if dimensions is None else dimensions
    check(type(dims) is list and len(dims) <= 128, 'DKN_V02_LIMIT')
    for d in dims: verify_dimension(d)
    ordered=sorted(dims,key=lambda d:d['dimension_id'])
    check(len({d['dimension_id'] for d in ordered})==len(ordered), 'DKN_V02_DIMENSION_DUPLICATE')
    # Return detached nested metadata so later caller mutations cannot change a signed object.
    ordered=read_canonical(canonical(ordered))
    body={'schema':'dkn.logical-artifact.v0.2-candidate','metadata_profile':'portable-files-only-v1',
          'inventory':_inventory(files), 'dimensions':ordered}
    return {**body,'logical_root':digest('logical',body)}

def verify_manifest(manifest: dict, files: dict[str,bytes], *, supported_schemas=None) -> dict:
    validate_manifest(manifest, supported_schemas=supported_schemas)
    expected=build_manifest(files,manifest['dimensions'])
    check(canonical(manifest) == canonical(expected),'DKN_V02_MANIFEST_MISMATCH')
    return {'integrity':'PASS','dimensions_committed':'PASS','dimension_semantics':'NOT_CHECKED','authority_effect':'NONE','logical_root':manifest['logical_root']}

def pack(files: dict[str,bytes], dimensions: list[dict] | None=None) -> tuple[bytes,dict]:
    manifest=build_manifest(files,dimensions)
    check(not any(p.casefold()=='.dkn' or p.casefold().startswith('.dkn/') for p in files), 'DKN_V02_RESERVED_PATH')
    entries={**files,'.dkn/manifest.json':canonical(manifest)}
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_STORED,allowZip64=False) as z:
        for p in sorted(entries):
            info=zipfile.ZipInfo(p,date_time=(1980,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_STORED
            info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16
            info.flag_bits=0
            z.writestr(info,entries[p])
    data=stream.getvalue()
    return data,manifest

def verify_archive(raw: bytes, *, supported_schemas=None) -> dict:
    check(type(raw) is bytes and len(raw) <= MAX_TRANSPORT, 'DKN_V02_LIMIT')
    # The sole admitted transport is a no-comment, non-ZIP64 canonical ZIP.
    # Bound its central directory before ZipFile allocates ZipInfo records.
    check(len(raw) >= 22 and raw[-22:-18] == b'PK\x05\x06', 'DKN_V02_ARCHIVE_INVALID')
    _, disk, cd_disk, disk_count, count, cd_size, cd_offset, comment = struct.unpack('<4s4H2LH', raw[-22:])
    check(disk == cd_disk == comment == 0 and disk_count == count and 1 <= count <= MAX_FILES+1,
          'DKN_V02_ARCHIVE_INVALID')
    check(cd_size <= count * (46 + 1024) and cd_offset + cd_size + 22 == len(raw),
          'DKN_V02_ARCHIVE_INVALID')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos=z.infolist();paths=[i.filename for i in infos]
            check(len(infos) == count, 'DKN_V02_ARCHIVE_INVALID')
            check(paths==sorted(paths) and len(paths)==len(set(paths)) and len(paths)<=MAX_FILES+1, 'DKN_V02_ARCHIVE_INVALID')
            check(sum(i.file_size for i in infos)<=MAX_TOTAL+MAX_META,'DKN_V02_LIMIT')
            _check_paths(paths)
            files={}
            for info in infos:
                _path(info.filename)
                if info.filename == '.dkn/manifest.json':
                    check(info.file_size <= MAX_META, 'DKN_V02_LIMIT')
                check(info.compress_type==zipfile.ZIP_STORED and info.file_size<=MAX_FILE and info.flag_bits & 1 == 0, 'DKN_V02_ARCHIVE_INVALID')
                check(info.date_time==(1980,1,1,0,0,0) and info.external_attr == ((stat.S_IFREG|0o644)<<16), 'DKN_V02_ARCHIVE_INVALID')
                check(not info.is_dir(), 'DKN_V02_ARCHIVE_INVALID')
                files[info.filename]=z.read(info)
    except Refusal: raise
    except (zipfile.BadZipFile, RuntimeError, OSError, ValueError, EOFError) as e: raise Refusal('DKN_V02_ARCHIVE_INVALID') from e
    check('.dkn/manifest.json' in files, 'DKN_V02_ARCHIVE_INVALID')
    manifest=read_canonical(files.pop('.dkn/manifest.json'))
    verify_manifest(manifest,files,supported_schemas=supported_schemas)
    expected,_=pack(files,manifest['dimensions'])
    check(expected==raw, 'DKN_V02_ARCHIVE_NOT_CANONICAL')
    return {'status':'PASS','logical_root':manifest['logical_root'],'transport_sha256':hashlib.sha256(raw).hexdigest(),
            'files':len(files),'dimension_semantics':'NOT_CHECKED','authority_effect':'NONE'}

def read_bounded_file(path: str | Path, maximum: int) -> bytes:
    """Bounded regular-file read with static symlink checks; not a hostile-writer vault."""
    check(type(maximum) is int and maximum>=0, 'DKN_V02_LIMIT')
    path=Path(os.path.abspath(path))
    for p in (path,*path.parents):
        check(not p.is_symlink(), 'DKN_V02_SOURCE_SYMLINK_REFUSED')
    flags=os.O_RDONLY|getattr(os,'O_BINARY',0)|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)
    try:
        fd=os.open(path,flags)
        with os.fdopen(fd,'rb') as f:
            before=os.fstat(f.fileno())
            check(stat.S_ISREG(before.st_mode), 'DKN_V02_SOURCE_INVALID')
            check(before.st_size<=maximum, 'DKN_V02_LIMIT')
            raw=f.read(maximum+1);after=os.fstat(f.fileno())
            check(len(raw)<=maximum, 'DKN_V02_LIMIT')
            check(before.st_size==after.st_size==len(raw) and before.st_mtime_ns==after.st_mtime_ns, 'DKN_V02_SOURCE_CHANGED')
            return raw
    except OSError as e:raise Refusal('DKN_V02_IO_ERROR') from e


def load_directory(root: Path) -> dict[str, bytes]:
    """Scan every admitted entry or refuse; never suppress directory I/O errors.

    This is a single-writer snapshot procedure, not an atomic filesystem snapshot.
    Empty directories carry no payload semantics in portable-files-only-v1.
    """
    root=Path(os.path.abspath(root))
    for path in (root, *root.parents):
        check(not path.is_symlink(), 'DKN_V02_SOURCE_SYMLINK_REFUSED')
    check(root.is_dir(), 'DKN_V02_SOURCE_INVALID')
    output={};total=0;entries=0;pending=[root]
    try:
        while pending:
            directory=pending.pop()
            # Path.rglob suppresses some scan errors. Explicit scandir must not.
            with os.scandir(directory) as scan:
                children=[]
                for entry in scan:
                    entries+=1
                    check(entries<=MAX_FILES*4, 'DKN_V02_LIMIT')
                    children.append(entry)
            for entry in sorted(children, key=lambda e:e.name):
                path=Path(entry.path)
                check(not entry.is_symlink(), 'DKN_V02_SOURCE_SYMLINK_REFUSED')
                if entry.is_dir(follow_symlinks=False):
                    pending.append(path)
                else:
                    check(entry.is_file(follow_symlinks=False), 'DKN_V02_SOURCE_INVALID')
                    name=path.relative_to(root).as_posix();_payload_path(name)
                    check(len(output)<MAX_FILES,'DKN_V02_LIMIT')
                    data=read_bounded_file(path,min(MAX_FILE,MAX_TOTAL-total))
                    total+=len(data);output[name]=data
    except OSError as e:raise Refusal('DKN_V02_IO_ERROR') from e
    _inventory(output)
    return output

def key_hex(key: Ed25519PrivateKey) -> str:
    return key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()

def _public(pub: str) -> Ed25519PublicKey:
    from .key_validation import admitted_public_key
    raw=bytes.fromhex(hex32(pub))
    check(admitted_public_key(raw), 'DKN_V02_PUBLIC_KEY_INVALID')
    return Ed25519PublicKey.from_public_bytes(raw)

def _verify_sig(pub: str, msg: bytes, sig: str):
    check(type(sig) is str and re.fullmatch('[0-9a-f]{128}',sig) is not None, 'DKN_V02_SIGNATURE_INVALID')
    check(int.from_bytes(bytes.fromhex(sig)[32:], 'little') < 2**252+27742317777372353535851937790883648493, 'DKN_V02_SIGNATURE_INVALID')
    public=_public(pub)
    try: public.verify(bytes.fromhex(sig),msg)
    except (InvalidSignature,ValueError) as e: raise Refusal('DKN_V02_SIGNATURE_INVALID') from e

def certify(manifest: dict, key: Ed25519PrivateKey, *, namespace_root: str | None=None) -> dict:
    validate_manifest(manifest)
    if namespace_root is not None: hex32(namespace_root)
    body={'schema':'dkn.detached-certificate.v0.2-candidate','logical_root':manifest['logical_root'],
          'namespace_root':namespace_root,'claim':'PUBLISHER_ATTESTS_COMMITMENT','signer_public_key_hex':key_hex(key)}
    return {**body,'signature_hex':key.sign(DOMAINS['certificate']+canonical(body)).hex()}

def verify_certificate(certificate: dict, manifest: dict) -> dict:
    exact(certificate, {'schema','logical_root','namespace_root','claim','signer_public_key_hex','signature_hex'})
    body={k:v for k,v in certificate.items() if k!='signature_hex'}
    check(body['schema']=='dkn.detached-certificate.v0.2-candidate' and body['claim']=='PUBLISHER_ATTESTS_COMMITMENT', 'DKN_V02_SCHEMA_INVALID')
    hex32(body['logical_root'])
    if body['namespace_root'] is not None:hex32(body['namespace_root'])
    validate_manifest(manifest)
    check(body['logical_root']==manifest['logical_root'], 'DKN_V02_MANIFEST_MISMATCH')
    _verify_sig(body['signer_public_key_hex'],DOMAINS['certificate']+canonical(body),certificate['signature_hex'])
    return {'signature':'PASS','publisher_statement':'PASS','authorization':'NOT_CHECKED','authority_effect':'NONE'}

def _validate_genesis_body(body: dict) -> None:
    check(body['schema']=='dkn.namespace-genesis.v0.2-candidate','DKN_V02_SCHEMA_INVALID')
    semantic_name=body['semantic_name'];purpose=body['purpose'];nonce=body['nonce']
    legacy_instance=body['legacy_instance'];recovery_policy_ref=body['recovery_policy_ref']
    check(type(semantic_name) is str and re.fullmatch('[a-z0-9][a-z0-9._-]{0,254}',semantic_name) is not None,'DKN_V02_NAME_INVALID')
    _token(purpose);_token(nonce)
    if legacy_instance is not None:
        check(type(legacy_instance) is str and legacy_instance.startswith('dkn:v0.1:b3:') and len(legacy_instance)==len('dkn:v0.1:b3:')+64, 'DKN_V02_INSTANCE_INVALID')
        hex32(legacy_instance.removeprefix('dkn:v0.1:b3:'))
    check(recovery_policy_ref is None or (type(recovery_policy_ref) is str and len(recovery_policy_ref)<=256), 'DKN_V02_SCHEMA_INVALID')
    _public(body['founder_public_key_hex'])

def declare_genesis(*,semantic_name: str,purpose: str,nonce: str,legacy_instance: str | None=None,
                    key: Ed25519PrivateKey,recovery_policy_ref: str | None=None) -> dict:
    # Human spelling is NOT globally exclusive; key signatures are proof of possession only.
    body={'schema':'dkn.namespace-genesis.v0.2-candidate','semantic_name':semantic_name,'purpose':purpose,
          'nonce':nonce,'legacy_instance':legacy_instance,'founder_public_key_hex':key_hex(key),
          'recovery_policy_ref':recovery_policy_ref}
    _validate_genesis_body(body)
    root=digest('namespace',body)
    return {**body,'namespace_root':root,'signature_hex':key.sign(DOMAINS['namespace']+canonical(body)).hex()}

def verify_genesis(value: dict) -> dict:
    exact(value,{'schema','semantic_name','purpose','nonce','legacy_instance','founder_public_key_hex','recovery_policy_ref','namespace_root','signature_hex'})
    check(value['schema']=='dkn.namespace-genesis.v0.2-candidate','DKN_V02_SCHEMA_INVALID')
    body={k:v for k,v in value.items() if k not in ('namespace_root','signature_hex')}
    _validate_genesis_body(body);hex32(value['namespace_root'])
    check(digest('namespace',body)==value['namespace_root'], 'DKN_V02_NAMESPACE_MISMATCH')
    _verify_sig(value['founder_public_key_hex'],DOMAINS['namespace']+canonical(body),value['signature_hex'])
    return {'namespace_root':value['namespace_root'],'signature':'PASS','human_name_exclusive':False,'legacy_binding':'NOT_APPLICABLE' if value['legacy_instance'] is None else 'NOT_ESTABLISHED','authority_effect':'NONE'}

def transition(genesis: dict, predecessor_key: Ed25519PrivateKey, successor_key_hex: str, *, epoch: int, previous_transition_hash: str | None=None) -> dict:
    verify_genesis(genesis)
    check(type(epoch) is int and 1<=epoch<2**63, 'DKN_V02_EPOCH_INVALID')
    _public(successor_key_hex)
    if previous_transition_hash is not None:hex32(previous_transition_hash)
    check((epoch==1)==(previous_transition_hash is None), 'DKN_V02_LINEAGE_INVALID')
    if epoch==1:check(key_hex(predecessor_key)==genesis['founder_public_key_hex'],'DKN_V02_LINEAGE_INVALID')
    body={'schema':'dkn.namespace-transition.v0.2-candidate','namespace_root':genesis['namespace_root'],
          'predecessor_public_key_hex':key_hex(predecessor_key),'successor_public_key_hex':successor_key_hex,
          'epoch':epoch,'previous_transition_hash':previous_transition_hash}
    return {**body,'transition_hash':digest('transition',body),'signature_hex':predecessor_key.sign(DOMAINS['transition']+canonical(body)).hex()}

def verify_transitions(genesis: dict, events: list[dict]) -> dict:
    verify_genesis(genesis)
    check(type(events) is list and len(events)<=MAX_FILES,'DKN_V02_LIMIT')
    active=genesis['founder_public_key_hex'];prev=None
    canonical(events)
    for index,e in enumerate(events,1):
        exact(e,{'schema','namespace_root','predecessor_public_key_hex','successor_public_key_hex','epoch','previous_transition_hash','transition_hash','signature_hex'})
        _public(e['successor_public_key_hex']);hex32(e['transition_hash'])
        body={k:v for k,v in e.items() if k not in ('transition_hash','signature_hex')}
        check(e['schema']=='dkn.namespace-transition.v0.2-candidate' and e['namespace_root']==genesis['namespace_root'] and type(e['epoch']) is int and e['epoch']==index and e['previous_transition_hash']==prev and e['predecessor_public_key_hex']==active,'DKN_V02_LINEAGE_INVALID')
        check(digest('transition',body)==e['transition_hash'], 'DKN_V02_LINEAGE_INVALID')
        _verify_sig(active,DOMAINS['transition']+canonical(body),e['signature_hex'])
        active=e['successor_public_key_hex'];prev=e['transition_hash']
    return {'signature_chain':'PASS','epoch':len(events),'active_key':active,'global_head':'NOT_ESTABLISHED','authority_effect':'NONE'}
