"""Offline witness-set evaluation, deliberately NOT a federation consensus engine.

Membership and minimum sequence are pinned caller policy, never learned from the
checkpoint being checked. A valid quorum is a bounded set of observations only.
"""
from __future__ import annotations
from collections import defaultdict
from .core import canonical, check
from .assurance import (validate, sam_hash, _records, _time, independent_subset,
                        _finish, BOUNDARY)
from .sam_schemas import V


def checkpoint_policy_ref(policy: dict) -> str:
    validate('checkpoint-policy', policy)
    # Reader high-water marks and age limits must evolve without re-signing history.
    membership = {k: v for k, v in policy.items() if k not in ('minimum_sequence', 'max_age_seconds')}
    return sam_hash('checkpoint-membership', membership)


def assess_checkpoints(checkpoints: list[dict], policy: dict, *, at_time: int) -> dict:
    canonical([checkpoints, policy, at_time]); _time(at_time)
    validate('checkpoint-policy', policy)
    pref = checkpoint_policy_ref(policy)
    records = _records(checkpoints, 'checkpoint')
    members = {m['public_key_hex']: m for m in policy['members']}
    policy_time_valid = policy['valid_from'] <= at_time < policy['valid_until']
    eligible = []
    excluded = []
    known = defaultdict(lambda: defaultdict(set))
    for record in records:
        b = record['body']; signer = record['signer_public_key_hex']
        if signer not in members:
            reason = 'NOT_IN_CALLER_MEMBERSHIP'
        elif b['policy_ref'] != pref or any(b[f] != policy[f] for f in ('substrate_ref', 'namespace_root', 'epoch')):
            reason = 'POLICY_OR_SCOPE_MISMATCH'
        else:
            # Known conflicting signed assertions are not erased by their expiry.
            known[b['sequence']][b['head_root']].add(signer)
            if b['sequence'] < policy['minimum_sequence']:
                reason = 'BELOW_CALLER_HIGH_WATER_MARK'
            elif not b['observed_at'] <= at_time < b['valid_until']:
                reason = 'OUTSIDE_VALIDITY'
            elif at_time-b['observed_at'] > policy['max_age_seconds']:
                reason = 'STALE_OBSERVATION'
            else:
                eligible.append(record)
                continue
        excluded.append({'checkpoint_ref': record['record_hash'], 'reason': reason})
    conflicts = [{'sequence': seq, 'heads': {h: sorted(keys) for h, keys in sorted(heads.items())}}
                 for seq, heads in sorted(known.items()) if len(heads) > 1]
    highest = max((r['body']['sequence'] for r in eligible), default=None)
    candidates = sorted({r['body']['head_root'] for r in eligible if r['body']['sequence'] == highest})
    selected = []
    selected_head = None
    if len(candidates) == 1:
        selected_head = candidates[0]
        keys = sorted({r['signer_public_key_hex'] for r in eligible
                       if r['body']['sequence'] == highest and r['body']['head_root'] == selected_head})
        selected = independent_subset(keys, members, policy['threshold'], policy['independence_dimensions']) or []
    status = 'CONTRADICTED' if conflicts else ('CONDITIONAL' if selected and policy_time_valid else 'INSUFFICIENT')
    return _finish({'schema': 'dkn.checkpoint-assessment.'+V, 'status': status,
                    'policy_ref': sam_hash('checkpoint-policy', policy),
                    'membership_policy_ref': pref, 'at_time': at_time, 'policy_time_valid': policy_time_valid,
                    'substrate_ref': policy['substrate_ref'], 'namespace_root': policy['namespace_root'],
                    'epoch': policy['epoch'], 'minimum_sequence': policy['minimum_sequence'],
                    'highest_eligible_sequence': highest, 'candidate_heads': candidates,
                    'observed_head': selected_head,
                    'selected_signers': selected,
                    'quorum': 'OBSERVED' if selected and policy_time_valid and not conflicts else 'NOT_ESTABLISHED',
                    'conflicts': conflicts, 'excluded_checkpoints': excluded,
                    'checkpoint_refs': sorted(r['record_hash'] for r in records),
                    'freshness': 'BOUNDED_OBSERVATION_ONLY' if status == 'CONDITIONAL' else 'NOT_ESTABLISHED',
                    'global_currentness': 'NOT_ESTABLISHED', 'consensus_safety': 'NOT_ESTABLISHED',
                    'independence': 'CALLER_POLICY_LABELS_ONLY',
                    'revocation_status': 'NOT_CHECKED', 'clock_source': 'CALLER_SUPPLIED',
                    'coverage': 'SUPPLIED_CHECKPOINTS_ONLY', **BOUNDARY}, 'checkpoint-report')


def make_handoff(checkpoints: list[dict], policy: dict, *, at_time: int, consumer: str) -> dict:
    """Recompute evidence, never accept a precomputed PASS from an external caller."""
    check(consumer in ('CHC', 'CCP'), 'DKN_V02_SAM_CONSUMER_UNSUPPORTED')
    result = assess_checkpoints(checkpoints, policy, at_time=at_time)
    return _finish({'schema': 'dkn.governance-evidence-handoff.'+V,
                    'consumer': consumer, 'assessment': result,
                    'admission': 'EXTERNAL_DECISION_REQUIRED',
                    'execution_authorized': False, 'recognition': 'NOT_EVALUATED',
                    'required_inputs': ['CALLER_RECOGNITION_POLICY', 'REVOCATION_POLICY',
                                        'FRESHNESS_POLICY', 'CAPABILITY_GRANT_IF_NEEDED'],
                    **BOUNDARY}, 'handoff')
