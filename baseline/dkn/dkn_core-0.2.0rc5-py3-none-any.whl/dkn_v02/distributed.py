"""DS-G1 read-only, evidence-aware composition of existing DKN verifiers.

All material is caller-supplied. No network, clock reading, pin mutation, signing,
execution, persistence, consensus, or inference from simulator omniscience occurs.
"""
from __future__ import annotations
import hashlib
from typing import Any
from .core import (Refusal, check, exact, canonical, read_canonical, hex32, _public,
                   verify_archive, verify_certificate)
from .lifecycle import verify_journal, assess_delegation, analyze_journals
from .assurance import verify_record, evaluate, compose, validate
from .federation import assess_checkpoints
from .distributed_schemas import V, MAX_OBJECTS, MAX_ARCHIVE, MAX_TICK, validate_shape

PREFIX=b'DKN_DS_G1\x00'

def object_hash(domain:str,value:Any)->str:
    check(domain in ('object','reader','view','scenario','trace-start','trace-entry'),'DKN_DS_DOMAIN_INVALID')
    return hashlib.sha256(PREFIX+domain.encode('ascii')+b'\x00'+canonical(value)).hexdigest()

def _copy(value): return read_canonical(canonical(value))

def validate_reader(reader:dict)->dict:
    validate_shape('reader',reader);_public(reader['subject_public_key_hex'])
    check(reader['operation']=='certify_artifact','DKN_DS_OPERATION_UNSUPPORTED')
    check(len(reader['composition_roots'])==len(set(reader['composition_roots'])),'DKN_DS_DUPLICATE')
    if reader['witness_policy'] is not None:
        validate('checkpoint-policy',reader['witness_policy'])
        check(reader['witness_policy']['namespace_root']==reader['expected_namespace'],'DKN_DS_SCOPE_MISMATCH')
    check(not reader['require_witness'] or reader['witness_policy'] is not None,'DKN_DS_POLICY_MISSING')
    if reader['assurance'] is not None:
        a=reader['assurance'];validate('contract',a['contract']);validate('policy',a['policy'])
        validate('context',{'schema':'dkn.assurance-context.v0.2-candidate','at_time':0,
                            'accepted_premises':a['accepted_premises']})
        check(a['contract']['scope']=={'substrate_ref':a['descriptor_ref'],
              'artifact_root':reader['expected_artifact_root'],'namespace_root':reader['expected_namespace']},
              'DKN_DS_SCOPE_MISMATCH')
    check(not reader['require_assurance'] or reader['assurance'] is not None,'DKN_DS_POLICY_MISSING')
    return reader


def _verify_envelope(envelope:dict)->dict:
    validate_shape('envelope',envelope)
    kind,v=envelope['kind'],envelope['value']
    if kind=='artifact':
        exact(v,{'archive_hex','certificate'},'DKN_DS_OBJECT_INVALID')
        s=v['archive_hex']
        check(type(s) is str and len(s)<=2*MAX_ARCHIVE and len(s)%2==0,'DKN_DS_LIMIT')
        check(all(c in '0123456789abcdef' for c in s),'DKN_DS_HEX_INVALID')
        from .navigation import _unpack_checked
        report,manifest=_unpack_checked(bytes.fromhex(s))
        certificate=v['certificate']
        if certificate is not None:
            signature=verify_certificate(certificate,manifest)
            return {**report,'certificate':signature,'signer_public_key_hex':certificate['signer_public_key_hex'],
                    'namespace_root':certificate['namespace_root']}
        return {**report,'certificate':None,'signer_public_key_hex':None,'namespace_root':None}
    if kind=='journal':
        exact(v,{'genesis','policy','events','checkpoint'},'DKN_DS_OBJECT_INVALID')
        # Checkpoint is assessed under reader time/pins, not admitted as timeless freshness.
        check(v['checkpoint'] is None or type(v['checkpoint']) is dict,'DKN_DS_OBJECT_INVALID')
        return verify_journal(v['genesis'],v['policy'],v['events'])
    return verify_record(v,expected_kind={'observation':'checkpoint','substrate':'substrate','evidence':'evidence'}[kind])


def assess_view(objects:list[dict],reader:dict,*,now:int)->dict:
    """Combine exact supplied evidence. Invalid candidates are quarantined visibly.

    A valid foreign object cannot satisfy scope or veto a namespace. Known valid local
    forks and same-scope contradictory observations are never hidden by a majority.
    Reader pins MUST originate in the application's accepted configuration.
    """
    check(type(objects) is list and len(objects)<=MAX_OBJECTS,'DKN_DS_LIMIT')
    check(type(now) is int and 0<=now<=MAX_TICK,'DKN_DS_TIME_INVALID')
    canonical([objects,reader,now]);validate_reader(reader)
    # Enforce aggregate lifecycle work before any signature replay, including bad candidates.
    journals=[o.get('value',{}).get('events',[]) for o in objects
              if type(o) is dict and o.get('kind')=='journal' and type(o.get('value')) is dict]
    check(len(journals)<=16 and sum(len(v) if type(v) is list else 0 for v in journals)<=512,'DKN_DS_LIMIT')
    seen=set(); valid=[];invalid=[];duplicates=0
    for obj in objects:
        ref=object_hash('object',obj)
        if ref in seen:
            duplicates+=1;continue
        seen.add(ref)
        try:
            result=_verify_envelope(obj)
            valid.append((ref,obj,result))
        except Refusal as exc:
            invalid.append({'object_ref':ref,'code':exc.code})
    valid.sort(key=lambda row:row[0]);invalid.sort(key=lambda row:row['object_ref'])
    artifacts=[{'object_ref':ref,'verification':report} for ref,o,report in valid
               if o['kind']=='artifact' and report['logical_root']==reader['expected_artifact_root']
               and report['signer_public_key_hex']==reader['subject_public_key_hex']
               and report['namespace_root']==reader['expected_namespace']]
    artifact={'status':'MATCH' if artifacts else 'INSUFFICIENT','matches':artifacts}
    local=[(ref,o['value'],r) for ref,o,r in valid
           if o['kind']=='journal' and r['namespace_root']==reader['expected_namespace']]
    exclusions=[ref for ref,o,r in valid if (o['kind']=='journal' and r['namespace_root']!=reader['expected_namespace'])
                or (o['kind']=='artifact' and (r['logical_root']!=reader['expected_artifact_root']
                    or r['signer_public_key_hex']!=reader['subject_public_key_hex']
                    or r['namespace_root']!=reader['expected_namespace']))]
    lifecycle={'status':'INDETERMINATE','reason':'PINNED_JOURNAL_MISSING','forks':None,
               'candidates':[],'newer_known_heads':[]}
    selected=[r for r in local if r[2]['head_ref']==reader['expected_head']]
    if local:
        first=local[0][1]
        forks=analyze_journals(first['genesis'],first['policy'],[row[1]['events'] for row in local])
        lifecycle['forks']=forks
        newer=[]
        for _,bundle,state in local:
            refs=[state['anchor_ref']]+[e['event_ref'] for e in bundle['events']]
            if reader['expected_head'] in refs[:-1]: newer.append(state['head_ref'])
        lifecycle['newer_known_heads']=sorted(set(newer))
        for ref,b,state in selected:
            try:
                args=dict(expected_namespace=reader['expected_namespace'],expected_head=reader['expected_head'],
                    subject_public_key_hex=reader['subject_public_key_hex'],artifact_root=reader['expected_artifact_root'],
                    operation=reader['operation'],now=now,max_checkpoint_age=reader['max_checkpoint_age'],checkpoint=b['checkpoint'])
                assessment=assess_delegation(b['genesis'],b['policy'],b['events'],minimum=reader['minimum'],**args)
                # Both floors must hold. Never let a newer local floor erase a conflicting external one.
                if reader['external_minimum'] is not None:
                    assess_delegation(b['genesis'],b['policy'],b['events'],minimum=reader['external_minimum'],**args)
                lifecycle['candidates'].append({'object_ref':ref,'assessment':assessment})
            except Refusal as exc:
                lifecycle['candidates'].append({'object_ref':ref,'refusal':exc.code})
        good=[r['assessment'] for r in lifecycle['candidates'] if 'assessment' in r]
        if forks['forks']:
            lifecycle.update(status='CONTRADICTED',reason='VISIBLE_LIFECYCLE_FORK')
        elif newer:
            lifecycle.update(status='INDETERMINATE',reason='PIN_NOT_MAXIMAL_IN_SUPPLIED_VIEW')
        elif any(r['status']=='MATCH_FOR_SUPPLIED_VIEW' for r in good):
            lifecycle.update(status='MATCH_FOR_SUPPLIED_VIEW',reason='EXACT_PINNED_EVIDENCE')
        elif any(r['status']=='NO_MATCH' for r in good):
            lifecycle.update(status='NO_MATCH',reason='NO_MATCH_IN_PINNED_VIEW')
        elif selected:
            lifecycle.update(reason='PINNED_EVIDENCE_INELIGIBLE')
    observations={o['value']['record_hash']:o['value'] for _,o,_ in valid if o['kind']=='observation'}
    witness={'status':'NOT_REQUESTED','assessment':None,'scope_binding':'NOT_CHECKED'}
    if reader['witness_policy'] is not None:
        cp=assess_checkpoints(list(observations.values()),reader['witness_policy'],at_time=now)
        bound=bool(selected and cp['observed_head']==reader['expected_head'] and
                   cp['highest_eligible_sequence']==selected[0][2]['sequence'] and
                   reader['witness_policy']['epoch']==selected[0][2]['epoch'])
        witness={'status':cp['status'] if bound or cp['status']=='CONTRADICTED' else 'INSUFFICIENT',
                 'assessment':cp,'scope_binding':'EXACT_JOURNAL_HEAD_SEQUENCE_EPOCH' if bound else 'NOT_ESTABLISHED'}
    descriptors={o['value']['record_hash']:o['value'] for _,o,_ in valid if o['kind']=='substrate'}
    evidence={o['value']['record_hash']:o['value'] for _,o,_ in valid if o['kind']=='evidence'}
    assurance={'status':'NOT_REQUESTED','assessment':None}
    if reader['assurance'] is not None:
        a=reader['assurance']
        if a['descriptor_ref'] in descriptors:
            r=evaluate(descriptors[a['descriptor_ref']],a['contract'],list(evidence.values()),a['policy'],
                      {'schema':'dkn.assurance-context.v0.2-candidate','at_time':now,'accepted_premises':a['accepted_premises']})
            assurance={'status':r['status'],'assessment':r}
        else:
            assurance={'status':'INSUFFICIENT','assessment':None}
    composition={'status':'NOT_REQUESTED','assessment':None}
    if reader['composition_roots']:
        if set(reader['composition_roots'])<=set(descriptors):
            r=compose(list(descriptors.values()),roots=reader['composition_roots'],at_time=now)
            composition={'status':r['status'],'assessment':r}
        else: composition={'status':'INCOMPLETE','assessment':None}
    statuses=[artifact['status'],lifecycle['status']]
    if reader['require_witness'] or witness['status']=='CONTRADICTED':statuses.append(witness['status'])
    if reader['require_assurance'] or assurance['status']=='CONTRADICTED':statuses.append(assurance['status'])
    if 'CONTRADICTED' in statuses: status='CONTRADICTED'
    elif 'NO_MATCH' in statuses:status='NO_MATCH'
    elif any(s not in ('MATCH','MATCH_FOR_SUPPLIED_VIEW','SATISFIES','CONDITIONAL') for s in statuses):status='INDETERMINATE'
    elif 'CONDITIONAL' in statuses:status='CONDITIONAL'
    else:status='MATCH_FOR_SUPPLIED_VIEW'
    result={'schema':'dkn.distributed-view.'+V,'status':status,'reader_ref':object_hash('reader',reader),
        'view_ref':object_hash('view',sorted(seen)),'evaluated_at':now,
        'artifact':artifact,'lifecycle':lifecycle,'witness':witness,'assurance':assurance,'composition':composition,
        'invalid_objects':invalid,'duplicate_objects':duplicates,'scope_exclusions':sorted(exclusions),
        'freshness':'SUPPLIED_VIEW_AND_CALLER_CLOCK_ONLY','coverage':'SUPPLIED_OBJECTS_ONLY',
        'global_currentness':'NOT_ESTABLISHED','consensus_safety':'NOT_ESTABLISHED',
        'execution_authorized':False,'admission':'EXTERNAL_DECISION_REQUIRED','authority_effect':'NONE'}
    validate_shape('view',result)
    return result
