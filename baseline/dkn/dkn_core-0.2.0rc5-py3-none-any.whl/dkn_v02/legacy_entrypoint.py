"""Keep the legacy CLI available, with a typed optional-dependency boundary."""
import importlib.util
import json


def main():
    if importlib.util.find_spec('blake3') is None:
        print(json.dumps({'status':'REFUSED','code':'DKN_LEGACY_DEPENDENCY_UNAVAILABLE',
                          'required_extra':'dkn-core[legacy]','authority_effect':'NONE'},sort_keys=True))
        return 2
    from dkn_core.cli import main as legacy_main
    return legacy_main()
