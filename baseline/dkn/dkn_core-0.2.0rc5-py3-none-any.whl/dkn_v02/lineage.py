"""Bounded fork analysis of complete supplied, signature-verified transition chains.

A visible fork is evidence of multiple signed successors, not a selected winner.
No absence-of-undiscovered-forks, recovery, revocation or currentness is implied.
"""
from .core import canonical, check, verify_genesis, verify_transitions


def analyze_lineage(genesis: dict, chains: list[list[dict]]) -> dict:
    canonical([genesis, chains])
    verify_genesis(genesis)
    check(type(chains) is list and 1 <= len(chains) <= 64, 'DKN_V02_LINEAGE_LIMIT')
    check(all(type(chain) is list for chain in chains), 'DKN_V02_LINEAGE_INVALID')
    check(sum(len(chain) for chain in chains) <= 512, 'DKN_V02_LINEAGE_LIMIT')
    nodes={}; children={};tips=set()
    for chain in chains:
        verify_transitions(genesis, chain)
        tips.add(chain[-1]['transition_hash'] if chain else genesis['namespace_root'])
        for event in chain:
            ref=event['transition_hash'];nodes[ref]=event
            predecessor=event['previous_transition_hash'] or genesis['namespace_root']
            children.setdefault(predecessor,set()).add(ref)
    forks=[{'predecessor_ref': parent,
            'successors': [{'transition_hash':ref,
                            'epoch':nodes[ref]['epoch'],
                            'successor_public_key_hex':nodes[ref]['successor_public_key_hex']}
                           for ref in sorted(refs)]}
           for parent,refs in sorted(children.items()) if len(refs)>1]
    return {'schema':'dkn.lineage-analysis.v0.2-candidate',
            'namespace_root':genesis['namespace_root'], 'supplied_chains':len(chains),
            'unique_transitions':len(nodes), 'supplied_chain_tips':sorted(tips),
            'forks':forks, 'fork_evidence':'OBSERVED' if forks else 'NOT_OBSERVED_IN_SUPPLIED_CHAINS',
            'signature_chains':'PASS', 'selected_head':None,
            'global_head':'NOT_ESTABLISHED','revocation':'NOT_CHECKED',
            'coverage':'SUPPLIED_CHAINS_ONLY','authority_effect':'NONE'}
