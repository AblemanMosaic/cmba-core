"""Explicit offline storage adapters; bytes are checked independently of providers.

These implement local publication/retrieval, not retention SLAs or a hardened
transactional vault. A hostile concurrent local filesystem writer is out of scope.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import stat
from typing import Protocol

from .core import Refusal, canonical, check, hex32, verify_archive, MAX_TOTAL, MAX_META, MAX_FILES, MAX_TRANSPORT
from .assurance import BOUNDARY, validate
from .sam_schemas import V



class Store(Protocol):
    backend_id: str
    def put(self, raw: bytes) -> dict: ...
    def get(self, transport_sha256: str) -> bytes: ...


def _locator(backend_id: str, raw: bytes) -> dict:
    report = verify_archive(raw)
    result = {'schema': 'dkn.storage-locator.'+V, 'backend_id': backend_id,
              'logical_root': report['logical_root'], 'transport_sha256': report['transport_sha256']}
    validate('locator', result)
    return result


class MemoryStore:
    """In-memory fixture/reference adapter. No persistent durability guarantee."""
    def __init__(self, backend_id: str = 'memory'):
        validate('locator', {'schema': 'dkn.storage-locator.'+V, 'backend_id': backend_id,
                             'logical_root': '0'*64, 'transport_sha256': '0'*64})
        self.backend_id = backend_id
        self._objects: dict[str, bytes] = {}

    def put(self, raw: bytes) -> dict:
        result = _locator(self.backend_id, raw)
        check(len(self._objects) < 128 or result['transport_sha256'] in self._objects,
              'DKN_V02_STORE_LIMIT')
        self._objects[result['transport_sha256']] = raw
        return result

    def get(self, transport_sha256: str) -> bytes:
        hex32(transport_sha256)
        check(transport_sha256 in self._objects, 'DKN_V02_STORE_NOT_FOUND')
        return self._objects[transport_sha256]


def _check_ancestors(path: Path) -> None:
    # Snapshot checks plus O_NOFOLLOW below, not descriptor-relative race immunity.
    for p in (path, *path.parents):
        check(not p.is_symlink(), 'DKN_V02_STORE_SYMLINK')


class DirectoryStore:
    """Create-only single-writer local content store; re-verify after every read.

    An interrupted write may leave a damaged candidate. Subsequent reads reject it.
    No overwrites, chmod, deletion, recovery, or network activity is performed.
    """
    def __init__(self, root: str | Path, backend_id: str = 'local'):
        validate('locator', {'schema': 'dkn.storage-locator.'+V, 'backend_id': backend_id,
                             'logical_root': '0'*64, 'transport_sha256': '0'*64})
        self.root = Path(os.path.abspath(root))
        self.backend_id = backend_id

    def get(self, transport_sha256: str) -> bytes:
        hex32(transport_sha256)
        path = self.root/(transport_sha256+'.zip')
        _check_ancestors(path)
        flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
        try:
            fd = os.open(path, flags)
            with os.fdopen(fd, 'rb') as f:
                before = os.fstat(f.fileno())
                check(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'DKN_V02_STORE_FILE_INVALID')
                check(before.st_size <= MAX_TRANSPORT, 'DKN_V02_STORE_LIMIT')
                raw = f.read(MAX_TRANSPORT+1)
                after = os.fstat(f.fileno())
                check(len(raw) <= MAX_TRANSPORT and before.st_size == after.st_size == len(raw)
                      and before.st_mtime_ns == after.st_mtime_ns, 'DKN_V02_STORE_CHANGED')
        except OSError as exc:
            raise Refusal('DKN_V02_STORE_IO_ERROR') from exc
        check(hashlib.sha256(raw).hexdigest() == transport_sha256, 'DKN_V02_STORE_DIGEST_MISMATCH')
        verify_archive(raw)
        return raw

    def put(self, raw: bytes) -> dict:
        locator = _locator(self.backend_id, raw)
        _check_ancestors(self.root)
        path = self.root/(locator['transport_sha256']+'.zip')
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            _check_ancestors(path)
            if path.exists():
                check(self.get(locator['transport_sha256']) == raw, 'DKN_V02_STORE_EXISTS_DIFFERENT')
                return locator
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
            fd = os.open(path, flags, 0o600)
            with os.fdopen(fd, 'wb') as f:
                f.write(raw); f.flush(); os.fsync(f.fileno())
        except OSError as exc:
            raise Refusal('DKN_V02_STORE_IO_ERROR') from exc
        return locator


def retrieve(locators: list[dict], stores: dict[str, Store], *, expected_root: str) -> tuple[bytes | None, dict]:
    """Ordered, bounded fallback. Untrusted bytes and locator identities are checked.

    Exhausting a supplied list means INDETERMINATE, never nonexistent globally.
    A third-party Store may perform I/O: the caller owns adapter/time budgets.
    """
    hex32(expected_root)
    check(type(locators) is list and len(locators) <= 16 and type(stores) is dict,
          'DKN_V02_STORE_LIMIT')
    canonical(locators)
    for locator in locators:
        validate('locator', locator)
    attempts = []
    for locator in locators:
        try:
            check(locator['logical_root'] == expected_root, 'DKN_V02_STORE_IDENTITY_MISMATCH')
            check(locator['backend_id'] in stores, 'DKN_V02_STORE_BACKEND_UNAVAILABLE')
            store = stores[locator['backend_id']]
            check(store.backend_id == locator['backend_id'], 'DKN_V02_STORE_BACKEND_MISMATCH')
            raw = store.get(locator['transport_sha256'])
            check(type(raw) is bytes and len(raw) <= MAX_TRANSPORT, 'DKN_V02_STORE_LIMIT')
            check(hashlib.sha256(raw).hexdigest() == locator['transport_sha256'], 'DKN_V02_STORE_DIGEST_MISMATCH')
            report = verify_archive(raw)
            check(report['logical_root'] == expected_root, 'DKN_V02_STORE_IDENTITY_MISMATCH')
            attempts.append({'locator': locator, 'status': 'RETRIEVED'})
            return raw, {'schema': 'dkn.retrieval-observation.'+V, 'status': 'RETRIEVED',
                         'logical_root': expected_root, 'attempts': attempts,
                         'availability_scope': 'THIS_INVOCATION_ONLY',
                         'freshness': 'NOT_ESTABLISHED', 'future_availability': 'NOT_ESTABLISHED', **BOUNDARY}
        except (Refusal, OSError) as exc:
            attempts.append({'locator': locator, 'status': 'REFUSED',
                             'code': exc.code if isinstance(exc, Refusal) else 'DKN_V02_STORE_IO_ERROR'})
    return None, {'schema': 'dkn.retrieval-observation.'+V, 'status': 'INDETERMINATE',
                  'logical_root': expected_root, 'attempts': attempts,
                  'reason': 'SUPPLIED_SOURCES_EXHAUSTED', 'global_absence': 'NOT_ESTABLISHED', **BOUNDARY}
