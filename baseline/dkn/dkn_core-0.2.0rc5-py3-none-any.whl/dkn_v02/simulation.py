"""Deterministic DS-G1 message/failure model around real DKN evidence evaluators.

This is NOT a P2P daemon or a consensus implementation. It models exact finite
schedules with public pre-signed fixtures, in-memory mailboxes and local pins.
No network, filesystem, real clock, randomness, key generation or implicit retry.
"""
from __future__ import annotations
import heapq
from .core import Refusal, canonical, read_canonical, check
from .distributed import object_hash, validate_reader, assess_view
from .distributed_schemas import V, MAX_TICK, MAX_ASSESSMENTS, validate_shape

MAX_TRACE=1024
MAX_SNAPSHOTS=16

def _copy(value):return read_canonical(canonical(value))

def validate_scenario(scenario:dict)->dict:
    validate_shape('scenario',scenario)
    for group in ('objects','nodes','readers'):
        ids=[row['id'] for row in scenario[group]]
        check(len(ids)==len(set(ids)),'DKN_DS_DUPLICATE')
    objects={v['id'] for v in scenario['objects']};nodes={v['id'] for v in scenario['nodes']}
    readers={v['id'] for v in scenario['readers']}
    for node in scenario['nodes']:
        check(set(node['initial_objects'])<=objects,'DKN_DS_REFERENCE_UNKNOWN')
        check(len(node['initial_objects'])==len(set(node['initial_objects'])),'DKN_DS_DUPLICATE')
        domains=[(d['dimension'],d['domain_id']) for d in node['fault_domains']]
        check(len(domains)==len(set(domains)),'DKN_DS_DUPLICATE')
    for reader in scenario['readers']:
        check(reader['node'] in nodes,'DKN_DS_REFERENCE_UNKNOWN');validate_reader(reader['policy'])
    time=0;labels=set();assessments=0
    for step in scenario['steps']:
        check(time<=step['at']<=scenario['until'],'DKN_DS_TIME_ORDER');time=step['at']
        action=step['action']
        for field in ('source','target','left','right','node'):
            if field in step:check(step[field] in nodes,'DKN_DS_REFERENCE_UNKNOWN')
        if 'reader' in step:check(step['reader'] in readers,'DKN_DS_REFERENCE_UNKNOWN')
        if 'object' in step:check(step['object'] in objects,'DKN_DS_REFERENCE_UNKNOWN')
        if action=='send':
            check(step['source']!=step['target'],'DKN_DS_SELF_LINK')
            check(step['at']+step['delay']<=MAX_TICK,'DKN_DS_TIME_INVALID')
        elif action=='partition':check(step['left']!=step['right'],'DKN_DS_SELF_LINK')
        elif action=='configure':validate_reader(step['policy'])
        elif action=='assess':
            check(step['label'] not in labels,'DKN_DS_DUPLICATE');labels.add(step['label']);assessments+=1
    check(assessments<=MAX_ASSESSMENTS,'DKN_DS_LIMIT')
    return scenario


def run_scenario(scenario:dict)->dict:
    """Return replayable finite transcript. Ties are due deliveries, then input steps.

    At each input step, due messages are processed first in (due-time, send-index)
    order. Zero-delay sends deliver immediately after their send step. A blocked
    delivery is dropped, not delayed for healing. Explicit sends model any retries.
    """
    validate_scenario(scenario);scenario=_copy(scenario)
    scenario_ref=object_hash('scenario',scenario)
    objects={o['id']:{'kind':o['kind'],'value':o['value']} for o in scenario['objects']}
    nodes={n['id']:{'known':set(n['initial_objects']),'online':True,'domains':n['fault_domains'],
                     'clock_offset':n['clock_offset']} for n in scenario['nodes']}
    readers={r['id']:{'node':r['node'],'policy':r['policy']} for r in scenario['readers']}
    blocked=set();failed_domains=set();queue=[];pending={};snapshots={}
    trace=[];assessments=[];message_index=0
    chain=object_hash('trace-start',{'scenario_ref':scenario_ref})
    def record(at,kind,details):
        nonlocal chain
        check(len(trace)<MAX_TRACE,'DKN_DS_TRACE_LIMIT')
        body={'index':len(trace),'time':at,'type':kind,'details':details,'previous_hash':chain}
        chain=object_hash('trace-entry',body);trace.append({**body,'entry_hash':chain})
        # Strict cumulative byte budget, not just per-entry budgeting.
        canonical(trace)
    def online(node):
        n=nodes[node]
        return n['online'] and not any((d['dimension'],d['domain_id']) in failed_domains for d in n['domains'])
    def link(a,b):return tuple(sorted((a,b)))
    def drain(until):
        while queue and queue[0][0]<=until:
            due,number,mid=heapq.heappop(queue)
            m=pending.pop(mid,None)
            if m is None:continue  # Explicitly dropped, already recorded.
            a,b=m['source'],m['target']
            if not online(a) or not online(b): outcome='ENDPOINT_UNAVAILABLE'
            elif link(a,b) in blocked:outcome='LINK_BLOCKED'
            else:
                outcome='DUPLICATE_DELIVERY' if m['object'] in nodes[b]['known'] else 'DELIVERED_UNTRUSTED'
                nodes[b]['known'].add(m['object'])
            record(due,'delivery',{'message':mid,**m,'outcome':outcome})
    for step in scenario['steps']:
        at,action=step['at'],step['action'];drain(at)
        if action=='send':
            message_index+=1;mid=f'm{message_index:06d}';a,b=step['source'],step['target']
            if step['object'] not in nodes[a]['known']:outcome='SOURCE_LACKS_OBJECT'
            elif not online(a) or not online(b):outcome='ENDPOINT_UNAVAILABLE'
            elif link(a,b) in blocked:outcome='LINK_BLOCKED'
            else:
                outcome='QUEUED';m={'source':a,'target':b,'object':step['object']}
                pending[mid]=m;heapq.heappush(queue,(at+step['delay'],message_index,mid))
            record(at,'send',{'message':mid,**{k:v for k,v in step.items() if k not in ('at','action')},'outcome':outcome})
            drain(at)
        elif action=='partition':
            pair=link(step['left'],step['right'])
            if step['blocked']:blocked.add(pair)
            else:blocked.discard(pair)
            record(at,'partition',{k:v for k,v in step.items() if k not in ('at','action')})
        elif action=='node':
            nodes[step['node']]['online']=step['online'];record(at,'node',{'node':step['node'],'online':step['online']})
        elif action=='clock':
            nodes[step['node']]['clock_offset']=step['offset'];record(at,'clock',{'node':step['node'],'offset':step['offset']})
        elif action=='domain':
            d=(step['dimension'],step['domain_id'])
            if step['online']:failed_domains.discard(d)
            else:failed_domains.add(d)
            record(at,'domain',{k:v for k,v in step.items() if k not in ('at','action')})
        elif action=='drop':
            check(step['message'] in pending,'DKN_DS_MESSAGE_UNKNOWN')
            pending.pop(step['message']);record(at,'drop',{'message':step['message']})
        elif action=='configure':
            readers[step['reader']]['policy']=_copy(step['policy'])
            record(at,'configure',{'reader':step['reader'],'policy_ref':object_hash('reader',step['policy']),
                                  'recognition':'EXPLICIT_SCENARIO_INPUT_NOT_NETWORK_AUTHORITY'})
        elif action=='snapshot':
            key=(step['node'],step['slot']);check(key in snapshots or len(snapshots)<MAX_SNAPSHOTS,'DKN_DS_LIMIT')
            snapshots[key]={'known':set(nodes[step['node']]['known']),
                'policies':{k:_copy(r['policy']) for k,r in readers.items() if r['node']==step['node']}}
            record(at,'snapshot',{'node':step['node'],'slot':step['slot'],'scope':'MODELED_LOCAL_DISK_ONLY'})
        elif action=='restore':
            key=(step['node'],step['slot']);check(key in snapshots,'DKN_DS_SNAPSHOT_UNKNOWN')
            snap=snapshots[key];nodes[step['node']]['known']=set(snap['known'])
            for rid,policy in snap['policies'].items():
                external=readers[rid]['policy']['external_minimum']
                readers[rid]['policy']=_copy(policy)
                readers[rid]['policy']['external_minimum']=external
            record(at,'restore',{'node':step['node'],'slot':step['slot'],
                                 'external_floor':'PRESERVED_BY_MODEL_ASSUMPTION_NOT_STORAGE_PROOF'})
        elif action=='assess':
            r=readers[step['reader']];node=r['node'];now=at+nodes[node]['clock_offset']
            if not online(node): report={'status':'INDETERMINATE','reason':'READER_OFFLINE','authority_effect':'NONE'}
            else:
                try:
                    report=assess_view([objects[name] for name in sorted(nodes[node]['known'])],r['policy'],now=now)
                except Refusal as exc:
                    report={'status':'REFUSED','code':exc.code,'authority_effect':'NONE'}
            assessment={'label':step['label'],'reader':step['reader'],'report':report}
            assessments.append(assessment)
            record(at,'assessment',assessment)
    drain(scenario['until'])
    result={'schema':'dkn.distributed-transcript.'+V,'scenario_ref':scenario_ref,'trace_root':chain,
        'trace':trace,'assessments':assessments,
        'terminal':{'time':scenario['until'],'pending_messages':sorted(pending),
            'nodes':[{'id':name,'online':online(name),'known_objects':sorted(n['known'])}
                     for name,n in sorted(nodes.items())],
            'reader_policy_refs':{name:object_hash('reader',r['policy']) for name,r in sorted(readers.items())}},
        'simulation_only':True,'model_profile':'DS-G1','production_evidence':False,
        'global_currentness':'NOT_ESTABLISHED','consensus_safety':'NOT_ESTABLISHED','authority_effect':'NONE'}
    validate_shape('transcript',result)
    return result


def verify_replay(scenario:dict,transcript:dict)->dict:
    """Recompute full trace and results, not merely a claimed hash chain or PASS flag."""
    validate_shape('transcript',transcript)
    expected=run_scenario(scenario)
    check(canonical(expected)==canonical(transcript),'DKN_DS_REPLAY_MISMATCH')
    return {'schema':'dkn.distributed-replay-check.'+V,'status':'MATCH_EXACT_SIMULATION_REPLAY',
            'scenario_ref':expected['scenario_ref'],'trace_root':expected['trace_root'],
            'simulation_only':True,'production_evidence':False,'authority_effect':'NONE'}
