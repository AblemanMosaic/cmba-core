"""Offline read/navigation CLI. Explicit paths, no network calls."""
import argparse
import json
from pathlib import Path
from .core import Refusal,read_canonical,read_bounded_file,MAX_META,MAX_TRANSPORT
from .navigation import LocalIndex,inspect
from .lineage import analyze_lineage


def _json(path):
    return None if path is None else read_canonical(read_bounded_file(path,MAX_META))


def main(argv=None):
    p=argparse.ArgumentParser(prog='python -m dkn_v02.nav_cli')
    sub=p.add_subparsers(dest='op',required=True)
    a=sub.add_parser('inspect');a.add_argument('archive')
    b=sub.add_parser('index');b.add_argument('vault');b.add_argument('archive')
    for command in (a,b):
        command.add_argument('--certificate')
        command.add_argument('--relations')
        command.add_argument('--genesis')
        command.add_argument('--transitions')
    c=sub.add_parser('resolve');c.add_argument('vault');c.add_argument('root')
    d=sub.add_parser('discover');d.add_argument('vault');d.add_argument('--name');d.add_argument('--namespace');d.add_argument('--signer');d.add_argument('--limit',type=int,default=64)
    e=sub.add_parser('traverse');e.add_argument('vault');e.add_argument('root');e.add_argument('--direction',choices=['incoming','outgoing'],default='outgoing');e.add_argument('--depth',type=int,default=3);e.add_argument('--nodes',type=int,default=128)
    f=sub.add_parser('compare');f.add_argument('vault');f.add_argument('namespace_root')
    g=sub.add_parser('lineage');g.add_argument('genesis');g.add_argument('chains')
    args=p.parse_args(argv)
    try:
        if args.op in ('inspect','index'):
            kws={n:_json(getattr(args,n)) for n in ('certificate','relations','genesis','transitions')}
            raw=read_bounded_file(args.archive,MAX_TRANSPORT)
            result=inspect(raw,**kws) if args.op=='inspect' else LocalIndex(args.vault).add(raw,**kws)
        elif args.op=='resolve':result=LocalIndex(args.vault).resolve_exact(args.root)
        elif args.op=='discover':result=LocalIndex(args.vault).discover(semantic_name=args.name,namespace_root=args.namespace,signer_public_key_hex=args.signer,limit=args.limit)
        elif args.op=='traverse':result=LocalIndex(args.vault).traverse(args.root,direction=args.direction,max_depth=args.depth,max_nodes=args.nodes)
        elif args.op=='lineage':result=analyze_lineage(_json(args.genesis),_json(args.chains))
        else:result=LocalIndex(args.vault).compare_namespace(args.namespace_root)
        print(json.dumps(result,sort_keys=True,ensure_ascii=False));return 0
    except (Refusal,OSError) as exc:
        print(json.dumps({'status':'REFUSED','code':exc.code if isinstance(exc,Refusal) and exc.code != 'DKN_V02_IO_ERROR' else 'DKN_V02_NAV_IO_ERROR','authority_effect':'NONE'}))
        return 2

if __name__=='__main__':raise SystemExit(main())
