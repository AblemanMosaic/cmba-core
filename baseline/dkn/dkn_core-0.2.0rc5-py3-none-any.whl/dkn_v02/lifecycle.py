"""Opt-in LC-F1 namespace lifecycle: finite, offline, reader-pinned evidence.

Not a capability broker, trusted clock, consensus protocol or live revocation service.
Existing v0.2 namespace/transition/certificate byte formats are not redefined.
"""
from __future__ import annotations

import hashlib
from typing import Any
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from .core import (Refusal, canonical, read_canonical, check, exact, hex32, _token,
                   _public, _verify_sig, key_hex, verify_genesis, verify_certificate)

PROFILE = 'dkn.lifecycle.v0.2-f1'
POLICY_SCHEMA = 'dkn.lifecycle-policy.v0.2-f1'
EVENT_SCHEMA = 'dkn.lifecycle-event.v0.2-f1'
CHECKPOINT_SCHEMA = 'dkn.lifecycle-checkpoint.v0.2-f1'
MAX_EVENTS = 256
MAX_GUARDIANS = 16
MAX_OPERATIONS = 16
MAX_GRANT_SECONDS = 366 * 24 * 3600
PREFIX = b'DKN_LC_F1\x00'
KINDS = frozenset(('delegate', 'revoke_grant', 'revoke_key', 'rotate', 'recover', 'suspend', 'resume'))


def _hash(kind: str, value: Any) -> str:
    return hashlib.sha256(PREFIX + kind.encode('ascii') + b'\x00' + canonical(value)).hexdigest()


def _message(kind: str, value: dict) -> bytes:
    return PREFIX + kind.encode('ascii') + b'\x00' + canonical(value)


def _integer(value: Any, minimum: int = 0, maximum: int = 2**63 - 1) -> int:
    check(type(value) is int and minimum <= value <= maximum, 'DKN_LC_NUMBER_INVALID')
    return value


def _keylist(keys: Any, maximum: int) -> None:
    check(type(keys) is list and len(keys) <= maximum, 'DKN_LC_LIMIT')
    for key in keys:
        _public(key)
    check(keys == sorted(set(keys)), 'DKN_LC_KEY_SET_INVALID')


def _operations(operations: Any) -> None:
    check(type(operations) is list and 1 <= len(operations) <= MAX_OPERATIONS, 'DKN_LC_LIMIT')
    for operation in operations:
        _token(operation)
    check(operations == sorted(set(operations)), 'DKN_LC_OPERATIONS_INVALID')


def validate_policy(policy: dict) -> dict:
    canonical(policy)
    exact(policy, {'schema', 'recovery_keys', 'recovery_threshold', 'allowed_operations',
                   'max_grant_seconds'}, 'DKN_LC_POLICY_INVALID')
    check(policy['schema'] == POLICY_SCHEMA, 'DKN_LC_POLICY_INVALID')
    _keylist(policy['recovery_keys'], MAX_GUARDIANS)
    _integer(policy['recovery_threshold'], 0, len(policy['recovery_keys']))
    check((not policy['recovery_keys']) == (policy['recovery_threshold'] == 0), 'DKN_LC_POLICY_INVALID')
    _operations(policy['allowed_operations'])
    _integer(policy['max_grant_seconds'], 1, MAX_GRANT_SECONDS)
    return {'policy_ref': 'dkn:lc-f1:sha256:' + _hash('policy', policy), 'authority_effect': 'NONE'}


def lifecycle_policy(*, recovery_keys: list[str], recovery_threshold: int,
                     allowed_operations: list[str], max_grant_seconds: int = 86400) -> dict:
    # Do not silently deduplicate a quorum or permission set.
    check(type(recovery_keys) is list and type(allowed_operations) is list, 'DKN_LC_POLICY_INVALID')
    policy = {'schema': POLICY_SCHEMA, 'recovery_keys': recovery_keys,
              'recovery_threshold': recovery_threshold, 'allowed_operations': allowed_operations,
              'max_grant_seconds': max_grant_seconds}
    validate_policy(policy)
    return read_canonical(canonical(policy))


def policy_reference(policy: dict) -> str:
    return validate_policy(policy)['policy_ref']


def lifecycle_anchor(genesis: dict, policy: dict) -> str:
    verify_genesis(genesis)
    ref = policy_reference(policy)
    check(genesis['recovery_policy_ref'] == ref, 'DKN_LC_POLICY_UNBOUND')
    check(genesis['founder_public_key_hex'] not in policy['recovery_keys'], 'DKN_LC_ROLE_OVERLAP')
    return _hash('anchor', {'schema': PROFILE, 'namespace_root': genesis['namespace_root'],
                            'policy_ref': ref})


def _payload(kind: str, payload: Any, policy: dict, issued_at: int) -> None:
    if kind == 'delegate':
        exact(payload, {'subject_public_key_hex', 'artifact_root', 'operations', 'not_before',
                        'expires_at'}, 'DKN_LC_PAYLOAD_INVALID')
        _public(payload['subject_public_key_hex']); hex32(payload['artifact_root'])
        _operations(payload['operations'])
        check(set(payload['operations']) <= set(policy['allowed_operations']), 'DKN_LC_SCOPE_ESCALATION')
        _integer(payload['not_before']); _integer(payload['expires_at'])
        check(issued_at <= payload['not_before'] < payload['expires_at'] and
              payload['expires_at'] - issued_at <= policy['max_grant_seconds'], 'DKN_LC_GRANT_TIME_INVALID')
    elif kind in ('rotate', 'recover'):
        exact(payload, {'successor_public_key_hex'}, 'DKN_LC_PAYLOAD_INVALID')
        _public(payload['successor_public_key_hex'])
    elif kind == 'revoke_grant':
        exact(payload, {'grant_ref'}, 'DKN_LC_PAYLOAD_INVALID'); hex32(payload['grant_ref'])
    elif kind == 'revoke_key':
        exact(payload, {'public_key_hex'}, 'DKN_LC_PAYLOAD_INVALID'); _public(payload['public_key_hex'])
    else:
        exact(payload, {'reason'}, 'DKN_LC_PAYLOAD_INVALID')
        check(type(payload['reason']) is str and 1 <= len(payload['reason']) <= 256, 'DKN_LC_PAYLOAD_INVALID')


def _proofs(signatures: Any, message: bytes) -> set[str]:
    check(type(signatures) is list and 1 <= len(signatures) <= MAX_GUARDIANS + 2, 'DKN_LC_SIGNATURE_SET_INVALID')
    keys = []
    for signature in signatures:
        exact(signature, {'public_key_hex', 'signature_hex'}, 'DKN_LC_SIGNATURE_SET_INVALID')
        _verify_sig(signature['public_key_hex'], message, signature['signature_hex'])
        keys.append(signature['public_key_hex'])
    check(keys == sorted(set(keys)), 'DKN_LC_SIGNATURE_SET_INVALID')
    return set(keys)


def _apply_payload(state: dict, policy: dict, kind: str, payload: dict, event_ref: str) -> None:
    if kind in ('rotate', 'recover'):
        successor = payload['successor_public_key_hex']
        check(successor not in state['used_controllers'] and successor not in state['revoked_keys'],
              'DKN_LC_RETIRED_KEY')
        check(successor not in policy['recovery_keys'], 'DKN_LC_ROLE_OVERLAP')
        state['used_controllers'].add(successor)
        state['active_key'] = successor
        state['epoch'] += 1
        state['epoch_start_ref'] = event_ref
        state['revoked_grants'].update(state['grants'])
        if kind == 'recover':
            state['suspended'] = False
    elif kind == 'delegate':
        subject = payload['subject_public_key_hex']
        check(not state['suspended'], 'DKN_LC_SUSPENDED')
        check(subject not in state['used_controllers'] and subject not in state['revoked_keys'], 'DKN_LC_RETIRED_KEY')
        check(subject not in policy['recovery_keys'], 'DKN_LC_ROLE_OVERLAP')
        state['grants'][event_ref] = {**payload, 'epoch': state['epoch']}
    elif kind == 'revoke_grant':
        ref = payload['grant_ref']
        check(ref in state['grants'] and ref not in state['revoked_grants'], 'DKN_LC_GRANT_UNKNOWN_OR_REVOKED')
        state['revoked_grants'].add(ref)
    elif kind == 'revoke_key':
        pub = payload['public_key_hex']
        check(pub != state['active_key'] and pub not in policy['recovery_keys'], 'DKN_LC_ROLE_OVERLAP')
        check(pub not in state['revoked_keys'], 'DKN_LC_KEY_ALREADY_REVOKED')
        state['revoked_keys'].add(pub)
    elif kind == 'suspend':
        check(not state['suspended'], 'DKN_LC_STATE_INVALID')
        state['suspended'] = True
        state['revoked_grants'].update(state['grants'])
    elif kind == 'resume':
        check(state['suspended'], 'DKN_LC_STATE_INVALID')
        state['suspended'] = False


def _replay(genesis: dict, policy: dict, events: list[dict]) -> dict:
    anchor = lifecycle_anchor(genesis, policy)
    check(type(events) is list and len(events) <= MAX_EVENTS, 'DKN_LC_LIMIT')
    canonical(events)
    state = {'anchor_ref': anchor, 'head_ref': anchor, 'sequence': 0, 'epoch': 0,
             'active_key': genesis['founder_public_key_hex'], 'issued_at': 0, 'epoch_start_ref': anchor,
             'suspended': False, 'grants': {}, 'revoked_grants': set(), 'revoked_keys': set(),
             'used_controllers': {genesis['founder_public_key_hex']}, 'refs': [anchor]}
    policy_ref = policy_reference(policy)
    for sequence, event in enumerate(events, 1):
        exact(event, {'body', 'event_ref', 'signatures'}, 'DKN_LC_EVENT_INVALID')
        body = event['body']
        exact(body, {'schema', 'namespace_root', 'policy_ref', 'sequence', 'previous_ref',
                     'issued_at', 'kind', 'payload'}, 'DKN_LC_EVENT_INVALID')
        _integer(body['sequence'], 1, MAX_EVENTS); _integer(body['issued_at'])
        hex32(body['namespace_root']); hex32(body['previous_ref']); hex32(event['event_ref'])
        check(body['schema'] == EVENT_SCHEMA and body['namespace_root'] == genesis['namespace_root']
              and body['policy_ref'] == policy_ref and body['sequence'] == sequence
              and body['previous_ref'] == state['head_ref'], 'DKN_LC_CHAIN_INVALID')
        check(body['issued_at'] >= state['issued_at'], 'DKN_LC_TIME_REVERSED')
        check(type(body['kind']) is str and body['kind'] in KINDS, 'DKN_LC_KIND_UNSUPPORTED')
        kind, payload = body['kind'], body['payload']
        _payload(kind, payload, policy, body['issued_at'])
        check(_hash('event', body) == event['event_ref'], 'DKN_LC_EVENT_MISMATCH')
        signers = _proofs(event['signatures'], _message('event-signature', body))
        if kind == 'recover':
            successor = payload['successor_public_key_hex']
            check(policy['recovery_threshold'] > 0, 'DKN_LC_RECOVERY_DISABLED')
            guardians = set(policy['recovery_keys'])
            check(successor in signers and signers - {successor} <= guardians and
                  len(signers & guardians) >= policy['recovery_threshold'], 'DKN_LC_RECOVERY_THRESHOLD')
        elif kind == 'rotate':
            check(signers == {state['active_key'], payload['successor_public_key_hex']}, 'DKN_LC_SIGNER_UNAUTHORIZED')
        else:
            check(signers == {state['active_key']}, 'DKN_LC_SIGNER_UNAUTHORIZED')
        _apply_payload(state, policy, kind, payload, event['event_ref'])
        state['head_ref'] = event['event_ref']
        state['sequence'] = sequence
        state['issued_at'] = body['issued_at']
        state['refs'].append(event['event_ref'])
    return state


def verify_journal(genesis: dict, policy: dict, events: list[dict]) -> dict:
    state = _replay(genesis, policy, events)
    return {'schema': 'dkn.lifecycle-state.v0.2-f1', 'namespace_root': genesis['namespace_root'],
            'policy_ref': policy_reference(policy), 'anchor_ref': state['anchor_ref'],
            'head_ref': state['head_ref'], 'sequence': state['sequence'], 'epoch': state['epoch'],
            'epoch_instance_ref': _hash('instance', {'namespace_root': genesis['namespace_root'],
                'policy_ref': policy_reference(policy), 'epoch': state['epoch'],
                'epoch_start_ref': state['epoch_start_ref'], 'active_key': state['active_key']}),
            'active_key': state['active_key'], 'suspended': state['suspended'],
            'last_declared_time': state['issued_at'],
            'grant_count': len(state['grants']), 'revoked_grant_count': len(state['revoked_grants']),
            'revoked_keys': sorted(state['revoked_keys']),
            'signature_chain': 'PASS', 'coverage': 'SUPPLIED_JOURNAL_ONLY',
            'global_currentness': 'NOT_ESTABLISHED', 'authority_effect': 'NONE'}


def prepare_event(genesis: dict, policy: dict, events: list[dict], *, kind: str,
                  payload: dict, issued_at: int) -> dict:
    """Prepare a context-bound unsigned proposal for separately held signing keys."""
    state = _replay(genesis, policy, events)
    _integer(issued_at)
    check(type(kind) is str and kind in KINDS, 'DKN_LC_KIND_UNSUPPORTED')
    check(state['sequence'] < MAX_EVENTS, 'DKN_LC_LIMIT')
    check(issued_at >= state['issued_at'], 'DKN_LC_TIME_REVERSED')
    if kind == 'recover':
        check(policy['recovery_threshold'] > 0, 'DKN_LC_RECOVERY_DISABLED')
    _payload(kind, payload, policy, issued_at)
    body = {'schema': EVENT_SCHEMA, 'namespace_root': genesis['namespace_root'],
            'policy_ref': policy_reference(policy), 'sequence': state['sequence'] + 1,
            'previous_ref': state['head_ref'], 'issued_at': issued_at, 'kind': kind,
            'payload': read_canonical(canonical(payload))}
    event_ref = _hash('event', body)
    _apply_payload(state, policy, kind, body['payload'], event_ref)
    return {'body': body, 'event_ref': event_ref}


def _check_proposal(genesis: dict, policy: dict, events: list[dict], proposal: dict) -> dict:
    canonical(proposal)
    exact(proposal, {'body', 'event_ref'}, 'DKN_LC_PROPOSAL_INVALID')
    body = proposal['body']
    exact(body, {'schema','namespace_root','policy_ref','sequence','previous_ref','issued_at','kind','payload'},
          'DKN_LC_PROPOSAL_INVALID')
    expected = prepare_event(genesis, policy, events, kind=body['kind'], payload=body['payload'], issued_at=body['issued_at'])
    check(expected == proposal, 'DKN_LC_PROPOSAL_MISMATCH')
    return body


def endorse_event(genesis: dict, policy: dict, events: list[dict], proposal: dict,
                  key: Ed25519PrivateKey) -> dict:
    """One participant's explicit signature, after checking the exact supplied context.

    Caller must independently recognize the namespace, policy, predecessor and action;
    signing software cannot infer the operator's intent or the globally current head.
    """
    check(isinstance(key, Ed25519PrivateKey), 'DKN_LC_SIGNING_KEY_INVALID')
    body = _check_proposal(genesis, policy, events, proposal)
    state = _replay(genesis, policy, events)
    kind = body['kind']
    if kind == 'recover':
        allowed = set(policy['recovery_keys']) | {body['payload']['successor_public_key_hex']}
    elif kind == 'rotate':
        allowed = {state['active_key'], body['payload']['successor_public_key_hex']}
    else:
        allowed = {state['active_key']}
    check(key_hex(key) in allowed, 'DKN_LC_SIGNER_UNAUTHORIZED')
    return {'public_key_hex': key_hex(key),
            'signature_hex': key.sign(_message('event-signature', body)).hex()}


def assemble_event(genesis: dict, policy: dict, events: list[dict], proposal: dict,
                   signatures: list[dict]) -> dict:
    """Collect PUBLIC endorsements; quorum, proof-of-possession and full replay are mandatory."""
    _check_proposal(genesis, policy, events, proposal)
    check(type(signatures) is list and 1 <= len(signatures) <= MAX_GUARDIANS+2, 'DKN_LC_SIGNATURE_SET_INVALID')
    for signature in signatures:
        exact(signature, {'public_key_hex','signature_hex'}, 'DKN_LC_SIGNATURE_SET_INVALID')
        hex32(signature['public_key_hex'])
    event = {**read_canonical(canonical(proposal)),
             'signatures': sorted(read_canonical(canonical(signatures)), key=lambda row: row['public_key_hex'])}
    verify_journal(genesis, policy, events + [event])
    return event


def make_event(genesis: dict, policy: dict, events: list[dict], *, kind: str,
               payload: dict, issued_at: int, signing_keys: list[Ed25519PrivateKey]) -> dict:
    """Convenience for locally controlled fixture/operational keys; split custody uses endorsements."""
    check(type(signing_keys) is list and 1 <= len(signing_keys) <= MAX_GUARDIANS + 2, 'DKN_LC_SIGNATURE_SET_INVALID')
    proposal = prepare_event(genesis, policy, events, kind=kind, payload=payload, issued_at=issued_at)
    signatures = [endorse_event(genesis, policy, events, proposal, key) for key in signing_keys]
    return assemble_event(genesis, policy, events, proposal, signatures)


def make_checkpoint(genesis: dict, policy: dict, events: list[dict], *, issued_at: int,
                    expires_at: int, key: Ed25519PrivateKey) -> dict:
    state = verify_journal(genesis, policy, events)
    _integer(issued_at); _integer(expires_at)
    check(isinstance(key, Ed25519PrivateKey), 'DKN_LC_SIGNING_KEY_INVALID')
    check(key_hex(key) == state['active_key'], 'DKN_LC_SIGNER_UNAUTHORIZED')
    check(state['last_declared_time'] <= issued_at < expires_at, 'DKN_LC_CHECKPOINT_TIME')
    body = {'schema': CHECKPOINT_SCHEMA, 'namespace_root': state['namespace_root'],
            'policy_ref': state['policy_ref'], 'head_ref': state['head_ref'],
            'sequence': state['sequence'], 'issued_at': issued_at, 'expires_at': expires_at,
            'signer_public_key_hex': key_hex(key)}
    return {**body, 'signature_hex': key.sign(_message('checkpoint', body)).hex()}


def _verify_checkpoint(checkpoint: dict, state: dict, *, now: int, max_age: int) -> dict:
    """Internal report input is not an authority; public assessment replays state first."""
    _integer(now); _integer(max_age, 1)
    canonical(checkpoint)
    exact(checkpoint, {'schema', 'namespace_root', 'policy_ref', 'head_ref', 'sequence',
                       'issued_at', 'expires_at', 'signer_public_key_hex', 'signature_hex'}, 'DKN_LC_CHECKPOINT_INVALID')
    body = {key: value for key, value in checkpoint.items() if key != 'signature_hex'}
    _integer(body['issued_at']); _integer(body['expires_at']); _integer(body['sequence'], 0, MAX_EVENTS)
    check(body['schema'] == CHECKPOINT_SCHEMA and body['namespace_root'] == state['namespace_root']
          and body['policy_ref'] == state['policy_ref'] and body['head_ref'] == state['head_ref']
          and body['sequence'] == state['sequence'] and body['signer_public_key_hex'] == state['active_key'],
          'DKN_LC_CHECKPOINT_MISMATCH')
    _verify_sig(body['signer_public_key_hex'], _message('checkpoint', body), checkpoint['signature_hex'])
    check(state['last_declared_time'] <= body['issued_at'] <= now < body['expires_at'] and
          now - body['issued_at'] <= max_age, 'DKN_LC_CHECKPOINT_TIME')
    return {'checkpoint': 'PASS_READER_TIME_BOUND', 'global_currentness': 'NOT_ESTABLISHED'}


def assess_delegation(genesis: dict, policy: dict, events: list[dict], *,
                      expected_namespace: str, expected_head: str, subject_public_key_hex: str,
                      artifact_root: str, operation: str, now: int, max_checkpoint_age: int,
                      checkpoint: dict | None, minimum: dict | None = None) -> dict:
    """Evaluate a bounded journal under caller-selected pins. Never execute a grant."""
    state = _replay(genesis, policy, events)
    report = verify_journal(genesis, policy, events)
    hex32(expected_namespace); hex32(expected_head); hex32(artifact_root)
    _public(subject_public_key_hex); _token(operation); _integer(now); _integer(max_checkpoint_age, 1)
    check(expected_namespace == genesis['namespace_root'] and expected_head == state['head_ref'], 'DKN_LC_PIN_MISMATCH')
    if minimum is not None:
        exact(minimum, {'sequence', 'head_ref'}, 'DKN_LC_FLOOR_INVALID')
        _integer(minimum['sequence'], 0, MAX_EVENTS); hex32(minimum['head_ref'])
        check(minimum['sequence'] <= state['sequence'] and
              state['refs'][minimum['sequence']] == minimum['head_ref'], 'DKN_LC_ROLLBACK_OR_FORK')
    check(state['issued_at'] <= now, 'DKN_LC_FUTURE_EVENT')
    status, reason, grants = 'NO_MATCH', 'NO_ACTIVE_EXACT_GRANT', []
    if checkpoint is None:
        status, reason = 'INDETERMINATE', 'CHECKPOINT_MISSING'
    else:
        _verify_checkpoint(checkpoint, report, now=now, max_age=max_checkpoint_age)
        if state['suspended']:
            reason = 'NAMESPACE_SUSPENDED'
        elif operation not in policy['allowed_operations']:
            reason = 'OPERATION_OUTSIDE_POLICY'
        elif subject_public_key_hex == state['active_key']:
            status, reason = 'MATCH_FOR_SUPPLIED_VIEW', 'CONTROLLER_FOR_SUPPLIED_VIEW'
        elif subject_public_key_hex in state['revoked_keys']:
            reason = 'KEY_REVOKED_IN_SUPPLIED_VIEW'
        else:
            grants = sorted(ref for ref, grant in state['grants'].items()
                if ref not in state['revoked_grants'] and grant['epoch'] == state['epoch']
                and grant['subject_public_key_hex'] == subject_public_key_hex
                and grant['artifact_root'] == artifact_root and operation in grant['operations']
                and grant['not_before'] <= now < grant['expires_at'])
            if grants:
                status, reason = 'MATCH_FOR_SUPPLIED_VIEW', 'EXACT_DELEGATION_FOR_SUPPLIED_VIEW'
    return {'schema': 'dkn.lifecycle-assessment.v0.2-f1', 'status': status, 'reason': reason,
            'namespace_root': expected_namespace, 'head_ref': expected_head, 'sequence': state['sequence'],
            'subject_public_key_hex': subject_public_key_hex, 'artifact_root': artifact_root,
            'operation': operation, 'evaluated_at': now, 'matching_grants': grants,
            'checkpoint': 'NOT_CHECKED' if checkpoint is None else 'PASS_READER_TIME_BOUND',
            'subject_possession': 'NOT_CHECKED', 'revocation': 'SUPPLIED_PINNED_VIEW_ONLY',
            'global_currentness': 'NOT_ESTABLISHED', 'acceptance': 'EXTERNAL_DECISION_REQUIRED',
            'authority_effect': 'NONE'}


def assess_certificate(certificate: dict, manifest: dict, genesis: dict, policy: dict,
                       events: list[dict], **reader_inputs: Any) -> dict:
    """Bind lifecycle evidence to an actual certificate; operation is fixed, not caller-aliased."""
    verify_certificate(certificate, manifest)
    check(certificate['namespace_root'] == genesis['namespace_root'], 'DKN_LC_PIN_MISMATCH')
    required = {'expected_namespace', 'expected_head', 'now', 'max_checkpoint_age', 'checkpoint'}
    check(required <= set(reader_inputs) <= required | {'minimum'}, 'DKN_LC_ARGUMENT_INVALID')
    result = assess_delegation(genesis, policy, events,
            subject_public_key_hex=certificate['signer_public_key_hex'], artifact_root=manifest['logical_root'],
            operation='certify_artifact', **reader_inputs)
    result['subject_possession'] = 'SIGNATURE_VERIFIED'
    return result


def analyze_journals(genesis: dict, policy: dict, chains: list[list[dict]]) -> dict:
    check(type(chains) is list and 1 <= len(chains) <= 32 and all(type(c) is list for c in chains), 'DKN_LC_LIMIT')
    check(sum(len(c) for c in chains) <= 512, 'DKN_LC_LIMIT'); canonical(chains)
    children, nodes, tips = {}, {}, set()
    for chain in chains:
        state = verify_journal(genesis, policy, chain)
        tips.add(state['head_ref'])
        for event in chain:
            ref, body = event['event_ref'], event['body']
            nodes[ref] = body
            children.setdefault(body['previous_ref'], set()).add(ref)
    forks = [{'predecessor_ref': parent, 'successors': [
                  {'event_ref': ref, 'kind': nodes[ref]['kind'], 'sequence': nodes[ref]['sequence']}
                  for ref in sorted(refs)]}
             for parent, refs in sorted(children.items()) if len(refs) > 1]
    result = {'schema': 'dkn.lifecycle-forks.v0.2-f1', 'namespace_root': genesis['namespace_root'],
              'supplied_chain_tips': sorted(tips), 'forks': forks, 'selected_head': None,
              'fork_evidence': 'OBSERVED' if forks else 'NOT_OBSERVED_IN_SUPPLIED_JOURNALS',
              'coverage': 'SUPPLIED_JOURNALS_ONLY', 'authority_effect': 'NONE'}
    canonical(result)
    return result


def inspect_with_lifecycle(raw: bytes, certificate: dict, genesis: dict, policy: dict,
                           events: list[dict], **reader_inputs: Any) -> dict:
    """Bind payload integrity, certificate and lifecycle evidence in one bounded report."""
    from .navigation import _unpack_checked
    archive_report, manifest = _unpack_checked(raw)
    assessment = assess_certificate(certificate, manifest, genesis, policy, events, **reader_inputs)
    result = {'schema': 'dkn.lifecycle-inspection.v0.2-f1', 'artifact': archive_report,
              'lifecycle': assessment, 'authority_effect': 'NONE'}
    canonical(result)
    return result
