"""Six declarative security-model templates, not measurements or certifications."""
from .sam_schemas import V, PROFILES
from .core import check

CATALOG = {
    'LOCAL_VAULT': {
        'mechanisms': ['local-filesystem', 'content-hash-verification'],
        'visibility': 'LOCAL_ONLY', 'adversaries': ['local-compromise', 'device-loss'],
        'assumptions': ['local-host-uncompromised'],
        'exclusions': ['No exclusive custody proof', 'No off-device backup or freshness guarantee'],
        'network': ['Offline access needs no network while bytes remain locally readable'],
    },
    'ENTERPRISE_DISTRIBUTED': {
        'mechanisms': ['organizational-identity', 'declared-replication', 'access-control'],
        'visibility': 'ACCESS_CONTROLLED', 'adversaries': ['administrator-compromise', 'shared-control-failure'],
        'assumptions': ['administrator-separation-holds'],
        'exclusions': ['Replica count and backup recovery are not measured by this template'],
        'network': ['Corporate network and identity provider availability are external assumptions'],
    },
    'PUBLIC_HOSTING': {
        'mechanisms': ['public-mirror', 'content-hash-verification'],
        'visibility': 'PUBLIC', 'adversaries': ['provider-removal', 'stale-mirror', 'credential-theft'],
        'assumptions': ['provider-retains-content'],
        'exclusions': ['No uptime, retention, or censorship-resistance guarantee'],
        'network': ['Provider and transit must be reachable for remote retrieval'],
    },
    'P2P_CAS': {
        'mechanisms': ['content-addressed-retrieval', 'peer-discovery', 'declared-pinning'],
        'visibility': 'PUBLIC', 'adversaries': ['sybil-peers', 'eclipse-attack', 'unpinning'],
        'assumptions': ['at-least-one-reachable-retaining-peer'],
        'exclusions': ['No automatic retention, peer independence, or discovery completeness'],
        'network': ['Bootstrap and provider discovery paths may have shared control'],
    },
    'FEDERATED_CCP': {
        'mechanisms': ['pinned-membership', 'signed-head-observations', 'external-recognition-policy'],
        'visibility': 'PUBLIC', 'adversaries': ['witness-collusion', 'partition', 'membership-compromise'],
        'assumptions': ['membership-pins-current', 'witness-separation-holds'],
        'exclusions': ['Witness quorum is not a consensus proof or constitutional admission'],
        'network': ['Partitions may prevent observations; this model specifies no liveness protocol'],
    },
    'HYBRID': {
        'mechanisms': ['local-copy', 'multiple-retrieval-paths', 'optional-witnesses'],
        'visibility': 'UNSPECIFIED', 'adversaries': ['shared-root-dependency', 'cross-backend-metadata-leak'],
        'assumptions': ['dependency-inventory-complete'],
        'exclusions': ['All-of declaration analysis is not a combined availability score'],
        'network': ['Each component retains its own reachability assumptions'],
    },
}


def reference_profile(name: str) -> dict:
    check(type(name) is str and name in PROFILES, 'DKN_V02_SAM_PROFILE_UNSUPPORTED')
    p = CATALOG[name]
    return {'schema': 'dkn.substrate.'+V, 'substrate_id': 'example.'+name.lower().replace('_', '-'),
            'profile': name, 'deployment_status': 'TEMPLATE',
            'mechanisms': list(p['mechanisms']), 'fault_domains': [],
            'assumptions': [{'id': a, 'value': True} for a in p['assumptions']],
            'dependencies': [], 'metadata_visibility': p['visibility'],
            'threat_model': {'adversaries': list(p['adversaries']),
                             'exclusions': list(p['exclusions']),
                             'network_assumptions': list(p['network'])},
            'valid_from': 0, 'valid_until': 2**63-1}
