"""DS-G1 shapes. Schemas do not verify hashes, signatures or conclusions."""
from __future__ import annotations
from copy import deepcopy
from jsonschema import Draft202012Validator
from .core import canonical, check
from .sam_schemas import SCHEMAS as SAM

V = 'v0.2-g1'
MAX_OBJECTS = 64
MAX_NODES = 16
MAX_STEPS = 256
MAX_READERS = 8
MAX_ASSESSMENTS = 32
MAX_TICK = 2**53 - 1
MAX_DELAY = 1000000
MAX_ARCHIVE = 256 * 1024

def obj(properties, required=None):
    return {'type':'object','properties':properties,'required':list(properties) if required is None else required,'additionalProperties':False}
def array(item, maximum, minimum=0):
    return {'type':'array','items':item,'minItems':minimum,'maxItems':maximum}
def enum(*items): return {'enum':list(items)}
def const(value): return {'const':value}
def nullable(value): return {'anyOf':[value,{'type':'null'}]}
def integer(low=0,high=MAX_TICK): return {'type':'integer','minimum':low,'maximum':high}
TOKEN={'type':'string','pattern':'^[a-z][a-z0-9._-]{0,63}$','maxLength':64}
HEX={'type':'string','pattern':'^[0-9a-f]{64}$','maxLength':64}
FLOOR=obj({'sequence':integer(0,256),'head_ref':HEX})
DOMAIN=obj({'dimension':enum('administration','provider','region','network','identity','power'), 'domain_id':TOKEN})
ENVELOPE=obj({'kind':enum('artifact','journal','observation','substrate','evidence'),'value':{'type':'object'}})
ASSURANCE=obj({'descriptor_ref':HEX,'contract':SAM['contract'],'policy':SAM['policy'],
               'accepted_premises':SAM['context']['properties']['accepted_premises']})
READER=obj({'schema':const('dkn.distributed-reader.'+V),
    'expected_artifact_root':HEX,'expected_namespace':HEX,'expected_head':HEX,
    'subject_public_key_hex':HEX,'operation':TOKEN,'max_checkpoint_age':integer(1),
    'minimum':nullable(FLOOR),'external_minimum':nullable(FLOOR),
    'require_witness':{'type':'boolean'},'witness_policy':nullable(SAM['checkpoint-policy']),
    'require_assurance':{'type':'boolean'},'assurance':nullable(ASSURANCE),
    'composition_roots':array(HEX,16)})
STEP_VARIANTS=[]
def step(action,properties):
    s=obj({'at':integer(),'action':const(action),**properties});STEP_VARIANTS.append(s);return s
step('send',{'source':TOKEN,'target':TOKEN,'object':TOKEN,'delay':integer(0,MAX_DELAY)})
step('partition',{'left':TOKEN,'right':TOKEN,'blocked':{'type':'boolean'}})
step('node',{'node':TOKEN,'online':{'type':'boolean'}})
step('clock',{'node':TOKEN,'offset':integer(-MAX_DELAY,MAX_DELAY)})
step('domain',{'dimension':DOMAIN['properties']['dimension'],'domain_id':TOKEN,'online':{'type':'boolean'}})
step('drop',{'message':{'type':'string','pattern':'^m[0-9]{6}$'}})
step('assess',{'reader':TOKEN,'label':TOKEN})
step('configure',{'reader':TOKEN,'policy':READER})
step('snapshot',{'node':TOKEN,'slot':TOKEN})
step('restore',{'node':TOKEN,'slot':TOKEN})
NODE=obj({'id':TOKEN,'fault_domains':array(DOMAIN,16),'initial_objects':array(TOKEN,MAX_OBJECTS),
          'clock_offset':integer(-MAX_DELAY,MAX_DELAY)})
SCENARIO=obj({'schema':const('dkn.distributed-scenario.'+V),'scenario_id':TOKEN,
    'topology':enum('LOCAL','ENTERPRISE','P2P','FEDERATED','HYBRID'),
    'objects':array(obj({'id':TOKEN,**ENVELOPE['properties']}),MAX_OBJECTS),
    'nodes':array(NODE,MAX_NODES,1),
    'readers':array(obj({'id':TOKEN,'node':TOKEN,'policy':READER}),MAX_READERS,1),
    'steps':array({'oneOf':STEP_VARIANTS},MAX_STEPS),'until':integer()})
VIEW=obj({'schema':const('dkn.distributed-view.'+V),
    'status':enum('MATCH_FOR_SUPPLIED_VIEW','CONDITIONAL','INDETERMINATE','NO_MATCH','CONTRADICTED'),
    'reader_ref':HEX,'view_ref':HEX,'evaluated_at':integer(),
    'artifact':{'type':'object'},'lifecycle':{'type':'object'},'witness':{'type':'object'},
    'assurance':{'type':'object'},'composition':{'type':'object'},
    'invalid_objects':array(obj({'object_ref':HEX,'code':{'type':'string'}}),MAX_OBJECTS),
    'duplicate_objects':integer(0,MAX_OBJECTS),'scope_exclusions':array(HEX,MAX_OBJECTS),
    'freshness':const('SUPPLIED_VIEW_AND_CALLER_CLOCK_ONLY'),
    'coverage':const('SUPPLIED_OBJECTS_ONLY'),'global_currentness':const('NOT_ESTABLISHED'),
    'consensus_safety':const('NOT_ESTABLISHED'),'execution_authorized':const(False),
    'admission':const('EXTERNAL_DECISION_REQUIRED'),'authority_effect':const('NONE')})
TRACE_ENTRY=obj({'index':integer(0,1024),'time':integer(),'type':TOKEN,'details':{'type':'object'},
                 'previous_hash':HEX,'entry_hash':HEX})
TRANSCRIPT=obj({'schema':const('dkn.distributed-transcript.'+V),'scenario_ref':HEX,'trace_root':HEX,
    'trace':array(TRACE_ENTRY,1024),'assessments':array(obj({'label':TOKEN,'reader':TOKEN,'report':{'type':'object'}}),MAX_ASSESSMENTS),
    'terminal':{'type':'object'},'simulation_only':const(True),'model_profile':const('DS-G1'),
    'production_evidence':const(False),'global_currentness':const('NOT_ESTABLISHED'),
    'consensus_safety':const('NOT_ESTABLISHED'),'authority_effect':const('NONE')})
REQUEST=obj({'schema':const('dkn.distributed-request.'+V),'operation':enum('assess','simulate','verify-replay'),
             'arguments':{'type':'object'}})
SCHEMAS={'envelope':ENVELOPE,'reader':READER,'scenario':SCENARIO,'view':VIEW,'transcript':TRANSCRIPT,'request':REQUEST}
VALIDATORS={k:Draft202012Validator(s) for k,s in SCHEMAS.items()}

def validate_shape(kind,value):
    check(type(kind) is str and kind in VALIDATORS,'DKN_DS_SCHEMA_UNSUPPORTED')
    canonical(value)
    check(VALIDATORS[kind].is_valid(value),'DKN_DS_SCHEMA_INVALID')
    return value

def export_schemas():
    return {k:{'$schema':'https://json-schema.org/draft/2020-12/schema',
               '$id':'dkn.distributed.'+k+'.'+V,**deepcopy(v)} for k,v in SCHEMAS.items()}
