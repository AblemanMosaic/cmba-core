"""Portable public passports for persistent users and session/agent identities."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from .boundary import BOUNDARY
from .canonical import exact_keys, object_hash
from .crypto import dkn_subject_id, mosaic_id, public_key_bytes
from .errors import require
from .namespace import derive_namespace, verify_namespace

ROLES = frozenset({"USER", "AGENT", "SESSION", "SERVICE", "COLLABORATOR"})


def create_passport(*, public_key_hex: str, role: str,
                    namespace: dict[str, Any] | None = None,
                    legacy_mosaic_id: str | None = None) -> dict[str, Any]:
    public_key_bytes(public_key_hex)
    require(role in ROLES, "DKN_PASSPORT_ROLE_INVALID")
    computed_mosaic = mosaic_id(public_key_hex)
    if legacy_mosaic_id is not None:
        require(legacy_mosaic_id == computed_mosaic, "DKN_MOSAIC_ID_MISMATCH")
    bound_namespace = None if namespace is None else verify_namespace(namespace)
    if bound_namespace is not None:
        require(bound_namespace["material"]["public_key_hex"] == public_key_hex,
                "DKN_IDENTITY_KEY_MISMATCH")
    body = {
        "schema": "dkn.passport.v0.1",
        "protocol_version": "v0.1",
        "identity_suite": "Ed25519+BLAKE3-256",
        "public_key_hex": public_key_hex,
        "subject_id": dkn_subject_id(public_key_hex),
        "mosaic_id": computed_mosaic,
        "role": role,
        "namespace": deepcopy(bound_namespace),
        "public_material_only": True,
        "possession_verified": False,
        "permission_granted": False,
        **BOUNDARY,
    }
    return {**body, "passport_hash": object_hash(body, b"DKN_PASSPORT_V0.1\x00")}


def import_mosaic_id(*, mosaic_id_value: str, public_key_hex: str, role: str,
                     semantic_namespace: str | None = None,
                     purpose: str = "identity",
                     nonce: str = "mosaic.identity.v0.1",
                     epoch_code: str = "legacy") -> dict[str, Any]:
    require(mosaic_id(public_key_hex) == mosaic_id_value, "DKN_MOSAIC_ID_MISMATCH")
    namespace = None
    if semantic_namespace is not None:
        namespace = derive_namespace(
            semantic_namespace=semantic_namespace,
            public_key_hex=public_key_hex,
            purpose=purpose,
            nonce=nonce,
            epoch_code=epoch_code,
        )
    passport = create_passport(
        public_key_hex=public_key_hex,
        role=role,
        namespace=namespace,
        legacy_mosaic_id=mosaic_id_value,
    )
    return {
        "schema": "dkn.mosaic-import.v0.1",
        "status": "PASS_KEY_DERIVATION",
        "passport": passport,
        "possession_required_for_authentication": True,
        "local_admission_required_for_authority": True,
        **BOUNDARY,
    }


def verify_passport(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "protocol_version", "identity_suite", "public_key_hex",
        "subject_id", "mosaic_id", "role", "namespace", "public_material_only",
        "possession_verified", "permission_granted", *BOUNDARY, "passport_hash",
    }, "DKN_PASSPORT_INVALID")
    require(item["schema"] == "dkn.passport.v0.1"
            and item["protocol_version"] == "v0.1"
            and item["identity_suite"] == "Ed25519+BLAKE3-256",
            "DKN_VERSION_UNSUPPORTED")
    expected = create_passport(
        public_key_hex=item["public_key_hex"],
        role=item["role"],
        namespace=item["namespace"],
        legacy_mosaic_id=item["mosaic_id"],
    )
    require(item == expected, "DKN_PASSPORT_INVALID")
    return expected

