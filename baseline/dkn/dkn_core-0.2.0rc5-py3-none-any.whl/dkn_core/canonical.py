"""DKN-CJSON-1 strict JSON parsing, serialization, and rooted bytes."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from .errors import DKNRefusal, require

MAX_INPUT_BYTES = 4 * 1024 * 1024
MAX_DEPTH = 32
MIN_INT = -(2**63)
MAX_INT = 2**63 - 1


def _check(value: Any, depth: int = 0) -> None:
    require(depth <= MAX_DEPTH, "DKN_CANONICAL_DEPTH_EXCEEDED")
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        require(MIN_INT <= value <= MAX_INT, "DKN_CANONICAL_NUMBER_INVALID")
        return
    if type(value) is str:
        require(len(value.encode("utf-8")) <= MAX_INPUT_BYTES, "DKN_CANONICAL_STRING_INVALID")
        require(not any(0xD800 <= ord(ch) <= 0xDFFF for ch in value),
                "DKN_CANONICAL_STRING_INVALID")
        return
    if type(value) is list:
        require(len(value) <= 4096, "DKN_CANONICAL_INPUT_LIMIT")
        for item in value:
            _check(item, depth + 1)
        return
    if type(value) is dict:
        require(len(value) <= 4096 and all(type(key) is str for key in value),
                "DKN_CANONICAL_INPUT_LIMIT")
        for key, item in value.items():
            _check(key, depth + 1)
            _check(item, depth + 1)
        return
    raise DKNRefusal("DKN_CANONICAL_TYPE_INVALID", type(value).__name__)


def canonical_bytes(value: Any) -> bytes:
    _check(value)
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def strict_loads(raw: bytes) -> Any:
    require(type(raw) is bytes and len(raw) <= MAX_INPUT_BYTES,
            "DKN_CANONICAL_INPUT_LIMIT")
    require(not raw.startswith(b"\xef\xbb\xbf"), "DKN_CANONICAL_JSON_INVALID", "BOM")

    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in items:
            require(key not in result, "DKN_CANONICAL_DUPLICATE_KEY", key)
            result[key] = value
        return result

    def number_refused(_: str) -> None:
        raise DKNRefusal("DKN_CANONICAL_NUMBER_INVALID")

    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=pairs,
            parse_float=number_refused,
            parse_constant=number_refused,
        )
        _check(value)
        return value
    except DKNRefusal:
        raise
    except (UnicodeError, ValueError, RecursionError) as error:
        raise DKNRefusal("DKN_CANONICAL_JSON_INVALID", type(error).__name__) from error


def strict_load_canonical(raw: bytes) -> Any:
    value = strict_loads(raw)
    require(canonical_bytes(value) == raw, "DKN_CANONICAL_JSON_NOT_CANONICAL")
    return value


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def object_hash(value: Any, domain: bytes = b"DKN_OBJECT_V0.1\x00") -> str:
    require(type(domain) is bytes and domain.endswith(b"\x00"), "DKN_HASH_INVALID")
    return sha256_hex(domain + canonical_bytes(value))


def exact_keys(value: Any, keys: set[str], code: str) -> dict[str, Any]:
    require(type(value) is dict and set(value) == keys, code)
    return value


def hex_string(value: Any, length: int, code: str) -> str:
    require(type(value) is str and len(value) == length, code)
    try:
        raw = bytes.fromhex(value)
    except ValueError as error:
        raise DKNRefusal(code) from error
    require(len(raw) * 2 == length and value == value.lower(), code)
    return value

