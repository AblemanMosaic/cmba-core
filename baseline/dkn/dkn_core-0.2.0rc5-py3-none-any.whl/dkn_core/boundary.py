"""The immutable DKN authority ceiling."""

BOUNDARY = {
    "standing": "INFORMATION_ONLY",
    "authority_effect": "NONE",
    "real_a5": False,
    "g0": "CLOSED",
}


def with_boundary(body: dict) -> dict:
    return {**body, **BOUNDARY}

