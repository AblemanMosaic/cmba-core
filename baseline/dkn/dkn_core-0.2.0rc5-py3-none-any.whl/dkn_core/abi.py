"""Language-neutral JSON ABI dispatcher."""

from __future__ import annotations

from typing import Any

from .boundary import BOUNDARY
from .canonical import exact_keys
from .errors import DKNRefusal
from .namespace import derive_namespace, verify_namespace
from .passport import create_passport, import_mosaic_id, verify_passport
from .records import verify_signed_record
from .thr import build_thr_manifest, verify_thr_manifest

ABI_SCHEMA = "dkn.abi-request.v0.1"


def _dispatch(operation: str, arguments: dict[str, Any]) -> Any:
    if operation == "namespace.derive":
        return derive_namespace(**arguments)
    if operation == "namespace.verify":
        exact_keys(arguments, {"namespace"}, "DKN_ABI_REQUEST_INVALID")
        return verify_namespace(arguments["namespace"])
    if operation == "passport.create":
        return create_passport(**arguments)
    if operation == "passport.import_mosaic":
        return import_mosaic_id(**arguments)
    if operation == "passport.verify":
        exact_keys(arguments, {"passport"}, "DKN_ABI_REQUEST_INVALID")
        return verify_passport(arguments["passport"])
    if operation == "thr.build":
        return build_thr_manifest(**arguments)
    if operation == "thr.verify":
        exact_keys(arguments, {"manifest"}, "DKN_ABI_REQUEST_INVALID")
        return verify_thr_manifest(arguments["manifest"])
    if operation == "record.verify":
        exact_keys(arguments, {"record"}, "DKN_ABI_REQUEST_INVALID")
        return verify_signed_record(arguments["record"])
    raise DKNRefusal("DKN_ABI_OPERATION_UNKNOWN", operation)


def invoke(request: Any) -> dict[str, Any]:
    try:
        item = exact_keys(request, {"schema", "request_id", "operation", "arguments"},
                          "DKN_ABI_REQUEST_INVALID")
        if item["schema"] != ABI_SCHEMA or type(item["request_id"]) is not str \
                or not item["request_id"] or type(item["operation"]) is not str \
                or type(item["arguments"]) is not dict:
            raise DKNRefusal("DKN_ABI_REQUEST_INVALID")
        result = _dispatch(item["operation"], item["arguments"])
        return {
            "schema": "dkn.abi-response.v0.1",
            "request_id": item["request_id"],
            "ok": True,
            "result": result,
            "refusal": None,
            **BOUNDARY,
        }
    except DKNRefusal as refusal:
        request_id = request.get("request_id") if type(request) is dict else None
        return {
            "schema": "dkn.abi-response.v0.1",
            "request_id": request_id,
            "ok": False,
            "result": None,
            "refusal": {"code": refusal.code, "detail": refusal.detail},
            **BOUNDARY,
        }

