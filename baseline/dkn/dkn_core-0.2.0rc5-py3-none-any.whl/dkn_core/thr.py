"""Three Hash Rule commitments for state, semantics, and governance metadata."""

from __future__ import annotations

import hashlib
from copy import deepcopy
from typing import Any

from .boundary import BOUNDARY
from .canonical import canonical_bytes, exact_keys, object_hash
from .errors import require

DOMAINS = {
    "state": b"DKN_THR_STATE_V0.1\x00",
    "semantic": b"DKN_THR_SEMANTIC_V0.1\x00",
    "governance": b"DKN_THR_GOVERNANCE_V0.1\x00",
}


def _commit(kind: str, value: Any) -> str:
    return hashlib.sha256(DOMAINS[kind] + canonical_bytes(value)).hexdigest()


def build_thr_manifest(*, state: Any, semantic: Any, governance: Any) -> dict[str, Any]:
    components = {
        "state": deepcopy(state),
        "semantic": deepcopy(semantic),
        "governance": deepcopy(governance),
    }
    commitments = {name: _commit(name, value) for name, value in components.items()}
    require(len(set(commitments.values())) == 3, "DKN_THR_DOMAIN_COLLAPSED")
    body = {
        "schema": "dkn.thr-manifest.v0.1",
        "hash_algorithm": "SHA-256",
        "serialization": "DKN-CJSON-1",
        "domain_separation": {
            "state": "DKN_THR_STATE_V0.1\\0",
            "semantic": "DKN_THR_SEMANTIC_V0.1\\0",
            "governance": "DKN_THR_GOVERNANCE_V0.1\\0",
        },
        "components": components,
        "commitments": {
            "state_hash": commitments["state"],
            "semantic_hash": commitments["semantic"],
            "governance_hash": commitments["governance"],
        },
        "non_equivalence": [
            "STATE_EQUALITY_DOES_NOT_PROVE_SEMANTIC_EQUALITY",
            "SEMANTIC_EQUALITY_DOES_NOT_PROVE_GOVERNANCE_ADMISSIBILITY",
            "GOVERNANCE_EQUALITY_DOES_NOT_PROVE_EXECUTION_AUTHORITY",
        ],
        **BOUNDARY,
    }
    return {**body, "thr_manifest_hash": object_hash(body, b"DKN_THR_MANIFEST_V0.1\x00")}


def verify_thr_manifest(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "hash_algorithm", "serialization", "domain_separation",
        "components", "commitments", "non_equivalence", *BOUNDARY,
        "thr_manifest_hash",
    }, "DKN_THR_INVALID")
    require(item["schema"] == "dkn.thr-manifest.v0.1"
            and item["hash_algorithm"] == "SHA-256"
            and item["serialization"] == "DKN-CJSON-1", "DKN_THR_INVALID")
    components = exact_keys(item["components"], {"state", "semantic", "governance"},
                            "DKN_THR_INVALID")
    expected = build_thr_manifest(
        state=components["state"],
        semantic=components["semantic"],
        governance=components["governance"],
    )
    require(item == expected, "DKN_THR_INVALID")
    return expected

