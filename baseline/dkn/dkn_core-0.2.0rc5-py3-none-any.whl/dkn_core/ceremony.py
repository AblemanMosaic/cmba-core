"""New-key ceremony with encrypted private custody kept outside passports."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .canonical import canonical_bytes
from .crypto import public_key_hex
from .errors import DKNRefusal, require
from .namespace import derive_namespace
from .passport import create_passport


def _write_exclusive(path: Path, data: bytes, mode: int) -> None:
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError as error:
        raise DKNRefusal("DKN_CEREMONY_OUTPUT_EXISTS", str(path)) from error
    except OSError as error:
        raise DKNRefusal("DKN_CEREMONY_PRIVATE_OUTPUT_INVALID", str(path)) from error


def new_key_ceremony(*, role: str, passphrase: bytes, private_out: Path,
                     passport_out: Path, semantic_namespace: str | None = None,
                     purpose: str = "identity", nonce: str = "dkn.identity.v0.1",
                     epoch_code: str = "e0001") -> dict[str, Any]:
    require(type(passphrase) is bytes and len(passphrase) >= 12,
            "DKN_CEREMONY_PASSPHRASE_REQUIRED")
    require(private_out.resolve() != passport_out.resolve()
            and private_out.suffix.lower() not in {".zip", ".json"},
            "DKN_CEREMONY_PRIVATE_OUTPUT_INVALID")
    require(not private_out.exists() and not passport_out.exists(),
            "DKN_CEREMONY_OUTPUT_EXISTS")
    private_key = Ed25519PrivateKey.generate()
    public_hex = public_key_hex(private_key)
    namespace = None
    if semantic_namespace is not None:
        namespace = derive_namespace(
            semantic_namespace=semantic_namespace,
            public_key_hex=public_hex,
            purpose=purpose,
            nonce=nonce,
            epoch_code=epoch_code,
        )
    passport = create_passport(public_key_hex=public_hex, role=role, namespace=namespace)
    encrypted = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.BestAvailableEncryption(passphrase),
    )
    _write_exclusive(private_out, encrypted, 0o600)
    try:
        _write_exclusive(passport_out, canonical_bytes(passport) + b"\n", 0o644)
    except Exception:
        # Do not delete or overwrite uncertain private-key custody.
        raise
    return {
        "schema": "dkn.key-ceremony-receipt.v0.1",
        "status": "PASS_NEW_KEY_MATERIAL_SEPARATED",
        "passport": passport,
        "private_key_encrypted": True,
        "private_key_in_passport": False,
        "private_key_in_portable_archive": False,
    }


def load_encrypted_private_key(path: Path, passphrase: bytes) -> Ed25519PrivateKey:
    try:
        key = serialization.load_pem_private_key(path.read_bytes(), password=passphrase)
    except Exception as error:
        raise DKNRefusal("DKN_PRIVATE_KEY_INVALID") from error
    require(isinstance(key, Ed25519PrivateKey), "DKN_PRIVATE_KEY_INVALID")
    return key

