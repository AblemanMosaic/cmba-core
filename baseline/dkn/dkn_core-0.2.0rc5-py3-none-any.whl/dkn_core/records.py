"""Signed DKN statements and lifecycle records."""

from __future__ import annotations

import hashlib
import re
from copy import deepcopy
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .boundary import BOUNDARY
from .canonical import canonical_bytes, exact_keys, hex_string, object_hash
from .crypto import public_key_bytes, public_key_hex, sign, verify
from .errors import require
from .passport import verify_passport
from .thr import verify_thr_manifest

SIGNING_DOMAIN = b"DKN_SIGNED_RECORD_V0.1\x00"
RECORD_TYPES = frozenset({
    "CONSTITUTIONAL_CHANGE",
    "COLLABORATOR_ATTESTATION",
    "PUBLICATION_RECEIPT",
    "RETRIEVAL_RECEIPT",
    "REVOCATION_SUPERSESSION",
    "EPOCH_TRANSITION",
})
_TOKEN = re.compile(r"[A-Z0-9][A-Z0-9._:-]{0,127}")


def _sha(value: Any, code: str = "DKN_RECORD_BODY_INVALID") -> str:
    return hex_string(value, 64, code)


def _token(value: Any) -> str:
    require(type(value) is str and _TOKEN.fullmatch(value) is not None,
            "DKN_RECORD_BODY_INVALID")
    return value


def _epoch(value: Any) -> str:
    require(type(value) is str and 1 <= len(value) <= 64
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}", value) is not None,
            "DKN_RECORD_BODY_INVALID")
    return value


def _subject(value: Any) -> str:
    require(type(value) is str
            and re.fullmatch(r"dknid:v0\.1:b3:[0-9a-f]{64}", value) is not None,
            "DKN_RECORD_BODY_INVALID")
    return value


def _boundary(value: dict[str, Any]) -> None:
    require({key: value.get(key) for key in BOUNDARY} == BOUNDARY,
            "DKN_RECORD_BODY_INVALID")


def signing_input(record_type: str, body: dict[str, Any], passport_hash: str) -> bytes:
    require(record_type in RECORD_TYPES, "DKN_RECORD_TYPE_UNSUPPORTED")
    _sha(passport_hash)
    value = {
        "schema": "dkn.record-signing-input.v0.1",
        "record_type": record_type,
        "body": deepcopy(body),
        "signer_passport_hash": passport_hash,
    }
    return SIGNING_DOMAIN + canonical_bytes(value)


def sign_record(*, record_type: str, body: dict[str, Any], passport: dict[str, Any],
                private_key: Ed25519PrivateKey) -> dict[str, Any]:
    checked_passport = verify_passport(passport)
    validate_record_body(record_type, body)
    require(public_key_hex(private_key) == checked_passport["public_key_hex"],
            "DKN_IDENTITY_KEY_MISMATCH")
    signature = sign(private_key, signing_input(
        record_type, body, checked_passport["passport_hash"]))
    envelope_body = {
        "schema": "dkn.signed-record.v0.1",
        "record_type": record_type,
        "body": deepcopy(body),
        "signer_passport": checked_passport,
        "signature_algorithm": "Ed25519",
        "signature_hex": signature,
        "signature_status": "PASS",
        "record_grants_authority": False,
        **BOUNDARY,
    }
    return {**envelope_body,
            "signed_record_hash": object_hash(envelope_body, b"DKN_SIGNED_RECORD_ENVELOPE_V0.1\x00")}


def verify_signed_record(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "record_type", "body", "signer_passport", "signature_algorithm",
        "signature_hex", "signature_status", "record_grants_authority", *BOUNDARY,
        "signed_record_hash",
    }, "DKN_RECORD_INVALID")
    require(item["schema"] == "dkn.signed-record.v0.1"
            and item["record_type"] in RECORD_TYPES
            and item["signature_algorithm"] == "Ed25519"
            and item["signature_status"] == "PASS"
            and item["record_grants_authority"] is False,
            "DKN_RECORD_INVALID")
    _boundary(item)
    passport = verify_passport(item["signer_passport"])
    validate_record_body(item["record_type"], item["body"])
    _verify_body_identity(item["record_type"], item["body"], passport["subject_id"])
    verify(
        passport["public_key_hex"],
        item["signature_hex"],
        signing_input(item["record_type"], item["body"], passport["passport_hash"]),
    )
    body = {key: deepcopy(raw) for key, raw in item.items() if key != "signed_record_hash"}
    require(item["signed_record_hash"]
            == object_hash(body, b"DKN_SIGNED_RECORD_ENVELOPE_V0.1\x00"),
            "DKN_RECORD_INVALID")
    return deepcopy(item)


def build_constitutional_change(*, base_thr_manifest_hash: str,
                                result_thr_manifest_hash: str,
                                changed_objects: list[dict[str, Any]],
                                acceptance_case_hashes: list[str],
                                namespace_binding_hash: str,
                                epoch_code: str,
                                engineering_revision: str,
                                author_subject_id: str) -> dict[str, Any]:
    _sha(base_thr_manifest_hash)
    _sha(result_thr_manifest_hash)
    require(base_thr_manifest_hash != result_thr_manifest_hash, "DKN_RECORD_BODY_INVALID")
    rows = []
    for raw in changed_objects:
        row = exact_keys(raw, {"path", "before_sha256", "after_sha256", "semantic_role"},
                         "DKN_RECORD_BODY_INVALID")
        require(type(row["path"]) is str and row["path"] and "\\" not in row["path"]
                and not row["path"].startswith("/")
                and all(part not in {"", ".", ".."} for part in row["path"].split("/")),
                "DKN_RECORD_BODY_INVALID")
        _sha(row["before_sha256"])
        _sha(row["after_sha256"])
        require(row["before_sha256"] != row["after_sha256"], "DKN_RECORD_BODY_INVALID")
        _token(row["semantic_role"])
        rows.append(deepcopy(row))
    require(rows and rows == sorted(rows, key=lambda row: row["path"])
            and len({row["path"].casefold() for row in rows}) == len(rows),
            "DKN_RECORD_BODY_INVALID")
    cases = sorted(set(acceptance_case_hashes))
    require(cases == acceptance_case_hashes and bool(cases), "DKN_RECORD_BODY_INVALID")
    for value in cases:
        _sha(value)
    _sha(namespace_binding_hash)
    _epoch(epoch_code)
    _subject(author_subject_id)
    require(re.fullmatch(r"r[0-9]{3}", engineering_revision) is not None,
            "DKN_RECORD_BODY_INVALID")
    body = {
        "schema": "dkn.constitutional-change.v0.1",
        "base_thr_manifest_hash": base_thr_manifest_hash,
        "result_thr_manifest_hash": result_thr_manifest_hash,
        "changed_objects": rows,
        "acceptance_case_hashes": cases,
        "namespace_binding_hash": namespace_binding_hash,
        "epoch_code": epoch_code,
        "engineering_revision": engineering_revision,
        "author_subject_id": author_subject_id,
        "import_status": "PROPOSAL_ONLY",
        "canonical_replacement_authorized": False,
        **BOUNDARY,
    }
    return body


def build_collaborator_attestation(*, collaborator_subject_id: str,
                                   subject_hash: str,
                                   namespace_binding_hash: str,
                                   epoch_code: str,
                                   statement: str) -> dict[str, Any]:
    _sha(subject_hash)
    _sha(namespace_binding_hash)
    _subject(collaborator_subject_id)
    _epoch(epoch_code)
    require(type(statement) is str and 0 < len(statement.encode("utf-8")) <= 4096,
            "DKN_RECORD_BODY_INVALID")
    body = {
        "schema": "dkn.collaborator-attestation.v0.1",
        "collaborator_subject_id": collaborator_subject_id,
        "subject_hash": subject_hash,
        "namespace_binding_hash": namespace_binding_hash,
        "epoch_code": epoch_code,
        "statement": statement,
        "statement_hash": object_hash(statement, b"DKN_COLLABORATOR_STATEMENT_V0.1\x00"),
        "attestation_grants_authority": False,
        **BOUNDARY,
    }
    return body


def build_storage_locator(*, provider_id: str, locator: str,
                          artifact_sha256: str) -> dict[str, Any]:
    require(type(provider_id) is str and 1 <= len(provider_id) <= 64
            and provider_id.upper() == provider_id, "DKN_STORAGE_LOCATOR_INVALID")
    require(type(locator) is str and 1 <= len(locator) <= 2048
            and locator == locator.strip(), "DKN_STORAGE_LOCATOR_INVALID")
    lowered = locator.casefold()
    require(not any(mark in lowered for mark in (
        "token=", "password=", "passwd=", "secret=", "private_key=", "apikey=",
        "api_key=", "authorization:", "credential=",
    )), "DKN_STORAGE_LOCATOR_CONTAINS_CREDENTIAL")
    _sha(artifact_sha256, "DKN_STORAGE_LOCATOR_INVALID")
    body = {
        "schema": "dkn.storage-locator.v0.1",
        "provider_id": provider_id,
        "locator": locator,
        "artifact_sha256": artifact_sha256,
        "storage_is_identity_authority": False,
        "replaceable_projection": True,
    }
    return {**body, "storage_locator_hash": object_hash(body, b"DKN_STORAGE_LOCATOR_V0.1\x00")}


def verify_storage_locator(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "provider_id", "locator", "artifact_sha256",
        "storage_is_identity_authority", "replaceable_projection",
        "storage_locator_hash",
    }, "DKN_STORAGE_LOCATOR_INVALID")
    expected = build_storage_locator(
        provider_id=item["provider_id"], locator=item["locator"],
        artifact_sha256=item["artifact_sha256"])
    require(item == expected, "DKN_STORAGE_LOCATOR_INVALID")
    return expected


def build_publication_receipt(*, publisher_subject_id: str, artifact_sha256: str,
                              thr_manifest: dict[str, Any],
                              namespace_binding_hash: str,
                              storage_locator: dict[str, Any],
                              published_epoch_code: str) -> dict[str, Any]:
    _sha(artifact_sha256)
    thr = verify_thr_manifest(thr_manifest)
    _sha(namespace_binding_hash)
    _subject(publisher_subject_id)
    _epoch(published_epoch_code)
    locator = verify_storage_locator(storage_locator)
    require(locator["artifact_sha256"] == artifact_sha256,
            "DKN_RECEIPT_ARTIFACT_MISMATCH")
    body = {
        "schema": "dkn.publication-receipt.v0.1",
        "publisher_subject_id": publisher_subject_id,
        "artifact_sha256": artifact_sha256,
        "thr_manifest_hash": thr["thr_manifest_hash"],
        "commitments": deepcopy(thr["commitments"]),
        "namespace_binding_hash": namespace_binding_hash,
        "storage_locator": locator,
        "published_epoch_code": published_epoch_code,
        "publication_authorized": False,
        "receipt_grants_authority": False,
        **BOUNDARY,
    }
    return body


def build_retrieval_receipt(*, retriever_subject_id: str,
                            publication_receipt: dict[str, Any],
                            artifact_bytes: bytes,
                            retrieved_epoch_code: str) -> dict[str, Any]:
    publication = verify_signed_record(publication_receipt)
    require(publication["record_type"] == "PUBLICATION_RECEIPT",
            "DKN_RECORD_BODY_INVALID")
    artifact_sha256 = hashlib.sha256(artifact_bytes).hexdigest()
    require(artifact_sha256 == publication["body"]["artifact_sha256"],
            "DKN_RECEIPT_ARTIFACT_MISMATCH")
    _subject(retriever_subject_id)
    _epoch(retrieved_epoch_code)
    body = {
        "schema": "dkn.retrieval-receipt.v0.1",
        "retriever_subject_id": retriever_subject_id,
        "publication_receipt_hash": publication["signed_record_hash"],
        "artifact_sha256": artifact_sha256,
        "storage_locator_hash": publication["body"]["storage_locator"]["storage_locator_hash"],
        "retrieved_epoch_code": retrieved_epoch_code,
        "artifact_verified_after_retrieval": True,
        "storage_is_identity_authority": False,
        **BOUNDARY,
    }
    return body


def verify_retrieval_receipt(*, receipt: dict[str, Any],
                             publication_receipt: dict[str, Any],
                             artifact_bytes: bytes) -> dict[str, Any]:
    checked = verify_signed_record(receipt)
    require(checked["record_type"] == "RETRIEVAL_RECEIPT", "DKN_RECORD_BODY_INVALID")
    publication = verify_signed_record(publication_receipt)
    require(publication["record_type"] == "PUBLICATION_RECEIPT", "DKN_RECORD_BODY_INVALID")
    observed = hashlib.sha256(artifact_bytes).hexdigest()
    require(checked["body"]["publication_receipt_hash"] == publication["signed_record_hash"]
            and checked["body"]["artifact_sha256"] == observed
            and publication["body"]["artifact_sha256"] == observed
            and checked["body"]["storage_locator_hash"]
            == publication["body"]["storage_locator"]["storage_locator_hash"],
            "DKN_RECEIPT_ARTIFACT_MISMATCH")
    return checked


def build_revocation_supersession(*, revoker_subject_id: str,
                                  target_subject_id: str,
                                  target_public_key_hex: str,
                                  disposition: str,
                                  reason_code: str,
                                  effective_epoch_code: str,
                                  successor_subject_id: str | None = None) -> dict[str, Any]:
    require(disposition in {"REVOKED", "SUPERSEDED"}, "DKN_RECORD_BODY_INVALID")
    require((disposition == "SUPERSEDED") == (successor_subject_id is not None),
            "DKN_RECORD_BODY_INVALID")
    _token(reason_code)
    _subject(revoker_subject_id)
    _subject(target_subject_id)
    public_key_bytes(target_public_key_hex)
    _epoch(effective_epoch_code)
    if successor_subject_id is not None:
        _subject(successor_subject_id)
    body = {
        "schema": "dkn.revocation-supersession.v0.1",
        "revoker_subject_id": revoker_subject_id,
        "target_subject_id": target_subject_id,
        "target_public_key_hex": target_public_key_hex,
        "disposition": disposition,
        "reason_code": reason_code,
        "effective_epoch_code": effective_epoch_code,
        "successor_subject_id": successor_subject_id,
        "revocation_grants_authority": False,
        **BOUNDARY,
    }
    return body


def build_epoch_transition(*, author_subject_id: str,
                           current_namespace_id: str,
                           next_namespace_id: str,
                           from_epoch_code: str,
                           to_epoch_code: str,
                           next_subject_id: str,
                           reason_code: str) -> dict[str, Any]:
    require(current_namespace_id != next_namespace_id
            and from_epoch_code != to_epoch_code, "DKN_RECORD_BODY_INVALID")
    _token(reason_code)
    _subject(author_subject_id)
    _subject(next_subject_id)
    require(re.fullmatch(r"dkn:v0\.1:b3:[0-9a-f]{64}", current_namespace_id) is not None
            and re.fullmatch(r"dkn:v0\.1:b3:[0-9a-f]{64}", next_namespace_id) is not None,
            "DKN_RECORD_BODY_INVALID")
    _epoch(from_epoch_code)
    _epoch(to_epoch_code)
    body = {
        "schema": "dkn.epoch-transition.v0.1",
        "author_subject_id": author_subject_id,
        "current_namespace_id": current_namespace_id,
        "next_namespace_id": next_namespace_id,
        "from_epoch_code": from_epoch_code,
        "to_epoch_code": to_epoch_code,
        "next_subject_id": next_subject_id,
        "reason_code": reason_code,
        "transition_grants_authority": False,
        **BOUNDARY,
    }
    return body


def validate_record_body(record_type: str, value: Any) -> dict[str, Any]:
    require(record_type in RECORD_TYPES and type(value) is dict,
            "DKN_RECORD_TYPE_UNSUPPORTED")
    schemas = {
        "CONSTITUTIONAL_CHANGE": ("dkn.constitutional-change.v0.1", {
            "schema", "base_thr_manifest_hash", "result_thr_manifest_hash",
            "changed_objects", "acceptance_case_hashes", "namespace_binding_hash",
            "epoch_code", "engineering_revision", "author_subject_id", "import_status",
            "canonical_replacement_authorized", *BOUNDARY,
        }),
        "COLLABORATOR_ATTESTATION": ("dkn.collaborator-attestation.v0.1", {
            "schema", "collaborator_subject_id", "subject_hash",
            "namespace_binding_hash", "epoch_code", "statement", "statement_hash",
            "attestation_grants_authority", *BOUNDARY,
        }),
        "PUBLICATION_RECEIPT": ("dkn.publication-receipt.v0.1", {
            "schema", "publisher_subject_id", "artifact_sha256", "thr_manifest_hash",
            "commitments", "namespace_binding_hash", "storage_locator",
            "published_epoch_code", "publication_authorized", "receipt_grants_authority",
            *BOUNDARY,
        }),
        "RETRIEVAL_RECEIPT": ("dkn.retrieval-receipt.v0.1", {
            "schema", "retriever_subject_id", "publication_receipt_hash",
            "artifact_sha256", "storage_locator_hash", "retrieved_epoch_code",
            "artifact_verified_after_retrieval", "storage_is_identity_authority",
            *BOUNDARY,
        }),
        "REVOCATION_SUPERSESSION": ("dkn.revocation-supersession.v0.1", {
            "schema", "revoker_subject_id", "target_subject_id", "target_public_key_hex",
            "disposition", "reason_code", "effective_epoch_code", "successor_subject_id",
            "revocation_grants_authority", *BOUNDARY,
        }),
        "EPOCH_TRANSITION": ("dkn.epoch-transition.v0.1", {
            "schema", "author_subject_id", "current_namespace_id", "next_namespace_id",
            "from_epoch_code", "to_epoch_code", "next_subject_id", "reason_code",
            "transition_grants_authority", *BOUNDARY,
        }),
    }
    schema, keys = schemas[record_type]
    item = exact_keys(value, keys, "DKN_RECORD_BODY_INVALID")
    require(item["schema"] == schema, "DKN_RECORD_BODY_INVALID")
    _boundary(item)
    # Rebuild validates field semantics and derived values.
    if record_type == "CONSTITUTIONAL_CHANGE":
        expected = build_constitutional_change(**{
            key: item[key] for key in (
                "base_thr_manifest_hash", "result_thr_manifest_hash", "changed_objects",
                "acceptance_case_hashes", "namespace_binding_hash", "epoch_code",
                "engineering_revision", "author_subject_id")})
    elif record_type == "COLLABORATOR_ATTESTATION":
        expected = build_collaborator_attestation(**{
            key: item[key] for key in (
                "collaborator_subject_id", "subject_hash", "namespace_binding_hash",
                "epoch_code", "statement")})
    elif record_type == "PUBLICATION_RECEIPT":
        # THR source object is intentionally not embedded; validate all commitments directly.
        _sha(item["artifact_sha256"])
        _sha(item["thr_manifest_hash"])
        exact_keys(item["commitments"], {"state_hash", "semantic_hash", "governance_hash"},
                   "DKN_RECORD_BODY_INVALID")
        for commitment in item["commitments"].values():
            _sha(commitment)
        _sha(item["namespace_binding_hash"])
        verify_storage_locator(item["storage_locator"])
        require(item["storage_locator"]["artifact_sha256"] == item["artifact_sha256"]
                and item["publication_authorized"] is False
                and item["receipt_grants_authority"] is False,
                "DKN_RECORD_BODY_INVALID")
        expected = item
    elif record_type == "RETRIEVAL_RECEIPT":
        for key in ("publication_receipt_hash", "artifact_sha256", "storage_locator_hash"):
            _sha(item[key])
        require(item["artifact_verified_after_retrieval"] is True
                and item["storage_is_identity_authority"] is False,
                "DKN_RECORD_BODY_INVALID")
        expected = item
    elif record_type == "REVOCATION_SUPERSESSION":
        expected = build_revocation_supersession(**{
            key: item[key] for key in (
                "revoker_subject_id", "target_subject_id", "target_public_key_hex",
                "disposition", "reason_code", "effective_epoch_code",
                "successor_subject_id")})
    else:
        expected = build_epoch_transition(**{
            key: item[key] for key in (
                "author_subject_id", "current_namespace_id", "next_namespace_id",
                "from_epoch_code", "to_epoch_code", "next_subject_id", "reason_code")})
    require(item == expected, "DKN_RECORD_BODY_INVALID")
    return deepcopy(item)


def _verify_body_identity(record_type: str, body: dict[str, Any], subject_id: str) -> None:
    field = {
        "CONSTITUTIONAL_CHANGE": "author_subject_id",
        "COLLABORATOR_ATTESTATION": "collaborator_subject_id",
        "PUBLICATION_RECEIPT": "publisher_subject_id",
        "RETRIEVAL_RECEIPT": "retriever_subject_id",
        "REVOCATION_SUPERSESSION": "revoker_subject_id",
        "EPOCH_TRANSITION": "author_subject_id",
    }[record_type]
    require(body[field] == subject_id, "DKN_RECORD_IDENTITY_MISMATCH")

