"""Explicit compatibility profile for UCM r029 DKN dimensions."""

from __future__ import annotations

from typing import Any

from blake3 import blake3

from .boundary import BOUNDARY
from .canonical import object_hash
from .crypto import mosaic_id, public_key_bytes
from .errors import require
from .namespace import verify_namespace

PROFILE = "DKN.AUTHORITY_KEYED_DIMENSION.UTF8_RAW_ED25519.V1"


def derive_ucm_legacy_dimension(*, phase_code: str, public_key_hex: str) -> dict[str, Any]:
    require(type(phase_code) is str and 0 < len(phase_code) <= 128
            and not any(0xD800 <= ord(ch) <= 0xDFFF for ch in phase_code),
            "DKN_EPOCH_CODE_INVALID")
    key = public_key_bytes(public_key_hex)
    body = {
        "schema": "dkn.compat.ucm-dimension.v0.1",
        "profile_id": PROFILE,
        "formula": "BLAKE3(UTF8(phase_code)||raw_ed25519_public_key)",
        "phase_code": phase_code,
        "public_key_hex": public_key_hex,
        "mosaic_id": mosaic_id(public_key_hex),
        "dimension_id": blake3(phase_code.encode("utf-8") + key).hexdigest(),
        "canonical_dkn_namespace": False,
        "permission_granted": False,
        **BOUNDARY,
    }
    return {**body, "legacy_binding_hash": object_hash(body, b"DKN_UCM_LEGACY_DIMENSION_V0.1\x00")}


def build_migration_binding(*, phase_code: str, public_key_hex: str,
                            namespace: dict[str, Any]) -> dict[str, Any]:
    legacy = derive_ucm_legacy_dimension(phase_code=phase_code,
                                         public_key_hex=public_key_hex)
    current = verify_namespace(namespace)
    require(current["material"]["public_key_hex"] == public_key_hex,
            "DKN_IDENTITY_KEY_MISMATCH")
    body = {
        "schema": "dkn.compat.migration-binding.v0.1",
        "legacy": legacy,
        "current_namespace": current,
        "migration_status": "PROPOSED_REBINDING_ONLY",
        "consumer_admission_required": True,
        **BOUNDARY,
    }
    return {**body, "migration_binding_hash": object_hash(body, b"DKN_MIGRATION_BINDING_V0.1\x00")}

