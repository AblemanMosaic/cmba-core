"""Canonical DKN namespace construction."""

from __future__ import annotations

import re
from typing import Any

from .boundary import BOUNDARY
from .canonical import canonical_bytes, exact_keys, object_hash
from .crypto import blake3_hex, dkn_subject_id, mosaic_id, public_key_bytes
from .errors import require

NAMESPACE_DOMAIN = b"DKN_NAMESPACE_V0.1\x00"
_LABEL = re.compile(r"[a-z0-9](?:[a-z0-9_-]{0,61}[a-z0-9])?")
_TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")


def parse_semantic_namespace(value: Any) -> tuple[str, str]:
    require(type(value) is str and 0 < len(value) <= 255 and value == value.strip(),
            "DKN_NAMESPACE_INVALID")
    require(value.isascii() and value == value.lower(), "DKN_NAMESPACE_INVALID")
    wildcard = value.endswith(".*")
    base = value[:-2] if wildcard else value
    require("*" not in base and base, "DKN_NAMESPACE_INVALID")
    labels = base.split(".")
    require(all(_LABEL.fullmatch(label) is not None for label in labels),
            "DKN_NAMESPACE_INVALID")
    return base, "WILDCARD_TERMINAL" if wildcard else "EXACT"


def _token(value: Any, code: str, maximum: int = 128) -> str:
    require(type(value) is str and len(value) <= maximum
            and _TOKEN.fullmatch(value) is not None, code)
    return value


def namespace_signing_material(*, semantic_namespace: str, public_key_hex: str,
                               purpose: str, nonce: str, epoch_code: str) -> dict[str, Any]:
    base, kind = parse_semantic_namespace(semantic_namespace)
    public_key_bytes(public_key_hex)
    _token(purpose, "DKN_PURPOSE_INVALID")
    _token(nonce, "DKN_NONCE_INVALID")
    _token(epoch_code, "DKN_EPOCH_CODE_INVALID", maximum=64)
    return {
        "schema": "dkn.namespace-material.v0.1",
        "protocol_version": "v0.1",
        "serialization": "DKN-CJSON-1",
        "hash_algorithm": "BLAKE3-256",
        "key_algorithm": "Ed25519",
        "semantic_namespace": base,
        "namespace_kind": kind,
        "public_key_hex": public_key_hex,
        "purpose": purpose,
        "nonce": nonce,
        "epoch_code": epoch_code,
    }


def derive_namespace(*, semantic_namespace: str, public_key_hex: str,
                     purpose: str, nonce: str, epoch_code: str) -> dict[str, Any]:
    material = namespace_signing_material(
        semantic_namespace=semantic_namespace,
        public_key_hex=public_key_hex,
        purpose=purpose,
        nonce=nonce,
        epoch_code=epoch_code,
    )
    digest = blake3_hex(NAMESPACE_DOMAIN, canonical_bytes(material))
    body = {
        "schema": "dkn.namespace.v0.1",
        "namespace_id": f"dkn:v0.1:b3:{digest}",
        "material": material,
        "subject_id": dkn_subject_id(public_key_hex),
        "mosaic_id": mosaic_id(public_key_hex),
        "identity_is_authority": False,
        "wildcard_grants_subnamespace_authority": False,
        **BOUNDARY,
    }
    return {**body, "namespace_binding_hash": object_hash(body, b"DKN_NAMESPACE_BINDING_V0.1\x00")}


def verify_namespace(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "namespace_id", "material", "subject_id", "mosaic_id",
        "identity_is_authority", "wildcard_grants_subnamespace_authority",
        *BOUNDARY, "namespace_binding_hash",
    }, "DKN_NAMESPACE_INVALID")
    require(item["schema"] == "dkn.namespace.v0.1", "DKN_VERSION_UNSUPPORTED")
    material = exact_keys(item["material"], {
        "schema", "protocol_version", "serialization", "hash_algorithm",
        "key_algorithm", "semantic_namespace", "namespace_kind", "public_key_hex",
        "purpose", "nonce", "epoch_code",
    }, "DKN_NAMESPACE_INVALID")
    semantic = material["semantic_namespace"] + (
        ".*" if material["namespace_kind"] == "WILDCARD_TERMINAL" else "")
    expected = derive_namespace(
        semantic_namespace=semantic,
        public_key_hex=material["public_key_hex"],
        purpose=material["purpose"],
        nonce=material["nonce"],
        epoch_code=material["epoch_code"],
    )
    require(item == expected, "DKN_NAMESPACE_INVALID")
    return expected

