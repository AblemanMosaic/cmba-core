"""DKN Core command-line interface. No command performs network effects."""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path
from typing import Any

from .abi import invoke
from .archive import verify_portable_archive
from .canonical import canonical_bytes, strict_load_canonical
from .ceremony import load_encrypted_private_key, new_key_ceremony
from .errors import DKNRefusal
from .namespace import derive_namespace
from .passport import create_passport, import_mosaic_id, verify_passport
from .records import sign_record, verify_retrieval_receipt, verify_signed_record
from .thr import build_thr_manifest


def _read_json(path: Path) -> Any:
    try:
        raw = path.read_bytes()
        # Portable text files may carry one LF as a file terminator; the hashed
        # canonical JSON value never includes it.
        if raw.endswith(b"\n"):
            raw = raw[:-1]
        return strict_load_canonical(raw)
    except OSError as error:
        raise DKNRefusal("DKN_CANONICAL_JSON_INVALID", str(path)) from error


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as error:
        raise DKNRefusal("DKN_ARCHIVE_INVALID", str(path)) from error


def _emit(value: Any, out: Path | None = None) -> None:
    raw = canonical_bytes(value) + b"\n"
    if out is None:
        sys.stdout.buffer.write(raw)
        return
    try:
        with out.open("xb") as stream:
            stream.write(raw)
    except FileExistsError as error:
        raise DKNRefusal("DKN_CEREMONY_OUTPUT_EXISTS", str(out)) from error


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dkn", description="DKN Core v0.1 r002")
    commands = parser.add_subparsers(dest="command", required=True)

    namespace = commands.add_parser("namespace")
    namespace_commands = namespace.add_subparsers(dest="namespace_command", required=True)
    derive = namespace_commands.add_parser("derive")
    derive.add_argument("--semantic-namespace", required=True)
    derive.add_argument("--public-key-hex", required=True)
    derive.add_argument("--purpose", required=True)
    derive.add_argument("--nonce", required=True)
    derive.add_argument("--epoch-code", required=True)
    derive.add_argument("--out", type=Path)

    passport = commands.add_parser("passport")
    passport_commands = passport.add_subparsers(dest="passport_command", required=True)
    create = passport_commands.add_parser("create")
    create.add_argument("--public-key-hex", required=True)
    create.add_argument("--role", required=True)
    create.add_argument("--namespace", type=Path)
    create.add_argument("--out", type=Path)
    imported = passport_commands.add_parser("import-mosaic")
    imported.add_argument("--mosaic-id", required=True)
    imported.add_argument("--public-key-hex", required=True)
    imported.add_argument("--role", required=True)
    imported.add_argument("--semantic-namespace")
    imported.add_argument("--purpose", default="identity")
    imported.add_argument("--nonce", default="mosaic.identity.v0.1")
    imported.add_argument("--epoch-code", default="legacy")
    imported.add_argument("--out", type=Path)
    inspect = passport_commands.add_parser("verify")
    inspect.add_argument("passport", type=Path)

    ceremony = commands.add_parser("ceremony")
    ceremony_commands = ceremony.add_subparsers(dest="ceremony_command", required=True)
    new = ceremony_commands.add_parser("new")
    new.add_argument("--role", required=True)
    new.add_argument("--private-out", type=Path, required=True)
    new.add_argument("--passport-out", type=Path, required=True)
    new.add_argument("--semantic-namespace")
    new.add_argument("--purpose", default="identity")
    new.add_argument("--nonce", default="dkn.identity.v0.1")
    new.add_argument("--epoch-code", default="e0001")

    thr = commands.add_parser("thr")
    thr_commands = thr.add_subparsers(dest="thr_command", required=True)
    thr_build = thr_commands.add_parser("build")
    thr_build.add_argument("--state", type=Path, required=True)
    thr_build.add_argument("--semantic", type=Path, required=True)
    thr_build.add_argument("--governance", type=Path, required=True)
    thr_build.add_argument("--out", type=Path)

    record = commands.add_parser("record")
    record_commands = record.add_subparsers(dest="record_command", required=True)
    record_sign = record_commands.add_parser("sign")
    record_sign.add_argument("--type", required=True)
    record_sign.add_argument("--body", type=Path, required=True)
    record_sign.add_argument("--passport", type=Path, required=True)
    record_sign.add_argument("--private-key", type=Path, required=True)
    record_sign.add_argument("--out", type=Path)
    record_verify = record_commands.add_parser("verify")
    record_verify.add_argument("record", type=Path)

    retrieval = commands.add_parser("retrieval")
    retrieval_commands = retrieval.add_subparsers(dest="retrieval_command", required=True)
    retrieval_verify = retrieval_commands.add_parser("verify")
    retrieval_verify.add_argument("--receipt", type=Path, required=True)
    retrieval_verify.add_argument("--publication", type=Path, required=True)
    retrieval_verify.add_argument("--artifact", type=Path, required=True)

    archive = commands.add_parser("archive")
    archive_commands = archive.add_subparsers(dest="archive_command", required=True)
    archive_verify = archive_commands.add_parser("verify")
    archive_verify.add_argument("archive", type=Path)

    abi = commands.add_parser("abi")
    abi.add_argument("request", type=Path)
    return parser


def run(args: argparse.Namespace) -> Any:
    if args.command == "namespace":
        result = derive_namespace(
            semantic_namespace=args.semantic_namespace,
            public_key_hex=args.public_key_hex,
            purpose=args.purpose,
            nonce=args.nonce,
            epoch_code=args.epoch_code,
        )
        _emit(result, args.out)
        return result
    if args.command == "passport":
        if args.passport_command == "create":
            namespace = _read_json(args.namespace) if args.namespace else None
            result = create_passport(public_key_hex=args.public_key_hex,
                                     role=args.role, namespace=namespace)
            _emit(result, args.out)
        elif args.passport_command == "import-mosaic":
            result = import_mosaic_id(
                mosaic_id_value=args.mosaic_id,
                public_key_hex=args.public_key_hex,
                role=args.role,
                semantic_namespace=args.semantic_namespace,
                purpose=args.purpose,
                nonce=args.nonce,
                epoch_code=args.epoch_code,
            )
            _emit(result, args.out)
        else:
            result = verify_passport(_read_json(args.passport))
            _emit(result)
        return result
    if args.command == "ceremony":
        first = getpass.getpass("New private-key passphrase: ").encode("utf-8")
        second = getpass.getpass("Confirm passphrase: ").encode("utf-8")
        if first != second:
            raise DKNRefusal("DKN_CEREMONY_PASSPHRASE_REQUIRED", "mismatch")
        result = new_key_ceremony(
            role=args.role,
            passphrase=first,
            private_out=args.private_out,
            passport_out=args.passport_out,
            semantic_namespace=args.semantic_namespace,
            purpose=args.purpose,
            nonce=args.nonce,
            epoch_code=args.epoch_code,
        )
        _emit(result)
        return result
    if args.command == "thr":
        result = build_thr_manifest(
            state=_read_json(args.state),
            semantic=_read_json(args.semantic),
            governance=_read_json(args.governance),
        )
        _emit(result, args.out)
        return result
    if args.command == "record":
        if args.record_command == "verify":
            result = verify_signed_record(_read_json(args.record))
        else:
            passphrase = getpass.getpass("Private-key passphrase: ").encode("utf-8")
            key = load_encrypted_private_key(args.private_key, passphrase)
            result = sign_record(
                record_type=args.type,
                body=_read_json(args.body),
                passport=_read_json(args.passport),
                private_key=key,
            )
        _emit(result, getattr(args, "out", None))
        return result
    if args.command == "retrieval":
        result = verify_retrieval_receipt(
            receipt=_read_json(args.receipt),
            publication_receipt=_read_json(args.publication),
            artifact_bytes=_read_bytes(args.artifact),
        )
        _emit(result)
        return result
    if args.command == "archive":
        result = verify_portable_archive(_read_bytes(args.archive))
        _emit(result)
        return result
    if args.command == "abi":
        result = invoke(_read_json(args.request))
        _emit(result)
        return result
    raise DKNRefusal("DKN_ABI_OPERATION_UNKNOWN")


def main(argv: list[str] | None = None) -> int:
    try:
        run(_parser().parse_args(argv))
        return 0
    except DKNRefusal as refusal:
        _emit({
            "schema": "dkn.cli-refusal.v0.1",
            "status": "REFUSED",
            "code": refusal.code,
            "detail": refusal.detail,
            "standing": "INFORMATION_ONLY",
            "authority_effect": "NONE",
            "real_a5": False,
            "g0": "CLOSED",
        })
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

