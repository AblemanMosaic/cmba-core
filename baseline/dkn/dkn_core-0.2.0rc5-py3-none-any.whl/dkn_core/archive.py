"""Deterministic public-only DKN portable archives."""

from __future__ import annotations

import hashlib
import io
import zipfile
from copy import deepcopy
from pathlib import PurePosixPath
from typing import Any, Iterable

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .boundary import BOUNDARY
from .canonical import canonical_bytes, exact_keys, object_hash, strict_load_canonical
from .crypto import public_key_hex, sign, verify
from .errors import DKNRefusal, require
from .namespace import verify_namespace
from .passport import verify_passport
from .thr import build_thr_manifest, verify_thr_manifest

META_FILES = (
    "META/STATE-MANIFEST.json",
    "META/THR-MANIFEST.json",
    "META/DKN-BINDING.json",
    "META/SELF-CERTIFICATE.json",
)
MANIFEST = "MANIFEST.json"
CERT_DOMAIN = b"DKN_ARCHIVE_SELF_CERTIFICATE_V0.1\x00"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024


def _portable_path(path: str) -> None:
    require(type(path) is str and path and "\\" not in path and not path.startswith("/"),
            "DKN_ARCHIVE_INVALID")
    parts = PurePosixPath(path).parts
    require(all(part not in {"", ".", ".."} for part in parts), "DKN_ARCHIVE_INVALID")


def _rows(payloads: dict[str, bytes]) -> list[dict[str, Any]]:
    rows = []
    seen: set[str] = set()
    for path in sorted(payloads):
        _portable_path(path)
        require(path.casefold() not in seen and type(payloads[path]) is bytes,
                "DKN_ARCHIVE_INVALID")
        seen.add(path.casefold())
        data = payloads[path]
        rows.append({
            "path": path,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    return rows


def _secret_scan(path: str, data: bytes) -> None:
    lowered = path.casefold()
    require(not lowered.endswith((".pem", ".key", ".p12", ".pfx", ".kdbx"))
            and not any(name in lowered.split("/") for name in (
                "credentials", "id_ed25519", "ipc.key", ".env")),
            "DKN_ARCHIVE_CREDENTIAL_MATERIAL_REFUSED", path)
    for line in data.splitlines():
        stripped = line.strip()
        require(stripped not in {
            b"-----BEGIN PRIVATE KEY-----",
            b"-----BEGIN ENCRYPTED PRIVATE KEY-----",
            b"-----BEGIN OPENSSH PRIVATE KEY-----",
            b"-----BEGIN RSA PRIVATE KEY-----",
        }, "DKN_ARCHIVE_CREDENTIAL_MATERIAL_REFUSED", path)


def build_dkn_binding(*, namespace: dict[str, Any] | None = None,
                      passport: dict[str, Any] | None = None) -> dict[str, Any]:
    if namespace is None and passport is None:
        status = "DECLARED_UNBOUND"
        checked_namespace = None
        checked_passport = None
    else:
        require(namespace is not None and passport is not None,
                "DKN_ARCHIVE_INVALID")
        checked_namespace = verify_namespace(namespace)
        checked_passport = verify_passport(passport)
        require(checked_namespace["subject_id"] == checked_passport["subject_id"]
                and checked_namespace["material"]["public_key_hex"]
                == checked_passport["public_key_hex"], "DKN_IDENTITY_KEY_MISMATCH")
        status = "BOUND_PUBLIC_IDENTITY"
    body = {
        "schema": "dkn.archive-binding.v0.1",
        "public_namespace": "dkn.core.v0.1",
        "status": status,
        "namespace": deepcopy(checked_namespace),
        "passport": deepcopy(checked_passport),
        "permission_granted": False,
        "storage_location_bound": False,
        "non_claims": ["IDENTITY_IS_NOT_AUTHORITY", "LOCATION_IS_NOT_IDENTITY"],
        **BOUNDARY,
    }
    return {**body, "dkn_binding_hash": object_hash(body, b"DKN_ARCHIVE_BINDING_V0.1\x00")}


def verify_dkn_binding(value: Any) -> dict[str, Any]:
    item = exact_keys(value, {
        "schema", "public_namespace", "status", "namespace", "passport",
        "permission_granted", "storage_location_bound", "non_claims", *BOUNDARY,
        "dkn_binding_hash",
    }, "DKN_ARCHIVE_INVALID")
    expected = build_dkn_binding(namespace=item["namespace"], passport=item["passport"])
    require(item == expected, "DKN_ARCHIVE_INVALID")
    return expected


def _zip_bytes(members: dict[str, bytes]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        for path in sorted(members):
            info = zipfile.ZipInfo(path, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.flag_bits = 0x800
            archive.writestr(info, members[path])
    return output.getvalue()


def build_portable_archive(*, payloads: dict[str, bytes],
                           namespace: dict[str, Any] | None = None,
                           passport: dict[str, Any] | None = None,
                           private_key: Ed25519PrivateKey | None = None,
                           engineering_revision: str = "r002") -> bytes:
    require(payloads and all(not path.startswith("META/") and path != MANIFEST
                             for path in payloads), "DKN_ARCHIVE_INVALID")
    require(len(engineering_revision) == 4 and engineering_revision.startswith("r")
            and engineering_revision[1:].isdigit(), "DKN_ARCHIVE_INVALID")
    for path, data in payloads.items():
        _secret_scan(path, data)
    state_rows = _rows(payloads)
    state_body = {
        "schema": "dkn.archive-state-manifest.v0.1",
        "public_version": "v0.1",
        "engineering_revision": engineering_revision,
        "scope": "LOGICAL_PAYLOAD_EXCLUDING_META_AND_CONTAINER_MANIFEST",
        "members": state_rows,
        "member_count": len(state_rows),
        "logical_bytes": sum(row["bytes"] for row in state_rows),
        **BOUNDARY,
    }
    state = {**state_body,
             "state_manifest_hash": object_hash(state_body, b"DKN_ARCHIVE_STATE_V0.1\x00")}
    binding = build_dkn_binding(namespace=namespace, passport=passport)
    semantic = {
        "schema": "dkn.archive-semantic.v0.1",
        "product": "DKN Core",
        "artifact_role": "PORTABLE_PROTOCOL_AND_REFERENCE_IMPLEMENTATION",
        "public_version": "v0.1",
        "engineering_revision": engineering_revision,
        "storage_agnostic": True,
    }
    governance = {
        "schema": "dkn.archive-governance.v0.1",
        "dkn_binding_hash": binding["dkn_binding_hash"],
        "publication_requires_explicit_external_authorization": True,
        "private_material_permitted": False,
        **BOUNDARY,
    }
    thr = build_thr_manifest(state=state, semantic=semantic, governance=governance)
    signing_body = {
        "schema": "dkn.archive-self-certificate-signing-body.v0.1",
        "public_version": "v0.1",
        "engineering_revision": engineering_revision,
        "state_manifest_hash": state["state_manifest_hash"],
        "thr_manifest_hash": thr["thr_manifest_hash"],
        "dkn_binding_hash": binding["dkn_binding_hash"],
    }
    if binding["status"] == "DECLARED_UNBOUND":
        require(private_key is None, "DKN_ARCHIVE_INVALID")
        status = "READY_FOR_EXTERNAL_DKN_CERTIFICATION"
        signature_hex = None
        signer_subject_id = None
    else:
        require(private_key is not None and passport is not None, "DKN_ARCHIVE_INVALID")
        checked_passport = verify_passport(passport)
        require(public_key_hex(private_key) == checked_passport["public_key_hex"],
                "DKN_IDENTITY_KEY_MISMATCH")
        status = "PASS_SELF_CERTIFIED"
        signature_hex = sign(private_key, CERT_DOMAIN + canonical_bytes(signing_body))
        signer_subject_id = checked_passport["subject_id"]
    cert_body = {
        "schema": "dkn.archive-self-certificate.v0.1",
        "signing_body": signing_body,
        "certificate_status": status,
        "signer_subject_id": signer_subject_id,
        "signature_algorithm": "Ed25519" if signature_hex is not None else None,
        "signature_hex": signature_hex,
        "transport_sha256_scope": "EXTERNAL_COMPLETE_ARCHIVE_BYTES",
        "publication_authorized": False,
        "independent_review_claimed": False,
        **BOUNDARY,
    }
    certificate = {**cert_body,
                   "certificate_hash": object_hash(cert_body, b"DKN_ARCHIVE_CERTIFICATE_V0.1\x00")}
    members = dict(payloads)
    members.update({
        META_FILES[0]: canonical_bytes(state),
        META_FILES[1]: canonical_bytes(thr),
        META_FILES[2]: canonical_bytes(binding),
        META_FILES[3]: canonical_bytes(certificate),
    })
    container_body = {
        "schema": "dkn.archive-container-manifest.v0.1",
        "scope": "ALL_ARCHIVE_MEMBERS_EXCEPT_THIS_MANIFEST",
        "members": _rows(members),
        "member_count": len(members),
    }
    members[MANIFEST] = canonical_bytes({
        **container_body,
        "container_manifest_hash": object_hash(
            container_body, b"DKN_ARCHIVE_CONTAINER_MANIFEST_V0.1\x00"),
    })
    return _zip_bytes(members)


def verify_portable_archive(raw: bytes) -> dict[str, Any]:
    require(type(raw) is bytes and len(raw) <= MAX_ARCHIVE_BYTES, "DKN_ARCHIVE_INVALID")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            paths = [info.filename for info in infos]
            require(len(paths) == len(set(paths)) and paths == sorted(paths),
                    "DKN_ARCHIVE_NOT_CANONICAL")
            require(all(info.compress_type == zipfile.ZIP_STORED
                        and info.date_time == (1980, 1, 1, 0, 0, 0)
                        and info.create_system == 3 for info in infos),
                    "DKN_ARCHIVE_NOT_CANONICAL")
            members = {path: archive.read(path) for path in paths}
    except DKNRefusal:
        raise
    except (zipfile.BadZipFile, KeyError, RuntimeError, OSError, ValueError) as error:
        raise DKNRefusal("DKN_ARCHIVE_INVALID", type(error).__name__) from error
    require(set(META_FILES).issubset(members) and MANIFEST in members,
            "DKN_ARCHIVE_MANIFEST_MISMATCH")
    for path, data in members.items():
        _portable_path(path)
        _secret_scan(path, data)
    container = strict_load_canonical(members[MANIFEST])
    container_body = exact_keys(container, {
        "schema", "scope", "members", "member_count", "container_manifest_hash",
    }, "DKN_ARCHIVE_MANIFEST_MISMATCH")
    require(container_body["schema"] == "dkn.archive-container-manifest.v0.1",
            "DKN_ARCHIVE_MANIFEST_MISMATCH")
    unsigned = {key: deepcopy(value) for key, value in container_body.items()
                if key != "container_manifest_hash"}
    require(container_body["container_manifest_hash"]
            == object_hash(unsigned, b"DKN_ARCHIVE_CONTAINER_MANIFEST_V0.1\x00"),
            "DKN_ARCHIVE_MANIFEST_MISMATCH")
    without_manifest = {key: value for key, value in members.items() if key != MANIFEST}
    require(container_body["members"] == _rows(without_manifest)
            and container_body["member_count"] == len(without_manifest),
            "DKN_ARCHIVE_MANIFEST_MISMATCH")
    state = strict_load_canonical(members[META_FILES[0]])
    thr = verify_thr_manifest(strict_load_canonical(members[META_FILES[1]]))
    binding = verify_dkn_binding(strict_load_canonical(members[META_FILES[2]]))
    certificate = strict_load_canonical(members[META_FILES[3]])
    payloads = {path: data for path, data in members.items()
                if path not in {*META_FILES, MANIFEST}}
    state_body = exact_keys(state, {
        "schema", "public_version", "engineering_revision", "scope", "members",
        "member_count", "logical_bytes", *BOUNDARY, "state_manifest_hash",
    }, "DKN_ARCHIVE_MANIFEST_MISMATCH")
    require(state_body["members"] == _rows(payloads)
            and state_body["member_count"] == len(payloads)
            and state_body["logical_bytes"] == sum(len(data) for data in payloads.values()),
            "DKN_ARCHIVE_MANIFEST_MISMATCH")
    state_unsigned = {key: deepcopy(value) for key, value in state.items()
                      if key != "state_manifest_hash"}
    require(state["state_manifest_hash"]
            == object_hash(state_unsigned, b"DKN_ARCHIVE_STATE_V0.1\x00")
            and thr["components"]["state"] == state
            and thr["components"]["governance"]["dkn_binding_hash"]
            == binding["dkn_binding_hash"], "DKN_ARCHIVE_MANIFEST_MISMATCH")
    cert = exact_keys(certificate, {
        "schema", "signing_body", "certificate_status", "signer_subject_id",
        "signature_algorithm", "signature_hex", "transport_sha256_scope",
        "publication_authorized", "independent_review_claimed", *BOUNDARY,
        "certificate_hash",
    }, "DKN_ARCHIVE_INVALID")
    cert_unsigned = {key: deepcopy(value) for key, value in cert.items()
                     if key != "certificate_hash"}
    require(cert["certificate_hash"]
            == object_hash(cert_unsigned, b"DKN_ARCHIVE_CERTIFICATE_V0.1\x00"),
            "DKN_ARCHIVE_INVALID")
    signing_body = cert["signing_body"]
    require(signing_body == {
        "schema": "dkn.archive-self-certificate-signing-body.v0.1",
        "public_version": "v0.1",
        "engineering_revision": state["engineering_revision"],
        "state_manifest_hash": state["state_manifest_hash"],
        "thr_manifest_hash": thr["thr_manifest_hash"],
        "dkn_binding_hash": binding["dkn_binding_hash"],
    }, "DKN_ARCHIVE_INVALID")
    if binding["status"] == "DECLARED_UNBOUND":
        require(cert["certificate_status"] == "READY_FOR_EXTERNAL_DKN_CERTIFICATION"
                and cert["signature_hex"] is None and cert["signer_subject_id"] is None,
                "DKN_ARCHIVE_INVALID")
    else:
        passport = verify_passport(binding["passport"])
        require(cert["certificate_status"] == "PASS_SELF_CERTIFIED"
                and cert["signer_subject_id"] == passport["subject_id"]
                and cert["signature_algorithm"] == "Ed25519", "DKN_ARCHIVE_INVALID")
        verify(passport["public_key_hex"], cert["signature_hex"],
               CERT_DOMAIN + canonical_bytes(signing_body))
    require(_zip_bytes(members) == raw, "DKN_ARCHIVE_NOT_CANONICAL")
    return {
        "schema": "dkn.archive-verification.v0.1",
        "status": "PASS",
        "transport_sha256": hashlib.sha256(raw).hexdigest(),
        "member_count": len(members),
        "state_manifest_hash": state["state_manifest_hash"],
        "thr_manifest_hash": thr["thr_manifest_hash"],
        "dkn_binding_hash": binding["dkn_binding_hash"],
        "certificate_hash": cert["certificate_hash"],
        "certificate_status": cert["certificate_status"],
        "private_material_found": False,
        **BOUNDARY,
    }

