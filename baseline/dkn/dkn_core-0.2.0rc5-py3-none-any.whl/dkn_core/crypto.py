"""Cryptographic profiles used by DKN Core."""

from __future__ import annotations

from blake3 import blake3
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from .canonical import hex_string
from .errors import DKNRefusal, require

NAMESPACE_HASH_ALGORITHM = "BLAKE3-256"
SIGNATURE_ALGORITHM = "Ed25519"

_P = 2**255 - 19
_D = (-121665 * pow(121666, _P - 2, _P)) % _P
_SQRT_M1 = pow(2, (_P - 1) // 4, _P)
_L = 2**252 + 27742317777372353535851937790883648493
_IDENTITY = (0, 1)


def _decode_point(encoded: bytes) -> tuple[int, int] | None:
    if len(encoded) != 32:
        return None
    value = int.from_bytes(encoded, "little")
    sign = (value >> 255) & 1
    y = value & ((1 << 255) - 1)
    if y >= _P:
        return None
    y2 = y * y % _P
    denominator = (_D * y2 + 1) % _P
    if denominator == 0:
        return None
    x2 = (y2 - 1) * pow(denominator, _P - 2, _P) % _P
    x = pow(x2, (_P + 3) // 8, _P)
    if x * x % _P != x2:
        x = x * _SQRT_M1 % _P
    if x * x % _P != x2 or (x == 0 and sign):
        return None
    if x & 1 != sign:
        x = _P - x
    return x, y


def _add(first: tuple[int, int], second: tuple[int, int]) -> tuple[int, int]:
    x1, y1 = first
    x2, y2 = second
    product = _D * x1 * x2 * y1 * y2 % _P
    x3 = (x1 * y2 + y1 * x2) * pow(1 + product, _P - 2, _P) % _P
    y3 = (y1 * y2 + x1 * x2) * pow(1 - product, _P - 2, _P) % _P
    return x3, y3


def _scalar(point: tuple[int, int], scalar: int) -> tuple[int, int]:
    result = _IDENTITY
    addend = point
    while scalar:
        if scalar & 1:
            result = _add(result, addend)
        addend = _add(addend, addend)
        scalar >>= 1
    return result


def public_key_bytes(public_key_hex: str) -> bytes:
    raw = bytes.fromhex(hex_string(public_key_hex, 64, "DKN_PUBLIC_KEY_INVALID"))
    point = _decode_point(raw)
    require(point is not None and point != _IDENTITY and _scalar(point, _L) == _IDENTITY,
            "DKN_PUBLIC_KEY_INVALID")
    return raw


def public_key_hex(private_key: Ed25519PrivateKey) -> str:
    return private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()


def blake3_hex(domain: bytes, data: bytes) -> str:
    require(type(domain) is bytes and domain.endswith(b"\x00"), "DKN_HASH_INVALID")
    return blake3(domain + data).hexdigest()


def mosaic_id(public_key_hex_value: str) -> str:
    """Legacy-compatible MosaicID: BLAKE3 over raw Ed25519 public-key bytes."""
    return blake3(public_key_bytes(public_key_hex_value)).hexdigest()


def dkn_subject_id(public_key_hex_value: str) -> str:
    digest = blake3_hex(b"DKN_SUBJECT_V0.1\x00", public_key_bytes(public_key_hex_value))
    return f"dknid:v0.1:b3:{digest}"


def sign(private_key: Ed25519PrivateKey, message: bytes) -> str:
    return private_key.sign(message).hex()


def verify(public_key_hex_value: str, signature_hex: str, message: bytes) -> None:
    raw_key = public_key_bytes(public_key_hex_value)
    signature = bytes.fromhex(hex_string(signature_hex, 128, "DKN_RECORD_SIGNATURE_INVALID"))
    try:
        Ed25519PublicKey.from_public_bytes(raw_key).verify(signature, message)
    except InvalidSignature as error:
        raise DKNRefusal("DKN_RECORD_SIGNATURE_INVALID") from error

